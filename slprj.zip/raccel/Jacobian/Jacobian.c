#include "Jacobian.h"
#include "Jacobian_types.h"
#include "rtwtypes.h"
#include <string.h>
#include "mwmathutil.h"
#include <stddef.h>
#include "Jacobian_private.h"
#include "coder_posix_time.h"
#include <stdlib.h>
#include "rt_logging_mmi.h"
#include "Jacobian_capi.h"
#include "Jacobian_dt.h"
extern void * CreateDiagnosticAsVoidPtr_wrapper ( const char * id , int nargs
, ... ) ; RTWExtModeInfo * gblRTWExtModeInfo = NULL ; void
raccelForceExtModeShutdown ( boolean_T extModeStartPktReceived ) { if ( !
extModeStartPktReceived ) { boolean_T stopRequested = false ;
rtExtModeWaitForStartPkt ( gblRTWExtModeInfo , 1 , & stopRequested ) ; }
rtExtModeShutdown ( 1 ) ; }
#include "slsv_diagnostic_codegen_c_api.h"
#include "slsa_sim_engine.h"
const int_T gblNumToFiles = 0 ; const int_T gblNumFrFiles = 0 ; const int_T
gblNumFrWksBlocks = 0 ;
#ifdef RSIM_WITH_SOLVER_MULTITASKING
boolean_T gbl_raccel_isMultitasking = 1 ;
#else
boolean_T gbl_raccel_isMultitasking = 0 ;
#endif
boolean_T gbl_raccel_tid01eq = 0 ; int_T gbl_raccel_NumST = 2 ; const char_T
* gbl_raccel_Version = "9.7 (R2022a) 13-Nov-2021" ; void
raccel_setup_MMIStateLog ( SimStruct * S ) {
#ifdef UseMMIDataLogging
rt_FillStateSigInfoFromMMI ( ssGetRTWLogInfo ( S ) , & ssGetErrorStatus ( S )
) ;
#else
UNUSED_PARAMETER ( S ) ;
#endif
} static DataMapInfo rt_dataMapInfo ; DataMapInfo * rt_dataMapInfoPtr = &
rt_dataMapInfo ; rtwCAPI_ModelMappingInfo * rt_modelMapInfoPtr = & (
rt_dataMapInfo . mmi ) ; const int_T gblNumRootInportBlks = 0 ; const int_T
gblNumModelInputs = 0 ; extern const char * gblInportFileName ; extern
rtInportTUtable * gblInportTUtables ; const int_T gblInportDataTypeIdx [ ] =
{ - 1 } ; const int_T gblInportDims [ ] = { - 1 } ; const int_T
gblInportComplex [ ] = { - 1 } ; const int_T gblInportInterpoFlag [ ] = { - 1
} ; const int_T gblInportContinuous [ ] = { - 1 } ; int_T enableFcnCallFlag [
] = { 1 , 1 } ; const char * raccelLoadInputsAndAperiodicHitTimes ( SimStruct
* S , const char * inportFileName , int * matFileFormat ) { return
rt_RAccelReadInportsMatFile ( S , inportFileName , matFileFormat ) ; }
#include "simstruc.h"
#include "fixedpoint.h"
#include "slsa_sim_engine.h"
#include "simtarget/slSimTgtSLExecSimBridge.h"
B rtB ; X rtX ; DW rtDW ; static SimStruct model_S ; SimStruct * const rtS =
& model_S ; static void gunzkbl0qg ( e2b0f4s35s * * pEmxArray , int32_T
numDimensions ) ; static void nm1vytfqlze ( gxcsgl11sl35 * pStruct ) ; static
void bbp43aslv1 ( naq1wbp3ki * * pEmxArray , int32_T numDimensions ) ; static
void nm1vytfqlzes ( gtd4jhsf2rw * pStruct ) ; static void m4davgb45z (
gtd4jhsf2rw pMatrix [ 11 ] ) ; static void cy4r1g1cm1 ( moo4o4s0qn * *
pEmxArray , int32_T numDimensions ) ; static void i4ptqqkvjj ( iyg0swfnbfoc *
pStruct ) ; static void dlcycob2hs ( iyg0swfnbfoc pMatrix [ 11 ] ) ; static
void m4davgb45zz ( gxcsgl11sl35 pMatrix [ 10 ] ) ; static void nm1vytfqlz (
kp1en3mw3xln * pStruct ) ; static void nm1vytfqlzest ( l2t3f2z1w3 * pStruct )
; static void akv0qbbtrt ( iyg0swfnbfoc pMatrix [ 10 ] ) ; static void
m4davgb45zzo ( gxcsgl11sl35 pMatrix [ 5 ] ) ; static void m4davgb45zzop (
gtd4jhsf2rw pMatrix [ 6 ] ) ; static void p1fxj0s5kq ( iyg0swfnbfoc pMatrix [
6 ] ) ; static void nm1vytfqlzestm ( itgfp4rmev * pStruct ) ; static void
oztqtqxwuh ( iabjthfi1p * pStruct ) ; static void l353migxc4 ( gh04rvpx0o *
pStruct ) ; static void ac0ugu5nlz ( e2b0f4s35s * emxArray , int32_T oldNumel
) ; static void b0l0vcvht3 ( e2b0f4s35s * * pEmxArray ) ; static void
ier0p3wwtw ( moo4o4s0qn * emxArray , int32_T oldNumel ) ; static void
keuyu41tq3 ( naq1wbp3ki * emxArray , int32_T oldNumel ) ; static void
mepjkxapz0 ( naq1wbp3ki * * pEmxArray ) ; static gtd4jhsf2rw * aydneur4h5so (
gtd4jhsf2rw * obj , real_T maxElements ) ; static gxcsgl11sl35 * ovxlwwg003 (
gxcsgl11sl35 * obj , gtd4jhsf2rw * iobj_0 , iyg0swfnbfoc * iobj_1 ) ; static
gxcsgl11sl35 * pbim0sdm1g ( gxcsgl11sl35 * obj , gtd4jhsf2rw * iobj_0 ,
iyg0swfnbfoc * iobj_1 ) ; static gxcsgl11sl35 * gd1a2d5whe ( gxcsgl11sl35 *
obj , gtd4jhsf2rw * iobj_0 , iyg0swfnbfoc * iobj_1 ) ; static gxcsgl11sl35 *
oswu44nkbe ( gxcsgl11sl35 * obj , gtd4jhsf2rw * iobj_0 , iyg0swfnbfoc *
iobj_1 ) ; static gxcsgl11sl35 * avigwta1rk ( gxcsgl11sl35 * obj ,
gtd4jhsf2rw * iobj_0 , iyg0swfnbfoc * iobj_1 ) ; static gxcsgl11sl35 *
fu3whh3mfb ( gxcsgl11sl35 * obj , gtd4jhsf2rw * iobj_0 , iyg0swfnbfoc *
iobj_1 ) ; static gxcsgl11sl35 * hi1fv3qgyp ( gxcsgl11sl35 * obj ,
gtd4jhsf2rw * iobj_0 , iyg0swfnbfoc * iobj_1 ) ; static gxcsgl11sl35 *
hgxe0mqtnx ( gxcsgl11sl35 * obj , gtd4jhsf2rw * iobj_0 , iyg0swfnbfoc *
iobj_1 ) ; static iyg0swfnbfoc * j32lrgnqkz ( iyg0swfnbfoc * obj , const
e2b0f4s35s * jname ) ; static void jywdovubw0d ( uint32_T mt [ 625 ] ,
uint32_T u [ 2 ] ) ; static boolean_T isihtjjmsz ( const uint32_T mt [ 625 ]
) ; static void civj2dafm1 ( real_T r [ 5 ] ) ; static boolean_T cduyt2xdp0 (
const e2b0f4s35s * a , const e2b0f4s35s * b ) ; static real_T lgt1s4cluf (
itgfp4rmev * obj , const e2b0f4s35s * bodyname ) ; static void njzmd0hlqd (
moo4o4s0qn * * pEmxArray ) ; static gxcsgl11sl35 * el2xo0x5qy ( gxcsgl11sl35
* obj , gtd4jhsf2rw * iobj_0 , iyg0swfnbfoc * iobj_1 , gxcsgl11sl35 * iobj_2
) ; static void hahijoalwi ( itgfp4rmev * obj , gxcsgl11sl35 * bodyin , const
e2b0f4s35s * parentName , iyg0swfnbfoc * iobj_0 , gxcsgl11sl35 * iobj_1 ,
gtd4jhsf2rw * iobj_2 ) ; static iabjthfi1p * clllcb3tqp ( iabjthfi1p * obj ,
kp1en3mw3xln * varargin_2 ) ; static void g1slahjfob0o ( gh04rvpx0o * obj ) ;
static void ljrzulvsuz ( iyg0swfnbf * pStruct ) ; static void azpme0b1ng (
gtd4jhsf2r * pStruct ) ; static void lt1ngaczuv ( gxcsgl11sl * pStruct ) ;
static void m4davgb45zzoph ( gxcsgl11sl pMatrix [ 10 ] ) ; static void
nm1vytfqlzestmw ( kp1en3mw3x * pStruct ) ; static void l353migxc4h (
exm4lytzjq * pStruct ) ; static gtd4jhsf2r * aydneur4h5 ( gtd4jhsf2r * obj )
; static gxcsgl11sl * mhyfpzbtel ( gxcsgl11sl * obj ) ; static void
dpajaj4gpx ( kp1en3mw3x * obj , gxcsgl11sl * iobj_0 ) ; static gxcsgl11sl *
mhyfpzbtelc ( gxcsgl11sl * obj ) ; static gxcsgl11sl * mhyfpzbtelc0 (
gxcsgl11sl * obj ) ; static gxcsgl11sl * mhyfpzbtelc0w ( gxcsgl11sl * obj ) ;
static void g1slahjfob ( exm4lytzjq * obj ) ; static void mqbow5axkl (
iyg0swfnbfo * pStruct ) ; static void lqdzki1nok ( gxcsgl11sl3 * pStruct ) ;
static void m4davgb45zzophb ( gxcsgl11sl3 pMatrix [ 10 ] ) ; static void
lstqfey1q1 ( kp1en3mw3xl * pStruct ) ; static void l353migxc4hk ( gsvdge1jib
* pStruct ) ; static void dpajaj4gpxk ( kp1en3mw3xl * obj , gxcsgl11sl3 *
iobj_0 ) ; static gxcsgl11sl3 * mhyfpzbtelc0wa ( gxcsgl11sl3 * obj ) ; static
gxcsgl11sl3 * mhyfpzbtelc0waz ( gxcsgl11sl3 * obj ) ; static void g1slahjfob0
( gsvdge1jib * obj ) ; static void ntmkpsyod5y ( const real_T pp_breaks [ 9 ]
, const real_T pp_coefs [ 96 ] , real_T x , real_T v [ 3 ] ) ; static void
jkqy2d3rp1 ( itgfp4rmev * obj , moo4o4s0qn * limits ) ; static void
lscqsvg2j5 ( ksusmq01tx * * pEmxArray , int32_T numDimensions ) ; static void
nmpbytu0qq ( ksusmq01tx * emxArray , int32_T oldNumel ) ; static void
adwdjvxler ( ksusmq01tx * * pEmxArray ) ; static void ku0om0mcw0 ( fgmfslti0b
* * pEmxArray , int32_T numDimensions ) ; static void pvxko1qdkz0yx (
boolean_T in1 [ 5 ] , const real_T in2 [ 5 ] , const moo4o4s0qn * in3 ) ;
static void pvxko1qdkz0y ( boolean_T in1 [ 5 ] , const real_T in2 [ 5 ] ,
const moo4o4s0qn * in3 ) ; static void aeyt1tjqck ( const boolean_T x [ 5 ] ,
int32_T i_data [ ] , int32_T * i_size ) ; static void or5i2fegiq ( real_T *
tstart_tv_sec , real_T * tstart_tv_nsec ) ; static void l32nija4f2 (
itgfp4rmev * obj , gxcsgl11sl35 * body , moo4o4s0qn * indices ) ; static void
lkcdsp2izk ( itgfp4rmev * obj , gxcsgl11sl35 * body1 , gxcsgl11sl35 * body2 ,
moo4o4s0qn * indices ) ; static void ocuijkr1g1jm ( const iyg0swfnbfoc * obj
, real_T ax [ 3 ] ) ; static void gxlkpqr51s ( real_T varargin_1 , real_T
varargin_2 , real_T varargin_3 , real_T varargin_4 , real_T varargin_5 ,
real_T varargin_6 , real_T varargin_7 , real_T varargin_8 , real_T varargin_9
, real_T y [ 9 ] ) ; static void knqlderc2u ( const real_T A [ 36 ] , const
moo4o4s0qn * B_p , moo4o4s0qn * C ) ; static void kyxgrilagz ( itgfp4rmev *
obj , const real_T qv [ 5 ] , const e2b0f4s35s * body1Name , real_T T_data [
] , int32_T T_size [ 2 ] , moo4o4s0qn * Jac ) ; static creal_T a0pew1ahvs (
const creal_T x ) ; static real_T irgxwzkbnq ( int32_T n , const real_T x [ 9
] , int32_T ix0 ) ; static real_T btgcf4cqcl ( int32_T n , const real_T x [ 9
] , int32_T ix0 , const real_T y [ 9 ] , int32_T iy0 ) ; static void
konv2omx5i ( int32_T n , real_T a , int32_T ix0 , const real_T y [ 9 ] ,
int32_T iy0 , real_T b_y [ 9 ] ) ; static real_T irgxwzkbnql ( const real_T x
[ 3 ] , int32_T ix0 ) ; static void konv2omx5it1w ( int32_T n , real_T a ,
const real_T x [ 9 ] , int32_T ix0 , real_T y [ 3 ] , int32_T iy0 ) ; static
void konv2omx5it1 ( int32_T n , real_T a , const real_T x [ 3 ] , int32_T ix0
, const real_T y [ 9 ] , int32_T iy0 , real_T b_y [ 9 ] ) ; static void
exvzrfriqd ( const real_T x [ 9 ] , int32_T ix0 , int32_T iy0 , real_T b_x [
9 ] ) ; static void bmjikbt2rd ( real_T a , real_T b , real_T * b_a , real_T
* b_b , real_T * c , real_T * s ) ; static void nfijn1ftpq ( const real_T x [
9 ] , int32_T ix0 , int32_T iy0 , real_T c , real_T s , real_T b_x [ 9 ] ) ;
static void cuphw2yuqi ( const real_T A [ 9 ] , real_T U [ 9 ] , real_T s [ 3
] , real_T V [ 9 ] ) ; static void d3njpynb5n ( const real_T Td [ 16 ] ,
const real_T T_data [ ] , const int32_T T_size [ 2 ] , real_T errorvec [ 6 ]
) ; static void knqlderc2umb ( const real_T A [ 6 ] , const moo4o4s0qn * B_i
, moo4o4s0qn * C ) ; static void mp1kcw5ibf ( itipyws4dn * * pEmxArray ,
int32_T numDimensions ) ; static real_T b2cutvohzkb ( const real_T x [ 6 ] )
; static void h2drfin2nju ( moo4o4s0qn * in1 , const moo4o4s0qn * in2 ) ;
static void iue3n2dlds ( itipyws4dn * emxArray , int32_T oldNumel ) ; static
real_T b43ytoj3db ( real_T tstart_tv_sec , real_T tstart_tv_nsec ) ; static
void iah2jhz5bn ( const real_T A [ 25 ] , const moo4o4s0qn * B_m , real_T
Y_data [ ] , int32_T * Y_size ) ; static void pvxko1qdkz0 ( real_T in1_data [
] , int32_T * in1_size , const moo4o4s0qn * in2 , real_T in3 , const real_T
in4 [ 25 ] , const moo4o4s0qn * in5 ) ; static void fkw0vbtdcb ( const
moo4o4s0qn * a , const real_T b [ 5 ] , real_T c [ 5 ] ) ; static void
cwpeqyyhqy ( const moo4o4s0qn * a , const real_T b [ 5 ] , real_T c [ 5 ] ) ;
static void b1xdicvyah ( itipyws4dn * * pEmxArray ) ; static void jfs5omen4s
( pmprofizlh * obj , real_T xSol [ 5 ] , iu3zpbmgcw * exitFlag , real_T * en
, real_T * iter ) ; static boolean_T himifevlz1 ( const itipyws4dn * x ) ;
static void h3f52mmr1n ( const real_T varargin_1 [ 2 ] , moo4o4s0qn * r ) ;
static void h2drfin2nj ( moo4o4s0qn * in1 , const moo4o4s0qn * in2 ) ; static
void gvjwo0dspq ( moo4o4s0qn * in1 , const moo4o4s0qn * in2 ) ; static void
civj2dafm1t ( real_T varargin_1 , moo4o4s0qn * r ) ; static void pvxko1qdkz (
moo4o4s0qn * in1 , const moo4o4s0qn * in2 , const moo4o4s0qn * in3 ) ; static
void bqde2t5zai ( pmprofizlh * obj , const real_T seed [ 5 ] , real_T xSol [
5 ] , real_T * solutionInfo_Iterations , real_T * solutionInfo_RRAttempts ,
real_T * solutionInfo_Error , real_T * solutionInfo_ExitFlag , char_T
solutionInfo_Status_data [ ] , int32_T solutionInfo_Status_size [ 2 ] ) ;
static void jw4vvjgwpp ( iidpvf4tee * * pEmxArray , int32_T numDimensions ) ;
static void f4i2s4lxoo ( iidpvf4tee * emxArray , int32_T oldNumel ) ; static
void g0pzyoia5l ( iidpvf4tee * * pEmxArray ) ; static void muadc51of1 (
izqiyoa4ub * * pEmxArray , int32_T numDimensions ) ; static void ghsky5aveh (
izqiyoa4ub * emxArray , int32_T oldNumel ) ; static void npfzq14tu1 (
izqiyoa4ub * * pEmxArray ) ; static void g30rxyn4gkf ( iabjthfi1p * obj ,
real_T initialGuess [ 5 ] , real_T * solutionInfo_Iterations , real_T *
solutionInfo_NumRandomRestarts , real_T * solutionInfo_PoseErrorNorm , real_T
* solutionInfo_ExitFlag , char_T solutionInfo_Status_data [ ] , int32_T
solutionInfo_Status_size [ 2 ] ) ; static void e3cpkwfxpp ( iabjthfi1p * obj
, const real_T tform [ 16 ] , const real_T weights [ 6 ] , const real_T
initialGuess [ 5 ] , real_T QSol [ 5 ] ) ; static void k5uooz0d10 (
fgmfslti0b * emxArray , int32_T oldNumel ) ; static void ocuijkr1g1 ( const
iyg0swfnbf * obj , real_T ax [ 3 ] ) ; static void evz05l0h04 ( kp1en3mw3x *
obj , const real_T qvec [ 5 ] , fgmfslti0b * Ttree ) ; static void
ocuijkr1g1j ( const iyg0swfnbfo * obj , real_T ax [ 3 ] ) ; static void
nzox4rsktc ( fgmfslti0b * * pEmxArray ) ; static void juzhbp4evd (
gxcsgl11sl35 * pStruct ) ; static void juzhbp4evdmo ( gtd4jhsf2rw * pStruct )
; static void khxkdsmcld ( gtd4jhsf2rw pMatrix [ 11 ] ) ; static void
aribxozslp ( iyg0swfnbfoc * pStruct ) ; static void bid1osq2cg ( iyg0swfnbfoc
pMatrix [ 11 ] ) ; static void khxkdsmcldw ( gxcsgl11sl35 pMatrix [ 10 ] ) ;
static void juzhbp4evdm ( kp1en3mw3xln * pStruct ) ; static void
juzhbp4evdmo5 ( l2t3f2z1w3 * pStruct ) ; static void gbw5gf1tdg (
iyg0swfnbfoc pMatrix [ 10 ] ) ; static void khxkdsmcldwh ( gxcsgl11sl35
pMatrix [ 5 ] ) ; static void khxkdsmcldwho ( gtd4jhsf2rw pMatrix [ 6 ] ) ;
static void a0paw2qkcg ( iyg0swfnbfoc pMatrix [ 6 ] ) ; static void
juzhbp4evdmo5g ( itgfp4rmev * pStruct ) ; static void ahaxxg3t2t ( iabjthfi1p
* pStruct ) ; static void oh1nyigqv2 ( gh04rvpx0o * pStruct ) ; static void
nxlivroytl ( iyg0swfnbf * pStruct ) ; static void gk3x1bjsmm ( gtd4jhsf2r *
pStruct ) ; static void juzhbp4evdmo5gl ( gxcsgl11sl * pStruct ) ; static
void khxkdsmcldwhoy ( gxcsgl11sl pMatrix [ 10 ] ) ; static void fmoeizylmr (
kp1en3mw3x * pStruct ) ; static void oh1nyigqv24 ( exm4lytzjq * pStruct ) ;
static void os2w0ymkwg ( iyg0swfnbfo * pStruct ) ; static void j4fdhx0u05 (
gxcsgl11sl3 * pStruct ) ; static void khxkdsmcldwhoyw ( gxcsgl11sl3 pMatrix [
10 ] ) ; static void olsrt3fqep ( kp1en3mw3xl * pStruct ) ; static void
oh1nyigqv241 ( gsvdge1jib * pStruct ) ; int32_T div_s32 ( int32_T numerator ,
int32_T denominator ) { int32_T quotient ; uint32_T tempAbsQuotient ; if (
denominator == 0 ) { quotient = numerator >= 0 ? MAX_int32_T : MIN_int32_T ;
} else { tempAbsQuotient = ( numerator < 0 ? ~ ( uint32_T ) numerator + 1U :
( uint32_T ) numerator ) / ( denominator < 0 ? ~ ( uint32_T ) denominator +
1U : ( uint32_T ) denominator ) ; quotient = ( numerator < 0 ) != (
denominator < 0 ) ? - ( int32_T ) tempAbsQuotient : ( int32_T )
tempAbsQuotient ; } return quotient ; } static void gunzkbl0qg ( e2b0f4s35s *
* pEmxArray , int32_T numDimensions ) { e2b0f4s35s * emxArray ; int32_T i ; *
pEmxArray = ( e2b0f4s35s * ) malloc ( sizeof ( e2b0f4s35s ) ) ; emxArray = *
pEmxArray ; emxArray -> data = ( char_T * ) NULL ; emxArray -> numDimensions
= numDimensions ; emxArray -> size = ( int32_T * ) malloc ( sizeof ( int32_T
) * numDimensions ) ; emxArray -> allocatedSize = 0 ; emxArray -> canFreeData
= true ; for ( i = 0 ; i < numDimensions ; i ++ ) { emxArray -> size [ i ] =
0 ; } } static void nm1vytfqlze ( gxcsgl11sl35 * pStruct ) { gunzkbl0qg ( &
pStruct -> NameInternal , 2 ) ; } static void bbp43aslv1 ( naq1wbp3ki * *
pEmxArray , int32_T numDimensions ) { naq1wbp3ki * emxArray ; int32_T i ; *
pEmxArray = ( naq1wbp3ki * ) malloc ( sizeof ( naq1wbp3ki ) ) ; emxArray = *
pEmxArray ; emxArray -> data = ( mqyxc3drwd * * ) NULL ; emxArray ->
numDimensions = numDimensions ; emxArray -> size = ( int32_T * ) malloc (
sizeof ( int32_T ) * numDimensions ) ; emxArray -> allocatedSize = 0 ;
emxArray -> canFreeData = true ; for ( i = 0 ; i < numDimensions ; i ++ ) {
emxArray -> size [ i ] = 0 ; } } static void nm1vytfqlzes ( gtd4jhsf2rw *
pStruct ) { bbp43aslv1 ( & pStruct -> CollisionGeometries , 2 ) ; } static
void m4davgb45z ( gtd4jhsf2rw pMatrix [ 11 ] ) { int32_T i ; for ( i = 0 ; i
< 11 ; i ++ ) { nm1vytfqlzes ( & pMatrix [ i ] ) ; } } static void cy4r1g1cm1
( moo4o4s0qn * * pEmxArray , int32_T numDimensions ) { moo4o4s0qn * emxArray
; int32_T i ; * pEmxArray = ( moo4o4s0qn * ) malloc ( sizeof ( moo4o4s0qn ) )
; emxArray = * pEmxArray ; emxArray -> data = ( real_T * ) NULL ; emxArray ->
numDimensions = numDimensions ; emxArray -> size = ( int32_T * ) malloc (
sizeof ( int32_T ) * numDimensions ) ; emxArray -> allocatedSize = 0 ;
emxArray -> canFreeData = true ; for ( i = 0 ; i < numDimensions ; i ++ ) {
emxArray -> size [ i ] = 0 ; } } static void i4ptqqkvjj ( iyg0swfnbfoc *
pStruct ) { gunzkbl0qg ( & pStruct -> Type , 2 ) ; cy4r1g1cm1 ( & pStruct ->
MotionSubspace , 2 ) ; gunzkbl0qg ( & pStruct -> NameInternal , 2 ) ;
cy4r1g1cm1 ( & pStruct -> PositionLimitsInternal , 2 ) ; cy4r1g1cm1 ( &
pStruct -> HomePositionInternal , 1 ) ; } static void dlcycob2hs (
iyg0swfnbfoc pMatrix [ 11 ] ) { int32_T i ; for ( i = 0 ; i < 11 ; i ++ ) {
i4ptqqkvjj ( & pMatrix [ i ] ) ; } } static void m4davgb45zz ( gxcsgl11sl35
pMatrix [ 10 ] ) { int32_T i ; for ( i = 0 ; i < 10 ; i ++ ) { nm1vytfqlze (
& pMatrix [ i ] ) ; } } static void nm1vytfqlz ( kp1en3mw3xln * pStruct ) {
nm1vytfqlze ( & pStruct -> Base ) ; m4davgb45z ( pStruct -> _pobj0 ) ;
dlcycob2hs ( pStruct -> _pobj1 ) ; m4davgb45zz ( pStruct -> _pobj2 ) ; }
static void nm1vytfqlzest ( l2t3f2z1w3 * pStruct ) { cy4r1g1cm1 ( & pStruct
-> Limits , 2 ) ; gunzkbl0qg ( & pStruct -> BodyName , 2 ) ; cy4r1g1cm1 ( &
pStruct -> ErrTemp , 1 ) ; cy4r1g1cm1 ( & pStruct -> GradTemp , 1 ) ; }
static void akv0qbbtrt ( iyg0swfnbfoc pMatrix [ 10 ] ) { int32_T i ; for ( i
= 0 ; i < 10 ; i ++ ) { i4ptqqkvjj ( & pMatrix [ i ] ) ; } } static void
m4davgb45zzo ( gxcsgl11sl35 pMatrix [ 5 ] ) { int32_T i ; for ( i = 0 ; i < 5
; i ++ ) { nm1vytfqlze ( & pMatrix [ i ] ) ; } } static void m4davgb45zzop (
gtd4jhsf2rw pMatrix [ 6 ] ) { int32_T i ; for ( i = 0 ; i < 6 ; i ++ ) {
nm1vytfqlzes ( & pMatrix [ i ] ) ; } } static void p1fxj0s5kq ( iyg0swfnbfoc
pMatrix [ 6 ] ) { int32_T i ; for ( i = 0 ; i < 6 ; i ++ ) { i4ptqqkvjj ( &
pMatrix [ i ] ) ; } } static void nm1vytfqlzestm ( itgfp4rmev * pStruct ) {
nm1vytfqlze ( & pStruct -> Base ) ; m4davgb45zzo ( pStruct -> _pobj0 ) ;
m4davgb45zzop ( pStruct -> _pobj1 ) ; p1fxj0s5kq ( pStruct -> _pobj2 ) ; }
static void oztqtqxwuh ( iabjthfi1p * pStruct ) { cy4r1g1cm1 ( & pStruct ->
Limits , 2 ) ; nm1vytfqlzest ( & pStruct -> _pobj0 ) ; akv0qbbtrt ( pStruct
-> _pobj1 ) ; m4davgb45zzo ( pStruct -> _pobj2 ) ; m4davgb45z ( pStruct ->
_pobj3 ) ; nm1vytfqlzestm ( & pStruct -> _pobj4 ) ; } static void l353migxc4
( gh04rvpx0o * pStruct ) { nm1vytfqlz ( & pStruct -> TreeInternal ) ;
oztqtqxwuh ( & pStruct -> IKInternal ) ; } static void ac0ugu5nlz (
e2b0f4s35s * emxArray , int32_T oldNumel ) { int32_T i ; int32_T newNumel ;
void * newData ; if ( oldNumel < 0 ) { oldNumel = 0 ; } newNumel = 1 ; for (
i = 0 ; i < emxArray -> numDimensions ; i ++ ) { newNumel *= emxArray -> size
[ i ] ; } if ( newNumel > emxArray -> allocatedSize ) { i = emxArray ->
allocatedSize ; if ( i < 16 ) { i = 16 ; } while ( i < newNumel ) { if ( i >
1073741823 ) { i = MAX_int32_T ; } else { i <<= 1 ; } } newData = calloc ( (
uint32_T ) i , sizeof ( char_T ) ) ; if ( emxArray -> data != NULL ) { memcpy
( newData , emxArray -> data , sizeof ( char_T ) * oldNumel ) ; if ( emxArray
-> canFreeData ) { free ( emxArray -> data ) ; } } emxArray -> data = (
char_T * ) newData ; emxArray -> allocatedSize = i ; emxArray -> canFreeData
= true ; } } static void b0l0vcvht3 ( e2b0f4s35s * * pEmxArray ) { if ( *
pEmxArray != ( e2b0f4s35s * ) NULL ) { if ( ( ( * pEmxArray ) -> data != (
char_T * ) NULL ) && ( * pEmxArray ) -> canFreeData ) { free ( ( * pEmxArray
) -> data ) ; } free ( ( * pEmxArray ) -> size ) ; free ( * pEmxArray ) ; *
pEmxArray = ( e2b0f4s35s * ) NULL ; } } static void ier0p3wwtw ( moo4o4s0qn *
emxArray , int32_T oldNumel ) { int32_T i ; int32_T newNumel ; void * newData
; if ( oldNumel < 0 ) { oldNumel = 0 ; } newNumel = 1 ; for ( i = 0 ; i <
emxArray -> numDimensions ; i ++ ) { newNumel *= emxArray -> size [ i ] ; }
if ( newNumel > emxArray -> allocatedSize ) { i = emxArray -> allocatedSize ;
if ( i < 16 ) { i = 16 ; } while ( i < newNumel ) { if ( i > 1073741823 ) { i
= MAX_int32_T ; } else { i <<= 1 ; } } newData = calloc ( ( uint32_T ) i ,
sizeof ( real_T ) ) ; if ( emxArray -> data != NULL ) { memcpy ( newData ,
emxArray -> data , sizeof ( real_T ) * oldNumel ) ; if ( emxArray ->
canFreeData ) { free ( emxArray -> data ) ; } } emxArray -> data = ( real_T *
) newData ; emxArray -> allocatedSize = i ; emxArray -> canFreeData = true ;
} } static void keuyu41tq3 ( naq1wbp3ki * emxArray , int32_T oldNumel ) {
int32_T i ; int32_T newNumel ; void * newData ; if ( oldNumel < 0 ) {
oldNumel = 0 ; } newNumel = 1 ; for ( i = 0 ; i < emxArray -> numDimensions ;
i ++ ) { newNumel *= emxArray -> size [ i ] ; } if ( newNumel > emxArray ->
allocatedSize ) { i = emxArray -> allocatedSize ; if ( i < 16 ) { i = 16 ; }
while ( i < newNumel ) { if ( i > 1073741823 ) { i = MAX_int32_T ; } else { i
<<= 1 ; } } newData = calloc ( ( uint32_T ) i , sizeof ( mqyxc3drwd * ) ) ;
if ( emxArray -> data != NULL ) { memcpy ( newData , ( void * ) emxArray ->
data , sizeof ( mqyxc3drwd * ) * oldNumel ) ; if ( emxArray -> canFreeData )
{ free ( ( void * ) emxArray -> data ) ; } } emxArray -> data = ( mqyxc3drwd
* * ) newData ; emxArray -> allocatedSize = i ; emxArray -> canFreeData =
true ; } } static void mepjkxapz0 ( naq1wbp3ki * * pEmxArray ) { if ( *
pEmxArray != ( naq1wbp3ki * ) NULL ) { if ( ( ( * pEmxArray ) -> data != (
mqyxc3drwd * * ) NULL ) && ( * pEmxArray ) -> canFreeData ) { free ( ( void *
) ( * pEmxArray ) -> data ) ; } free ( ( * pEmxArray ) -> size ) ; free ( *
pEmxArray ) ; * pEmxArray = ( naq1wbp3ki * ) NULL ; } } static gtd4jhsf2rw *
aydneur4h5so ( gtd4jhsf2rw * obj , real_T maxElements ) { void *
defaultCollisionObj_GeometryInternal ; gtd4jhsf2rw * b_obj ; mqyxc3drwd *
obj_p ; naq1wbp3ki * e ; real_T c ; int32_T b_i ; int32_T d ; bbp43aslv1 ( &
e , 2 ) ; obj -> Size = 0.0 ; b_obj = obj ; obj -> MaxElements = maxElements
; b_i = e -> size [ 0 ] * e -> size [ 1 ] ; e -> size [ 1 ] = ( int32_T ) obj
-> MaxElements ; keuyu41tq3 ( e , b_i ) ; b_i = obj -> CollisionGeometries ->
size [ 0 ] * obj -> CollisionGeometries -> size [ 1 ] ; obj ->
CollisionGeometries -> size [ 0 ] = 1 ; obj -> CollisionGeometries -> size [
1 ] = e -> size [ 1 ] ; keuyu41tq3 ( obj -> CollisionGeometries , b_i ) ;
defaultCollisionObj_GeometryInternal = 0 ; obj_p = & obj -> _pobj0 ; obj ->
_pobj0 . CollisionPrimitive = defaultCollisionObj_GeometryInternal ; obj ->
_pobj0 . matlabCodegenIsDeleted = false ; c = obj -> MaxElements ; d = (
int32_T ) c - 1 ; mepjkxapz0 ( & e ) ; for ( b_i = 0 ; b_i <= d ; b_i ++ ) {
obj -> CollisionGeometries -> data [ b_i ] = obj_p ; } return b_obj ; }
static gxcsgl11sl35 * ovxlwwg003 ( gxcsgl11sl35 * obj , gtd4jhsf2rw * iobj_0
, iyg0swfnbfoc * iobj_1 ) { e2b0f4s35s * switch_expression ; gxcsgl11sl35 *
b_obj ; real_T poslim_data [ 12 ] ; int32_T b_kstr ; int32_T loop_ub ; char_T
b_p [ 9 ] ; char_T b [ 8 ] ; int8_T msubspace_data [ 36 ] ; int8_T b_I [ 9 ]
; int8_T tmp [ 6 ] ; boolean_T b_bool ; static const char_T tmp_p [ 10 ] = {
'd' , 'u' , 'm' , 'm' , 'y' , 'b' , 'o' , 'd' , 'y' , '1' } ; static const
int8_T tmp_e [ 16 ] = { 1 , 0 , 0 , 0 , 0 , 1 , 0 , 0 , 0 , 0 , 1 , 0 , 0 , 0
, 0 , 1 } ; static const char_T tmp_i [ 14 ] = { 'd' , 'u' , 'm' , 'm' , 'y'
, 'b' , 'o' , 'd' , 'y' , '1' , '_' , 'j' , 'n' , 't' } ; static const char_T
tmp_m [ 5 ] = { 'f' , 'i' , 'x' , 'e' , 'd' } ; static const char_T tmp_g [ 8
] = { 'r' , 'e' , 'v' , 'o' , 'l' , 'u' , 't' , 'e' } ; static const char_T
tmp_j [ 9 ] = { 'p' , 'r' , 'i' , 's' , 'm' , 'a' , 't' , 'i' , 'c' } ;
int32_T exitg1 ; b_obj = obj ; b_kstr = obj -> NameInternal -> size [ 0 ] *
obj -> NameInternal -> size [ 1 ] ; obj -> NameInternal -> size [ 0 ] = 1 ;
obj -> NameInternal -> size [ 1 ] = 10 ; ac0ugu5nlz ( obj -> NameInternal ,
b_kstr ) ; for ( b_kstr = 0 ; b_kstr < 10 ; b_kstr ++ ) { obj -> NameInternal
-> data [ b_kstr ] = tmp_p [ b_kstr ] ; } iobj_1 -> InTree = false ; for (
b_kstr = 0 ; b_kstr < 16 ; b_kstr ++ ) { iobj_1 -> JointToParentTransform [
b_kstr ] = tmp_e [ b_kstr ] ; } for ( b_kstr = 0 ; b_kstr < 16 ; b_kstr ++ )
{ iobj_1 -> ChildToJointTransform [ b_kstr ] = tmp_e [ b_kstr ] ; } b_kstr =
iobj_1 -> NameInternal -> size [ 0 ] * iobj_1 -> NameInternal -> size [ 1 ] ;
iobj_1 -> NameInternal -> size [ 0 ] = 1 ; iobj_1 -> NameInternal -> size [ 1
] = 14 ; ac0ugu5nlz ( iobj_1 -> NameInternal , b_kstr ) ; for ( b_kstr = 0 ;
b_kstr < 14 ; b_kstr ++ ) { iobj_1 -> NameInternal -> data [ b_kstr ] = tmp_i
[ b_kstr ] ; } b_kstr = iobj_1 -> Type -> size [ 0 ] * iobj_1 -> Type -> size
[ 1 ] ; iobj_1 -> Type -> size [ 0 ] = 1 ; iobj_1 -> Type -> size [ 1 ] = 5 ;
ac0ugu5nlz ( iobj_1 -> Type , b_kstr ) ; for ( b_kstr = 0 ; b_kstr < 5 ;
b_kstr ++ ) { iobj_1 -> Type -> data [ b_kstr ] = tmp_m [ b_kstr ] ; }
gunzkbl0qg ( & switch_expression , 2 ) ; b_kstr = switch_expression -> size [
0 ] * switch_expression -> size [ 1 ] ; switch_expression -> size [ 0 ] = 1 ;
switch_expression -> size [ 1 ] = iobj_1 -> Type -> size [ 1 ] ; ac0ugu5nlz (
switch_expression , b_kstr ) ; loop_ub = iobj_1 -> Type -> size [ 1 ] - 1 ;
for ( b_kstr = 0 ; b_kstr <= loop_ub ; b_kstr ++ ) { switch_expression ->
data [ b_kstr ] = iobj_1 -> Type -> data [ b_kstr ] ; } for ( b_kstr = 0 ;
b_kstr < 8 ; b_kstr ++ ) { b [ b_kstr ] = tmp_g [ b_kstr ] ; } b_bool = false
; if ( switch_expression -> size [ 1 ] != 8 ) { } else { b_kstr = 1 ; do {
exitg1 = 0 ; if ( b_kstr - 1 < 8 ) { if ( switch_expression -> data [ b_kstr
- 1 ] != b [ b_kstr - 1 ] ) { exitg1 = 1 ; } else { b_kstr ++ ; } } else {
b_bool = true ; exitg1 = 1 ; } } while ( exitg1 == 0 ) ; } if ( b_bool ) {
b_kstr = 0 ; } else { for ( b_kstr = 0 ; b_kstr < 9 ; b_kstr ++ ) { b_p [
b_kstr ] = tmp_j [ b_kstr ] ; } if ( switch_expression -> size [ 1 ] != 9 ) {
} else { b_kstr = 1 ; do { exitg1 = 0 ; if ( b_kstr - 1 < 9 ) { if (
switch_expression -> data [ b_kstr - 1 ] != b_p [ b_kstr - 1 ] ) { exitg1 = 1
; } else { b_kstr ++ ; } } else { b_bool = true ; exitg1 = 1 ; } } while (
exitg1 == 0 ) ; } if ( b_bool ) { b_kstr = 1 ; } else { b_kstr = - 1 ; } }
b0l0vcvht3 ( & switch_expression ) ; switch ( b_kstr ) { case 0 : tmp [ 0 ] =
0 ; tmp [ 1 ] = 0 ; tmp [ 2 ] = 1 ; tmp [ 3 ] = 0 ; tmp [ 4 ] = 0 ; tmp [ 5 ]
= 0 ; for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr ++ ) { msubspace_data [ b_kstr ]
= tmp [ b_kstr ] ; } poslim_data [ 0 ] = - 3.1415926535897931 ; poslim_data [
1 ] = 3.1415926535897931 ; iobj_1 -> VelocityNumber = 1.0 ; iobj_1 ->
PositionNumber = 1.0 ; iobj_1 -> JointAxisInternal [ 0 ] = 0.0 ; iobj_1 ->
JointAxisInternal [ 1 ] = 0.0 ; iobj_1 -> JointAxisInternal [ 2 ] = 1.0 ;
break ; case 1 : tmp [ 0 ] = 0 ; tmp [ 1 ] = 0 ; tmp [ 2 ] = 0 ; tmp [ 3 ] =
0 ; tmp [ 4 ] = 0 ; tmp [ 5 ] = 1 ; for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr ++
) { msubspace_data [ b_kstr ] = tmp [ b_kstr ] ; } poslim_data [ 0 ] = - 0.5
; poslim_data [ 1 ] = 0.5 ; iobj_1 -> VelocityNumber = 1.0 ; iobj_1 ->
PositionNumber = 1.0 ; iobj_1 -> JointAxisInternal [ 0 ] = 0.0 ; iobj_1 ->
JointAxisInternal [ 1 ] = 0.0 ; iobj_1 -> JointAxisInternal [ 2 ] = 1.0 ;
break ; default : for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr ++ ) {
msubspace_data [ b_kstr ] = 0 ; } poslim_data [ 0 ] = 0.0 ; poslim_data [ 1 ]
= 0.0 ; iobj_1 -> VelocityNumber = 0.0 ; iobj_1 -> PositionNumber = 0.0 ;
iobj_1 -> JointAxisInternal [ 0 ] = 0.0 ; iobj_1 -> JointAxisInternal [ 1 ] =
0.0 ; iobj_1 -> JointAxisInternal [ 2 ] = 0.0 ; break ; } b_kstr = iobj_1 ->
MotionSubspace -> size [ 0 ] * iobj_1 -> MotionSubspace -> size [ 1 ] ;
iobj_1 -> MotionSubspace -> size [ 0 ] = 6 ; iobj_1 -> MotionSubspace -> size
[ 1 ] = 1 ; ier0p3wwtw ( iobj_1 -> MotionSubspace , b_kstr ) ; for ( b_kstr =
0 ; b_kstr < 6 ; b_kstr ++ ) { iobj_1 -> MotionSubspace -> data [ b_kstr ] =
msubspace_data [ b_kstr ] ; } b_kstr = iobj_1 -> PositionLimitsInternal ->
size [ 0 ] * iobj_1 -> PositionLimitsInternal -> size [ 1 ] ; iobj_1 ->
PositionLimitsInternal -> size [ 0 ] = 1 ; iobj_1 -> PositionLimitsInternal
-> size [ 1 ] = 2 ; ier0p3wwtw ( iobj_1 -> PositionLimitsInternal , b_kstr )
; for ( b_kstr = 0 ; b_kstr < 2 ; b_kstr ++ ) { iobj_1 ->
PositionLimitsInternal -> data [ b_kstr ] = poslim_data [ b_kstr ] ; } b_kstr
= iobj_1 -> HomePositionInternal -> size [ 0 ] ; iobj_1 ->
HomePositionInternal -> size [ 0 ] = 1 ; ier0p3wwtw ( iobj_1 ->
HomePositionInternal , b_kstr ) ; iobj_1 -> HomePositionInternal -> data [ 0
] = 0.0 ; obj -> JointInternal = iobj_1 ; obj -> Index = - 1.0 ; obj ->
ParentIndex = - 1.0 ; obj -> MassInternal = 1.0 ; obj -> CenterOfMassInternal
[ 0 ] = 0.0 ; obj -> CenterOfMassInternal [ 1 ] = 0.0 ; obj ->
CenterOfMassInternal [ 2 ] = 0.0 ; for ( b_kstr = 0 ; b_kstr < 9 ; b_kstr ++
) { b_I [ b_kstr ] = 0 ; } b_I [ 0 ] = 1 ; b_I [ 4 ] = 1 ; b_I [ 8 ] = 1 ;
for ( b_kstr = 0 ; b_kstr < 9 ; b_kstr ++ ) { obj -> InertiaInternal [ b_kstr
] = b_I [ b_kstr ] ; } for ( b_kstr = 0 ; b_kstr < 36 ; b_kstr ++ ) {
msubspace_data [ b_kstr ] = 0 ; } for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr ++ )
{ msubspace_data [ b_kstr + 6 * b_kstr ] = 1 ; } for ( b_kstr = 0 ; b_kstr <
36 ; b_kstr ++ ) { obj -> SpatialInertia [ b_kstr ] = msubspace_data [ b_kstr
] ; } obj -> CollisionsInternal = aydneur4h5so ( iobj_0 , 0.0 ) ; return
b_obj ; } static gxcsgl11sl35 * pbim0sdm1g ( gxcsgl11sl35 * obj , gtd4jhsf2rw
* iobj_0 , iyg0swfnbfoc * iobj_1 ) { e2b0f4s35s * switch_expression ;
gxcsgl11sl35 * b_obj ; real_T poslim_data [ 12 ] ; int32_T b_kstr ; int32_T
loop_ub ; char_T b_p [ 9 ] ; char_T b [ 8 ] ; int8_T msubspace_data [ 36 ] ;
int8_T b_I [ 9 ] ; int8_T tmp [ 6 ] ; boolean_T b_bool ; static const char_T
tmp_p [ 10 ] = { 'd' , 'u' , 'm' , 'm' , 'y' , 'b' , 'o' , 'd' , 'y' , '2' }
; static const int8_T tmp_e [ 16 ] = { 1 , 0 , 0 , 0 , 0 , 1 , 0 , 0 , 0 , 0
, 1 , 0 , 0 , 0 , 0 , 1 } ; static const char_T tmp_i [ 14 ] = { 'd' , 'u' ,
'm' , 'm' , 'y' , 'b' , 'o' , 'd' , 'y' , '2' , '_' , 'j' , 'n' , 't' } ;
static const char_T tmp_m [ 5 ] = { 'f' , 'i' , 'x' , 'e' , 'd' } ; static
const char_T tmp_g [ 8 ] = { 'r' , 'e' , 'v' , 'o' , 'l' , 'u' , 't' , 'e' }
; static const char_T tmp_j [ 9 ] = { 'p' , 'r' , 'i' , 's' , 'm' , 'a' , 't'
, 'i' , 'c' } ; int32_T exitg1 ; b_obj = obj ; b_kstr = obj -> NameInternal
-> size [ 0 ] * obj -> NameInternal -> size [ 1 ] ; obj -> NameInternal ->
size [ 0 ] = 1 ; obj -> NameInternal -> size [ 1 ] = 10 ; ac0ugu5nlz ( obj ->
NameInternal , b_kstr ) ; for ( b_kstr = 0 ; b_kstr < 10 ; b_kstr ++ ) { obj
-> NameInternal -> data [ b_kstr ] = tmp_p [ b_kstr ] ; } iobj_1 -> InTree =
false ; for ( b_kstr = 0 ; b_kstr < 16 ; b_kstr ++ ) { iobj_1 ->
JointToParentTransform [ b_kstr ] = tmp_e [ b_kstr ] ; } for ( b_kstr = 0 ;
b_kstr < 16 ; b_kstr ++ ) { iobj_1 -> ChildToJointTransform [ b_kstr ] =
tmp_e [ b_kstr ] ; } b_kstr = iobj_1 -> NameInternal -> size [ 0 ] * iobj_1
-> NameInternal -> size [ 1 ] ; iobj_1 -> NameInternal -> size [ 0 ] = 1 ;
iobj_1 -> NameInternal -> size [ 1 ] = 14 ; ac0ugu5nlz ( iobj_1 ->
NameInternal , b_kstr ) ; for ( b_kstr = 0 ; b_kstr < 14 ; b_kstr ++ ) {
iobj_1 -> NameInternal -> data [ b_kstr ] = tmp_i [ b_kstr ] ; } b_kstr =
iobj_1 -> Type -> size [ 0 ] * iobj_1 -> Type -> size [ 1 ] ; iobj_1 -> Type
-> size [ 0 ] = 1 ; iobj_1 -> Type -> size [ 1 ] = 5 ; ac0ugu5nlz ( iobj_1 ->
Type , b_kstr ) ; for ( b_kstr = 0 ; b_kstr < 5 ; b_kstr ++ ) { iobj_1 ->
Type -> data [ b_kstr ] = tmp_m [ b_kstr ] ; } gunzkbl0qg ( &
switch_expression , 2 ) ; b_kstr = switch_expression -> size [ 0 ] *
switch_expression -> size [ 1 ] ; switch_expression -> size [ 0 ] = 1 ;
switch_expression -> size [ 1 ] = iobj_1 -> Type -> size [ 1 ] ; ac0ugu5nlz (
switch_expression , b_kstr ) ; loop_ub = iobj_1 -> Type -> size [ 1 ] - 1 ;
for ( b_kstr = 0 ; b_kstr <= loop_ub ; b_kstr ++ ) { switch_expression ->
data [ b_kstr ] = iobj_1 -> Type -> data [ b_kstr ] ; } for ( b_kstr = 0 ;
b_kstr < 8 ; b_kstr ++ ) { b [ b_kstr ] = tmp_g [ b_kstr ] ; } b_bool = false
; if ( switch_expression -> size [ 1 ] != 8 ) { } else { b_kstr = 1 ; do {
exitg1 = 0 ; if ( b_kstr - 1 < 8 ) { if ( switch_expression -> data [ b_kstr
- 1 ] != b [ b_kstr - 1 ] ) { exitg1 = 1 ; } else { b_kstr ++ ; } } else {
b_bool = true ; exitg1 = 1 ; } } while ( exitg1 == 0 ) ; } if ( b_bool ) {
b_kstr = 0 ; } else { for ( b_kstr = 0 ; b_kstr < 9 ; b_kstr ++ ) { b_p [
b_kstr ] = tmp_j [ b_kstr ] ; } if ( switch_expression -> size [ 1 ] != 9 ) {
} else { b_kstr = 1 ; do { exitg1 = 0 ; if ( b_kstr - 1 < 9 ) { if (
switch_expression -> data [ b_kstr - 1 ] != b_p [ b_kstr - 1 ] ) { exitg1 = 1
; } else { b_kstr ++ ; } } else { b_bool = true ; exitg1 = 1 ; } } while (
exitg1 == 0 ) ; } if ( b_bool ) { b_kstr = 1 ; } else { b_kstr = - 1 ; } }
b0l0vcvht3 ( & switch_expression ) ; switch ( b_kstr ) { case 0 : tmp [ 0 ] =
0 ; tmp [ 1 ] = 0 ; tmp [ 2 ] = 1 ; tmp [ 3 ] = 0 ; tmp [ 4 ] = 0 ; tmp [ 5 ]
= 0 ; for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr ++ ) { msubspace_data [ b_kstr ]
= tmp [ b_kstr ] ; } poslim_data [ 0 ] = - 3.1415926535897931 ; poslim_data [
1 ] = 3.1415926535897931 ; iobj_1 -> VelocityNumber = 1.0 ; iobj_1 ->
PositionNumber = 1.0 ; iobj_1 -> JointAxisInternal [ 0 ] = 0.0 ; iobj_1 ->
JointAxisInternal [ 1 ] = 0.0 ; iobj_1 -> JointAxisInternal [ 2 ] = 1.0 ;
break ; case 1 : tmp [ 0 ] = 0 ; tmp [ 1 ] = 0 ; tmp [ 2 ] = 0 ; tmp [ 3 ] =
0 ; tmp [ 4 ] = 0 ; tmp [ 5 ] = 1 ; for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr ++
) { msubspace_data [ b_kstr ] = tmp [ b_kstr ] ; } poslim_data [ 0 ] = - 0.5
; poslim_data [ 1 ] = 0.5 ; iobj_1 -> VelocityNumber = 1.0 ; iobj_1 ->
PositionNumber = 1.0 ; iobj_1 -> JointAxisInternal [ 0 ] = 0.0 ; iobj_1 ->
JointAxisInternal [ 1 ] = 0.0 ; iobj_1 -> JointAxisInternal [ 2 ] = 1.0 ;
break ; default : for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr ++ ) {
msubspace_data [ b_kstr ] = 0 ; } poslim_data [ 0 ] = 0.0 ; poslim_data [ 1 ]
= 0.0 ; iobj_1 -> VelocityNumber = 0.0 ; iobj_1 -> PositionNumber = 0.0 ;
iobj_1 -> JointAxisInternal [ 0 ] = 0.0 ; iobj_1 -> JointAxisInternal [ 1 ] =
0.0 ; iobj_1 -> JointAxisInternal [ 2 ] = 0.0 ; break ; } b_kstr = iobj_1 ->
MotionSubspace -> size [ 0 ] * iobj_1 -> MotionSubspace -> size [ 1 ] ;
iobj_1 -> MotionSubspace -> size [ 0 ] = 6 ; iobj_1 -> MotionSubspace -> size
[ 1 ] = 1 ; ier0p3wwtw ( iobj_1 -> MotionSubspace , b_kstr ) ; for ( b_kstr =
0 ; b_kstr < 6 ; b_kstr ++ ) { iobj_1 -> MotionSubspace -> data [ b_kstr ] =
msubspace_data [ b_kstr ] ; } b_kstr = iobj_1 -> PositionLimitsInternal ->
size [ 0 ] * iobj_1 -> PositionLimitsInternal -> size [ 1 ] ; iobj_1 ->
PositionLimitsInternal -> size [ 0 ] = 1 ; iobj_1 -> PositionLimitsInternal
-> size [ 1 ] = 2 ; ier0p3wwtw ( iobj_1 -> PositionLimitsInternal , b_kstr )
; for ( b_kstr = 0 ; b_kstr < 2 ; b_kstr ++ ) { iobj_1 ->
PositionLimitsInternal -> data [ b_kstr ] = poslim_data [ b_kstr ] ; } b_kstr
= iobj_1 -> HomePositionInternal -> size [ 0 ] ; iobj_1 ->
HomePositionInternal -> size [ 0 ] = 1 ; ier0p3wwtw ( iobj_1 ->
HomePositionInternal , b_kstr ) ; iobj_1 -> HomePositionInternal -> data [ 0
] = 0.0 ; obj -> JointInternal = iobj_1 ; obj -> Index = - 1.0 ; obj ->
ParentIndex = - 1.0 ; obj -> MassInternal = 1.0 ; obj -> CenterOfMassInternal
[ 0 ] = 0.0 ; obj -> CenterOfMassInternal [ 1 ] = 0.0 ; obj ->
CenterOfMassInternal [ 2 ] = 0.0 ; for ( b_kstr = 0 ; b_kstr < 9 ; b_kstr ++
) { b_I [ b_kstr ] = 0 ; } b_I [ 0 ] = 1 ; b_I [ 4 ] = 1 ; b_I [ 8 ] = 1 ;
for ( b_kstr = 0 ; b_kstr < 9 ; b_kstr ++ ) { obj -> InertiaInternal [ b_kstr
] = b_I [ b_kstr ] ; } for ( b_kstr = 0 ; b_kstr < 36 ; b_kstr ++ ) {
msubspace_data [ b_kstr ] = 0 ; } for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr ++ )
{ msubspace_data [ b_kstr + 6 * b_kstr ] = 1 ; } for ( b_kstr = 0 ; b_kstr <
36 ; b_kstr ++ ) { obj -> SpatialInertia [ b_kstr ] = msubspace_data [ b_kstr
] ; } obj -> CollisionsInternal = aydneur4h5so ( iobj_0 , 0.0 ) ; return
b_obj ; } static gxcsgl11sl35 * gd1a2d5whe ( gxcsgl11sl35 * obj , gtd4jhsf2rw
* iobj_0 , iyg0swfnbfoc * iobj_1 ) { e2b0f4s35s * switch_expression ;
gxcsgl11sl35 * b_obj ; real_T poslim_data [ 12 ] ; int32_T b_kstr ; int32_T
loop_ub ; char_T b_p [ 9 ] ; char_T b [ 8 ] ; int8_T msubspace_data [ 36 ] ;
int8_T b_I [ 9 ] ; int8_T tmp [ 6 ] ; boolean_T b_bool ; static const char_T
tmp_p [ 10 ] = { 'd' , 'u' , 'm' , 'm' , 'y' , 'b' , 'o' , 'd' , 'y' , '3' }
; static const int8_T tmp_e [ 16 ] = { 1 , 0 , 0 , 0 , 0 , 1 , 0 , 0 , 0 , 0
, 1 , 0 , 0 , 0 , 0 , 1 } ; static const char_T tmp_i [ 14 ] = { 'd' , 'u' ,
'm' , 'm' , 'y' , 'b' , 'o' , 'd' , 'y' , '3' , '_' , 'j' , 'n' , 't' } ;
static const char_T tmp_m [ 5 ] = { 'f' , 'i' , 'x' , 'e' , 'd' } ; static
const char_T tmp_g [ 8 ] = { 'r' , 'e' , 'v' , 'o' , 'l' , 'u' , 't' , 'e' }
; static const char_T tmp_j [ 9 ] = { 'p' , 'r' , 'i' , 's' , 'm' , 'a' , 't'
, 'i' , 'c' } ; int32_T exitg1 ; b_obj = obj ; b_kstr = obj -> NameInternal
-> size [ 0 ] * obj -> NameInternal -> size [ 1 ] ; obj -> NameInternal ->
size [ 0 ] = 1 ; obj -> NameInternal -> size [ 1 ] = 10 ; ac0ugu5nlz ( obj ->
NameInternal , b_kstr ) ; for ( b_kstr = 0 ; b_kstr < 10 ; b_kstr ++ ) { obj
-> NameInternal -> data [ b_kstr ] = tmp_p [ b_kstr ] ; } iobj_1 -> InTree =
false ; for ( b_kstr = 0 ; b_kstr < 16 ; b_kstr ++ ) { iobj_1 ->
JointToParentTransform [ b_kstr ] = tmp_e [ b_kstr ] ; } for ( b_kstr = 0 ;
b_kstr < 16 ; b_kstr ++ ) { iobj_1 -> ChildToJointTransform [ b_kstr ] =
tmp_e [ b_kstr ] ; } b_kstr = iobj_1 -> NameInternal -> size [ 0 ] * iobj_1
-> NameInternal -> size [ 1 ] ; iobj_1 -> NameInternal -> size [ 0 ] = 1 ;
iobj_1 -> NameInternal -> size [ 1 ] = 14 ; ac0ugu5nlz ( iobj_1 ->
NameInternal , b_kstr ) ; for ( b_kstr = 0 ; b_kstr < 14 ; b_kstr ++ ) {
iobj_1 -> NameInternal -> data [ b_kstr ] = tmp_i [ b_kstr ] ; } b_kstr =
iobj_1 -> Type -> size [ 0 ] * iobj_1 -> Type -> size [ 1 ] ; iobj_1 -> Type
-> size [ 0 ] = 1 ; iobj_1 -> Type -> size [ 1 ] = 5 ; ac0ugu5nlz ( iobj_1 ->
Type , b_kstr ) ; for ( b_kstr = 0 ; b_kstr < 5 ; b_kstr ++ ) { iobj_1 ->
Type -> data [ b_kstr ] = tmp_m [ b_kstr ] ; } gunzkbl0qg ( &
switch_expression , 2 ) ; b_kstr = switch_expression -> size [ 0 ] *
switch_expression -> size [ 1 ] ; switch_expression -> size [ 0 ] = 1 ;
switch_expression -> size [ 1 ] = iobj_1 -> Type -> size [ 1 ] ; ac0ugu5nlz (
switch_expression , b_kstr ) ; loop_ub = iobj_1 -> Type -> size [ 1 ] - 1 ;
for ( b_kstr = 0 ; b_kstr <= loop_ub ; b_kstr ++ ) { switch_expression ->
data [ b_kstr ] = iobj_1 -> Type -> data [ b_kstr ] ; } for ( b_kstr = 0 ;
b_kstr < 8 ; b_kstr ++ ) { b [ b_kstr ] = tmp_g [ b_kstr ] ; } b_bool = false
; if ( switch_expression -> size [ 1 ] != 8 ) { } else { b_kstr = 1 ; do {
exitg1 = 0 ; if ( b_kstr - 1 < 8 ) { if ( switch_expression -> data [ b_kstr
- 1 ] != b [ b_kstr - 1 ] ) { exitg1 = 1 ; } else { b_kstr ++ ; } } else {
b_bool = true ; exitg1 = 1 ; } } while ( exitg1 == 0 ) ; } if ( b_bool ) {
b_kstr = 0 ; } else { for ( b_kstr = 0 ; b_kstr < 9 ; b_kstr ++ ) { b_p [
b_kstr ] = tmp_j [ b_kstr ] ; } if ( switch_expression -> size [ 1 ] != 9 ) {
} else { b_kstr = 1 ; do { exitg1 = 0 ; if ( b_kstr - 1 < 9 ) { if (
switch_expression -> data [ b_kstr - 1 ] != b_p [ b_kstr - 1 ] ) { exitg1 = 1
; } else { b_kstr ++ ; } } else { b_bool = true ; exitg1 = 1 ; } } while (
exitg1 == 0 ) ; } if ( b_bool ) { b_kstr = 1 ; } else { b_kstr = - 1 ; } }
b0l0vcvht3 ( & switch_expression ) ; switch ( b_kstr ) { case 0 : tmp [ 0 ] =
0 ; tmp [ 1 ] = 0 ; tmp [ 2 ] = 1 ; tmp [ 3 ] = 0 ; tmp [ 4 ] = 0 ; tmp [ 5 ]
= 0 ; for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr ++ ) { msubspace_data [ b_kstr ]
= tmp [ b_kstr ] ; } poslim_data [ 0 ] = - 3.1415926535897931 ; poslim_data [
1 ] = 3.1415926535897931 ; iobj_1 -> VelocityNumber = 1.0 ; iobj_1 ->
PositionNumber = 1.0 ; iobj_1 -> JointAxisInternal [ 0 ] = 0.0 ; iobj_1 ->
JointAxisInternal [ 1 ] = 0.0 ; iobj_1 -> JointAxisInternal [ 2 ] = 1.0 ;
break ; case 1 : tmp [ 0 ] = 0 ; tmp [ 1 ] = 0 ; tmp [ 2 ] = 0 ; tmp [ 3 ] =
0 ; tmp [ 4 ] = 0 ; tmp [ 5 ] = 1 ; for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr ++
) { msubspace_data [ b_kstr ] = tmp [ b_kstr ] ; } poslim_data [ 0 ] = - 0.5
; poslim_data [ 1 ] = 0.5 ; iobj_1 -> VelocityNumber = 1.0 ; iobj_1 ->
PositionNumber = 1.0 ; iobj_1 -> JointAxisInternal [ 0 ] = 0.0 ; iobj_1 ->
JointAxisInternal [ 1 ] = 0.0 ; iobj_1 -> JointAxisInternal [ 2 ] = 1.0 ;
break ; default : for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr ++ ) {
msubspace_data [ b_kstr ] = 0 ; } poslim_data [ 0 ] = 0.0 ; poslim_data [ 1 ]
= 0.0 ; iobj_1 -> VelocityNumber = 0.0 ; iobj_1 -> PositionNumber = 0.0 ;
iobj_1 -> JointAxisInternal [ 0 ] = 0.0 ; iobj_1 -> JointAxisInternal [ 1 ] =
0.0 ; iobj_1 -> JointAxisInternal [ 2 ] = 0.0 ; break ; } b_kstr = iobj_1 ->
MotionSubspace -> size [ 0 ] * iobj_1 -> MotionSubspace -> size [ 1 ] ;
iobj_1 -> MotionSubspace -> size [ 0 ] = 6 ; iobj_1 -> MotionSubspace -> size
[ 1 ] = 1 ; ier0p3wwtw ( iobj_1 -> MotionSubspace , b_kstr ) ; for ( b_kstr =
0 ; b_kstr < 6 ; b_kstr ++ ) { iobj_1 -> MotionSubspace -> data [ b_kstr ] =
msubspace_data [ b_kstr ] ; } b_kstr = iobj_1 -> PositionLimitsInternal ->
size [ 0 ] * iobj_1 -> PositionLimitsInternal -> size [ 1 ] ; iobj_1 ->
PositionLimitsInternal -> size [ 0 ] = 1 ; iobj_1 -> PositionLimitsInternal
-> size [ 1 ] = 2 ; ier0p3wwtw ( iobj_1 -> PositionLimitsInternal , b_kstr )
; for ( b_kstr = 0 ; b_kstr < 2 ; b_kstr ++ ) { iobj_1 ->
PositionLimitsInternal -> data [ b_kstr ] = poslim_data [ b_kstr ] ; } b_kstr
= iobj_1 -> HomePositionInternal -> size [ 0 ] ; iobj_1 ->
HomePositionInternal -> size [ 0 ] = 1 ; ier0p3wwtw ( iobj_1 ->
HomePositionInternal , b_kstr ) ; iobj_1 -> HomePositionInternal -> data [ 0
] = 0.0 ; obj -> JointInternal = iobj_1 ; obj -> Index = - 1.0 ; obj ->
ParentIndex = - 1.0 ; obj -> MassInternal = 1.0 ; obj -> CenterOfMassInternal
[ 0 ] = 0.0 ; obj -> CenterOfMassInternal [ 1 ] = 0.0 ; obj ->
CenterOfMassInternal [ 2 ] = 0.0 ; for ( b_kstr = 0 ; b_kstr < 9 ; b_kstr ++
) { b_I [ b_kstr ] = 0 ; } b_I [ 0 ] = 1 ; b_I [ 4 ] = 1 ; b_I [ 8 ] = 1 ;
for ( b_kstr = 0 ; b_kstr < 9 ; b_kstr ++ ) { obj -> InertiaInternal [ b_kstr
] = b_I [ b_kstr ] ; } for ( b_kstr = 0 ; b_kstr < 36 ; b_kstr ++ ) {
msubspace_data [ b_kstr ] = 0 ; } for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr ++ )
{ msubspace_data [ b_kstr + 6 * b_kstr ] = 1 ; } for ( b_kstr = 0 ; b_kstr <
36 ; b_kstr ++ ) { obj -> SpatialInertia [ b_kstr ] = msubspace_data [ b_kstr
] ; } obj -> CollisionsInternal = aydneur4h5so ( iobj_0 , 0.0 ) ; return
b_obj ; } static gxcsgl11sl35 * oswu44nkbe ( gxcsgl11sl35 * obj , gtd4jhsf2rw
* iobj_0 , iyg0swfnbfoc * iobj_1 ) { e2b0f4s35s * switch_expression ;
gxcsgl11sl35 * b_obj ; real_T poslim_data [ 12 ] ; int32_T b_kstr ; int32_T
loop_ub ; char_T b_p [ 9 ] ; char_T b [ 8 ] ; int8_T msubspace_data [ 36 ] ;
int8_T b_I [ 9 ] ; int8_T tmp [ 6 ] ; boolean_T b_bool ; static const char_T
tmp_p [ 10 ] = { 'd' , 'u' , 'm' , 'm' , 'y' , 'b' , 'o' , 'd' , 'y' , '4' }
; static const int8_T tmp_e [ 16 ] = { 1 , 0 , 0 , 0 , 0 , 1 , 0 , 0 , 0 , 0
, 1 , 0 , 0 , 0 , 0 , 1 } ; static const char_T tmp_i [ 14 ] = { 'd' , 'u' ,
'm' , 'm' , 'y' , 'b' , 'o' , 'd' , 'y' , '4' , '_' , 'j' , 'n' , 't' } ;
static const char_T tmp_m [ 5 ] = { 'f' , 'i' , 'x' , 'e' , 'd' } ; static
const char_T tmp_g [ 8 ] = { 'r' , 'e' , 'v' , 'o' , 'l' , 'u' , 't' , 'e' }
; static const char_T tmp_j [ 9 ] = { 'p' , 'r' , 'i' , 's' , 'm' , 'a' , 't'
, 'i' , 'c' } ; int32_T exitg1 ; b_obj = obj ; b_kstr = obj -> NameInternal
-> size [ 0 ] * obj -> NameInternal -> size [ 1 ] ; obj -> NameInternal ->
size [ 0 ] = 1 ; obj -> NameInternal -> size [ 1 ] = 10 ; ac0ugu5nlz ( obj ->
NameInternal , b_kstr ) ; for ( b_kstr = 0 ; b_kstr < 10 ; b_kstr ++ ) { obj
-> NameInternal -> data [ b_kstr ] = tmp_p [ b_kstr ] ; } iobj_1 -> InTree =
false ; for ( b_kstr = 0 ; b_kstr < 16 ; b_kstr ++ ) { iobj_1 ->
JointToParentTransform [ b_kstr ] = tmp_e [ b_kstr ] ; } for ( b_kstr = 0 ;
b_kstr < 16 ; b_kstr ++ ) { iobj_1 -> ChildToJointTransform [ b_kstr ] =
tmp_e [ b_kstr ] ; } b_kstr = iobj_1 -> NameInternal -> size [ 0 ] * iobj_1
-> NameInternal -> size [ 1 ] ; iobj_1 -> NameInternal -> size [ 0 ] = 1 ;
iobj_1 -> NameInternal -> size [ 1 ] = 14 ; ac0ugu5nlz ( iobj_1 ->
NameInternal , b_kstr ) ; for ( b_kstr = 0 ; b_kstr < 14 ; b_kstr ++ ) {
iobj_1 -> NameInternal -> data [ b_kstr ] = tmp_i [ b_kstr ] ; } b_kstr =
iobj_1 -> Type -> size [ 0 ] * iobj_1 -> Type -> size [ 1 ] ; iobj_1 -> Type
-> size [ 0 ] = 1 ; iobj_1 -> Type -> size [ 1 ] = 5 ; ac0ugu5nlz ( iobj_1 ->
Type , b_kstr ) ; for ( b_kstr = 0 ; b_kstr < 5 ; b_kstr ++ ) { iobj_1 ->
Type -> data [ b_kstr ] = tmp_m [ b_kstr ] ; } gunzkbl0qg ( &
switch_expression , 2 ) ; b_kstr = switch_expression -> size [ 0 ] *
switch_expression -> size [ 1 ] ; switch_expression -> size [ 0 ] = 1 ;
switch_expression -> size [ 1 ] = iobj_1 -> Type -> size [ 1 ] ; ac0ugu5nlz (
switch_expression , b_kstr ) ; loop_ub = iobj_1 -> Type -> size [ 1 ] - 1 ;
for ( b_kstr = 0 ; b_kstr <= loop_ub ; b_kstr ++ ) { switch_expression ->
data [ b_kstr ] = iobj_1 -> Type -> data [ b_kstr ] ; } for ( b_kstr = 0 ;
b_kstr < 8 ; b_kstr ++ ) { b [ b_kstr ] = tmp_g [ b_kstr ] ; } b_bool = false
; if ( switch_expression -> size [ 1 ] != 8 ) { } else { b_kstr = 1 ; do {
exitg1 = 0 ; if ( b_kstr - 1 < 8 ) { if ( switch_expression -> data [ b_kstr
- 1 ] != b [ b_kstr - 1 ] ) { exitg1 = 1 ; } else { b_kstr ++ ; } } else {
b_bool = true ; exitg1 = 1 ; } } while ( exitg1 == 0 ) ; } if ( b_bool ) {
b_kstr = 0 ; } else { for ( b_kstr = 0 ; b_kstr < 9 ; b_kstr ++ ) { b_p [
b_kstr ] = tmp_j [ b_kstr ] ; } if ( switch_expression -> size [ 1 ] != 9 ) {
} else { b_kstr = 1 ; do { exitg1 = 0 ; if ( b_kstr - 1 < 9 ) { if (
switch_expression -> data [ b_kstr - 1 ] != b_p [ b_kstr - 1 ] ) { exitg1 = 1
; } else { b_kstr ++ ; } } else { b_bool = true ; exitg1 = 1 ; } } while (
exitg1 == 0 ) ; } if ( b_bool ) { b_kstr = 1 ; } else { b_kstr = - 1 ; } }
b0l0vcvht3 ( & switch_expression ) ; switch ( b_kstr ) { case 0 : tmp [ 0 ] =
0 ; tmp [ 1 ] = 0 ; tmp [ 2 ] = 1 ; tmp [ 3 ] = 0 ; tmp [ 4 ] = 0 ; tmp [ 5 ]
= 0 ; for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr ++ ) { msubspace_data [ b_kstr ]
= tmp [ b_kstr ] ; } poslim_data [ 0 ] = - 3.1415926535897931 ; poslim_data [
1 ] = 3.1415926535897931 ; iobj_1 -> VelocityNumber = 1.0 ; iobj_1 ->
PositionNumber = 1.0 ; iobj_1 -> JointAxisInternal [ 0 ] = 0.0 ; iobj_1 ->
JointAxisInternal [ 1 ] = 0.0 ; iobj_1 -> JointAxisInternal [ 2 ] = 1.0 ;
break ; case 1 : tmp [ 0 ] = 0 ; tmp [ 1 ] = 0 ; tmp [ 2 ] = 0 ; tmp [ 3 ] =
0 ; tmp [ 4 ] = 0 ; tmp [ 5 ] = 1 ; for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr ++
) { msubspace_data [ b_kstr ] = tmp [ b_kstr ] ; } poslim_data [ 0 ] = - 0.5
; poslim_data [ 1 ] = 0.5 ; iobj_1 -> VelocityNumber = 1.0 ; iobj_1 ->
PositionNumber = 1.0 ; iobj_1 -> JointAxisInternal [ 0 ] = 0.0 ; iobj_1 ->
JointAxisInternal [ 1 ] = 0.0 ; iobj_1 -> JointAxisInternal [ 2 ] = 1.0 ;
break ; default : for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr ++ ) {
msubspace_data [ b_kstr ] = 0 ; } poslim_data [ 0 ] = 0.0 ; poslim_data [ 1 ]
= 0.0 ; iobj_1 -> VelocityNumber = 0.0 ; iobj_1 -> PositionNumber = 0.0 ;
iobj_1 -> JointAxisInternal [ 0 ] = 0.0 ; iobj_1 -> JointAxisInternal [ 1 ] =
0.0 ; iobj_1 -> JointAxisInternal [ 2 ] = 0.0 ; break ; } b_kstr = iobj_1 ->
MotionSubspace -> size [ 0 ] * iobj_1 -> MotionSubspace -> size [ 1 ] ;
iobj_1 -> MotionSubspace -> size [ 0 ] = 6 ; iobj_1 -> MotionSubspace -> size
[ 1 ] = 1 ; ier0p3wwtw ( iobj_1 -> MotionSubspace , b_kstr ) ; for ( b_kstr =
0 ; b_kstr < 6 ; b_kstr ++ ) { iobj_1 -> MotionSubspace -> data [ b_kstr ] =
msubspace_data [ b_kstr ] ; } b_kstr = iobj_1 -> PositionLimitsInternal ->
size [ 0 ] * iobj_1 -> PositionLimitsInternal -> size [ 1 ] ; iobj_1 ->
PositionLimitsInternal -> size [ 0 ] = 1 ; iobj_1 -> PositionLimitsInternal
-> size [ 1 ] = 2 ; ier0p3wwtw ( iobj_1 -> PositionLimitsInternal , b_kstr )
; for ( b_kstr = 0 ; b_kstr < 2 ; b_kstr ++ ) { iobj_1 ->
PositionLimitsInternal -> data [ b_kstr ] = poslim_data [ b_kstr ] ; } b_kstr
= iobj_1 -> HomePositionInternal -> size [ 0 ] ; iobj_1 ->
HomePositionInternal -> size [ 0 ] = 1 ; ier0p3wwtw ( iobj_1 ->
HomePositionInternal , b_kstr ) ; iobj_1 -> HomePositionInternal -> data [ 0
] = 0.0 ; obj -> JointInternal = iobj_1 ; obj -> Index = - 1.0 ; obj ->
ParentIndex = - 1.0 ; obj -> MassInternal = 1.0 ; obj -> CenterOfMassInternal
[ 0 ] = 0.0 ; obj -> CenterOfMassInternal [ 1 ] = 0.0 ; obj ->
CenterOfMassInternal [ 2 ] = 0.0 ; for ( b_kstr = 0 ; b_kstr < 9 ; b_kstr ++
) { b_I [ b_kstr ] = 0 ; } b_I [ 0 ] = 1 ; b_I [ 4 ] = 1 ; b_I [ 8 ] = 1 ;
for ( b_kstr = 0 ; b_kstr < 9 ; b_kstr ++ ) { obj -> InertiaInternal [ b_kstr
] = b_I [ b_kstr ] ; } for ( b_kstr = 0 ; b_kstr < 36 ; b_kstr ++ ) {
msubspace_data [ b_kstr ] = 0 ; } for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr ++ )
{ msubspace_data [ b_kstr + 6 * b_kstr ] = 1 ; } for ( b_kstr = 0 ; b_kstr <
36 ; b_kstr ++ ) { obj -> SpatialInertia [ b_kstr ] = msubspace_data [ b_kstr
] ; } obj -> CollisionsInternal = aydneur4h5so ( iobj_0 , 0.0 ) ; return
b_obj ; } static gxcsgl11sl35 * avigwta1rk ( gxcsgl11sl35 * obj , gtd4jhsf2rw
* iobj_0 , iyg0swfnbfoc * iobj_1 ) { e2b0f4s35s * switch_expression ;
gxcsgl11sl35 * b_obj ; real_T poslim_data [ 12 ] ; int32_T b_kstr ; int32_T
loop_ub ; char_T b_p [ 9 ] ; char_T b [ 8 ] ; int8_T msubspace_data [ 36 ] ;
int8_T b_I [ 9 ] ; int8_T tmp [ 6 ] ; boolean_T b_bool ; static const char_T
tmp_p [ 10 ] = { 'd' , 'u' , 'm' , 'm' , 'y' , 'b' , 'o' , 'd' , 'y' , '5' }
; static const int8_T tmp_e [ 16 ] = { 1 , 0 , 0 , 0 , 0 , 1 , 0 , 0 , 0 , 0
, 1 , 0 , 0 , 0 , 0 , 1 } ; static const char_T tmp_i [ 14 ] = { 'd' , 'u' ,
'm' , 'm' , 'y' , 'b' , 'o' , 'd' , 'y' , '5' , '_' , 'j' , 'n' , 't' } ;
static const char_T tmp_m [ 5 ] = { 'f' , 'i' , 'x' , 'e' , 'd' } ; static
const char_T tmp_g [ 8 ] = { 'r' , 'e' , 'v' , 'o' , 'l' , 'u' , 't' , 'e' }
; static const char_T tmp_j [ 9 ] = { 'p' , 'r' , 'i' , 's' , 'm' , 'a' , 't'
, 'i' , 'c' } ; int32_T exitg1 ; b_obj = obj ; b_kstr = obj -> NameInternal
-> size [ 0 ] * obj -> NameInternal -> size [ 1 ] ; obj -> NameInternal ->
size [ 0 ] = 1 ; obj -> NameInternal -> size [ 1 ] = 10 ; ac0ugu5nlz ( obj ->
NameInternal , b_kstr ) ; for ( b_kstr = 0 ; b_kstr < 10 ; b_kstr ++ ) { obj
-> NameInternal -> data [ b_kstr ] = tmp_p [ b_kstr ] ; } iobj_1 -> InTree =
false ; for ( b_kstr = 0 ; b_kstr < 16 ; b_kstr ++ ) { iobj_1 ->
JointToParentTransform [ b_kstr ] = tmp_e [ b_kstr ] ; } for ( b_kstr = 0 ;
b_kstr < 16 ; b_kstr ++ ) { iobj_1 -> ChildToJointTransform [ b_kstr ] =
tmp_e [ b_kstr ] ; } b_kstr = iobj_1 -> NameInternal -> size [ 0 ] * iobj_1
-> NameInternal -> size [ 1 ] ; iobj_1 -> NameInternal -> size [ 0 ] = 1 ;
iobj_1 -> NameInternal -> size [ 1 ] = 14 ; ac0ugu5nlz ( iobj_1 ->
NameInternal , b_kstr ) ; for ( b_kstr = 0 ; b_kstr < 14 ; b_kstr ++ ) {
iobj_1 -> NameInternal -> data [ b_kstr ] = tmp_i [ b_kstr ] ; } b_kstr =
iobj_1 -> Type -> size [ 0 ] * iobj_1 -> Type -> size [ 1 ] ; iobj_1 -> Type
-> size [ 0 ] = 1 ; iobj_1 -> Type -> size [ 1 ] = 5 ; ac0ugu5nlz ( iobj_1 ->
Type , b_kstr ) ; for ( b_kstr = 0 ; b_kstr < 5 ; b_kstr ++ ) { iobj_1 ->
Type -> data [ b_kstr ] = tmp_m [ b_kstr ] ; } gunzkbl0qg ( &
switch_expression , 2 ) ; b_kstr = switch_expression -> size [ 0 ] *
switch_expression -> size [ 1 ] ; switch_expression -> size [ 0 ] = 1 ;
switch_expression -> size [ 1 ] = iobj_1 -> Type -> size [ 1 ] ; ac0ugu5nlz (
switch_expression , b_kstr ) ; loop_ub = iobj_1 -> Type -> size [ 1 ] - 1 ;
for ( b_kstr = 0 ; b_kstr <= loop_ub ; b_kstr ++ ) { switch_expression ->
data [ b_kstr ] = iobj_1 -> Type -> data [ b_kstr ] ; } for ( b_kstr = 0 ;
b_kstr < 8 ; b_kstr ++ ) { b [ b_kstr ] = tmp_g [ b_kstr ] ; } b_bool = false
; if ( switch_expression -> size [ 1 ] != 8 ) { } else { b_kstr = 1 ; do {
exitg1 = 0 ; if ( b_kstr - 1 < 8 ) { if ( switch_expression -> data [ b_kstr
- 1 ] != b [ b_kstr - 1 ] ) { exitg1 = 1 ; } else { b_kstr ++ ; } } else {
b_bool = true ; exitg1 = 1 ; } } while ( exitg1 == 0 ) ; } if ( b_bool ) {
b_kstr = 0 ; } else { for ( b_kstr = 0 ; b_kstr < 9 ; b_kstr ++ ) { b_p [
b_kstr ] = tmp_j [ b_kstr ] ; } if ( switch_expression -> size [ 1 ] != 9 ) {
} else { b_kstr = 1 ; do { exitg1 = 0 ; if ( b_kstr - 1 < 9 ) { if (
switch_expression -> data [ b_kstr - 1 ] != b_p [ b_kstr - 1 ] ) { exitg1 = 1
; } else { b_kstr ++ ; } } else { b_bool = true ; exitg1 = 1 ; } } while (
exitg1 == 0 ) ; } if ( b_bool ) { b_kstr = 1 ; } else { b_kstr = - 1 ; } }
b0l0vcvht3 ( & switch_expression ) ; switch ( b_kstr ) { case 0 : tmp [ 0 ] =
0 ; tmp [ 1 ] = 0 ; tmp [ 2 ] = 1 ; tmp [ 3 ] = 0 ; tmp [ 4 ] = 0 ; tmp [ 5 ]
= 0 ; for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr ++ ) { msubspace_data [ b_kstr ]
= tmp [ b_kstr ] ; } poslim_data [ 0 ] = - 3.1415926535897931 ; poslim_data [
1 ] = 3.1415926535897931 ; iobj_1 -> VelocityNumber = 1.0 ; iobj_1 ->
PositionNumber = 1.0 ; iobj_1 -> JointAxisInternal [ 0 ] = 0.0 ; iobj_1 ->
JointAxisInternal [ 1 ] = 0.0 ; iobj_1 -> JointAxisInternal [ 2 ] = 1.0 ;
break ; case 1 : tmp [ 0 ] = 0 ; tmp [ 1 ] = 0 ; tmp [ 2 ] = 0 ; tmp [ 3 ] =
0 ; tmp [ 4 ] = 0 ; tmp [ 5 ] = 1 ; for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr ++
) { msubspace_data [ b_kstr ] = tmp [ b_kstr ] ; } poslim_data [ 0 ] = - 0.5
; poslim_data [ 1 ] = 0.5 ; iobj_1 -> VelocityNumber = 1.0 ; iobj_1 ->
PositionNumber = 1.0 ; iobj_1 -> JointAxisInternal [ 0 ] = 0.0 ; iobj_1 ->
JointAxisInternal [ 1 ] = 0.0 ; iobj_1 -> JointAxisInternal [ 2 ] = 1.0 ;
break ; default : for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr ++ ) {
msubspace_data [ b_kstr ] = 0 ; } poslim_data [ 0 ] = 0.0 ; poslim_data [ 1 ]
= 0.0 ; iobj_1 -> VelocityNumber = 0.0 ; iobj_1 -> PositionNumber = 0.0 ;
iobj_1 -> JointAxisInternal [ 0 ] = 0.0 ; iobj_1 -> JointAxisInternal [ 1 ] =
0.0 ; iobj_1 -> JointAxisInternal [ 2 ] = 0.0 ; break ; } b_kstr = iobj_1 ->
MotionSubspace -> size [ 0 ] * iobj_1 -> MotionSubspace -> size [ 1 ] ;
iobj_1 -> MotionSubspace -> size [ 0 ] = 6 ; iobj_1 -> MotionSubspace -> size
[ 1 ] = 1 ; ier0p3wwtw ( iobj_1 -> MotionSubspace , b_kstr ) ; for ( b_kstr =
0 ; b_kstr < 6 ; b_kstr ++ ) { iobj_1 -> MotionSubspace -> data [ b_kstr ] =
msubspace_data [ b_kstr ] ; } b_kstr = iobj_1 -> PositionLimitsInternal ->
size [ 0 ] * iobj_1 -> PositionLimitsInternal -> size [ 1 ] ; iobj_1 ->
PositionLimitsInternal -> size [ 0 ] = 1 ; iobj_1 -> PositionLimitsInternal
-> size [ 1 ] = 2 ; ier0p3wwtw ( iobj_1 -> PositionLimitsInternal , b_kstr )
; for ( b_kstr = 0 ; b_kstr < 2 ; b_kstr ++ ) { iobj_1 ->
PositionLimitsInternal -> data [ b_kstr ] = poslim_data [ b_kstr ] ; } b_kstr
= iobj_1 -> HomePositionInternal -> size [ 0 ] ; iobj_1 ->
HomePositionInternal -> size [ 0 ] = 1 ; ier0p3wwtw ( iobj_1 ->
HomePositionInternal , b_kstr ) ; iobj_1 -> HomePositionInternal -> data [ 0
] = 0.0 ; obj -> JointInternal = iobj_1 ; obj -> Index = - 1.0 ; obj ->
ParentIndex = - 1.0 ; obj -> MassInternal = 1.0 ; obj -> CenterOfMassInternal
[ 0 ] = 0.0 ; obj -> CenterOfMassInternal [ 1 ] = 0.0 ; obj ->
CenterOfMassInternal [ 2 ] = 0.0 ; for ( b_kstr = 0 ; b_kstr < 9 ; b_kstr ++
) { b_I [ b_kstr ] = 0 ; } b_I [ 0 ] = 1 ; b_I [ 4 ] = 1 ; b_I [ 8 ] = 1 ;
for ( b_kstr = 0 ; b_kstr < 9 ; b_kstr ++ ) { obj -> InertiaInternal [ b_kstr
] = b_I [ b_kstr ] ; } for ( b_kstr = 0 ; b_kstr < 36 ; b_kstr ++ ) {
msubspace_data [ b_kstr ] = 0 ; } for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr ++ )
{ msubspace_data [ b_kstr + 6 * b_kstr ] = 1 ; } for ( b_kstr = 0 ; b_kstr <
36 ; b_kstr ++ ) { obj -> SpatialInertia [ b_kstr ] = msubspace_data [ b_kstr
] ; } obj -> CollisionsInternal = aydneur4h5so ( iobj_0 , 0.0 ) ; return
b_obj ; } static gxcsgl11sl35 * fu3whh3mfb ( gxcsgl11sl35 * obj , gtd4jhsf2rw
* iobj_0 , iyg0swfnbfoc * iobj_1 ) { e2b0f4s35s * switch_expression ;
gxcsgl11sl35 * b_obj ; real_T poslim_data [ 12 ] ; int32_T b_kstr ; int32_T
loop_ub ; char_T b_p [ 9 ] ; char_T b [ 8 ] ; int8_T msubspace_data [ 36 ] ;
int8_T tmp [ 6 ] ; boolean_T b_bool ; static const char_T tmp_p [ 5 ] = { 'B'
, 'o' , 'd' , 'y' , '3' } ; static const real_T tmp_e [ 9 ] = {
0.00048193525831480939 , 1.1944093883727363E-10 , - 6.2658506159853219E-11 ,
1.1944093883727363E-10 , 0.00030522145092060006 , - 0.00011300338668685345 ,
- 6.2658506159853219E-11 , - 0.00011300338668685345 , 0.00023825592973021332
} ; static const real_T tmp_i [ 36 ] = { 0.00048193525831480939 ,
1.1944093883727363E-10 , - 6.2658506159853219E-11 , 0.0 ,
0.005222002231897436 , - 0.0022600754799565618 , 1.1944093883727363E-10 ,
0.00030522145092060006 , - 0.00011300338668685345 , - 0.005222002231897436 ,
0.0 , 2.9210674086135609E-9 , - 6.2658506159853219E-11 , -
0.00011300338668685345 , 0.00023825592973021332 , 0.0022600754799565618 , -
2.9210674086135609E-9 , 0.0 , 0.0 , - 0.005222002231897436 ,
0.0022600754799565618 , 0.12014630900663614 , 0.0 , 0.0 ,
0.005222002231897436 , 0.0 , - 2.9210674086135609E-9 , 0.0 ,
0.12014630900663614 , 0.0 , - 0.0022600754799565618 , 2.9210674086135609E-9 ,
0.0 , 0.0 , 0.0 , 0.12014630900663614 } ; static const int8_T tmp_m [ 16 ] =
{ 1 , 0 , 0 , 0 , 0 , 1 , 0 , 0 , 0 , 0 , 1 , 0 , 0 , 0 , 0 , 1 } ; static
const char_T tmp_g [ 6 ] = { 'J' , 'o' , 'i' , 'n' , 't' , '3' } ; static
const char_T tmp_j [ 8 ] = { 'r' , 'e' , 'v' , 'o' , 'l' , 'u' , 't' , 'e' }
; static const char_T tmp_f [ 9 ] = { 'p' , 'r' , 'i' , 's' , 'm' , 'a' , 't'
, 'i' , 'c' } ; static const real_T tmp_c [ 16 ] = { 6.123233995736766E-17 ,
0.0 , - 1.0 , 0.0 , - 1.0 , - 1.6081226496766366E-16 , -
6.123233995736766E-17 , 0.0 , - 1.6081226496766366E-16 , 1.0 , -
9.8469112778142665E-33 , 0.0 , - 5.5511151231257827E-17 , -
0.12964538766168227 , 0.20102726089780065 , 1.0 } ; static const real_T tmp_k
[ 16 ] = { 1.0 , 0.0 , 0.0 , 0.0 , 0.0 , 1.0 , 0.0 , 0.0 , 0.0 , 0.0 , 1.0 ,
0.0 , 0.0 , 0.0 , 0.0 , 1.0 } ; static const real_T tmp_b [ 36 ] = { 0.0 ,
0.0 , 1.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 ,
0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 ,
0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 } ; int32_T exitg1 ;
b_obj = obj ; b_kstr = obj -> NameInternal -> size [ 0 ] * obj ->
NameInternal -> size [ 1 ] ; obj -> NameInternal -> size [ 0 ] = 1 ; obj ->
NameInternal -> size [ 1 ] = 5 ; ac0ugu5nlz ( obj -> NameInternal , b_kstr )
; for ( b_kstr = 0 ; b_kstr < 5 ; b_kstr ++ ) { obj -> NameInternal -> data [
b_kstr ] = tmp_p [ b_kstr ] ; } obj -> ParentIndex = 2.0 ; obj ->
MassInternal = 0.12014630900663614 ; obj -> CenterOfMassInternal [ 0 ] = -
2.4312585486518934E-8 ; obj -> CenterOfMassInternal [ 1 ] = -
0.018811027143844503 ; obj -> CenterOfMassInternal [ 2 ] = -
0.043463692518502628 ; for ( b_kstr = 0 ; b_kstr < 9 ; b_kstr ++ ) { obj ->
InertiaInternal [ b_kstr ] = tmp_e [ b_kstr ] ; } for ( b_kstr = 0 ; b_kstr <
36 ; b_kstr ++ ) { obj -> SpatialInertia [ b_kstr ] = tmp_i [ b_kstr ] ; }
iobj_1 -> InTree = false ; for ( b_kstr = 0 ; b_kstr < 16 ; b_kstr ++ ) {
iobj_1 -> JointToParentTransform [ b_kstr ] = tmp_m [ b_kstr ] ; } for (
b_kstr = 0 ; b_kstr < 16 ; b_kstr ++ ) { iobj_1 -> ChildToJointTransform [
b_kstr ] = tmp_m [ b_kstr ] ; } b_kstr = iobj_1 -> NameInternal -> size [ 0 ]
* iobj_1 -> NameInternal -> size [ 1 ] ; iobj_1 -> NameInternal -> size [ 0 ]
= 1 ; iobj_1 -> NameInternal -> size [ 1 ] = 6 ; ac0ugu5nlz ( iobj_1 ->
NameInternal , b_kstr ) ; for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr ++ ) {
iobj_1 -> NameInternal -> data [ b_kstr ] = tmp_g [ b_kstr ] ; } b_kstr =
iobj_1 -> Type -> size [ 0 ] * iobj_1 -> Type -> size [ 1 ] ; iobj_1 -> Type
-> size [ 0 ] = 1 ; iobj_1 -> Type -> size [ 1 ] = 8 ; ac0ugu5nlz ( iobj_1 ->
Type , b_kstr ) ; for ( b_kstr = 0 ; b_kstr < 8 ; b_kstr ++ ) { iobj_1 ->
Type -> data [ b_kstr ] = tmp_j [ b_kstr ] ; } gunzkbl0qg ( &
switch_expression , 2 ) ; b_kstr = switch_expression -> size [ 0 ] *
switch_expression -> size [ 1 ] ; switch_expression -> size [ 0 ] = 1 ;
switch_expression -> size [ 1 ] = iobj_1 -> Type -> size [ 1 ] ; ac0ugu5nlz (
switch_expression , b_kstr ) ; loop_ub = iobj_1 -> Type -> size [ 1 ] - 1 ;
for ( b_kstr = 0 ; b_kstr <= loop_ub ; b_kstr ++ ) { switch_expression ->
data [ b_kstr ] = iobj_1 -> Type -> data [ b_kstr ] ; } for ( b_kstr = 0 ;
b_kstr < 8 ; b_kstr ++ ) { b [ b_kstr ] = tmp_j [ b_kstr ] ; } b_bool = false
; if ( switch_expression -> size [ 1 ] != 8 ) { } else { b_kstr = 1 ; do {
exitg1 = 0 ; if ( b_kstr - 1 < 8 ) { if ( switch_expression -> data [ b_kstr
- 1 ] != b [ b_kstr - 1 ] ) { exitg1 = 1 ; } else { b_kstr ++ ; } } else {
b_bool = true ; exitg1 = 1 ; } } while ( exitg1 == 0 ) ; } if ( b_bool ) {
b_kstr = 0 ; } else { for ( b_kstr = 0 ; b_kstr < 9 ; b_kstr ++ ) { b_p [
b_kstr ] = tmp_f [ b_kstr ] ; } if ( switch_expression -> size [ 1 ] != 9 ) {
} else { b_kstr = 1 ; do { exitg1 = 0 ; if ( b_kstr - 1 < 9 ) { if (
switch_expression -> data [ b_kstr - 1 ] != b_p [ b_kstr - 1 ] ) { exitg1 = 1
; } else { b_kstr ++ ; } } else { b_bool = true ; exitg1 = 1 ; } } while (
exitg1 == 0 ) ; } if ( b_bool ) { b_kstr = 1 ; } else { b_kstr = - 1 ; } }
b0l0vcvht3 ( & switch_expression ) ; switch ( b_kstr ) { case 0 : tmp [ 0 ] =
0 ; tmp [ 1 ] = 0 ; tmp [ 2 ] = 1 ; tmp [ 3 ] = 0 ; tmp [ 4 ] = 0 ; tmp [ 5 ]
= 0 ; for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr ++ ) { msubspace_data [ b_kstr ]
= tmp [ b_kstr ] ; } poslim_data [ 0 ] = - 3.1415926535897931 ; poslim_data [
1 ] = 3.1415926535897931 ; iobj_1 -> VelocityNumber = 1.0 ; iobj_1 ->
PositionNumber = 1.0 ; iobj_1 -> JointAxisInternal [ 0 ] = 0.0 ; iobj_1 ->
JointAxisInternal [ 1 ] = 0.0 ; iobj_1 -> JointAxisInternal [ 2 ] = 1.0 ;
break ; case 1 : tmp [ 0 ] = 0 ; tmp [ 1 ] = 0 ; tmp [ 2 ] = 0 ; tmp [ 3 ] =
0 ; tmp [ 4 ] = 0 ; tmp [ 5 ] = 1 ; for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr ++
) { msubspace_data [ b_kstr ] = tmp [ b_kstr ] ; } poslim_data [ 0 ] = - 0.5
; poslim_data [ 1 ] = 0.5 ; iobj_1 -> VelocityNumber = 1.0 ; iobj_1 ->
PositionNumber = 1.0 ; iobj_1 -> JointAxisInternal [ 0 ] = 0.0 ; iobj_1 ->
JointAxisInternal [ 1 ] = 0.0 ; iobj_1 -> JointAxisInternal [ 2 ] = 1.0 ;
break ; default : for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr ++ ) {
msubspace_data [ b_kstr ] = 0 ; } poslim_data [ 0 ] = 0.0 ; poslim_data [ 1 ]
= 0.0 ; iobj_1 -> VelocityNumber = 0.0 ; iobj_1 -> PositionNumber = 0.0 ;
iobj_1 -> JointAxisInternal [ 0 ] = 0.0 ; iobj_1 -> JointAxisInternal [ 1 ] =
0.0 ; iobj_1 -> JointAxisInternal [ 2 ] = 0.0 ; break ; } b_kstr = iobj_1 ->
MotionSubspace -> size [ 0 ] * iobj_1 -> MotionSubspace -> size [ 1 ] ;
iobj_1 -> MotionSubspace -> size [ 0 ] = 6 ; iobj_1 -> MotionSubspace -> size
[ 1 ] = 1 ; ier0p3wwtw ( iobj_1 -> MotionSubspace , b_kstr ) ; for ( b_kstr =
0 ; b_kstr < 6 ; b_kstr ++ ) { iobj_1 -> MotionSubspace -> data [ b_kstr ] =
msubspace_data [ b_kstr ] ; } b_kstr = iobj_1 -> PositionLimitsInternal ->
size [ 0 ] * iobj_1 -> PositionLimitsInternal -> size [ 1 ] ; iobj_1 ->
PositionLimitsInternal -> size [ 0 ] = 1 ; iobj_1 -> PositionLimitsInternal
-> size [ 1 ] = 2 ; ier0p3wwtw ( iobj_1 -> PositionLimitsInternal , b_kstr )
; for ( b_kstr = 0 ; b_kstr < 2 ; b_kstr ++ ) { iobj_1 ->
PositionLimitsInternal -> data [ b_kstr ] = poslim_data [ b_kstr ] ; } b_kstr
= iobj_1 -> HomePositionInternal -> size [ 0 ] ; iobj_1 ->
HomePositionInternal -> size [ 0 ] = 1 ; ier0p3wwtw ( iobj_1 ->
HomePositionInternal , b_kstr ) ; iobj_1 -> HomePositionInternal -> data [ 0
] = 0.0 ; obj -> JointInternal = iobj_1 ; for ( b_kstr = 0 ; b_kstr < 16 ;
b_kstr ++ ) { obj -> JointInternal -> JointToParentTransform [ b_kstr ] =
tmp_c [ b_kstr ] ; } for ( b_kstr = 0 ; b_kstr < 16 ; b_kstr ++ ) { obj ->
JointInternal -> ChildToJointTransform [ b_kstr ] = tmp_k [ b_kstr ] ; }
b_kstr = obj -> JointInternal -> MotionSubspace -> size [ 0 ] * obj ->
JointInternal -> MotionSubspace -> size [ 1 ] ; obj -> JointInternal ->
MotionSubspace -> size [ 0 ] = 6 ; obj -> JointInternal -> MotionSubspace ->
size [ 1 ] = 1 ; ier0p3wwtw ( obj -> JointInternal -> MotionSubspace , b_kstr
) ; for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr ++ ) { obj -> JointInternal ->
MotionSubspace -> data [ b_kstr ] = tmp_b [ b_kstr ] ; } obj -> JointInternal
-> InTree = true ; b_kstr = obj -> JointInternal -> PositionLimitsInternal ->
size [ 0 ] * obj -> JointInternal -> PositionLimitsInternal -> size [ 1 ] ;
obj -> JointInternal -> PositionLimitsInternal -> size [ 0 ] = 1 ; obj ->
JointInternal -> PositionLimitsInternal -> size [ 1 ] = 2 ; ier0p3wwtw ( obj
-> JointInternal -> PositionLimitsInternal , b_kstr ) ; obj -> JointInternal
-> PositionLimitsInternal -> data [ 0 ] = - 3.1415926535897931 ; obj ->
JointInternal -> PositionLimitsInternal -> data [ obj -> JointInternal ->
PositionLimitsInternal -> size [ 0 ] ] = 3.1415926535897931 ; obj ->
JointInternal -> JointAxisInternal [ 0 ] = 0.0 ; obj -> JointInternal ->
JointAxisInternal [ 1 ] = 0.0 ; obj -> JointInternal -> JointAxisInternal [ 2
] = 1.0 ; b_kstr = obj -> JointInternal -> HomePositionInternal -> size [ 0 ]
; obj -> JointInternal -> HomePositionInternal -> size [ 0 ] = 1 ; ier0p3wwtw
( obj -> JointInternal -> HomePositionInternal , b_kstr ) ; obj ->
JointInternal -> HomePositionInternal -> data [ 0 ] = - 1.9151863819270278 ;
obj -> CollisionsInternal = aydneur4h5so ( iobj_0 , 0.0 ) ; return b_obj ; }
static gxcsgl11sl35 * hi1fv3qgyp ( gxcsgl11sl35 * obj , gtd4jhsf2rw * iobj_0
, iyg0swfnbfoc * iobj_1 ) { e2b0f4s35s * switch_expression ; gxcsgl11sl35 *
b_obj ; real_T poslim_data [ 12 ] ; int32_T b_kstr ; int32_T loop_ub ; char_T
b_p [ 9 ] ; char_T b [ 8 ] ; int8_T msubspace_data [ 36 ] ; int8_T tmp [ 6 ]
; boolean_T b_bool ; static const char_T tmp_p [ 5 ] = { 'B' , 'o' , 'd' ,
'y' , '4' } ; static const real_T tmp_e [ 9 ] = { 0.0061470676990103565 , -
1.1369853105127018E-11 , 0.00021083847265506637 , - 1.1369853105127018E-11 ,
0.0061767884361518819 , 1.4951174649514462E-10 , 0.00021083847265506637 ,
1.4951174649514462E-10 , 6.2747279453924073E-5 } ; static const real_T tmp_i
[ 36 ] = { 0.0061470676990103565 , - 1.1369853105127018E-11 ,
0.00021083847265506637 , 0.0 , - 0.025864138734936881 , -
6.2317092946633816E-10 , - 1.1369853105127018E-11 , 0.0061767884361518819 ,
1.4951174649514462E-10 , 0.025864138734936881 , 0.0 , 0.000803059428615373 ,
0.00021083847265506637 , 1.4951174649514462E-10 , 6.2747279453924073E-5 ,
6.2317092946633816E-10 , - 0.000803059428615373 , 0.0 , 0.0 ,
0.025864138734936881 , 6.2317092946633816E-10 , 0.11424153504112755 , 0.0 ,
0.0 , - 0.025864138734936881 , 0.0 , - 0.000803059428615373 , 0.0 ,
0.11424153504112755 , 0.0 , - 6.2317092946633816E-10 , 0.000803059428615373 ,
0.0 , 0.0 , 0.0 , 0.11424153504112755 } ; static const int8_T tmp_m [ 16 ] =
{ 1 , 0 , 0 , 0 , 0 , 1 , 0 , 0 , 0 , 0 , 1 , 0 , 0 , 0 , 0 , 1 } ; static
const char_T tmp_g [ 6 ] = { 'J' , 'o' , 'i' , 'n' , 't' , '4' } ; static
const char_T tmp_j [ 8 ] = { 'r' , 'e' , 'v' , 'o' , 'l' , 'u' , 't' , 'e' }
; static const char_T tmp_f [ 9 ] = { 'p' , 'r' , 'i' , 's' , 'm' , 'a' , 't'
, 'i' , 'c' } ; static const real_T tmp_c [ 16 ] = { 6.123233995736766E-17 ,
0.0 , - 1.0 , 0.0 , 1.0 , 9.4941075965749281E-16 , 6.123233995736766E-17 ,
0.0 , 9.4941075965749281E-16 , - 1.0 , 5.8134642394530281E-32 , 0.0 , -
1.3877787807814457E-16 , 0.038414905179222407 , - 0.050000000000000447 , 1.0
} ; static const real_T tmp_k [ 16 ] = { 1.0 , 0.0 , 0.0 , 0.0 , 0.0 , 1.0 ,
0.0 , 0.0 , 0.0 , 0.0 , 1.0 , 0.0 , 0.0 , 0.0 , 0.0 , 1.0 } ; static const
real_T tmp_b [ 36 ] = { 0.0 , 0.0 , 1.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 ,
0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 ,
0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 ,
0.0 } ; int32_T exitg1 ; b_obj = obj ; b_kstr = obj -> NameInternal -> size [
0 ] * obj -> NameInternal -> size [ 1 ] ; obj -> NameInternal -> size [ 0 ] =
1 ; obj -> NameInternal -> size [ 1 ] = 5 ; ac0ugu5nlz ( obj -> NameInternal
, b_kstr ) ; for ( b_kstr = 0 ; b_kstr < 5 ; b_kstr ++ ) { obj ->
NameInternal -> data [ b_kstr ] = tmp_p [ b_kstr ] ; } obj -> ParentIndex =
3.0 ; obj -> MassInternal = 0.11424153504112755 ; obj -> CenterOfMassInternal
[ 0 ] = - 0.0070294873780036952 ; obj -> CenterOfMassInternal [ 1 ] = -
5.4548543070783613E-9 ; obj -> CenterOfMassInternal [ 2 ] =
0.22639873252425796 ; for ( b_kstr = 0 ; b_kstr < 9 ; b_kstr ++ ) { obj ->
InertiaInternal [ b_kstr ] = tmp_e [ b_kstr ] ; } for ( b_kstr = 0 ; b_kstr <
36 ; b_kstr ++ ) { obj -> SpatialInertia [ b_kstr ] = tmp_i [ b_kstr ] ; }
iobj_1 -> InTree = false ; for ( b_kstr = 0 ; b_kstr < 16 ; b_kstr ++ ) {
iobj_1 -> JointToParentTransform [ b_kstr ] = tmp_m [ b_kstr ] ; } for (
b_kstr = 0 ; b_kstr < 16 ; b_kstr ++ ) { iobj_1 -> ChildToJointTransform [
b_kstr ] = tmp_m [ b_kstr ] ; } b_kstr = iobj_1 -> NameInternal -> size [ 0 ]
* iobj_1 -> NameInternal -> size [ 1 ] ; iobj_1 -> NameInternal -> size [ 0 ]
= 1 ; iobj_1 -> NameInternal -> size [ 1 ] = 6 ; ac0ugu5nlz ( iobj_1 ->
NameInternal , b_kstr ) ; for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr ++ ) {
iobj_1 -> NameInternal -> data [ b_kstr ] = tmp_g [ b_kstr ] ; } b_kstr =
iobj_1 -> Type -> size [ 0 ] * iobj_1 -> Type -> size [ 1 ] ; iobj_1 -> Type
-> size [ 0 ] = 1 ; iobj_1 -> Type -> size [ 1 ] = 8 ; ac0ugu5nlz ( iobj_1 ->
Type , b_kstr ) ; for ( b_kstr = 0 ; b_kstr < 8 ; b_kstr ++ ) { iobj_1 ->
Type -> data [ b_kstr ] = tmp_j [ b_kstr ] ; } gunzkbl0qg ( &
switch_expression , 2 ) ; b_kstr = switch_expression -> size [ 0 ] *
switch_expression -> size [ 1 ] ; switch_expression -> size [ 0 ] = 1 ;
switch_expression -> size [ 1 ] = iobj_1 -> Type -> size [ 1 ] ; ac0ugu5nlz (
switch_expression , b_kstr ) ; loop_ub = iobj_1 -> Type -> size [ 1 ] - 1 ;
for ( b_kstr = 0 ; b_kstr <= loop_ub ; b_kstr ++ ) { switch_expression ->
data [ b_kstr ] = iobj_1 -> Type -> data [ b_kstr ] ; } for ( b_kstr = 0 ;
b_kstr < 8 ; b_kstr ++ ) { b [ b_kstr ] = tmp_j [ b_kstr ] ; } b_bool = false
; if ( switch_expression -> size [ 1 ] != 8 ) { } else { b_kstr = 1 ; do {
exitg1 = 0 ; if ( b_kstr - 1 < 8 ) { if ( switch_expression -> data [ b_kstr
- 1 ] != b [ b_kstr - 1 ] ) { exitg1 = 1 ; } else { b_kstr ++ ; } } else {
b_bool = true ; exitg1 = 1 ; } } while ( exitg1 == 0 ) ; } if ( b_bool ) {
b_kstr = 0 ; } else { for ( b_kstr = 0 ; b_kstr < 9 ; b_kstr ++ ) { b_p [
b_kstr ] = tmp_f [ b_kstr ] ; } if ( switch_expression -> size [ 1 ] != 9 ) {
} else { b_kstr = 1 ; do { exitg1 = 0 ; if ( b_kstr - 1 < 9 ) { if (
switch_expression -> data [ b_kstr - 1 ] != b_p [ b_kstr - 1 ] ) { exitg1 = 1
; } else { b_kstr ++ ; } } else { b_bool = true ; exitg1 = 1 ; } } while (
exitg1 == 0 ) ; } if ( b_bool ) { b_kstr = 1 ; } else { b_kstr = - 1 ; } }
b0l0vcvht3 ( & switch_expression ) ; switch ( b_kstr ) { case 0 : tmp [ 0 ] =
0 ; tmp [ 1 ] = 0 ; tmp [ 2 ] = 1 ; tmp [ 3 ] = 0 ; tmp [ 4 ] = 0 ; tmp [ 5 ]
= 0 ; for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr ++ ) { msubspace_data [ b_kstr ]
= tmp [ b_kstr ] ; } poslim_data [ 0 ] = - 3.1415926535897931 ; poslim_data [
1 ] = 3.1415926535897931 ; iobj_1 -> VelocityNumber = 1.0 ; iobj_1 ->
PositionNumber = 1.0 ; iobj_1 -> JointAxisInternal [ 0 ] = 0.0 ; iobj_1 ->
JointAxisInternal [ 1 ] = 0.0 ; iobj_1 -> JointAxisInternal [ 2 ] = 1.0 ;
break ; case 1 : tmp [ 0 ] = 0 ; tmp [ 1 ] = 0 ; tmp [ 2 ] = 0 ; tmp [ 3 ] =
0 ; tmp [ 4 ] = 0 ; tmp [ 5 ] = 1 ; for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr ++
) { msubspace_data [ b_kstr ] = tmp [ b_kstr ] ; } poslim_data [ 0 ] = - 0.5
; poslim_data [ 1 ] = 0.5 ; iobj_1 -> VelocityNumber = 1.0 ; iobj_1 ->
PositionNumber = 1.0 ; iobj_1 -> JointAxisInternal [ 0 ] = 0.0 ; iobj_1 ->
JointAxisInternal [ 1 ] = 0.0 ; iobj_1 -> JointAxisInternal [ 2 ] = 1.0 ;
break ; default : for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr ++ ) {
msubspace_data [ b_kstr ] = 0 ; } poslim_data [ 0 ] = 0.0 ; poslim_data [ 1 ]
= 0.0 ; iobj_1 -> VelocityNumber = 0.0 ; iobj_1 -> PositionNumber = 0.0 ;
iobj_1 -> JointAxisInternal [ 0 ] = 0.0 ; iobj_1 -> JointAxisInternal [ 1 ] =
0.0 ; iobj_1 -> JointAxisInternal [ 2 ] = 0.0 ; break ; } b_kstr = iobj_1 ->
MotionSubspace -> size [ 0 ] * iobj_1 -> MotionSubspace -> size [ 1 ] ;
iobj_1 -> MotionSubspace -> size [ 0 ] = 6 ; iobj_1 -> MotionSubspace -> size
[ 1 ] = 1 ; ier0p3wwtw ( iobj_1 -> MotionSubspace , b_kstr ) ; for ( b_kstr =
0 ; b_kstr < 6 ; b_kstr ++ ) { iobj_1 -> MotionSubspace -> data [ b_kstr ] =
msubspace_data [ b_kstr ] ; } b_kstr = iobj_1 -> PositionLimitsInternal ->
size [ 0 ] * iobj_1 -> PositionLimitsInternal -> size [ 1 ] ; iobj_1 ->
PositionLimitsInternal -> size [ 0 ] = 1 ; iobj_1 -> PositionLimitsInternal
-> size [ 1 ] = 2 ; ier0p3wwtw ( iobj_1 -> PositionLimitsInternal , b_kstr )
; for ( b_kstr = 0 ; b_kstr < 2 ; b_kstr ++ ) { iobj_1 ->
PositionLimitsInternal -> data [ b_kstr ] = poslim_data [ b_kstr ] ; } b_kstr
= iobj_1 -> HomePositionInternal -> size [ 0 ] ; iobj_1 ->
HomePositionInternal -> size [ 0 ] = 1 ; ier0p3wwtw ( iobj_1 ->
HomePositionInternal , b_kstr ) ; iobj_1 -> HomePositionInternal -> data [ 0
] = 0.0 ; obj -> JointInternal = iobj_1 ; for ( b_kstr = 0 ; b_kstr < 16 ;
b_kstr ++ ) { obj -> JointInternal -> JointToParentTransform [ b_kstr ] =
tmp_c [ b_kstr ] ; } for ( b_kstr = 0 ; b_kstr < 16 ; b_kstr ++ ) { obj ->
JointInternal -> ChildToJointTransform [ b_kstr ] = tmp_k [ b_kstr ] ; }
b_kstr = obj -> JointInternal -> MotionSubspace -> size [ 0 ] * obj ->
JointInternal -> MotionSubspace -> size [ 1 ] ; obj -> JointInternal ->
MotionSubspace -> size [ 0 ] = 6 ; obj -> JointInternal -> MotionSubspace ->
size [ 1 ] = 1 ; ier0p3wwtw ( obj -> JointInternal -> MotionSubspace , b_kstr
) ; for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr ++ ) { obj -> JointInternal ->
MotionSubspace -> data [ b_kstr ] = tmp_b [ b_kstr ] ; } obj -> JointInternal
-> InTree = true ; b_kstr = obj -> JointInternal -> PositionLimitsInternal ->
size [ 0 ] * obj -> JointInternal -> PositionLimitsInternal -> size [ 1 ] ;
obj -> JointInternal -> PositionLimitsInternal -> size [ 0 ] = 1 ; obj ->
JointInternal -> PositionLimitsInternal -> size [ 1 ] = 2 ; ier0p3wwtw ( obj
-> JointInternal -> PositionLimitsInternal , b_kstr ) ; obj -> JointInternal
-> PositionLimitsInternal -> data [ 0 ] = - 3.1415926535897931 ; obj ->
JointInternal -> PositionLimitsInternal -> data [ obj -> JointInternal ->
PositionLimitsInternal -> size [ 0 ] ] = 3.1415926535897931 ; obj ->
JointInternal -> JointAxisInternal [ 0 ] = 0.0 ; obj -> JointInternal ->
JointAxisInternal [ 1 ] = 0.0 ; obj -> JointInternal -> JointAxisInternal [ 2
] = 1.0 ; b_kstr = obj -> JointInternal -> HomePositionInternal -> size [ 0 ]
; obj -> JointInternal -> HomePositionInternal -> size [ 0 ] = 1 ; ier0p3wwtw
( obj -> JointInternal -> HomePositionInternal , b_kstr ) ; obj ->
JointInternal -> HomePositionInternal -> data [ 0 ] = 0.072381728460883 ; obj
-> CollisionsInternal = aydneur4h5so ( iobj_0 , 0.0 ) ; return b_obj ; }
static gxcsgl11sl35 * hgxe0mqtnx ( gxcsgl11sl35 * obj , gtd4jhsf2rw * iobj_0
, iyg0swfnbfoc * iobj_1 ) { e2b0f4s35s * switch_expression ; gxcsgl11sl35 *
b_obj ; real_T poslim_data [ 12 ] ; int32_T b_kstr ; int32_T loop_ub ; char_T
b_p [ 9 ] ; char_T b [ 8 ] ; int8_T msubspace_data [ 36 ] ; int8_T tmp [ 6 ]
; boolean_T b_bool ; static const char_T tmp_p [ 5 ] = { 'B' , 'o' , 'd' ,
'y' , '5' } ; static const real_T tmp_e [ 9 ] = { 2.9592973804081925E-5 ,
5.5506574343527351E-10 , 3.9747839403552309E-8 , 5.5506574343527351E-10 ,
2.9904535545232642E-5 , - 5.4271892835393152E-10 , 3.9747839403552309E-8 , -
5.4271892835393152E-10 , 8.039035682334612E-6 } ; static const real_T tmp_i [
36 ] = { 2.9592973804081925E-5 , 5.5506574343527351E-10 ,
3.9747839403552309E-8 , 0.0 , - 0.00074462040130163828 ,
1.6413899336396969E-8 , 5.5506574343527351E-10 , 2.9904535545232642E-5 , -
5.4271892835393152E-10 , 0.00074462040130163828 , 0.0 , 9.4357542984962823E-7
, 3.9747839403552309E-8 , - 5.4271892835393152E-10 , 8.039035682334612E-6 , -
1.6413899336396969E-8 , - 9.4357542984962823E-7 , 0.0 , 0.0 ,
0.00074462040130163828 , - 1.6413899336396969E-8 , 0.027739437080711832 , 0.0
, 0.0 , - 0.00074462040130163828 , 0.0 , - 9.4357542984962823E-7 , 0.0 ,
0.027739437080711832 , 0.0 , 1.6413899336396969E-8 , 9.4357542984962823E-7 ,
0.0 , 0.0 , 0.0 , 0.027739437080711832 } ; static const int8_T tmp_m [ 16 ] =
{ 1 , 0 , 0 , 0 , 0 , 1 , 0 , 0 , 0 , 0 , 1 , 0 , 0 , 0 , 0 , 1 } ; static
const char_T tmp_g [ 6 ] = { 'J' , 'o' , 'i' , 'n' , 't' , '5' } ; static
const char_T tmp_j [ 8 ] = { 'r' , 'e' , 'v' , 'o' , 'l' , 'u' , 't' , 'e' }
; static const char_T tmp_f [ 9 ] = { 'p' , 'r' , 'i' , 's' , 'm' , 'a' , 't'
, 'i' , 'c' } ; static const real_T tmp_c [ 16 ] = { 6.123233995736766E-17 ,
- 1.0 , - 0.0 , 0.0 , 6.123233995736766E-17 , 3.749399456654644E-33 , 1.0 ,
0.0 , - 1.0 , - 6.123233995736766E-17 , 6.123233995736766E-17 , 0.0 , -
0.056650758675274054 , 3.4220484771503661E-16 , 0.26254402400728288 , 1.0 } ;
static const real_T tmp_k [ 16 ] = { 1.0 , 0.0 , 0.0 , 0.0 , 0.0 , 1.0 , 0.0
, 0.0 , 0.0 , 0.0 , 1.0 , 0.0 , 0.0 , 0.0 , 0.0 , 1.0 } ; static const real_T
tmp_b [ 36 ] = { 0.0 , 0.0 , 1.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 ,
0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 ,
0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 }
; int32_T exitg1 ; b_obj = obj ; b_kstr = obj -> NameInternal -> size [ 0 ] *
obj -> NameInternal -> size [ 1 ] ; obj -> NameInternal -> size [ 0 ] = 1 ;
obj -> NameInternal -> size [ 1 ] = 5 ; ac0ugu5nlz ( obj -> NameInternal ,
b_kstr ) ; for ( b_kstr = 0 ; b_kstr < 5 ; b_kstr ++ ) { obj -> NameInternal
-> data [ b_kstr ] = tmp_p [ b_kstr ] ; } obj -> ParentIndex = 4.0 ; obj ->
MassInternal = 0.027739437080711832 ; obj -> CenterOfMassInternal [ 0 ] = -
3.4015666111181762E-5 ; obj -> CenterOfMassInternal [ 1 ] =
5.9171710257271622E-7 ; obj -> CenterOfMassInternal [ 2 ] =
0.026843385434789445 ; for ( b_kstr = 0 ; b_kstr < 9 ; b_kstr ++ ) { obj ->
InertiaInternal [ b_kstr ] = tmp_e [ b_kstr ] ; } for ( b_kstr = 0 ; b_kstr <
36 ; b_kstr ++ ) { obj -> SpatialInertia [ b_kstr ] = tmp_i [ b_kstr ] ; }
iobj_1 -> InTree = false ; for ( b_kstr = 0 ; b_kstr < 16 ; b_kstr ++ ) {
iobj_1 -> JointToParentTransform [ b_kstr ] = tmp_m [ b_kstr ] ; } for (
b_kstr = 0 ; b_kstr < 16 ; b_kstr ++ ) { iobj_1 -> ChildToJointTransform [
b_kstr ] = tmp_m [ b_kstr ] ; } b_kstr = iobj_1 -> NameInternal -> size [ 0 ]
* iobj_1 -> NameInternal -> size [ 1 ] ; iobj_1 -> NameInternal -> size [ 0 ]
= 1 ; iobj_1 -> NameInternal -> size [ 1 ] = 6 ; ac0ugu5nlz ( iobj_1 ->
NameInternal , b_kstr ) ; for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr ++ ) {
iobj_1 -> NameInternal -> data [ b_kstr ] = tmp_g [ b_kstr ] ; } b_kstr =
iobj_1 -> Type -> size [ 0 ] * iobj_1 -> Type -> size [ 1 ] ; iobj_1 -> Type
-> size [ 0 ] = 1 ; iobj_1 -> Type -> size [ 1 ] = 8 ; ac0ugu5nlz ( iobj_1 ->
Type , b_kstr ) ; for ( b_kstr = 0 ; b_kstr < 8 ; b_kstr ++ ) { iobj_1 ->
Type -> data [ b_kstr ] = tmp_j [ b_kstr ] ; } gunzkbl0qg ( &
switch_expression , 2 ) ; b_kstr = switch_expression -> size [ 0 ] *
switch_expression -> size [ 1 ] ; switch_expression -> size [ 0 ] = 1 ;
switch_expression -> size [ 1 ] = iobj_1 -> Type -> size [ 1 ] ; ac0ugu5nlz (
switch_expression , b_kstr ) ; loop_ub = iobj_1 -> Type -> size [ 1 ] - 1 ;
for ( b_kstr = 0 ; b_kstr <= loop_ub ; b_kstr ++ ) { switch_expression ->
data [ b_kstr ] = iobj_1 -> Type -> data [ b_kstr ] ; } for ( b_kstr = 0 ;
b_kstr < 8 ; b_kstr ++ ) { b [ b_kstr ] = tmp_j [ b_kstr ] ; } b_bool = false
; if ( switch_expression -> size [ 1 ] != 8 ) { } else { b_kstr = 1 ; do {
exitg1 = 0 ; if ( b_kstr - 1 < 8 ) { if ( switch_expression -> data [ b_kstr
- 1 ] != b [ b_kstr - 1 ] ) { exitg1 = 1 ; } else { b_kstr ++ ; } } else {
b_bool = true ; exitg1 = 1 ; } } while ( exitg1 == 0 ) ; } if ( b_bool ) {
b_kstr = 0 ; } else { for ( b_kstr = 0 ; b_kstr < 9 ; b_kstr ++ ) { b_p [
b_kstr ] = tmp_f [ b_kstr ] ; } if ( switch_expression -> size [ 1 ] != 9 ) {
} else { b_kstr = 1 ; do { exitg1 = 0 ; if ( b_kstr - 1 < 9 ) { if (
switch_expression -> data [ b_kstr - 1 ] != b_p [ b_kstr - 1 ] ) { exitg1 = 1
; } else { b_kstr ++ ; } } else { b_bool = true ; exitg1 = 1 ; } } while (
exitg1 == 0 ) ; } if ( b_bool ) { b_kstr = 1 ; } else { b_kstr = - 1 ; } }
b0l0vcvht3 ( & switch_expression ) ; switch ( b_kstr ) { case 0 : tmp [ 0 ] =
0 ; tmp [ 1 ] = 0 ; tmp [ 2 ] = 1 ; tmp [ 3 ] = 0 ; tmp [ 4 ] = 0 ; tmp [ 5 ]
= 0 ; for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr ++ ) { msubspace_data [ b_kstr ]
= tmp [ b_kstr ] ; } poslim_data [ 0 ] = - 3.1415926535897931 ; poslim_data [
1 ] = 3.1415926535897931 ; iobj_1 -> VelocityNumber = 1.0 ; iobj_1 ->
PositionNumber = 1.0 ; iobj_1 -> JointAxisInternal [ 0 ] = 0.0 ; iobj_1 ->
JointAxisInternal [ 1 ] = 0.0 ; iobj_1 -> JointAxisInternal [ 2 ] = 1.0 ;
break ; case 1 : tmp [ 0 ] = 0 ; tmp [ 1 ] = 0 ; tmp [ 2 ] = 0 ; tmp [ 3 ] =
0 ; tmp [ 4 ] = 0 ; tmp [ 5 ] = 1 ; for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr ++
) { msubspace_data [ b_kstr ] = tmp [ b_kstr ] ; } poslim_data [ 0 ] = - 0.5
; poslim_data [ 1 ] = 0.5 ; iobj_1 -> VelocityNumber = 1.0 ; iobj_1 ->
PositionNumber = 1.0 ; iobj_1 -> JointAxisInternal [ 0 ] = 0.0 ; iobj_1 ->
JointAxisInternal [ 1 ] = 0.0 ; iobj_1 -> JointAxisInternal [ 2 ] = 1.0 ;
break ; default : for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr ++ ) {
msubspace_data [ b_kstr ] = 0 ; } poslim_data [ 0 ] = 0.0 ; poslim_data [ 1 ]
= 0.0 ; iobj_1 -> VelocityNumber = 0.0 ; iobj_1 -> PositionNumber = 0.0 ;
iobj_1 -> JointAxisInternal [ 0 ] = 0.0 ; iobj_1 -> JointAxisInternal [ 1 ] =
0.0 ; iobj_1 -> JointAxisInternal [ 2 ] = 0.0 ; break ; } b_kstr = iobj_1 ->
MotionSubspace -> size [ 0 ] * iobj_1 -> MotionSubspace -> size [ 1 ] ;
iobj_1 -> MotionSubspace -> size [ 0 ] = 6 ; iobj_1 -> MotionSubspace -> size
[ 1 ] = 1 ; ier0p3wwtw ( iobj_1 -> MotionSubspace , b_kstr ) ; for ( b_kstr =
0 ; b_kstr < 6 ; b_kstr ++ ) { iobj_1 -> MotionSubspace -> data [ b_kstr ] =
msubspace_data [ b_kstr ] ; } b_kstr = iobj_1 -> PositionLimitsInternal ->
size [ 0 ] * iobj_1 -> PositionLimitsInternal -> size [ 1 ] ; iobj_1 ->
PositionLimitsInternal -> size [ 0 ] = 1 ; iobj_1 -> PositionLimitsInternal
-> size [ 1 ] = 2 ; ier0p3wwtw ( iobj_1 -> PositionLimitsInternal , b_kstr )
; for ( b_kstr = 0 ; b_kstr < 2 ; b_kstr ++ ) { iobj_1 ->
PositionLimitsInternal -> data [ b_kstr ] = poslim_data [ b_kstr ] ; } b_kstr
= iobj_1 -> HomePositionInternal -> size [ 0 ] ; iobj_1 ->
HomePositionInternal -> size [ 0 ] = 1 ; ier0p3wwtw ( iobj_1 ->
HomePositionInternal , b_kstr ) ; iobj_1 -> HomePositionInternal -> data [ 0
] = 0.0 ; obj -> JointInternal = iobj_1 ; for ( b_kstr = 0 ; b_kstr < 16 ;
b_kstr ++ ) { obj -> JointInternal -> JointToParentTransform [ b_kstr ] =
tmp_c [ b_kstr ] ; } for ( b_kstr = 0 ; b_kstr < 16 ; b_kstr ++ ) { obj ->
JointInternal -> ChildToJointTransform [ b_kstr ] = tmp_k [ b_kstr ] ; }
b_kstr = obj -> JointInternal -> MotionSubspace -> size [ 0 ] * obj ->
JointInternal -> MotionSubspace -> size [ 1 ] ; obj -> JointInternal ->
MotionSubspace -> size [ 0 ] = 6 ; obj -> JointInternal -> MotionSubspace ->
size [ 1 ] = 1 ; ier0p3wwtw ( obj -> JointInternal -> MotionSubspace , b_kstr
) ; for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr ++ ) { obj -> JointInternal ->
MotionSubspace -> data [ b_kstr ] = tmp_b [ b_kstr ] ; } obj -> JointInternal
-> InTree = true ; b_kstr = obj -> JointInternal -> PositionLimitsInternal ->
size [ 0 ] * obj -> JointInternal -> PositionLimitsInternal -> size [ 1 ] ;
obj -> JointInternal -> PositionLimitsInternal -> size [ 0 ] = 1 ; obj ->
JointInternal -> PositionLimitsInternal -> size [ 1 ] = 2 ; ier0p3wwtw ( obj
-> JointInternal -> PositionLimitsInternal , b_kstr ) ; obj -> JointInternal
-> PositionLimitsInternal -> data [ 0 ] = - 3.1415926535897931 ; obj ->
JointInternal -> PositionLimitsInternal -> data [ obj -> JointInternal ->
PositionLimitsInternal -> size [ 0 ] ] = 3.1415926535897931 ; obj ->
JointInternal -> JointAxisInternal [ 0 ] = 0.0 ; obj -> JointInternal ->
JointAxisInternal [ 1 ] = 0.0 ; obj -> JointInternal -> JointAxisInternal [ 2
] = 1.0 ; b_kstr = obj -> JointInternal -> HomePositionInternal -> size [ 0 ]
; obj -> JointInternal -> HomePositionInternal -> size [ 0 ] = 1 ; ier0p3wwtw
( obj -> JointInternal -> HomePositionInternal , b_kstr ) ; obj ->
JointInternal -> HomePositionInternal -> data [ 0 ] = - 0.649127250930941 ;
obj -> CollisionsInternal = aydneur4h5so ( iobj_0 , 0.0 ) ; return b_obj ; }
static iyg0swfnbfoc * j32lrgnqkz ( iyg0swfnbfoc * obj , const e2b0f4s35s *
jname ) { e2b0f4s35s * switch_expression ; iyg0swfnbfoc * b_obj ; real_T
poslim_data [ 12 ] ; int32_T b_kstr ; int32_T loop_ub ; char_T b_p [ 9 ] ;
char_T b [ 8 ] ; int8_T msubspace_data [ 36 ] ; int8_T tmp [ 6 ] ; boolean_T
b_bool ; static const int8_T tmp_p [ 16 ] = { 1 , 0 , 0 , 0 , 0 , 1 , 0 , 0 ,
0 , 0 , 1 , 0 , 0 , 0 , 0 , 1 } ; static const char_T tmp_e [ 5 ] = { 'f' ,
'i' , 'x' , 'e' , 'd' } ; static const char_T tmp_i [ 8 ] = { 'r' , 'e' , 'v'
, 'o' , 'l' , 'u' , 't' , 'e' } ; static const char_T tmp_m [ 9 ] = { 'p' ,
'r' , 'i' , 's' , 'm' , 'a' , 't' , 'i' , 'c' } ; int32_T exitg1 ; obj ->
InTree = false ; for ( b_kstr = 0 ; b_kstr < 16 ; b_kstr ++ ) { obj ->
JointToParentTransform [ b_kstr ] = tmp_p [ b_kstr ] ; } for ( b_kstr = 0 ;
b_kstr < 16 ; b_kstr ++ ) { obj -> ChildToJointTransform [ b_kstr ] = tmp_p [
b_kstr ] ; } b_obj = obj ; b_kstr = obj -> NameInternal -> size [ 0 ] * obj
-> NameInternal -> size [ 1 ] ; obj -> NameInternal -> size [ 0 ] = 1 ; obj
-> NameInternal -> size [ 1 ] = jname -> size [ 1 ] ; ac0ugu5nlz ( obj ->
NameInternal , b_kstr ) ; loop_ub = jname -> size [ 1 ] - 1 ; for ( b_kstr =
0 ; b_kstr <= loop_ub ; b_kstr ++ ) { obj -> NameInternal -> data [ b_kstr ]
= jname -> data [ b_kstr ] ; } b_kstr = obj -> Type -> size [ 0 ] * obj ->
Type -> size [ 1 ] ; obj -> Type -> size [ 0 ] = 1 ; obj -> Type -> size [ 1
] = 5 ; ac0ugu5nlz ( obj -> Type , b_kstr ) ; for ( b_kstr = 0 ; b_kstr < 5 ;
b_kstr ++ ) { obj -> Type -> data [ b_kstr ] = tmp_e [ b_kstr ] ; }
gunzkbl0qg ( & switch_expression , 2 ) ; b_kstr = switch_expression -> size [
0 ] * switch_expression -> size [ 1 ] ; switch_expression -> size [ 0 ] = 1 ;
switch_expression -> size [ 1 ] = obj -> Type -> size [ 1 ] ; ac0ugu5nlz (
switch_expression , b_kstr ) ; loop_ub = obj -> Type -> size [ 1 ] - 1 ; for
( b_kstr = 0 ; b_kstr <= loop_ub ; b_kstr ++ ) { switch_expression -> data [
b_kstr ] = obj -> Type -> data [ b_kstr ] ; } for ( b_kstr = 0 ; b_kstr < 8 ;
b_kstr ++ ) { b [ b_kstr ] = tmp_i [ b_kstr ] ; } b_bool = false ; if (
switch_expression -> size [ 1 ] != 8 ) { } else { b_kstr = 1 ; do { exitg1 =
0 ; if ( b_kstr - 1 < 8 ) { if ( switch_expression -> data [ b_kstr - 1 ] !=
b [ b_kstr - 1 ] ) { exitg1 = 1 ; } else { b_kstr ++ ; } } else { b_bool =
true ; exitg1 = 1 ; } } while ( exitg1 == 0 ) ; } if ( b_bool ) { b_kstr = 0
; } else { for ( b_kstr = 0 ; b_kstr < 9 ; b_kstr ++ ) { b_p [ b_kstr ] =
tmp_m [ b_kstr ] ; } if ( switch_expression -> size [ 1 ] != 9 ) { } else {
b_kstr = 1 ; do { exitg1 = 0 ; if ( b_kstr - 1 < 9 ) { if ( switch_expression
-> data [ b_kstr - 1 ] != b_p [ b_kstr - 1 ] ) { exitg1 = 1 ; } else { b_kstr
++ ; } } else { b_bool = true ; exitg1 = 1 ; } } while ( exitg1 == 0 ) ; } if
( b_bool ) { b_kstr = 1 ; } else { b_kstr = - 1 ; } } b0l0vcvht3 ( &
switch_expression ) ; switch ( b_kstr ) { case 0 : tmp [ 0 ] = 0 ; tmp [ 1 ]
= 0 ; tmp [ 2 ] = 1 ; tmp [ 3 ] = 0 ; tmp [ 4 ] = 0 ; tmp [ 5 ] = 0 ; for (
b_kstr = 0 ; b_kstr < 6 ; b_kstr ++ ) { msubspace_data [ b_kstr ] = tmp [
b_kstr ] ; } poslim_data [ 0 ] = - 3.1415926535897931 ; poslim_data [ 1 ] =
3.1415926535897931 ; obj -> VelocityNumber = 1.0 ; obj -> PositionNumber =
1.0 ; obj -> JointAxisInternal [ 0 ] = 0.0 ; obj -> JointAxisInternal [ 1 ] =
0.0 ; obj -> JointAxisInternal [ 2 ] = 1.0 ; break ; case 1 : tmp [ 0 ] = 0 ;
tmp [ 1 ] = 0 ; tmp [ 2 ] = 0 ; tmp [ 3 ] = 0 ; tmp [ 4 ] = 0 ; tmp [ 5 ] = 1
; for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr ++ ) { msubspace_data [ b_kstr ] =
tmp [ b_kstr ] ; } poslim_data [ 0 ] = - 0.5 ; poslim_data [ 1 ] = 0.5 ; obj
-> VelocityNumber = 1.0 ; obj -> PositionNumber = 1.0 ; obj ->
JointAxisInternal [ 0 ] = 0.0 ; obj -> JointAxisInternal [ 1 ] = 0.0 ; obj ->
JointAxisInternal [ 2 ] = 1.0 ; break ; default : for ( b_kstr = 0 ; b_kstr <
6 ; b_kstr ++ ) { msubspace_data [ b_kstr ] = 0 ; } poslim_data [ 0 ] = 0.0 ;
poslim_data [ 1 ] = 0.0 ; obj -> VelocityNumber = 0.0 ; obj -> PositionNumber
= 0.0 ; obj -> JointAxisInternal [ 0 ] = 0.0 ; obj -> JointAxisInternal [ 1 ]
= 0.0 ; obj -> JointAxisInternal [ 2 ] = 0.0 ; break ; } b_kstr = obj ->
MotionSubspace -> size [ 0 ] * obj -> MotionSubspace -> size [ 1 ] ; obj ->
MotionSubspace -> size [ 0 ] = 6 ; obj -> MotionSubspace -> size [ 1 ] = 1 ;
ier0p3wwtw ( obj -> MotionSubspace , b_kstr ) ; for ( b_kstr = 0 ; b_kstr < 6
; b_kstr ++ ) { obj -> MotionSubspace -> data [ b_kstr ] = msubspace_data [
b_kstr ] ; } b_kstr = obj -> PositionLimitsInternal -> size [ 0 ] * obj ->
PositionLimitsInternal -> size [ 1 ] ; obj -> PositionLimitsInternal -> size
[ 0 ] = 1 ; obj -> PositionLimitsInternal -> size [ 1 ] = 2 ; ier0p3wwtw (
obj -> PositionLimitsInternal , b_kstr ) ; for ( b_kstr = 0 ; b_kstr < 2 ;
b_kstr ++ ) { obj -> PositionLimitsInternal -> data [ b_kstr ] = poslim_data
[ b_kstr ] ; } b_kstr = obj -> HomePositionInternal -> size [ 0 ] ; obj ->
HomePositionInternal -> size [ 0 ] = 1 ; ier0p3wwtw ( obj ->
HomePositionInternal , b_kstr ) ; obj -> HomePositionInternal -> data [ 0 ] =
0.0 ; return b_obj ; } static void jywdovubw0d ( uint32_T mt [ 625 ] ,
uint32_T u [ 2 ] ) { int32_T b_j ; int32_T b_kk ; uint32_T mti ; uint32_T y ;
for ( b_j = 0 ; b_j < 2 ; b_j ++ ) { mti = mt [ 624 ] + 1U ; if ( mt [ 624 ]
+ 1U >= 625U ) { for ( b_kk = 0 ; b_kk < 227 ; b_kk ++ ) { y = ( mt [ b_kk +
1 ] & 2147483647U ) | ( mt [ b_kk ] & 2147483648U ) ; if ( ( y & 1U ) == 0U )
{ y >>= 1U ; } else { y = y >> 1U ^ 2567483615U ; } mt [ b_kk ] = mt [ b_kk +
397 ] ^ y ; } for ( b_kk = 0 ; b_kk < 396 ; b_kk ++ ) { y = ( mt [ b_kk + 227
] & 2147483648U ) | ( mt [ b_kk + 228 ] & 2147483647U ) ; if ( ( y & 1U ) ==
0U ) { y >>= 1U ; } else { y = y >> 1U ^ 2567483615U ; } mt [ b_kk + 227 ] =
mt [ b_kk ] ^ y ; } y = ( mt [ 623 ] & 2147483648U ) | ( mt [ 0 ] &
2147483647U ) ; if ( ( y & 1U ) == 0U ) { y >>= 1U ; } else { y = y >> 1U ^
2567483615U ; } mt [ 623 ] = mt [ 396 ] ^ y ; mti = 1U ; } y = mt [ ( int32_T
) mti - 1 ] ; mt [ 624 ] = mti ; y ^= y >> 11U ; y ^= y << 7U & 2636928640U ;
y ^= y << 15U & 4022730752U ; u [ b_j ] = y >> 18U ^ y ; } } static boolean_T
isihtjjmsz ( const uint32_T mt [ 625 ] ) { int32_T k ; boolean_T exitg1 ;
boolean_T isvalid ; if ( ( mt [ 624 ] >= 1U ) && ( mt [ 624 ] < 625U ) ) {
isvalid = false ; k = 0 ; exitg1 = false ; while ( ( ! exitg1 ) && ( k + 1 <
625 ) ) { if ( mt [ k ] == 0U ) { k ++ ; } else { isvalid = true ; exitg1 =
true ; } } } else { isvalid = false ; } return isvalid ; } static void
civj2dafm1 ( real_T r [ 5 ] ) { real_T b_r ; int32_T b_k ; int32_T exitg1 ;
uint32_T b_u [ 2 ] ; for ( b_k = 0 ; b_k < 5 ; b_k ++ ) { do { exitg1 = 0 ;
jywdovubw0d ( rtDW . iovoxirwro , b_u ) ; b_r = ( ( real_T ) ( b_u [ 0 ] >>
5U ) * 6.7108864E+7 + ( real_T ) ( b_u [ 1 ] >> 6U ) ) *
1.1102230246251565E-16 ; if ( b_r == 0.0 ) { if ( ! isihtjjmsz ( rtDW .
iovoxirwro ) ) { rtDW . iovoxirwro [ 0 ] = 5489U ; rtDW . iovoxirwro [ 624 ]
= 624U ; } } else { exitg1 = 1 ; } } while ( exitg1 == 0 ) ; r [ b_k ] = b_r
; } } static boolean_T cduyt2xdp0 ( const e2b0f4s35s * a , const e2b0f4s35s *
b ) { int32_T b_kstr ; int32_T exitg1 ; boolean_T b_bool ; boolean_T d ;
b_bool = false ; d = ( a -> size [ 1 ] == 0 ) ; if ( d && ( b -> size [ 1 ]
== 0 ) ) { b_bool = true ; } else if ( a -> size [ 1 ] != b -> size [ 1 ] ) {
} else { b_kstr = 1 ; do { exitg1 = 0 ; if ( b_kstr - 1 <= b -> size [ 1 ] -
1 ) { if ( a -> data [ b_kstr - 1 ] != b -> data [ b_kstr - 1 ] ) { exitg1 =
1 ; } else { b_kstr ++ ; } } else { b_bool = true ; exitg1 = 1 ; } } while (
exitg1 == 0 ) ; } return b_bool ; } static real_T lgt1s4cluf ( itgfp4rmev *
obj , const e2b0f4s35s * bodyname ) { e2b0f4s35s * bname ; gxcsgl11sl35 *
obj_p ; real_T b ; real_T bid ; int32_T b_i ; int32_T i ; int32_T loop_ub ;
boolean_T exitg1 ; gunzkbl0qg ( & bname , 2 ) ; bid = - 1.0 ; i = bname ->
size [ 0 ] * bname -> size [ 1 ] ; bname -> size [ 0 ] = 1 ; bname -> size [
1 ] = obj -> Base . NameInternal -> size [ 1 ] ; ac0ugu5nlz ( bname , i ) ;
loop_ub = obj -> Base . NameInternal -> size [ 1 ] - 1 ; for ( i = 0 ; i <=
loop_ub ; i ++ ) { bname -> data [ i ] = obj -> Base . NameInternal -> data [
i ] ; } if ( cduyt2xdp0 ( bname , bodyname ) ) { bid = 0.0 ; } else { b = obj
-> NumBodies ; b_i = 0 ; exitg1 = false ; while ( ( ! exitg1 ) && ( b_i <= (
int32_T ) b - 1 ) ) { obj_p = obj -> Bodies [ b_i ] ; i = bname -> size [ 0 ]
* bname -> size [ 1 ] ; bname -> size [ 0 ] = 1 ; bname -> size [ 1 ] = obj_p
-> NameInternal -> size [ 1 ] ; ac0ugu5nlz ( bname , i ) ; loop_ub = obj_p ->
NameInternal -> size [ 1 ] - 1 ; for ( i = 0 ; i <= loop_ub ; i ++ ) { bname
-> data [ i ] = obj_p -> NameInternal -> data [ i ] ; } if ( cduyt2xdp0 (
bname , bodyname ) ) { bid = ( real_T ) b_i + 1.0 ; exitg1 = true ; } else {
b_i ++ ; } } } b0l0vcvht3 ( & bname ) ; return bid ; } static void njzmd0hlqd
( moo4o4s0qn * * pEmxArray ) { if ( * pEmxArray != ( moo4o4s0qn * ) NULL ) {
if ( ( ( * pEmxArray ) -> data != ( real_T * ) NULL ) && ( * pEmxArray ) ->
canFreeData ) { free ( ( * pEmxArray ) -> data ) ; } free ( ( * pEmxArray )
-> size ) ; free ( * pEmxArray ) ; * pEmxArray = ( moo4o4s0qn * ) NULL ; } }
static gxcsgl11sl35 * el2xo0x5qy ( gxcsgl11sl35 * obj , gtd4jhsf2rw * iobj_0
, iyg0swfnbfoc * iobj_1 , gxcsgl11sl35 * iobj_2 ) { e2b0f4s35s * jname ;
e2b0f4s35s * jtype ; gtd4jhsf2rw * newObj ; gtd4jhsf2rw * obj_e ;
gxcsgl11sl35 * newbody ; iyg0swfnbfoc * obj_p ; moo4o4s0qn * obj_m ;
mqyxc3drwd * obj_i ; real_T obj_f [ 36 ] ; real_T obj_g [ 16 ] ; real_T
poslim_data [ 12 ] ; real_T obj_j [ 9 ] ; real_T b_x ; real_T obj_idx_1 ;
real_T obj_idx_2 ; int32_T b_k ; int32_T b_kstr ; int32_T minnanb ; char_T
b_p [ 9 ] ; char_T b_vstr [ 9 ] ; char_T partial_match_data [ 9 ] ; char_T b
[ 8 ] ; char_T vstr [ 8 ] ; char_T b_e [ 5 ] ; char_T c_vstr [ 5 ] ; int8_T
msubspace_data [ 36 ] ; int8_T b_I [ 9 ] ; int8_T tmp [ 6 ] ; boolean_T
b_bool ; boolean_T matched ; static const int8_T tmp_p [ 16 ] = { 1 , 0 , 0 ,
0 , 0 , 1 , 0 , 0 , 0 , 0 , 1 , 0 , 0 , 0 , 0 , 1 } ; static const char_T
tmp_e [ 8 ] = { 'r' , 'e' , 'v' , 'o' , 'l' , 'u' , 't' , 'e' } ; static
const char_T tmp_i [ 9 ] = { 'p' , 'r' , 'i' , 's' , 'm' , 'a' , 't' , 'i' ,
'c' } ; static const char_T tmp_m [ 5 ] = { 'f' , 'i' , 'x' , 'e' , 'd' } ;
static const char_T tmp_g [ 128 ] = { '\x00' , '\x01' , '\x02' , '\x03' ,
'\x04' , '\x05' , '\x06' , '\x07' , '\x08' , '	' , '\x0a' , '\x0b' , '\x0c' ,
'\x0d' , '\x0e' , '\x0f' , '\x10' , '\x11' , '\x12' , '\x13' , '\x14' ,
'\x15' , '\x16' , '\x17' , '\x18' , '\x19' , '\x1a' , '\x1b' , '\x1c' ,
'\x1d' , '\x1e' , '\x1f' , ' ' , '!' , '\"' , '#' , '$' , '%' , '&' , '\'' ,
'(' , ')' , '*' , '+' , ',' , '-' , '.' , '/' , '0' , '1' , '2' , '3' , '4' ,
'5' , '6' , '7' , '8' , '9' , ':' , ';' , '<' , '=' , '>' , '?' , '@' , 'a' ,
'b' , 'c' , 'd' , 'e' , 'f' , 'g' , 'h' , 'i' , 'j' , 'k' , 'l' , 'm' , 'n' ,
'o' , 'p' , 'q' , 'r' , 's' , 't' , 'u' , 'v' , 'w' , 'x' , 'y' , 'z' , '[' ,
'\\' , ']' , '^' , '_' , '`' , 'a' , 'b' , 'c' , 'd' , 'e' , 'f' , 'g' , 'h'
, 'i' , 'j' , 'k' , 'l' , 'm' , 'n' , 'o' , 'p' , 'q' , 'r' , 's' , 't' , 'u'
, 'v' , 'w' , 'x' , 'y' , 'z' , '{' , '|' , '}' , '~' , '\x7f' } ; int32_T
exitg1 ; int32_T partial_match_size_idx_1 ; boolean_T guard1 = false ;
boolean_T guard11 = false ; boolean_T guard2 = false ; boolean_T guard3 =
false ; gunzkbl0qg ( & jtype , 2 ) ; b_kstr = jtype -> size [ 0 ] * jtype ->
size [ 1 ] ; jtype -> size [ 0 ] = 1 ; jtype -> size [ 1 ] = obj ->
NameInternal -> size [ 1 ] ; ac0ugu5nlz ( jtype , b_kstr ) ; minnanb = obj ->
NameInternal -> size [ 1 ] - 1 ; for ( b_kstr = 0 ; b_kstr <= minnanb ;
b_kstr ++ ) { jtype -> data [ b_kstr ] = obj -> NameInternal -> data [ b_kstr
] ; } newbody = iobj_2 ; b_kstr = iobj_2 -> NameInternal -> size [ 0 ] *
iobj_2 -> NameInternal -> size [ 1 ] ; iobj_2 -> NameInternal -> size [ 0 ] =
1 ; iobj_2 -> NameInternal -> size [ 1 ] = jtype -> size [ 1 ] ; ac0ugu5nlz (
iobj_2 -> NameInternal , b_kstr ) ; minnanb = jtype -> size [ 1 ] - 1 ; for (
b_kstr = 0 ; b_kstr <= minnanb ; b_kstr ++ ) { iobj_2 -> NameInternal -> data
[ b_kstr ] = jtype -> data [ b_kstr ] ; } gunzkbl0qg ( & jname , 2 ) ; b_kstr
= jname -> size [ 0 ] * jname -> size [ 1 ] ; jname -> size [ 0 ] = 1 ; jname
-> size [ 1 ] = jtype -> size [ 1 ] + 4 ; ac0ugu5nlz ( jname , b_kstr ) ;
minnanb = jtype -> size [ 1 ] ; if ( minnanb - 1 >= 0 ) { memcpy ( & jname ->
data [ 0 ] , & jtype -> data [ 0 ] , minnanb * sizeof ( char_T ) ) ; } jname
-> data [ jtype -> size [ 1 ] ] = '_' ; jname -> data [ jtype -> size [ 1 ] +
1 ] = 'j' ; jname -> data [ jtype -> size [ 1 ] + 2 ] = 'n' ; jname -> data [
jtype -> size [ 1 ] + 3 ] = 't' ; iobj_2 -> JointInternal = j32lrgnqkz ( &
iobj_1 [ 0 ] , jname ) ; iobj_2 -> Index = - 1.0 ; iobj_2 -> ParentIndex = -
1.0 ; iobj_2 -> MassInternal = 1.0 ; iobj_2 -> CenterOfMassInternal [ 0 ] =
0.0 ; iobj_2 -> CenterOfMassInternal [ 1 ] = 0.0 ; iobj_2 ->
CenterOfMassInternal [ 2 ] = 0.0 ; for ( b_kstr = 0 ; b_kstr < 9 ; b_kstr ++
) { b_I [ b_kstr ] = 0 ; } b_I [ 0 ] = 1 ; b_I [ 4 ] = 1 ; b_I [ 8 ] = 1 ;
for ( b_kstr = 0 ; b_kstr < 9 ; b_kstr ++ ) { iobj_2 -> InertiaInternal [
b_kstr ] = b_I [ b_kstr ] ; } for ( b_kstr = 0 ; b_kstr < 36 ; b_kstr ++ ) {
msubspace_data [ b_kstr ] = 0 ; } for ( b_k = 0 ; b_k < 6 ; b_k ++ ) {
msubspace_data [ b_k + 6 * b_k ] = 1 ; } for ( b_kstr = 0 ; b_kstr < 36 ;
b_kstr ++ ) { iobj_2 -> SpatialInertia [ b_kstr ] = msubspace_data [ b_kstr ]
; } iobj_2 -> CollisionsInternal = aydneur4h5so ( & iobj_0 [ 0 ] , 0.0 ) ;
obj_p = obj -> JointInternal ; b_kstr = jtype -> size [ 0 ] * jtype -> size [
1 ] ; jtype -> size [ 0 ] = 1 ; jtype -> size [ 1 ] = obj_p -> Type -> size [
1 ] ; ac0ugu5nlz ( jtype , b_kstr ) ; minnanb = obj_p -> Type -> size [ 1 ] -
1 ; for ( b_kstr = 0 ; b_kstr <= minnanb ; b_kstr ++ ) { jtype -> data [
b_kstr ] = obj_p -> Type -> data [ b_kstr ] ; } b_kstr = jname -> size [ 0 ]
* jname -> size [ 1 ] ; jname -> size [ 0 ] = 1 ; jname -> size [ 1 ] = obj_p
-> NameInternal -> size [ 1 ] ; ac0ugu5nlz ( jname , b_kstr ) ; minnanb =
obj_p -> NameInternal -> size [ 1 ] - 1 ; for ( b_kstr = 0 ; b_kstr <=
minnanb ; b_kstr ++ ) { jname -> data [ b_kstr ] = obj_p -> NameInternal ->
data [ b_kstr ] ; } iobj_1 [ 1 ] . InTree = false ; for ( b_kstr = 0 ; b_kstr
< 16 ; b_kstr ++ ) { iobj_1 [ 1 ] . JointToParentTransform [ b_kstr ] = tmp_p
[ b_kstr ] ; } for ( b_kstr = 0 ; b_kstr < 16 ; b_kstr ++ ) { iobj_1 [ 1 ] .
ChildToJointTransform [ b_kstr ] = tmp_p [ b_kstr ] ; } b_kstr = iobj_1 [ 1 ]
. NameInternal -> size [ 0 ] * iobj_1 [ 1 ] . NameInternal -> size [ 1 ] ;
iobj_1 [ 1 ] . NameInternal -> size [ 0 ] = 1 ; iobj_1 [ 1 ] . NameInternal
-> size [ 1 ] = jname -> size [ 1 ] ; ac0ugu5nlz ( iobj_1 [ 1 ] .
NameInternal , b_kstr ) ; minnanb = jname -> size [ 1 ] - 1 ; for ( b_kstr =
0 ; b_kstr <= minnanb ; b_kstr ++ ) { iobj_1 [ 1 ] . NameInternal -> data [
b_kstr ] = jname -> data [ b_kstr ] ; } b0l0vcvht3 ( & jname ) ;
partial_match_size_idx_1 = 8 ; b_k = 0 ; matched = false ; for ( b_kstr = 0 ;
b_kstr < 8 ; b_kstr ++ ) { partial_match_data [ b_kstr ] = ' ' ; vstr [
b_kstr ] = tmp_e [ b_kstr ] ; } guard1 = false ; guard2 = false ; guard3 =
false ; if ( jtype -> size [ 1 ] <= 8 ) { b_x = jtype -> size [ 1 ] ; for (
b_kstr = 0 ; b_kstr < 8 ; b_kstr ++ ) { b [ b_kstr ] = tmp_e [ b_kstr ] ; }
b_bool = false ; minnanb = jtype -> size [ 1 ] ; guard11 = false ; if ( (
int32_T ) b_x <= minnanb ) { b_kstr = ( int32_T ) b_x ; minnanb =
muIntScalarMin_sint32 ( minnanb , b_kstr ) - 1 ; guard11 = true ; } else if (
jtype -> size [ 1 ] == 8 ) { minnanb = 7 ; guard11 = true ; } if ( guard11 )
{ b_kstr = 1 ; do { exitg1 = 0 ; if ( b_kstr - 1 <= minnanb ) { if ( tmp_g [
( uint8_T ) jtype -> data [ b_kstr - 1 ] & 127 ] != tmp_g [ ( int32_T ) b [
b_kstr - 1 ] ] ) { exitg1 = 1 ; } else { b_kstr ++ ; } } else { b_bool = true
; exitg1 = 1 ; } } while ( exitg1 == 0 ) ; } if ( b_bool ) { if ( jtype ->
size [ 1 ] == 8 ) { b_k = 1 ; partial_match_size_idx_1 = 8 ; for ( b_kstr = 0
; b_kstr < 8 ; b_kstr ++ ) { b_p [ b_kstr ] = vstr [ b_kstr ] ; } } else {
partial_match_size_idx_1 = 8 ; for ( b_kstr = 0 ; b_kstr < 8 ; b_kstr ++ ) {
partial_match_data [ b_kstr ] = vstr [ b_kstr ] ; } matched = true ; b_k = 1
; guard3 = true ; } } else { guard3 = true ; } } else { guard3 = true ; } if
( guard3 ) { for ( b_kstr = 0 ; b_kstr < 9 ; b_kstr ++ ) { b_vstr [ b_kstr ]
= tmp_i [ b_kstr ] ; } if ( jtype -> size [ 1 ] <= 9 ) { b_x = jtype -> size
[ 1 ] ; for ( b_kstr = 0 ; b_kstr < 9 ; b_kstr ++ ) { b_p [ b_kstr ] = tmp_i
[ b_kstr ] ; } b_bool = false ; minnanb = jtype -> size [ 1 ] ; guard11 =
false ; if ( ( int32_T ) b_x <= minnanb ) { b_kstr = ( int32_T ) b_x ;
minnanb = muIntScalarMin_sint32 ( minnanb , b_kstr ) - 1 ; guard11 = true ; }
else if ( jtype -> size [ 1 ] == 9 ) { minnanb = 8 ; guard11 = true ; } if (
guard11 ) { b_kstr = 1 ; do { exitg1 = 0 ; if ( b_kstr - 1 <= minnanb ) { if
( tmp_g [ ( uint8_T ) jtype -> data [ b_kstr - 1 ] & 127 ] != tmp_g [ (
int32_T ) b_p [ b_kstr - 1 ] ] ) { exitg1 = 1 ; } else { b_kstr ++ ; } } else
{ b_bool = true ; exitg1 = 1 ; } } while ( exitg1 == 0 ) ; } if ( b_bool ) {
if ( jtype -> size [ 1 ] == 9 ) { b_k = 1 ; partial_match_size_idx_1 = 9 ;
for ( b_kstr = 0 ; b_kstr < 9 ; b_kstr ++ ) { b_p [ b_kstr ] = b_vstr [
b_kstr ] ; } } else { if ( ! matched ) { partial_match_size_idx_1 = 9 ; for (
b_kstr = 0 ; b_kstr < 9 ; b_kstr ++ ) { partial_match_data [ b_kstr ] =
b_vstr [ b_kstr ] ; } } matched = true ; b_k ++ ; guard2 = true ; } } else {
guard2 = true ; } } else { guard2 = true ; } } if ( guard2 ) { for ( b_kstr =
0 ; b_kstr < 5 ; b_kstr ++ ) { c_vstr [ b_kstr ] = tmp_m [ b_kstr ] ; } if (
jtype -> size [ 1 ] <= 5 ) { b_x = jtype -> size [ 1 ] ; for ( b_kstr = 0 ;
b_kstr < 5 ; b_kstr ++ ) { b_e [ b_kstr ] = tmp_m [ b_kstr ] ; } b_bool =
false ; minnanb = jtype -> size [ 1 ] ; guard11 = false ; if ( ( int32_T )
b_x <= minnanb ) { b_kstr = ( int32_T ) b_x ; minnanb = muIntScalarMin_sint32
( minnanb , b_kstr ) - 1 ; guard11 = true ; } else if ( jtype -> size [ 1 ]
== 5 ) { minnanb = 4 ; guard11 = true ; } if ( guard11 ) { b_kstr = 1 ; do {
exitg1 = 0 ; if ( b_kstr - 1 <= minnanb ) { if ( tmp_g [ ( uint8_T ) jtype ->
data [ b_kstr - 1 ] & 127 ] != tmp_g [ ( int32_T ) b_e [ b_kstr - 1 ] ] ) {
exitg1 = 1 ; } else { b_kstr ++ ; } } else { b_bool = true ; exitg1 = 1 ; } }
while ( exitg1 == 0 ) ; } if ( b_bool ) { if ( jtype -> size [ 1 ] == 5 ) {
b_k = 1 ; partial_match_size_idx_1 = 5 ; for ( b_kstr = 0 ; b_kstr < 5 ;
b_kstr ++ ) { b_p [ b_kstr ] = c_vstr [ b_kstr ] ; } } else { if ( ! matched
) { partial_match_size_idx_1 = 5 ; for ( b_kstr = 0 ; b_kstr < 5 ; b_kstr ++
) { partial_match_data [ b_kstr ] = c_vstr [ b_kstr ] ; } } b_k ++ ; guard1 =
true ; } } else { guard1 = true ; } } else { guard1 = true ; } } if ( guard1
) { if ( b_k == 0 ) { partial_match_size_idx_1 = 8 ; for ( b_kstr = 0 ;
b_kstr < 8 ; b_kstr ++ ) { b_p [ b_kstr ] = ' ' ; } } else { minnanb =
partial_match_size_idx_1 - 1 ; memcpy ( & b_p [ 0 ] , & partial_match_data [
0 ] , ( minnanb + 1 ) * sizeof ( char_T ) ) ; } } if ( ( b_k == 0 ) || (
jtype -> size [ 1 ] == 0 ) ) { partial_match_size_idx_1 = 8 ; for ( b_kstr =
0 ; b_kstr < 8 ; b_kstr ++ ) { partial_match_data [ b_kstr ] = ' ' ; } } else
{ minnanb = partial_match_size_idx_1 - 1 ; memcpy ( & partial_match_data [ 0
] , & b_p [ 0 ] , ( minnanb + 1 ) * sizeof ( char_T ) ) ; } b_kstr = iobj_1 [
1 ] . Type -> size [ 0 ] * iobj_1 [ 1 ] . Type -> size [ 1 ] ; iobj_1 [ 1 ] .
Type -> size [ 0 ] = 1 ; iobj_1 [ 1 ] . Type -> size [ 1 ] =
partial_match_size_idx_1 ; ac0ugu5nlz ( iobj_1 [ 1 ] . Type , b_kstr ) ;
minnanb = partial_match_size_idx_1 - 1 ; for ( b_kstr = 0 ; b_kstr <= minnanb
; b_kstr ++ ) { iobj_1 [ 1 ] . Type -> data [ b_kstr ] = partial_match_data [
b_kstr ] ; } b_kstr = jtype -> size [ 0 ] * jtype -> size [ 1 ] ; jtype ->
size [ 0 ] = 1 ; jtype -> size [ 1 ] = iobj_1 [ 1 ] . Type -> size [ 1 ] ;
ac0ugu5nlz ( jtype , b_kstr ) ; minnanb = iobj_1 [ 1 ] . Type -> size [ 1 ] -
1 ; for ( b_kstr = 0 ; b_kstr <= minnanb ; b_kstr ++ ) { jtype -> data [
b_kstr ] = iobj_1 [ 1 ] . Type -> data [ b_kstr ] ; } for ( b_kstr = 0 ;
b_kstr < 8 ; b_kstr ++ ) { b [ b_kstr ] = tmp_e [ b_kstr ] ; } b_bool = false
; if ( jtype -> size [ 1 ] != 8 ) { } else { b_kstr = 1 ; do { exitg1 = 0 ;
if ( b_kstr - 1 < 8 ) { if ( jtype -> data [ b_kstr - 1 ] != b [ b_kstr - 1 ]
) { exitg1 = 1 ; } else { b_kstr ++ ; } } else { b_bool = true ; exitg1 = 1 ;
} } while ( exitg1 == 0 ) ; } if ( b_bool ) { b_x = 0.0 ; } else { for (
b_kstr = 0 ; b_kstr < 9 ; b_kstr ++ ) { b_p [ b_kstr ] = tmp_i [ b_kstr ] ; }
if ( jtype -> size [ 1 ] != 9 ) { } else { b_kstr = 1 ; do { exitg1 = 0 ; if
( b_kstr - 1 < 9 ) { if ( jtype -> data [ b_kstr - 1 ] != b_p [ b_kstr - 1 ]
) { exitg1 = 1 ; } else { b_kstr ++ ; } } else { b_bool = true ; exitg1 = 1 ;
} } while ( exitg1 == 0 ) ; } if ( b_bool ) { b_x = 1.0 ; } else { b_x = -
1.0 ; } } switch ( ( int32_T ) b_x ) { case 0 : tmp [ 0 ] = 0 ; tmp [ 1 ] = 0
; tmp [ 2 ] = 1 ; tmp [ 3 ] = 0 ; tmp [ 4 ] = 0 ; tmp [ 5 ] = 0 ; for (
b_kstr = 0 ; b_kstr < 6 ; b_kstr ++ ) { msubspace_data [ b_kstr ] = tmp [
b_kstr ] ; } poslim_data [ 0 ] = - 3.1415926535897931 ; poslim_data [ 1 ] =
3.1415926535897931 ; iobj_1 [ 1 ] . VelocityNumber = 1.0 ; iobj_1 [ 1 ] .
PositionNumber = 1.0 ; iobj_1 [ 1 ] . JointAxisInternal [ 0 ] = 0.0 ; iobj_1
[ 1 ] . JointAxisInternal [ 1 ] = 0.0 ; iobj_1 [ 1 ] . JointAxisInternal [ 2
] = 1.0 ; break ; case 1 : tmp [ 0 ] = 0 ; tmp [ 1 ] = 0 ; tmp [ 2 ] = 0 ;
tmp [ 3 ] = 0 ; tmp [ 4 ] = 0 ; tmp [ 5 ] = 1 ; for ( b_kstr = 0 ; b_kstr < 6
; b_kstr ++ ) { msubspace_data [ b_kstr ] = tmp [ b_kstr ] ; } poslim_data [
0 ] = - 0.5 ; poslim_data [ 1 ] = 0.5 ; iobj_1 [ 1 ] . VelocityNumber = 1.0 ;
iobj_1 [ 1 ] . PositionNumber = 1.0 ; iobj_1 [ 1 ] . JointAxisInternal [ 0 ]
= 0.0 ; iobj_1 [ 1 ] . JointAxisInternal [ 1 ] = 0.0 ; iobj_1 [ 1 ] .
JointAxisInternal [ 2 ] = 1.0 ; break ; default : for ( b_kstr = 0 ; b_kstr <
6 ; b_kstr ++ ) { msubspace_data [ b_kstr ] = 0 ; } poslim_data [ 0 ] = 0.0 ;
poslim_data [ 1 ] = 0.0 ; iobj_1 [ 1 ] . VelocityNumber = 0.0 ; iobj_1 [ 1 ]
. PositionNumber = 0.0 ; iobj_1 [ 1 ] . JointAxisInternal [ 0 ] = 0.0 ;
iobj_1 [ 1 ] . JointAxisInternal [ 1 ] = 0.0 ; iobj_1 [ 1 ] .
JointAxisInternal [ 2 ] = 0.0 ; break ; } b_kstr = iobj_1 [ 1 ] .
MotionSubspace -> size [ 0 ] * iobj_1 [ 1 ] . MotionSubspace -> size [ 1 ] ;
iobj_1 [ 1 ] . MotionSubspace -> size [ 0 ] = 6 ; iobj_1 [ 1 ] .
MotionSubspace -> size [ 1 ] = 1 ; ier0p3wwtw ( iobj_1 [ 1 ] . MotionSubspace
, b_kstr ) ; for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr ++ ) { iobj_1 [ 1 ] .
MotionSubspace -> data [ b_kstr ] = msubspace_data [ b_kstr ] ; } b_kstr =
iobj_1 [ 1 ] . PositionLimitsInternal -> size [ 0 ] * iobj_1 [ 1 ] .
PositionLimitsInternal -> size [ 1 ] ; iobj_1 [ 1 ] . PositionLimitsInternal
-> size [ 0 ] = 1 ; iobj_1 [ 1 ] . PositionLimitsInternal -> size [ 1 ] = 2 ;
ier0p3wwtw ( iobj_1 [ 1 ] . PositionLimitsInternal , b_kstr ) ; for ( b_kstr
= 0 ; b_kstr < 2 ; b_kstr ++ ) { iobj_1 [ 1 ] . PositionLimitsInternal ->
data [ b_kstr ] = poslim_data [ b_kstr ] ; } b_kstr = iobj_1 [ 1 ] .
HomePositionInternal -> size [ 0 ] ; iobj_1 [ 1 ] . HomePositionInternal ->
size [ 0 ] = 1 ; ier0p3wwtw ( iobj_1 [ 1 ] . HomePositionInternal , b_kstr )
; iobj_1 [ 1 ] . HomePositionInternal -> data [ 0 ] = 0.0 ; b_kstr = jtype ->
size [ 0 ] * jtype -> size [ 1 ] ; jtype -> size [ 0 ] = 1 ; jtype -> size [
1 ] = obj_p -> NameInternal -> size [ 1 ] ; ac0ugu5nlz ( jtype , b_kstr ) ;
minnanb = obj_p -> NameInternal -> size [ 1 ] - 1 ; for ( b_kstr = 0 ; b_kstr
<= minnanb ; b_kstr ++ ) { jtype -> data [ b_kstr ] = obj_p -> NameInternal
-> data [ b_kstr ] ; } if ( jtype -> size [ 1 ] != 0 ) { b_kstr = jtype ->
size [ 0 ] * jtype -> size [ 1 ] ; jtype -> size [ 0 ] = 1 ; jtype -> size [
1 ] = obj_p -> NameInternal -> size [ 1 ] ; ac0ugu5nlz ( jtype , b_kstr ) ;
minnanb = obj_p -> NameInternal -> size [ 1 ] - 1 ; for ( b_kstr = 0 ; b_kstr
<= minnanb ; b_kstr ++ ) { jtype -> data [ b_kstr ] = obj_p -> NameInternal
-> data [ b_kstr ] ; } if ( ! iobj_1 [ 1 ] . InTree ) { b_kstr = iobj_1 [ 1 ]
. NameInternal -> size [ 0 ] * iobj_1 [ 1 ] . NameInternal -> size [ 1 ] ;
iobj_1 [ 1 ] . NameInternal -> size [ 0 ] = 1 ; iobj_1 [ 1 ] . NameInternal
-> size [ 1 ] = jtype -> size [ 1 ] ; ac0ugu5nlz ( iobj_1 [ 1 ] .
NameInternal , b_kstr ) ; minnanb = jtype -> size [ 1 ] - 1 ; for ( b_kstr =
0 ; b_kstr <= minnanb ; b_kstr ++ ) { iobj_1 [ 1 ] . NameInternal -> data [
b_kstr ] = jtype -> data [ b_kstr ] ; } } } b0l0vcvht3 ( & jtype ) ;
cy4r1g1cm1 ( & obj_m , 1 ) ; b_k = obj_p -> PositionLimitsInternal -> size [
0 ] << 1 ; b_kstr = iobj_1 [ 1 ] . PositionLimitsInternal -> size [ 0 ] *
iobj_1 [ 1 ] . PositionLimitsInternal -> size [ 1 ] ; iobj_1 [ 1 ] .
PositionLimitsInternal -> size [ 0 ] = obj_p -> PositionLimitsInternal ->
size [ 0 ] ; iobj_1 [ 1 ] . PositionLimitsInternal -> size [ 1 ] = 2 ;
ier0p3wwtw ( iobj_1 [ 1 ] . PositionLimitsInternal , b_kstr ) ; b_kstr =
obj_m -> size [ 0 ] ; obj_m -> size [ 0 ] = b_k ; ier0p3wwtw ( obj_m , b_kstr
) ; for ( b_kstr = 0 ; b_kstr < b_k ; b_kstr ++ ) { obj_m -> data [ b_kstr ]
= obj_p -> PositionLimitsInternal -> data [ b_kstr ] ; } minnanb = obj_m ->
size [ 0 ] ; for ( b_kstr = 0 ; b_kstr < minnanb ; b_kstr ++ ) { iobj_1 [ 1 ]
. PositionLimitsInternal -> data [ b_kstr ] = obj_m -> data [ b_kstr ] ; }
b_kstr = obj_m -> size [ 0 ] ; obj_m -> size [ 0 ] = obj_p ->
HomePositionInternal -> size [ 0 ] ; ier0p3wwtw ( obj_m , b_kstr ) ; minnanb
= obj_p -> HomePositionInternal -> size [ 0 ] ; for ( b_kstr = 0 ; b_kstr <
minnanb ; b_kstr ++ ) { obj_m -> data [ b_kstr ] = obj_p ->
HomePositionInternal -> data [ b_kstr ] ; } b_kstr = iobj_1 [ 1 ] .
HomePositionInternal -> size [ 0 ] ; iobj_1 [ 1 ] . HomePositionInternal ->
size [ 0 ] = obj_m -> size [ 0 ] ; ier0p3wwtw ( iobj_1 [ 1 ] .
HomePositionInternal , b_kstr ) ; minnanb = obj_m -> size [ 0 ] ; for (
b_kstr = 0 ; b_kstr < minnanb ; b_kstr ++ ) { iobj_1 [ 1 ] .
HomePositionInternal -> data [ b_kstr ] = obj_m -> data [ b_kstr ] ; } b_x =
obj_p -> JointAxisInternal [ 0 ] ; obj_idx_1 = obj_p -> JointAxisInternal [ 1
] ; obj_idx_2 = obj_p -> JointAxisInternal [ 2 ] ; iobj_1 [ 1 ] .
JointAxisInternal [ 0 ] = b_x ; iobj_1 [ 1 ] . JointAxisInternal [ 1 ] =
obj_idx_1 ; iobj_1 [ 1 ] . JointAxisInternal [ 2 ] = obj_idx_2 ; b_k = 6 *
obj_p -> MotionSubspace -> size [ 1 ] ; b_kstr = iobj_1 [ 1 ] .
MotionSubspace -> size [ 0 ] * iobj_1 [ 1 ] . MotionSubspace -> size [ 1 ] ;
iobj_1 [ 1 ] . MotionSubspace -> size [ 0 ] = 6 ; iobj_1 [ 1 ] .
MotionSubspace -> size [ 1 ] = obj_p -> MotionSubspace -> size [ 1 ] ;
ier0p3wwtw ( iobj_1 [ 1 ] . MotionSubspace , b_kstr ) ; b_kstr = obj_m ->
size [ 0 ] ; obj_m -> size [ 0 ] = b_k ; ier0p3wwtw ( obj_m , b_kstr ) ; for
( b_kstr = 0 ; b_kstr < b_k ; b_kstr ++ ) { obj_m -> data [ b_kstr ] = obj_p
-> MotionSubspace -> data [ b_kstr ] ; } minnanb = obj_m -> size [ 0 ] ; for
( b_kstr = 0 ; b_kstr < minnanb ; b_kstr ++ ) { iobj_1 [ 1 ] . MotionSubspace
-> data [ b_kstr ] = obj_m -> data [ b_kstr ] ; } njzmd0hlqd ( & obj_m ) ;
for ( b_kstr = 0 ; b_kstr < 16 ; b_kstr ++ ) { obj_g [ b_kstr ] = obj_p ->
JointToParentTransform [ b_kstr ] ; } for ( b_kstr = 0 ; b_kstr < 16 ; b_kstr
++ ) { iobj_1 [ 1 ] . JointToParentTransform [ b_kstr ] = obj_g [ b_kstr ] ;
} for ( b_kstr = 0 ; b_kstr < 16 ; b_kstr ++ ) { obj_g [ b_kstr ] = obj_p ->
ChildToJointTransform [ b_kstr ] ; } for ( b_kstr = 0 ; b_kstr < 16 ; b_kstr
++ ) { iobj_1 [ 1 ] . ChildToJointTransform [ b_kstr ] = obj_g [ b_kstr ] ; }
iobj_2 -> JointInternal = & iobj_1 [ 1 ] ; iobj_2 -> MassInternal = obj ->
MassInternal ; b_x = obj -> CenterOfMassInternal [ 0 ] ; obj_idx_1 = obj ->
CenterOfMassInternal [ 1 ] ; obj_idx_2 = obj -> CenterOfMassInternal [ 2 ] ;
iobj_2 -> CenterOfMassInternal [ 0 ] = b_x ; iobj_2 -> CenterOfMassInternal [
1 ] = obj_idx_1 ; iobj_2 -> CenterOfMassInternal [ 2 ] = obj_idx_2 ; for (
b_kstr = 0 ; b_kstr < 9 ; b_kstr ++ ) { obj_j [ b_kstr ] = obj ->
InertiaInternal [ b_kstr ] ; } for ( b_kstr = 0 ; b_kstr < 9 ; b_kstr ++ ) {
iobj_2 -> InertiaInternal [ b_kstr ] = obj_j [ b_kstr ] ; } for ( b_kstr = 0
; b_kstr < 36 ; b_kstr ++ ) { obj_f [ b_kstr ] = obj -> SpatialInertia [
b_kstr ] ; } for ( b_kstr = 0 ; b_kstr < 36 ; b_kstr ++ ) { iobj_2 ->
SpatialInertia [ b_kstr ] = obj_f [ b_kstr ] ; } obj_e = obj ->
CollisionsInternal ; newObj = aydneur4h5so ( & iobj_0 [ 1 ] , obj_e ->
MaxElements ) ; newObj -> Size = obj_e -> Size ; b_x = obj_e -> Size ;
minnanb = ( int32_T ) b_x - 1 ; for ( b_k = 0 ; b_k <= minnanb ; b_k ++ ) {
obj_i = obj_e -> CollisionGeometries -> data [ b_k ] ; newObj ->
CollisionGeometries -> data [ b_k ] = obj_i ; } iobj_2 -> CollisionsInternal
= newObj ; return newbody ; } static void hahijoalwi ( itgfp4rmev * obj ,
gxcsgl11sl35 * bodyin , const e2b0f4s35s * parentName , iyg0swfnbfoc * iobj_0
, gxcsgl11sl35 * iobj_1 , gtd4jhsf2rw * iobj_2 ) { e2b0f4s35s * bname ;
gxcsgl11sl35 * body ; iyg0swfnbfoc * jnt ; real_T b_index ; real_T pid ;
int32_T b_kstr ; int32_T loop_ub ; char_T b [ 5 ] ; boolean_T b_bool ; static
const char_T tmp [ 5 ] = { 'f' , 'i' , 'x' , 'e' , 'd' } ; int32_T exitg1 ;
gunzkbl0qg ( & bname , 2 ) ; b_kstr = bname -> size [ 0 ] * bname -> size [ 1
] ; bname -> size [ 0 ] = 1 ; bname -> size [ 1 ] = bodyin -> NameInternal ->
size [ 1 ] ; ac0ugu5nlz ( bname , b_kstr ) ; loop_ub = bodyin -> NameInternal
-> size [ 1 ] - 1 ; for ( b_kstr = 0 ; b_kstr <= loop_ub ; b_kstr ++ ) {
bname -> data [ b_kstr ] = bodyin -> NameInternal -> data [ b_kstr ] ; }
lgt1s4cluf ( obj , bname ) ; pid = lgt1s4cluf ( obj , parentName ) ; b_index
= obj -> NumBodies + 1.0 ; body = el2xo0x5qy ( bodyin , & iobj_2 [ 0 ] , &
iobj_0 [ 0 ] , iobj_1 ) ; obj -> Bodies [ ( int32_T ) b_index - 1 ] = body ;
body -> Index = b_index ; body -> ParentIndex = pid ; body -> JointInternal
-> InTree = true ; obj -> NumBodies ++ ; jnt = body -> JointInternal ; b_kstr
= bname -> size [ 0 ] * bname -> size [ 1 ] ; bname -> size [ 0 ] = 1 ; bname
-> size [ 1 ] = jnt -> Type -> size [ 1 ] ; ac0ugu5nlz ( bname , b_kstr ) ;
loop_ub = jnt -> Type -> size [ 1 ] - 1 ; for ( b_kstr = 0 ; b_kstr <=
loop_ub ; b_kstr ++ ) { bname -> data [ b_kstr ] = jnt -> Type -> data [
b_kstr ] ; } for ( b_kstr = 0 ; b_kstr < 5 ; b_kstr ++ ) { b [ b_kstr ] = tmp
[ b_kstr ] ; } b_bool = false ; if ( bname -> size [ 1 ] != 5 ) { } else {
b_kstr = 1 ; do { exitg1 = 0 ; if ( b_kstr - 1 < 5 ) { if ( bname -> data [
b_kstr - 1 ] != b [ b_kstr - 1 ] ) { exitg1 = 1 ; } else { b_kstr ++ ; } }
else { b_bool = true ; exitg1 = 1 ; } } while ( exitg1 == 0 ) ; } b0l0vcvht3
( & bname ) ; if ( ! b_bool ) { obj -> NumNonFixedBodies ++ ; jnt = body ->
JointInternal ; b_kstr = ( int32_T ) body -> Index - 1 ; obj ->
PositionDoFMap [ b_kstr ] = obj -> PositionNumber + 1.0 ; obj ->
PositionDoFMap [ b_kstr + 5 ] = obj -> PositionNumber + jnt -> PositionNumber
; jnt = body -> JointInternal ; b_kstr = ( int32_T ) body -> Index - 1 ; obj
-> VelocityDoFMap [ b_kstr ] = obj -> VelocityNumber + 1.0 ; obj ->
VelocityDoFMap [ b_kstr + 5 ] = obj -> VelocityNumber + jnt -> VelocityNumber
; } else { b_kstr = ( int32_T ) body -> Index - 1 ; obj -> PositionDoFMap [
b_kstr ] = 0.0 ; obj -> PositionDoFMap [ b_kstr + 5 ] = - 1.0 ; b_kstr = (
int32_T ) body -> Index - 1 ; obj -> VelocityDoFMap [ b_kstr ] = 0.0 ; obj ->
VelocityDoFMap [ b_kstr + 5 ] = - 1.0 ; } jnt = body -> JointInternal ; obj
-> PositionNumber += jnt -> PositionNumber ; jnt = body -> JointInternal ;
obj -> VelocityNumber += jnt -> VelocityNumber ; } static iabjthfi1p *
clllcb3tqp ( iabjthfi1p * obj , kp1en3mw3xln * varargin_2 ) { e2b0f4s35s *
bname ; e2b0f4s35s * switch_expression_p ; gtd4jhsf2rw * iobj_0_p ;
gtd4jhsf2rw * iobj_2 ; gtd4jhsf2rw * newObj ; gxcsgl11sl35 * body ;
gxcsgl11sl35 * iobj_1 ; gxcsgl11sl35 * parent ; iabjthfi1p * b_obj ;
itgfp4rmev * iobj_3 ; iyg0swfnbfoc * iobj_0 ; iyg0swfnbfoc * iobj_1_p ;
mqyxc3drwd * obj_p ; pmprofizlh * iobj_4 ; real_T poslim_data [ 12 ] ; real_T
b_p ; real_T bid ; int32_T kstr ; int32_T loop_ub ; int32_T ret ; char_T b [
18 ] ; char_T switch_expression [ 18 ] ; char_T b_i [ 9 ] ; char_T b_e [ 8 ]
; int8_T msubspace_data [ 36 ] ; int8_T b_I [ 9 ] ; int8_T tmp [ 6 ] ;
boolean_T b_bool ; static const int8_T tmp_p [ 16 ] = { 1 , 0 , 0 , 0 , 0 , 1
, 0 , 0 , 0 , 0 , 1 , 0 , 0 , 0 , 0 , 1 } ; static const char_T tmp_e [ 8 ] =
{ 'b' , 'a' , 's' , 'e' , '_' , 'j' , 'n' , 't' } ; static const char_T tmp_i
[ 5 ] = { 'f' , 'i' , 'x' , 'e' , 'd' } ; static const char_T tmp_m [ 8 ] = {
'r' , 'e' , 'v' , 'o' , 'l' , 'u' , 't' , 'e' } ; static const char_T tmp_g [
9 ] = { 'p' , 'r' , 'i' , 's' , 'm' , 'a' , 't' , 'i' , 'c' } ; static const
nm2s20qzlx tmp_j = { 0.0 , 0.0 } ; static const char_T tmp_f [ 18 ] = { 'L' ,
'e' , 'v' , 'e' , 'n' , 'b' , 'e' , 'r' , 'g' , 'M' , 'a' , 'r' , 'q' , 'u' ,
'a' , 'r' , 'd' , 't' } ; real_T unusedExpr [ 5 ] ; int32_T exitg1 ;
boolean_T exitg2 ; obj -> isInitialized = 0 ; b_obj = obj ; iobj_0 = & obj ->
_pobj1 [ 0 ] ; iobj_1 = & obj -> _pobj2 [ 0 ] ; iobj_2 = & obj -> _pobj3 [ 0
] ; iobj_3 = & obj -> _pobj4 ; iobj_4 = & obj -> _pobj5 ; body = & iobj_3 ->
Base ; iobj_0_p = & iobj_3 -> _pobj1 [ 0 ] ; kstr = body -> NameInternal ->
size [ 0 ] * body -> NameInternal -> size [ 1 ] ; body -> NameInternal ->
size [ 0 ] = 1 ; body -> NameInternal -> size [ 1 ] = 4 ; ac0ugu5nlz ( body
-> NameInternal , kstr ) ; body -> NameInternal -> data [ 0 ] = 'b' ; body ->
NameInternal -> data [ 1 ] = 'a' ; body -> NameInternal -> data [ 2 ] = 's' ;
body -> NameInternal -> data [ 3 ] = 'e' ; iobj_3 -> _pobj2 [ 0 ] . InTree =
false ; for ( kstr = 0 ; kstr < 16 ; kstr ++ ) { iobj_3 -> _pobj2 [ 0 ] .
JointToParentTransform [ kstr ] = tmp_p [ kstr ] ; } for ( kstr = 0 ; kstr <
16 ; kstr ++ ) { iobj_3 -> _pobj2 [ 0 ] . ChildToJointTransform [ kstr ] =
tmp_p [ kstr ] ; } kstr = iobj_3 -> _pobj2 [ 0 ] . NameInternal -> size [ 0 ]
* iobj_3 -> _pobj2 [ 0 ] . NameInternal -> size [ 1 ] ; iobj_3 -> _pobj2 [ 0
] . NameInternal -> size [ 0 ] = 1 ; iobj_3 -> _pobj2 [ 0 ] . NameInternal ->
size [ 1 ] = 8 ; ac0ugu5nlz ( iobj_3 -> _pobj2 [ 0 ] . NameInternal , kstr )
; for ( kstr = 0 ; kstr < 8 ; kstr ++ ) { iobj_3 -> _pobj2 [ 0 ] .
NameInternal -> data [ kstr ] = tmp_e [ kstr ] ; } kstr = iobj_3 -> _pobj2 [
0 ] . Type -> size [ 0 ] * iobj_3 -> _pobj2 [ 0 ] . Type -> size [ 1 ] ;
iobj_3 -> _pobj2 [ 0 ] . Type -> size [ 0 ] = 1 ; iobj_3 -> _pobj2 [ 0 ] .
Type -> size [ 1 ] = 5 ; ac0ugu5nlz ( iobj_3 -> _pobj2 [ 0 ] . Type , kstr )
; for ( kstr = 0 ; kstr < 5 ; kstr ++ ) { iobj_3 -> _pobj2 [ 0 ] . Type ->
data [ kstr ] = tmp_i [ kstr ] ; } gunzkbl0qg ( & switch_expression_p , 2 ) ;
kstr = switch_expression_p -> size [ 0 ] * switch_expression_p -> size [ 1 ]
; switch_expression_p -> size [ 0 ] = 1 ; switch_expression_p -> size [ 1 ] =
iobj_3 -> _pobj2 [ 0 ] . Type -> size [ 1 ] ; ac0ugu5nlz (
switch_expression_p , kstr ) ; loop_ub = iobj_3 -> _pobj2 [ 0 ] . Type ->
size [ 1 ] - 1 ; for ( kstr = 0 ; kstr <= loop_ub ; kstr ++ ) {
switch_expression_p -> data [ kstr ] = iobj_3 -> _pobj2 [ 0 ] . Type -> data
[ kstr ] ; } for ( kstr = 0 ; kstr < 8 ; kstr ++ ) { b_e [ kstr ] = tmp_m [
kstr ] ; } b_bool = false ; if ( switch_expression_p -> size [ 1 ] != 8 ) { }
else { ret = 1 ; do { exitg1 = 0 ; if ( ret - 1 < 8 ) { if (
switch_expression_p -> data [ ret - 1 ] != b_e [ ret - 1 ] ) { exitg1 = 1 ; }
else { ret ++ ; } } else { b_bool = true ; exitg1 = 1 ; } } while ( exitg1 ==
0 ) ; } if ( b_bool ) { bid = 0.0 ; } else { for ( kstr = 0 ; kstr < 9 ; kstr
++ ) { b_i [ kstr ] = tmp_g [ kstr ] ; } if ( switch_expression_p -> size [ 1
] != 9 ) { } else { ret = 1 ; do { exitg1 = 0 ; if ( ret - 1 < 9 ) { if (
switch_expression_p -> data [ ret - 1 ] != b_i [ ret - 1 ] ) { exitg1 = 1 ; }
else { ret ++ ; } } else { b_bool = true ; exitg1 = 1 ; } } while ( exitg1 ==
0 ) ; } if ( b_bool ) { bid = 1.0 ; } else { bid = - 1.0 ; } } switch ( (
int32_T ) bid ) { case 0 : tmp [ 0 ] = 0 ; tmp [ 1 ] = 0 ; tmp [ 2 ] = 1 ;
tmp [ 3 ] = 0 ; tmp [ 4 ] = 0 ; tmp [ 5 ] = 0 ; for ( kstr = 0 ; kstr < 6 ;
kstr ++ ) { msubspace_data [ kstr ] = tmp [ kstr ] ; } poslim_data [ 0 ] = -
3.1415926535897931 ; poslim_data [ 1 ] = 3.1415926535897931 ; iobj_3 ->
_pobj2 [ 0 ] . VelocityNumber = 1.0 ; iobj_3 -> _pobj2 [ 0 ] . PositionNumber
= 1.0 ; iobj_3 -> _pobj2 [ 0 ] . JointAxisInternal [ 0 ] = 0.0 ; iobj_3 ->
_pobj2 [ 0 ] . JointAxisInternal [ 1 ] = 0.0 ; iobj_3 -> _pobj2 [ 0 ] .
JointAxisInternal [ 2 ] = 1.0 ; break ; case 1 : tmp [ 0 ] = 0 ; tmp [ 1 ] =
0 ; tmp [ 2 ] = 0 ; tmp [ 3 ] = 0 ; tmp [ 4 ] = 0 ; tmp [ 5 ] = 1 ; for (
kstr = 0 ; kstr < 6 ; kstr ++ ) { msubspace_data [ kstr ] = tmp [ kstr ] ; }
poslim_data [ 0 ] = - 0.5 ; poslim_data [ 1 ] = 0.5 ; iobj_3 -> _pobj2 [ 0 ]
. VelocityNumber = 1.0 ; iobj_3 -> _pobj2 [ 0 ] . PositionNumber = 1.0 ;
iobj_3 -> _pobj2 [ 0 ] . JointAxisInternal [ 0 ] = 0.0 ; iobj_3 -> _pobj2 [ 0
] . JointAxisInternal [ 1 ] = 0.0 ; iobj_3 -> _pobj2 [ 0 ] .
JointAxisInternal [ 2 ] = 1.0 ; break ; default : for ( kstr = 0 ; kstr < 6 ;
kstr ++ ) { msubspace_data [ kstr ] = 0 ; } poslim_data [ 0 ] = 0.0 ;
poslim_data [ 1 ] = 0.0 ; iobj_3 -> _pobj2 [ 0 ] . VelocityNumber = 0.0 ;
iobj_3 -> _pobj2 [ 0 ] . PositionNumber = 0.0 ; iobj_3 -> _pobj2 [ 0 ] .
JointAxisInternal [ 0 ] = 0.0 ; iobj_3 -> _pobj2 [ 0 ] . JointAxisInternal [
1 ] = 0.0 ; iobj_3 -> _pobj2 [ 0 ] . JointAxisInternal [ 2 ] = 0.0 ; break ;
} kstr = iobj_3 -> _pobj2 [ 0 ] . MotionSubspace -> size [ 0 ] * iobj_3 ->
_pobj2 [ 0 ] . MotionSubspace -> size [ 1 ] ; iobj_3 -> _pobj2 [ 0 ] .
MotionSubspace -> size [ 0 ] = 6 ; iobj_3 -> _pobj2 [ 0 ] . MotionSubspace ->
size [ 1 ] = 1 ; ier0p3wwtw ( iobj_3 -> _pobj2 [ 0 ] . MotionSubspace , kstr
) ; for ( kstr = 0 ; kstr < 6 ; kstr ++ ) { iobj_3 -> _pobj2 [ 0 ] .
MotionSubspace -> data [ kstr ] = msubspace_data [ kstr ] ; } kstr = iobj_3
-> _pobj2 [ 0 ] . PositionLimitsInternal -> size [ 0 ] * iobj_3 -> _pobj2 [ 0
] . PositionLimitsInternal -> size [ 1 ] ; iobj_3 -> _pobj2 [ 0 ] .
PositionLimitsInternal -> size [ 0 ] = 1 ; iobj_3 -> _pobj2 [ 0 ] .
PositionLimitsInternal -> size [ 1 ] = 2 ; ier0p3wwtw ( iobj_3 -> _pobj2 [ 0
] . PositionLimitsInternal , kstr ) ; for ( kstr = 0 ; kstr < 2 ; kstr ++ ) {
iobj_3 -> _pobj2 [ 0 ] . PositionLimitsInternal -> data [ kstr ] =
poslim_data [ kstr ] ; } kstr = iobj_3 -> _pobj2 [ 0 ] . HomePositionInternal
-> size [ 0 ] ; iobj_3 -> _pobj2 [ 0 ] . HomePositionInternal -> size [ 0 ] =
1 ; ier0p3wwtw ( iobj_3 -> _pobj2 [ 0 ] . HomePositionInternal , kstr ) ;
iobj_3 -> _pobj2 [ 0 ] . HomePositionInternal -> data [ 0 ] = 0.0 ; body ->
JointInternal = & iobj_3 -> _pobj2 [ 0 ] ; body -> Index = - 1.0 ; body ->
ParentIndex = - 1.0 ; body -> MassInternal = 1.0 ; body ->
CenterOfMassInternal [ 0 ] = 0.0 ; body -> CenterOfMassInternal [ 1 ] = 0.0 ;
body -> CenterOfMassInternal [ 2 ] = 0.0 ; for ( kstr = 0 ; kstr < 9 ; kstr
++ ) { b_I [ kstr ] = 0 ; } b_I [ 0 ] = 1 ; b_I [ 4 ] = 1 ; b_I [ 8 ] = 1 ;
for ( kstr = 0 ; kstr < 9 ; kstr ++ ) { body -> InertiaInternal [ kstr ] =
b_I [ kstr ] ; } for ( kstr = 0 ; kstr < 36 ; kstr ++ ) { msubspace_data [
kstr ] = 0 ; } for ( ret = 0 ; ret < 6 ; ret ++ ) { msubspace_data [ ret + 6
* ret ] = 1 ; } for ( kstr = 0 ; kstr < 36 ; kstr ++ ) { body ->
SpatialInertia [ kstr ] = msubspace_data [ kstr ] ; } body ->
CollisionsInternal = aydneur4h5so ( iobj_0_p , 0.0 ) ; iobj_3 -> Base . Index
= 0.0 ; civj2dafm1 ( unusedExpr ) ; iobj_0_p = & iobj_3 -> _pobj1 [ 1 ] ;
iobj_1_p = & iobj_3 -> _pobj2 [ 1 ] ; body = & iobj_3 -> _pobj0 [ 0 ] ;
iobj_3 -> Bodies [ 0 ] = ovxlwwg003 ( & ( & ( & iobj_3 -> _pobj0 [ 0 ] ) [ 0
] ) [ 0 ] , & ( & iobj_0_p [ 0 ] ) [ 0 ] , & ( & iobj_1_p [ 0 ] ) [ 0 ] ) ;
iobj_3 -> Bodies [ 1 ] = pbim0sdm1g ( & ( & body [ 0 ] ) [ 1 ] , & ( &
iobj_0_p [ 0 ] ) [ 1 ] , & ( & iobj_1_p [ 0 ] ) [ 1 ] ) ; iobj_3 -> Bodies [
2 ] = gd1a2d5whe ( & ( & body [ 0 ] ) [ 2 ] , & ( & iobj_0_p [ 0 ] ) [ 2 ] ,
& ( & iobj_1_p [ 0 ] ) [ 2 ] ) ; iobj_3 -> Bodies [ 3 ] = oswu44nkbe ( & ( &
body [ 0 ] ) [ 3 ] , & ( & iobj_0_p [ 0 ] ) [ 3 ] , & ( & iobj_1_p [ 0 ] ) [
3 ] ) ; iobj_3 -> Bodies [ 4 ] = avigwta1rk ( & ( & body [ 0 ] ) [ 4 ] , & (
& iobj_0_p [ 0 ] ) [ 4 ] , & ( & iobj_1_p [ 0 ] ) [ 4 ] ) ; iobj_3 ->
NumBodies = 0.0 ; iobj_3 -> NumNonFixedBodies = 0.0 ; iobj_3 ->
PositionNumber = 0.0 ; iobj_3 -> VelocityNumber = 0.0 ; civj2dafm1 (
unusedExpr ) ; for ( kstr = 0 ; kstr < 5 ; kstr ++ ) { iobj_3 ->
PositionDoFMap [ kstr ] = 0.0 ; } for ( kstr = 0 ; kstr < 5 ; kstr ++ ) {
iobj_3 -> PositionDoFMap [ kstr + 5 ] = - 1.0 ; } for ( kstr = 0 ; kstr < 5 ;
kstr ++ ) { iobj_3 -> VelocityDoFMap [ kstr ] = 0.0 ; } for ( kstr = 0 ; kstr
< 5 ; kstr ++ ) { iobj_3 -> VelocityDoFMap [ kstr + 5 ] = - 1.0 ; } kstr =
switch_expression_p -> size [ 0 ] * switch_expression_p -> size [ 1 ] ;
switch_expression_p -> size [ 0 ] = 1 ; switch_expression_p -> size [ 1 ] =
varargin_2 -> Base . NameInternal -> size [ 1 ] ; ac0ugu5nlz (
switch_expression_p , kstr ) ; loop_ub = varargin_2 -> Base . NameInternal ->
size [ 1 ] - 1 ; for ( kstr = 0 ; kstr <= loop_ub ; kstr ++ ) {
switch_expression_p -> data [ kstr ] = varargin_2 -> Base . NameInternal ->
data [ kstr ] ; } gunzkbl0qg ( & bname , 2 ) ; bid = - 1.0 ; kstr = bname ->
size [ 0 ] * bname -> size [ 1 ] ; bname -> size [ 0 ] = 1 ; bname -> size [
1 ] = iobj_3 -> Base . NameInternal -> size [ 1 ] ; ac0ugu5nlz ( bname , kstr
) ; loop_ub = iobj_3 -> Base . NameInternal -> size [ 1 ] - 1 ; for ( kstr =
0 ; kstr <= loop_ub ; kstr ++ ) { bname -> data [ kstr ] = iobj_3 -> Base .
NameInternal -> data [ kstr ] ; } if ( cduyt2xdp0 ( bname ,
switch_expression_p ) ) { bid = 0.0 ; } else { b_p = iobj_3 -> NumBodies ;
ret = 0 ; exitg2 = false ; while ( ( ! exitg2 ) && ( ret <= ( int32_T ) b_p -
1 ) ) { body = iobj_3 -> Bodies [ ret ] ; kstr = bname -> size [ 0 ] * bname
-> size [ 1 ] ; bname -> size [ 0 ] = 1 ; bname -> size [ 1 ] = body ->
NameInternal -> size [ 1 ] ; ac0ugu5nlz ( bname , kstr ) ; loop_ub = body ->
NameInternal -> size [ 1 ] - 1 ; for ( kstr = 0 ; kstr <= loop_ub ; kstr ++ )
{ bname -> data [ kstr ] = body -> NameInternal -> data [ kstr ] ; } if (
cduyt2xdp0 ( bname , switch_expression_p ) ) { bid = ( real_T ) ret + 1.0 ;
exitg2 = true ; } else { ret ++ ; } } } if ( ( ! ( bid == 0.0 ) ) && ( bid <
0.0 ) ) { kstr = iobj_3 -> Base . NameInternal -> size [ 0 ] * iobj_3 -> Base
. NameInternal -> size [ 1 ] ; iobj_3 -> Base . NameInternal -> size [ 0 ] =
1 ; iobj_3 -> Base . NameInternal -> size [ 1 ] = switch_expression_p -> size
[ 1 ] ; ac0ugu5nlz ( iobj_3 -> Base . NameInternal , kstr ) ; loop_ub =
switch_expression_p -> size [ 1 ] - 1 ; for ( kstr = 0 ; kstr <= loop_ub ;
kstr ++ ) { iobj_3 -> Base . NameInternal -> data [ kstr ] =
switch_expression_p -> data [ kstr ] ; } } b0l0vcvht3 ( & switch_expression_p
) ; iobj_0_p = varargin_2 -> Base . CollisionsInternal ; newObj =
aydneur4h5so ( & ( & ( & ( & ( & iobj_2 [ 0 ] ) [ 0 ] ) [ 0 ] ) [ 0 ] ) [ 0 ]
, iobj_0_p -> MaxElements ) ; newObj -> Size = iobj_0_p -> Size ; b_p =
iobj_0_p -> Size ; kstr = ( int32_T ) b_p - 1 ; for ( ret = 0 ; ret <= kstr ;
ret ++ ) { obj_p = iobj_0_p -> CollisionGeometries -> data [ ret ] ; newObj
-> CollisionGeometries -> data [ ret ] = obj_p ; } iobj_3 -> Base .
CollisionsInternal = newObj ; if ( varargin_2 -> NumBodies >= 1.0 ) { body =
varargin_2 -> Bodies [ 0 ] ; bid = body -> ParentIndex ; if ( bid > 0.0 ) {
parent = varargin_2 -> Bodies [ ( int32_T ) bid - 1 ] ; } else { parent = &
varargin_2 -> Base ; } kstr = bname -> size [ 0 ] * bname -> size [ 1 ] ;
bname -> size [ 0 ] = 1 ; bname -> size [ 1 ] = parent -> NameInternal ->
size [ 1 ] ; ac0ugu5nlz ( bname , kstr ) ; loop_ub = parent -> NameInternal
-> size [ 1 ] - 1 ; for ( kstr = 0 ; kstr <= loop_ub ; kstr ++ ) { bname ->
data [ kstr ] = parent -> NameInternal -> data [ kstr ] ; } hahijoalwi (
iobj_3 , body , bname , & ( & ( & ( & ( & iobj_0 [ 0 ] ) [ 0 ] ) [ 0 ] ) [ 0
] ) [ 0 ] , & ( & ( & ( & ( & iobj_1 [ 0 ] ) [ 0 ] ) [ 0 ] ) [ 0 ] ) [ 0 ] ,
& ( & ( & ( & ( & iobj_2 [ 0 ] ) [ 0 ] ) [ 0 ] ) [ 0 ] ) [ 1 ] ) ; } if (
varargin_2 -> NumBodies >= 2.0 ) { body = varargin_2 -> Bodies [ 1 ] ; bid =
body -> ParentIndex ; if ( bid > 0.0 ) { parent = varargin_2 -> Bodies [ (
int32_T ) bid - 1 ] ; } else { parent = & varargin_2 -> Base ; } kstr = bname
-> size [ 0 ] * bname -> size [ 1 ] ; bname -> size [ 0 ] = 1 ; bname -> size
[ 1 ] = parent -> NameInternal -> size [ 1 ] ; ac0ugu5nlz ( bname , kstr ) ;
loop_ub = parent -> NameInternal -> size [ 1 ] - 1 ; for ( kstr = 0 ; kstr <=
loop_ub ; kstr ++ ) { bname -> data [ kstr ] = parent -> NameInternal -> data
[ kstr ] ; } hahijoalwi ( iobj_3 , body , bname , & ( & ( & ( & ( & iobj_0 [
0 ] ) [ 0 ] ) [ 0 ] ) [ 0 ] ) [ 2 ] , & ( & ( & ( & ( & iobj_1 [ 0 ] ) [ 0 ]
) [ 0 ] ) [ 0 ] ) [ 1 ] , & ( & ( & ( & ( & iobj_2 [ 0 ] ) [ 0 ] ) [ 0 ] ) [
0 ] ) [ 3 ] ) ; } if ( varargin_2 -> NumBodies >= 3.0 ) { body = varargin_2
-> Bodies [ 2 ] ; bid = body -> ParentIndex ; if ( bid > 0.0 ) { parent =
varargin_2 -> Bodies [ ( int32_T ) bid - 1 ] ; } else { parent = & varargin_2
-> Base ; } kstr = bname -> size [ 0 ] * bname -> size [ 1 ] ; bname -> size
[ 0 ] = 1 ; bname -> size [ 1 ] = parent -> NameInternal -> size [ 1 ] ;
ac0ugu5nlz ( bname , kstr ) ; loop_ub = parent -> NameInternal -> size [ 1 ]
- 1 ; for ( kstr = 0 ; kstr <= loop_ub ; kstr ++ ) { bname -> data [ kstr ] =
parent -> NameInternal -> data [ kstr ] ; } hahijoalwi ( iobj_3 , body ,
bname , & ( & ( & ( & ( & iobj_0 [ 0 ] ) [ 0 ] ) [ 0 ] ) [ 0 ] ) [ 4 ] , & (
& ( & ( & ( & iobj_1 [ 0 ] ) [ 0 ] ) [ 0 ] ) [ 0 ] ) [ 2 ] , & ( & ( & ( & (
& iobj_2 [ 0 ] ) [ 0 ] ) [ 0 ] ) [ 0 ] ) [ 5 ] ) ; } if ( varargin_2 ->
NumBodies >= 4.0 ) { body = varargin_2 -> Bodies [ 3 ] ; bid = body ->
ParentIndex ; if ( bid > 0.0 ) { parent = varargin_2 -> Bodies [ ( int32_T )
bid - 1 ] ; } else { parent = & varargin_2 -> Base ; } kstr = bname -> size [
0 ] * bname -> size [ 1 ] ; bname -> size [ 0 ] = 1 ; bname -> size [ 1 ] =
parent -> NameInternal -> size [ 1 ] ; ac0ugu5nlz ( bname , kstr ) ; loop_ub
= parent -> NameInternal -> size [ 1 ] - 1 ; for ( kstr = 0 ; kstr <= loop_ub
; kstr ++ ) { bname -> data [ kstr ] = parent -> NameInternal -> data [ kstr
] ; } hahijoalwi ( iobj_3 , body , bname , & ( & ( & ( & ( & iobj_0 [ 0 ] ) [
0 ] ) [ 0 ] ) [ 0 ] ) [ 6 ] , & ( & ( & ( & ( & iobj_1 [ 0 ] ) [ 0 ] ) [ 0 ]
) [ 0 ] ) [ 3 ] , & ( & ( & ( & ( & iobj_2 [ 0 ] ) [ 0 ] ) [ 0 ] ) [ 0 ] ) [
7 ] ) ; } if ( varargin_2 -> NumBodies >= 5.0 ) { body = varargin_2 -> Bodies
[ 4 ] ; bid = body -> ParentIndex ; if ( bid > 0.0 ) { parent = varargin_2 ->
Bodies [ ( int32_T ) bid - 1 ] ; } else { parent = & varargin_2 -> Base ; }
kstr = bname -> size [ 0 ] * bname -> size [ 1 ] ; bname -> size [ 0 ] = 1 ;
bname -> size [ 1 ] = parent -> NameInternal -> size [ 1 ] ; ac0ugu5nlz (
bname , kstr ) ; loop_ub = parent -> NameInternal -> size [ 1 ] - 1 ; for (
kstr = 0 ; kstr <= loop_ub ; kstr ++ ) { bname -> data [ kstr ] = parent ->
NameInternal -> data [ kstr ] ; } hahijoalwi ( iobj_3 , body , bname , & ( &
( & ( & ( & iobj_0 [ 0 ] ) [ 0 ] ) [ 0 ] ) [ 0 ] ) [ 8 ] , & ( & ( & ( & ( &
iobj_1 [ 0 ] ) [ 0 ] ) [ 0 ] ) [ 0 ] ) [ 4 ] , & ( & ( & ( & ( & iobj_2 [ 0 ]
) [ 0 ] ) [ 0 ] ) [ 0 ] ) [ 9 ] ) ; } b0l0vcvht3 ( & bname ) ; obj ->
RigidBodyTreeInternal = iobj_3 ; iobj_4 -> MaxNumIteration = 1500.0 ; iobj_4
-> MaxTime = 10.0 ; iobj_4 -> SolutionTolerance = 1.0E-6 ; iobj_4 ->
ConstraintsOn = true ; iobj_4 -> RandomRestart = true ; iobj_4 ->
StepTolerance = 1.0E-12 ; iobj_4 -> GradientTolerance = 5.0E-9 ; iobj_4 ->
ErrorChangeTolerance = 1.0E-12 ; iobj_4 -> DampingBias = 0.0025 ; iobj_4 ->
UseErrorDamping = true ; for ( kstr = 0 ; kstr < 18 ; kstr ++ ) { iobj_4 ->
Name [ kstr ] = tmp_f [ kstr ] ; } iobj_4 -> TimeObj . StartTime = tmp_j ;
iobj_4 -> TimeObjInternal . StartTime = tmp_j ; obj -> Solver = iobj_4 ;
iobj_4 = obj -> Solver ; bid = iobj_4 -> ErrorChangeTolerance ; b_p = iobj_4
-> DampingBias ; b_bool = iobj_4 -> UseErrorDamping ; for ( kstr = 0 ; kstr <
18 ; kstr ++ ) { switch_expression [ kstr ] = obj -> Solver -> Name [ kstr ]
; } for ( kstr = 0 ; kstr < 18 ; kstr ++ ) { b [ kstr ] = tmp_f [ kstr ] ; }
ret = memcmp ( & switch_expression [ 0 ] , & b [ 0 ] , 18 ) ; if ( ret == 0 )
{ bid = 0.001 ; b_p = 0.0025 ; b_bool = true ; } iobj_4 = obj -> Solver ;
iobj_4 -> MaxNumIteration = 1500.0 ; iobj_4 -> MaxTime = 10.0 ; iobj_4 ->
GradientTolerance = 0.001 ; iobj_4 -> SolutionTolerance = 0.01 ; iobj_4 ->
ConstraintsOn = true ; iobj_4 -> RandomRestart = false ; iobj_4 ->
StepTolerance = 1.0E-14 ; iobj_4 -> ErrorChangeTolerance = bid ; iobj_4 ->
DampingBias = b_p ; iobj_4 -> UseErrorDamping = b_bool ; obj ->
matlabCodegenIsDeleted = false ; return b_obj ; } static void g1slahjfob0o (
gh04rvpx0o * obj ) { e2b0f4s35s * jname ; gtd4jhsf2rw * iobj_0 ; gxcsgl11sl35
* iobj_2 ; iyg0swfnbfoc * iobj_1 ; kp1en3mw3xln * obj_p ; real_T poslim_data
[ 12 ] ; int32_T b_kstr ; int32_T loop_ub ; char_T b_p [ 9 ] ; char_T b [ 8 ]
; int8_T msubspace_data [ 36 ] ; int8_T tmp [ 6 ] ; boolean_T b_bool ; static
const char_T tmp_p [ 5 ] = { 'B' , 'o' , 'd' , 'y' , '1' } ; static const
real_T tmp_e [ 9 ] = { 0.0040894995012619572 , 2.9552305786773808E-10 ,
9.980130319567888E-10 , 2.9552305786773808E-10 , 0.0039539591910302879 , -
0.00036219306837993173 , 9.980130319567888E-10 , - 0.00036219306837993173 ,
0.00049638998948809039 } ; static const real_T tmp_i [ 36 ] = {
0.0040894995012619572 , 2.9552305786773808E-10 , 9.980130319567888E-10 , 0.0
, - 0.02945884490528235 , 0.0027887864464463 , 2.9552305786773808E-10 ,
0.0039539591910302879 , - 0.00036219306837993173 , 0.02945884490528235 , 0.0
, - 1.5429895872786831E-8 , 9.980130319567888E-10 , - 0.00036219306837993173
, 0.00049638998948809039 , - 0.0027887864464463 , 1.5429895872786831E-8 , 0.0
, 0.0 , 0.02945884490528235 , - 0.0027887864464463 , 0.28651908744870846 ,
0.0 , 0.0 , - 0.02945884490528235 , 0.0 , 1.5429895872786831E-8 , 0.0 ,
0.28651908744870846 , 0.0 , 0.0027887864464463 , - 1.5429895872786831E-8 ,
0.0 , 0.0 , 0.0 , 0.28651908744870846 } ; static const int8_T tmp_m [ 16 ] =
{ 1 , 0 , 0 , 0 , 0 , 1 , 0 , 0 , 0 , 0 , 1 , 0 , 0 , 0 , 0 , 1 } ; static
const char_T tmp_g [ 6 ] = { 'J' , 'o' , 'i' , 'n' , 't' , '1' } ; static
const char_T tmp_j [ 8 ] = { 'r' , 'e' , 'v' , 'o' , 'l' , 'u' , 't' , 'e' }
; static const char_T tmp_f [ 9 ] = { 'p' , 'r' , 'i' , 's' , 'm' , 'a' , 't'
, 'i' , 'c' } ; static const real_T tmp_c [ 16 ] = { 6.123233995736766E-17 ,
0.0 , 1.0 , 0.0 , 1.0 , 6.123233995736766E-17 , - 6.123233995736766E-17 , 0.0
, - 6.123233995736766E-17 , 1.0 , 3.749399456654644E-33 , 0.0 ,
0.0065704530241911842 , 0.04712085191226531 , 0.019427065864845966 , 1.0 } ;
static const real_T tmp_k [ 16 ] = { 1.0 , 0.0 , 0.0 , 0.0 , 0.0 , 1.0 , 0.0
, 0.0 , 0.0 , 0.0 , 1.0 , 0.0 , 0.0 , 0.0 , 0.0 , 1.0 } ; static const real_T
tmp_b [ 36 ] = { 0.0 , 0.0 , 1.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 ,
0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 ,
0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 }
; static const char_T tmp_n [ 5 ] = { 'B' , 'o' , 'd' , 'y' , '2' } ; static
const real_T tmp_l [ 9 ] = { 0.014376218450001947 , - 1.165065060553606E-9 ,
1.3368018040216121E-9 , - 1.165065060553606E-9 , 0.013713755769918337 ,
0.0016230471472996051 , 1.3368018040216121E-9 , 0.0016230471472996051 ,
0.00086369456911506478 } ; static const real_T tmp_d [ 36 ] = {
0.014376218450001947 , - 1.165065060553606E-9 , 1.3368018040216121E-9 , 0.0 ,
- 0.069224605751215265 , - 0.0080750346949890941 , - 1.165065060553606E-9 ,
0.013713755769918337 , 0.0016230471472996051 , 0.069224605751215265 , 0.0 ,
7.2566878750362473E-9 , 1.3368018040216121E-9 , 0.0016230471472996051 ,
0.00086369456911506478 , 0.0080750346949890941 , - 7.2566878750362473E-9 ,
0.0 , 0.0 , 0.069224605751215265 , 0.0080750346949890941 , 0.3575354053670361
, 0.0 , 0.0 , - 0.069224605751215265 , 0.0 , - 7.2566878750362473E-9 , 0.0 ,
0.3575354053670361 , 0.0 , - 0.0080750346949890941 , 7.2566878750362473E-9 ,
0.0 , 0.0 , 0.0 , 0.3575354053670361 } ; static const char_T tmp_o [ 6 ] = {
'J' , 'o' , 'i' , 'n' , 't' , '2' } ; static const real_T tmp_dz [ 16 ] = {
6.123233995736766E-17 , 0.0 , 1.0 , 0.0 , 1.0 , - 1.6081226496766366E-16 , -
6.123233995736766E-17 , 0.0 , 1.6081226496766366E-16 , 1.0 , -
9.8469112778142665E-33 , 0.0 , 2.7755575615628914E-17 , -
0.040001000000000037 , 0.13000000000000009 , 1.0 } ; int32_T exitg1 ; obj ->
isInitialized = 1 ; obj_p = & obj -> TreeInternal ; obj -> TreeInternal .
NumBodies = 5.0 ; iobj_0 = & obj -> TreeInternal . _pobj0 [ 0 ] ; iobj_1 = &
obj -> TreeInternal . _pobj1 [ 0 ] ; iobj_2 = & obj -> TreeInternal . _pobj2
[ 0 ] ; obj -> TreeInternal . Bodies [ 0 ] = ovxlwwg003 ( & ( & obj_p ->
_pobj2 [ 0 ] ) [ 0 ] , & iobj_0 [ 0 ] , & iobj_1 [ 0 ] ) ; obj ->
TreeInternal . Bodies [ 1 ] = pbim0sdm1g ( & iobj_2 [ 1 ] , & iobj_0 [ 1 ] ,
& iobj_1 [ 1 ] ) ; obj -> TreeInternal . Bodies [ 2 ] = gd1a2d5whe ( & iobj_2
[ 2 ] , & iobj_0 [ 2 ] , & iobj_1 [ 2 ] ) ; obj -> TreeInternal . Bodies [ 3
] = oswu44nkbe ( & iobj_2 [ 3 ] , & iobj_0 [ 3 ] , & iobj_1 [ 3 ] ) ; obj ->
TreeInternal . Bodies [ 4 ] = avigwta1rk ( & iobj_2 [ 4 ] , & iobj_0 [ 4 ] ,
& iobj_1 [ 4 ] ) ; iobj_2 = & obj -> TreeInternal . _pobj2 [ 5 ] ; b_kstr =
obj -> TreeInternal . _pobj2 [ 5 ] . NameInternal -> size [ 0 ] * obj ->
TreeInternal . _pobj2 [ 5 ] . NameInternal -> size [ 1 ] ; obj ->
TreeInternal . _pobj2 [ 5 ] . NameInternal -> size [ 0 ] = 1 ; obj ->
TreeInternal . _pobj2 [ 5 ] . NameInternal -> size [ 1 ] = 5 ; ac0ugu5nlz (
obj -> TreeInternal . _pobj2 [ 5 ] . NameInternal , b_kstr ) ; for ( b_kstr =
0 ; b_kstr < 5 ; b_kstr ++ ) { obj -> TreeInternal . _pobj2 [ 5 ] .
NameInternal -> data [ b_kstr ] = tmp_p [ b_kstr ] ; } obj -> TreeInternal .
_pobj2 [ 5 ] . ParentIndex = 0.0 ; obj -> TreeInternal . _pobj2 [ 5 ] .
MassInternal = 0.28651908744870846 ; obj -> TreeInternal . _pobj2 [ 5 ] .
CenterOfMassInternal [ 0 ] = 5.3852942260082526E-8 ; obj -> TreeInternal .
_pobj2 [ 5 ] . CenterOfMassInternal [ 1 ] = 0.0097333356436350438 ; obj ->
TreeInternal . _pobj2 [ 5 ] . CenterOfMassInternal [ 2 ] =
0.10281634346806287 ; for ( b_kstr = 0 ; b_kstr < 9 ; b_kstr ++ ) { obj ->
TreeInternal . _pobj2 [ 5 ] . InertiaInternal [ b_kstr ] = tmp_e [ b_kstr ] ;
} for ( b_kstr = 0 ; b_kstr < 36 ; b_kstr ++ ) { obj -> TreeInternal . _pobj2
[ 5 ] . SpatialInertia [ b_kstr ] = tmp_i [ b_kstr ] ; } obj_p -> _pobj1 [ 5
] . InTree = false ; for ( b_kstr = 0 ; b_kstr < 16 ; b_kstr ++ ) { obj_p ->
_pobj1 [ 5 ] . JointToParentTransform [ b_kstr ] = tmp_m [ b_kstr ] ; } for (
b_kstr = 0 ; b_kstr < 16 ; b_kstr ++ ) { obj_p -> _pobj1 [ 5 ] .
ChildToJointTransform [ b_kstr ] = tmp_m [ b_kstr ] ; } b_kstr = obj_p ->
_pobj1 [ 5 ] . NameInternal -> size [ 0 ] * obj_p -> _pobj1 [ 5 ] .
NameInternal -> size [ 1 ] ; obj_p -> _pobj1 [ 5 ] . NameInternal -> size [ 0
] = 1 ; obj_p -> _pobj1 [ 5 ] . NameInternal -> size [ 1 ] = 6 ; ac0ugu5nlz (
obj_p -> _pobj1 [ 5 ] . NameInternal , b_kstr ) ; for ( b_kstr = 0 ; b_kstr <
6 ; b_kstr ++ ) { obj_p -> _pobj1 [ 5 ] . NameInternal -> data [ b_kstr ] =
tmp_g [ b_kstr ] ; } b_kstr = obj_p -> _pobj1 [ 5 ] . Type -> size [ 0 ] *
obj_p -> _pobj1 [ 5 ] . Type -> size [ 1 ] ; obj_p -> _pobj1 [ 5 ] . Type ->
size [ 0 ] = 1 ; obj_p -> _pobj1 [ 5 ] . Type -> size [ 1 ] = 8 ; ac0ugu5nlz
( obj_p -> _pobj1 [ 5 ] . Type , b_kstr ) ; for ( b_kstr = 0 ; b_kstr < 8 ;
b_kstr ++ ) { obj_p -> _pobj1 [ 5 ] . Type -> data [ b_kstr ] = tmp_j [
b_kstr ] ; } gunzkbl0qg ( & jname , 2 ) ; b_kstr = jname -> size [ 0 ] *
jname -> size [ 1 ] ; jname -> size [ 0 ] = 1 ; jname -> size [ 1 ] = obj_p
-> _pobj1 [ 5 ] . Type -> size [ 1 ] ; ac0ugu5nlz ( jname , b_kstr ) ;
loop_ub = obj_p -> _pobj1 [ 5 ] . Type -> size [ 1 ] - 1 ; for ( b_kstr = 0 ;
b_kstr <= loop_ub ; b_kstr ++ ) { jname -> data [ b_kstr ] = obj_p -> _pobj1
[ 5 ] . Type -> data [ b_kstr ] ; } for ( b_kstr = 0 ; b_kstr < 8 ; b_kstr ++
) { b [ b_kstr ] = tmp_j [ b_kstr ] ; } b_bool = false ; if ( jname -> size [
1 ] != 8 ) { } else { b_kstr = 1 ; do { exitg1 = 0 ; if ( b_kstr - 1 < 8 ) {
if ( jname -> data [ b_kstr - 1 ] != b [ b_kstr - 1 ] ) { exitg1 = 1 ; } else
{ b_kstr ++ ; } } else { b_bool = true ; exitg1 = 1 ; } } while ( exitg1 == 0
) ; } if ( b_bool ) { b_kstr = 0 ; } else { for ( b_kstr = 0 ; b_kstr < 9 ;
b_kstr ++ ) { b_p [ b_kstr ] = tmp_f [ b_kstr ] ; } if ( jname -> size [ 1 ]
!= 9 ) { } else { b_kstr = 1 ; do { exitg1 = 0 ; if ( b_kstr - 1 < 9 ) { if (
jname -> data [ b_kstr - 1 ] != b_p [ b_kstr - 1 ] ) { exitg1 = 1 ; } else {
b_kstr ++ ; } } else { b_bool = true ; exitg1 = 1 ; } } while ( exitg1 == 0 )
; } if ( b_bool ) { b_kstr = 1 ; } else { b_kstr = - 1 ; } } switch ( b_kstr
) { case 0 : tmp [ 0 ] = 0 ; tmp [ 1 ] = 0 ; tmp [ 2 ] = 1 ; tmp [ 3 ] = 0 ;
tmp [ 4 ] = 0 ; tmp [ 5 ] = 0 ; for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr ++ ) {
msubspace_data [ b_kstr ] = tmp [ b_kstr ] ; } poslim_data [ 0 ] = -
3.1415926535897931 ; poslim_data [ 1 ] = 3.1415926535897931 ; obj_p -> _pobj1
[ 5 ] . VelocityNumber = 1.0 ; obj_p -> _pobj1 [ 5 ] . PositionNumber = 1.0 ;
obj_p -> _pobj1 [ 5 ] . JointAxisInternal [ 0 ] = 0.0 ; obj_p -> _pobj1 [ 5 ]
. JointAxisInternal [ 1 ] = 0.0 ; obj_p -> _pobj1 [ 5 ] . JointAxisInternal [
2 ] = 1.0 ; break ; case 1 : tmp [ 0 ] = 0 ; tmp [ 1 ] = 0 ; tmp [ 2 ] = 0 ;
tmp [ 3 ] = 0 ; tmp [ 4 ] = 0 ; tmp [ 5 ] = 1 ; for ( b_kstr = 0 ; b_kstr < 6
; b_kstr ++ ) { msubspace_data [ b_kstr ] = tmp [ b_kstr ] ; } poslim_data [
0 ] = - 0.5 ; poslim_data [ 1 ] = 0.5 ; obj_p -> _pobj1 [ 5 ] .
VelocityNumber = 1.0 ; obj_p -> _pobj1 [ 5 ] . PositionNumber = 1.0 ; obj_p
-> _pobj1 [ 5 ] . JointAxisInternal [ 0 ] = 0.0 ; obj_p -> _pobj1 [ 5 ] .
JointAxisInternal [ 1 ] = 0.0 ; obj_p -> _pobj1 [ 5 ] . JointAxisInternal [ 2
] = 1.0 ; break ; default : for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr ++ ) {
msubspace_data [ b_kstr ] = 0 ; } poslim_data [ 0 ] = 0.0 ; poslim_data [ 1 ]
= 0.0 ; obj_p -> _pobj1 [ 5 ] . VelocityNumber = 0.0 ; obj_p -> _pobj1 [ 5 ]
. PositionNumber = 0.0 ; obj_p -> _pobj1 [ 5 ] . JointAxisInternal [ 0 ] =
0.0 ; obj_p -> _pobj1 [ 5 ] . JointAxisInternal [ 1 ] = 0.0 ; obj_p -> _pobj1
[ 5 ] . JointAxisInternal [ 2 ] = 0.0 ; break ; } b_kstr = obj_p -> _pobj1 [
5 ] . MotionSubspace -> size [ 0 ] * obj_p -> _pobj1 [ 5 ] . MotionSubspace
-> size [ 1 ] ; obj_p -> _pobj1 [ 5 ] . MotionSubspace -> size [ 0 ] = 6 ;
obj_p -> _pobj1 [ 5 ] . MotionSubspace -> size [ 1 ] = 1 ; ier0p3wwtw ( obj_p
-> _pobj1 [ 5 ] . MotionSubspace , b_kstr ) ; for ( b_kstr = 0 ; b_kstr < 6 ;
b_kstr ++ ) { obj_p -> _pobj1 [ 5 ] . MotionSubspace -> data [ b_kstr ] =
msubspace_data [ b_kstr ] ; } b_kstr = obj_p -> _pobj1 [ 5 ] .
PositionLimitsInternal -> size [ 0 ] * obj_p -> _pobj1 [ 5 ] .
PositionLimitsInternal -> size [ 1 ] ; obj_p -> _pobj1 [ 5 ] .
PositionLimitsInternal -> size [ 0 ] = 1 ; obj_p -> _pobj1 [ 5 ] .
PositionLimitsInternal -> size [ 1 ] = 2 ; ier0p3wwtw ( obj_p -> _pobj1 [ 5 ]
. PositionLimitsInternal , b_kstr ) ; for ( b_kstr = 0 ; b_kstr < 2 ; b_kstr
++ ) { obj_p -> _pobj1 [ 5 ] . PositionLimitsInternal -> data [ b_kstr ] =
poslim_data [ b_kstr ] ; } b_kstr = obj_p -> _pobj1 [ 5 ] .
HomePositionInternal -> size [ 0 ] ; obj_p -> _pobj1 [ 5 ] .
HomePositionInternal -> size [ 0 ] = 1 ; ier0p3wwtw ( obj_p -> _pobj1 [ 5 ] .
HomePositionInternal , b_kstr ) ; obj_p -> _pobj1 [ 5 ] .
HomePositionInternal -> data [ 0 ] = 0.0 ; obj -> TreeInternal . _pobj2 [ 5 ]
. JointInternal = & obj_p -> _pobj1 [ 5 ] ; for ( b_kstr = 0 ; b_kstr < 16 ;
b_kstr ++ ) { obj -> TreeInternal . _pobj2 [ 5 ] . JointInternal ->
JointToParentTransform [ b_kstr ] = tmp_c [ b_kstr ] ; } for ( b_kstr = 0 ;
b_kstr < 16 ; b_kstr ++ ) { obj -> TreeInternal . _pobj2 [ 5 ] .
JointInternal -> ChildToJointTransform [ b_kstr ] = tmp_k [ b_kstr ] ; }
b_kstr = obj -> TreeInternal . _pobj2 [ 5 ] . JointInternal -> MotionSubspace
-> size [ 0 ] * obj -> TreeInternal . _pobj2 [ 5 ] . JointInternal ->
MotionSubspace -> size [ 1 ] ; obj -> TreeInternal . _pobj2 [ 5 ] .
JointInternal -> MotionSubspace -> size [ 0 ] = 6 ; obj -> TreeInternal .
_pobj2 [ 5 ] . JointInternal -> MotionSubspace -> size [ 1 ] = 1 ; ier0p3wwtw
( obj -> TreeInternal . _pobj2 [ 5 ] . JointInternal -> MotionSubspace ,
b_kstr ) ; for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr ++ ) { obj -> TreeInternal
. _pobj2 [ 5 ] . JointInternal -> MotionSubspace -> data [ b_kstr ] = tmp_b [
b_kstr ] ; } obj -> TreeInternal . _pobj2 [ 5 ] . JointInternal -> InTree =
true ; b_kstr = obj -> TreeInternal . _pobj2 [ 5 ] . JointInternal ->
PositionLimitsInternal -> size [ 0 ] * obj -> TreeInternal . _pobj2 [ 5 ] .
JointInternal -> PositionLimitsInternal -> size [ 1 ] ; obj -> TreeInternal .
_pobj2 [ 5 ] . JointInternal -> PositionLimitsInternal -> size [ 0 ] = 1 ;
obj -> TreeInternal . _pobj2 [ 5 ] . JointInternal -> PositionLimitsInternal
-> size [ 1 ] = 2 ; ier0p3wwtw ( obj -> TreeInternal . _pobj2 [ 5 ] .
JointInternal -> PositionLimitsInternal , b_kstr ) ; obj -> TreeInternal .
_pobj2 [ 5 ] . JointInternal -> PositionLimitsInternal -> data [ 0 ] = -
3.1415926535897931 ; obj -> TreeInternal . _pobj2 [ 5 ] . JointInternal ->
PositionLimitsInternal -> data [ obj -> TreeInternal . _pobj2 [ 5 ] .
JointInternal -> PositionLimitsInternal -> size [ 0 ] ] = 3.1415926535897931
; obj -> TreeInternal . _pobj2 [ 5 ] . JointInternal -> JointAxisInternal [ 0
] = 0.0 ; obj -> TreeInternal . _pobj2 [ 5 ] . JointInternal ->
JointAxisInternal [ 1 ] = 0.0 ; obj -> TreeInternal . _pobj2 [ 5 ] .
JointInternal -> JointAxisInternal [ 2 ] = 1.0 ; b_kstr = obj -> TreeInternal
. _pobj2 [ 5 ] . JointInternal -> HomePositionInternal -> size [ 0 ] ; obj ->
TreeInternal . _pobj2 [ 5 ] . JointInternal -> HomePositionInternal -> size [
0 ] = 1 ; ier0p3wwtw ( obj -> TreeInternal . _pobj2 [ 5 ] . JointInternal ->
HomePositionInternal , b_kstr ) ; obj -> TreeInternal . _pobj2 [ 5 ] .
JointInternal -> HomePositionInternal -> data [ 0 ] = - 2.6538287270903349 ;
obj -> TreeInternal . _pobj2 [ 5 ] . CollisionsInternal = aydneur4h5so ( &
obj -> TreeInternal . _pobj0 [ 5 ] , 0.0 ) ; obj -> TreeInternal . Bodies [ 0
] = iobj_2 ; obj -> TreeInternal . Bodies [ 0 ] -> Index = 1.0 ; iobj_2 = &
obj -> TreeInternal . _pobj2 [ 6 ] ; b_kstr = obj -> TreeInternal . _pobj2 [
6 ] . NameInternal -> size [ 0 ] * obj -> TreeInternal . _pobj2 [ 6 ] .
NameInternal -> size [ 1 ] ; obj -> TreeInternal . _pobj2 [ 6 ] .
NameInternal -> size [ 0 ] = 1 ; obj -> TreeInternal . _pobj2 [ 6 ] .
NameInternal -> size [ 1 ] = 5 ; ac0ugu5nlz ( obj -> TreeInternal . _pobj2 [
6 ] . NameInternal , b_kstr ) ; for ( b_kstr = 0 ; b_kstr < 5 ; b_kstr ++ ) {
obj -> TreeInternal . _pobj2 [ 6 ] . NameInternal -> data [ b_kstr ] = tmp_n
[ b_kstr ] ; } obj -> TreeInternal . _pobj2 [ 6 ] . ParentIndex = 1.0 ; obj
-> TreeInternal . _pobj2 [ 6 ] . MassInternal = 0.3575354053670361 ; obj ->
TreeInternal . _pobj2 [ 6 ] . CenterOfMassInternal [ 0 ] = -
2.0296417546639134E-8 ; obj -> TreeInternal . _pobj2 [ 6 ] .
CenterOfMassInternal [ 1 ] = - 0.022585272881435293 ; obj -> TreeInternal .
_pobj2 [ 6 ] . CenterOfMassInternal [ 2 ] = 0.19361608588148402 ; for (
b_kstr = 0 ; b_kstr < 9 ; b_kstr ++ ) { obj -> TreeInternal . _pobj2 [ 6 ] .
InertiaInternal [ b_kstr ] = tmp_l [ b_kstr ] ; } for ( b_kstr = 0 ; b_kstr <
36 ; b_kstr ++ ) { obj -> TreeInternal . _pobj2 [ 6 ] . SpatialInertia [
b_kstr ] = tmp_d [ b_kstr ] ; } obj_p -> _pobj1 [ 6 ] . InTree = false ; for
( b_kstr = 0 ; b_kstr < 16 ; b_kstr ++ ) { obj_p -> _pobj1 [ 6 ] .
JointToParentTransform [ b_kstr ] = tmp_m [ b_kstr ] ; } for ( b_kstr = 0 ;
b_kstr < 16 ; b_kstr ++ ) { obj_p -> _pobj1 [ 6 ] . ChildToJointTransform [
b_kstr ] = tmp_m [ b_kstr ] ; } b_kstr = obj_p -> _pobj1 [ 6 ] . NameInternal
-> size [ 0 ] * obj_p -> _pobj1 [ 6 ] . NameInternal -> size [ 1 ] ; obj_p ->
_pobj1 [ 6 ] . NameInternal -> size [ 0 ] = 1 ; obj_p -> _pobj1 [ 6 ] .
NameInternal -> size [ 1 ] = 6 ; ac0ugu5nlz ( obj_p -> _pobj1 [ 6 ] .
NameInternal , b_kstr ) ; for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr ++ ) { obj_p
-> _pobj1 [ 6 ] . NameInternal -> data [ b_kstr ] = tmp_o [ b_kstr ] ; }
b_kstr = obj_p -> _pobj1 [ 6 ] . Type -> size [ 0 ] * obj_p -> _pobj1 [ 6 ] .
Type -> size [ 1 ] ; obj_p -> _pobj1 [ 6 ] . Type -> size [ 0 ] = 1 ; obj_p
-> _pobj1 [ 6 ] . Type -> size [ 1 ] = 8 ; ac0ugu5nlz ( obj_p -> _pobj1 [ 6 ]
. Type , b_kstr ) ; for ( b_kstr = 0 ; b_kstr < 8 ; b_kstr ++ ) { obj_p ->
_pobj1 [ 6 ] . Type -> data [ b_kstr ] = tmp_j [ b_kstr ] ; } b_kstr = jname
-> size [ 0 ] * jname -> size [ 1 ] ; jname -> size [ 0 ] = 1 ; jname -> size
[ 1 ] = obj_p -> _pobj1 [ 6 ] . Type -> size [ 1 ] ; ac0ugu5nlz ( jname ,
b_kstr ) ; loop_ub = obj_p -> _pobj1 [ 6 ] . Type -> size [ 1 ] - 1 ; for (
b_kstr = 0 ; b_kstr <= loop_ub ; b_kstr ++ ) { jname -> data [ b_kstr ] =
obj_p -> _pobj1 [ 6 ] . Type -> data [ b_kstr ] ; } b_bool = false ; if (
jname -> size [ 1 ] != 8 ) { } else { b_kstr = 1 ; do { exitg1 = 0 ; if (
b_kstr - 1 < 8 ) { if ( jname -> data [ b_kstr - 1 ] != b [ b_kstr - 1 ] ) {
exitg1 = 1 ; } else { b_kstr ++ ; } } else { b_bool = true ; exitg1 = 1 ; } }
while ( exitg1 == 0 ) ; } if ( b_bool ) { b_kstr = 0 ; } else { for ( b_kstr
= 0 ; b_kstr < 9 ; b_kstr ++ ) { b_p [ b_kstr ] = tmp_f [ b_kstr ] ; } if (
jname -> size [ 1 ] != 9 ) { } else { b_kstr = 1 ; do { exitg1 = 0 ; if (
b_kstr - 1 < 9 ) { if ( jname -> data [ b_kstr - 1 ] != b_p [ b_kstr - 1 ] )
{ exitg1 = 1 ; } else { b_kstr ++ ; } } else { b_bool = true ; exitg1 = 1 ; }
} while ( exitg1 == 0 ) ; } if ( b_bool ) { b_kstr = 1 ; } else { b_kstr = -
1 ; } } switch ( b_kstr ) { case 0 : tmp [ 0 ] = 0 ; tmp [ 1 ] = 0 ; tmp [ 2
] = 1 ; tmp [ 3 ] = 0 ; tmp [ 4 ] = 0 ; tmp [ 5 ] = 0 ; for ( b_kstr = 0 ;
b_kstr < 6 ; b_kstr ++ ) { msubspace_data [ b_kstr ] = tmp [ b_kstr ] ; }
poslim_data [ 0 ] = - 3.1415926535897931 ; poslim_data [ 1 ] =
3.1415926535897931 ; obj_p -> _pobj1 [ 6 ] . VelocityNumber = 1.0 ; obj_p ->
_pobj1 [ 6 ] . PositionNumber = 1.0 ; obj_p -> _pobj1 [ 6 ] .
JointAxisInternal [ 0 ] = 0.0 ; obj_p -> _pobj1 [ 6 ] . JointAxisInternal [ 1
] = 0.0 ; obj_p -> _pobj1 [ 6 ] . JointAxisInternal [ 2 ] = 1.0 ; break ;
case 1 : tmp [ 0 ] = 0 ; tmp [ 1 ] = 0 ; tmp [ 2 ] = 0 ; tmp [ 3 ] = 0 ; tmp
[ 4 ] = 0 ; tmp [ 5 ] = 1 ; for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr ++ ) {
msubspace_data [ b_kstr ] = tmp [ b_kstr ] ; } poslim_data [ 0 ] = - 0.5 ;
poslim_data [ 1 ] = 0.5 ; obj_p -> _pobj1 [ 6 ] . VelocityNumber = 1.0 ;
obj_p -> _pobj1 [ 6 ] . PositionNumber = 1.0 ; obj_p -> _pobj1 [ 6 ] .
JointAxisInternal [ 0 ] = 0.0 ; obj_p -> _pobj1 [ 6 ] . JointAxisInternal [ 1
] = 0.0 ; obj_p -> _pobj1 [ 6 ] . JointAxisInternal [ 2 ] = 1.0 ; break ;
default : for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr ++ ) { msubspace_data [
b_kstr ] = 0 ; } poslim_data [ 0 ] = 0.0 ; poslim_data [ 1 ] = 0.0 ; obj_p ->
_pobj1 [ 6 ] . VelocityNumber = 0.0 ; obj_p -> _pobj1 [ 6 ] . PositionNumber
= 0.0 ; obj_p -> _pobj1 [ 6 ] . JointAxisInternal [ 0 ] = 0.0 ; obj_p ->
_pobj1 [ 6 ] . JointAxisInternal [ 1 ] = 0.0 ; obj_p -> _pobj1 [ 6 ] .
JointAxisInternal [ 2 ] = 0.0 ; break ; } b_kstr = obj_p -> _pobj1 [ 6 ] .
MotionSubspace -> size [ 0 ] * obj_p -> _pobj1 [ 6 ] . MotionSubspace -> size
[ 1 ] ; obj_p -> _pobj1 [ 6 ] . MotionSubspace -> size [ 0 ] = 6 ; obj_p ->
_pobj1 [ 6 ] . MotionSubspace -> size [ 1 ] = 1 ; ier0p3wwtw ( obj_p ->
_pobj1 [ 6 ] . MotionSubspace , b_kstr ) ; for ( b_kstr = 0 ; b_kstr < 6 ;
b_kstr ++ ) { obj_p -> _pobj1 [ 6 ] . MotionSubspace -> data [ b_kstr ] =
msubspace_data [ b_kstr ] ; } b_kstr = obj_p -> _pobj1 [ 6 ] .
PositionLimitsInternal -> size [ 0 ] * obj_p -> _pobj1 [ 6 ] .
PositionLimitsInternal -> size [ 1 ] ; obj_p -> _pobj1 [ 6 ] .
PositionLimitsInternal -> size [ 0 ] = 1 ; obj_p -> _pobj1 [ 6 ] .
PositionLimitsInternal -> size [ 1 ] = 2 ; ier0p3wwtw ( obj_p -> _pobj1 [ 6 ]
. PositionLimitsInternal , b_kstr ) ; for ( b_kstr = 0 ; b_kstr < 2 ; b_kstr
++ ) { obj_p -> _pobj1 [ 6 ] . PositionLimitsInternal -> data [ b_kstr ] =
poslim_data [ b_kstr ] ; } b_kstr = obj_p -> _pobj1 [ 6 ] .
HomePositionInternal -> size [ 0 ] ; obj_p -> _pobj1 [ 6 ] .
HomePositionInternal -> size [ 0 ] = 1 ; ier0p3wwtw ( obj_p -> _pobj1 [ 6 ] .
HomePositionInternal , b_kstr ) ; obj_p -> _pobj1 [ 6 ] .
HomePositionInternal -> data [ 0 ] = 0.0 ; obj -> TreeInternal . _pobj2 [ 6 ]
. JointInternal = & obj_p -> _pobj1 [ 6 ] ; for ( b_kstr = 0 ; b_kstr < 16 ;
b_kstr ++ ) { obj -> TreeInternal . _pobj2 [ 6 ] . JointInternal ->
JointToParentTransform [ b_kstr ] = tmp_dz [ b_kstr ] ; } for ( b_kstr = 0 ;
b_kstr < 16 ; b_kstr ++ ) { obj -> TreeInternal . _pobj2 [ 6 ] .
JointInternal -> ChildToJointTransform [ b_kstr ] = tmp_k [ b_kstr ] ; }
b_kstr = obj -> TreeInternal . _pobj2 [ 6 ] . JointInternal -> MotionSubspace
-> size [ 0 ] * obj -> TreeInternal . _pobj2 [ 6 ] . JointInternal ->
MotionSubspace -> size [ 1 ] ; obj -> TreeInternal . _pobj2 [ 6 ] .
JointInternal -> MotionSubspace -> size [ 0 ] = 6 ; obj -> TreeInternal .
_pobj2 [ 6 ] . JointInternal -> MotionSubspace -> size [ 1 ] = 1 ; ier0p3wwtw
( obj -> TreeInternal . _pobj2 [ 6 ] . JointInternal -> MotionSubspace ,
b_kstr ) ; for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr ++ ) { obj -> TreeInternal
. _pobj2 [ 6 ] . JointInternal -> MotionSubspace -> data [ b_kstr ] = tmp_b [
b_kstr ] ; } obj -> TreeInternal . _pobj2 [ 6 ] . JointInternal -> InTree =
true ; b_kstr = obj -> TreeInternal . _pobj2 [ 6 ] . JointInternal ->
PositionLimitsInternal -> size [ 0 ] * obj -> TreeInternal . _pobj2 [ 6 ] .
JointInternal -> PositionLimitsInternal -> size [ 1 ] ; obj -> TreeInternal .
_pobj2 [ 6 ] . JointInternal -> PositionLimitsInternal -> size [ 0 ] = 1 ;
obj -> TreeInternal . _pobj2 [ 6 ] . JointInternal -> PositionLimitsInternal
-> size [ 1 ] = 2 ; ier0p3wwtw ( obj -> TreeInternal . _pobj2 [ 6 ] .
JointInternal -> PositionLimitsInternal , b_kstr ) ; obj -> TreeInternal .
_pobj2 [ 6 ] . JointInternal -> PositionLimitsInternal -> data [ 0 ] = -
3.1415926535897931 ; obj -> TreeInternal . _pobj2 [ 6 ] . JointInternal ->
PositionLimitsInternal -> data [ obj -> TreeInternal . _pobj2 [ 6 ] .
JointInternal -> PositionLimitsInternal -> size [ 0 ] ] = 3.1415926535897931
; obj -> TreeInternal . _pobj2 [ 6 ] . JointInternal -> JointAxisInternal [ 0
] = 0.0 ; obj -> TreeInternal . _pobj2 [ 6 ] . JointInternal ->
JointAxisInternal [ 1 ] = 0.0 ; obj -> TreeInternal . _pobj2 [ 6 ] .
JointInternal -> JointAxisInternal [ 2 ] = 1.0 ; b_kstr = obj -> TreeInternal
. _pobj2 [ 6 ] . JointInternal -> HomePositionInternal -> size [ 0 ] ; obj ->
TreeInternal . _pobj2 [ 6 ] . JointInternal -> HomePositionInternal -> size [
0 ] = 1 ; ier0p3wwtw ( obj -> TreeInternal . _pobj2 [ 6 ] . JointInternal ->
HomePositionInternal , b_kstr ) ; obj -> TreeInternal . _pobj2 [ 6 ] .
JointInternal -> HomePositionInternal -> data [ 0 ] = 1.5133016287744308 ;
obj -> TreeInternal . _pobj2 [ 6 ] . CollisionsInternal = aydneur4h5so ( &
obj -> TreeInternal . _pobj0 [ 6 ] , 0.0 ) ; obj -> TreeInternal . Bodies [ 1
] = iobj_2 ; obj -> TreeInternal . Bodies [ 1 ] -> Index = 2.0 ; obj ->
TreeInternal . Bodies [ 2 ] = fu3whh3mfb ( & obj -> TreeInternal . _pobj2 [ 7
] , & obj -> TreeInternal . _pobj0 [ 7 ] , & obj -> TreeInternal . _pobj1 [ 7
] ) ; obj -> TreeInternal . Bodies [ 2 ] -> Index = 3.0 ; obj -> TreeInternal
. Bodies [ 3 ] = hi1fv3qgyp ( & obj -> TreeInternal . _pobj2 [ 8 ] , & obj ->
TreeInternal . _pobj0 [ 8 ] , & obj -> TreeInternal . _pobj1 [ 8 ] ) ; obj ->
TreeInternal . Bodies [ 3 ] -> Index = 4.0 ; obj -> TreeInternal . Bodies [ 4
] = hgxe0mqtnx ( & obj -> TreeInternal . _pobj2 [ 9 ] , & obj -> TreeInternal
. _pobj0 [ 9 ] , & obj -> TreeInternal . _pobj1 [ 9 ] ) ; obj -> TreeInternal
. Bodies [ 4 ] -> Index = 5.0 ; obj -> TreeInternal . Gravity [ 0 ] = 0.0 ;
obj -> TreeInternal . Gravity [ 1 ] = - 9.80665 ; obj -> TreeInternal .
Gravity [ 2 ] = 0.0 ; b_kstr = obj -> TreeInternal . Base . NameInternal ->
size [ 0 ] * obj -> TreeInternal . Base . NameInternal -> size [ 1 ] ; obj ->
TreeInternal . Base . NameInternal -> size [ 0 ] = 1 ; obj -> TreeInternal .
Base . NameInternal -> size [ 1 ] = 4 ; ac0ugu5nlz ( obj -> TreeInternal .
Base . NameInternal , b_kstr ) ; obj -> TreeInternal . Base . NameInternal ->
data [ 0 ] = 'B' ; obj -> TreeInternal . Base . NameInternal -> data [ 1 ] =
'a' ; obj -> TreeInternal . Base . NameInternal -> data [ 2 ] = 's' ; obj ->
TreeInternal . Base . NameInternal -> data [ 3 ] = 'e' ; obj -> TreeInternal
. Base . ParentIndex = - 1.0 ; obj -> TreeInternal . Base . MassInternal =
0.0 ; obj -> TreeInternal . Base . CenterOfMassInternal [ 0 ] = 0.0 ; obj ->
TreeInternal . Base . CenterOfMassInternal [ 1 ] = 0.0 ; obj -> TreeInternal
. Base . CenterOfMassInternal [ 2 ] = 0.0 ; for ( b_kstr = 0 ; b_kstr < 9 ;
b_kstr ++ ) { obj -> TreeInternal . Base . InertiaInternal [ b_kstr ] = 0.0 ;
} for ( b_kstr = 0 ; b_kstr < 36 ; b_kstr ++ ) { obj -> TreeInternal . Base .
SpatialInertia [ b_kstr ] = 0.0 ; } b_kstr = jname -> size [ 0 ] * jname ->
size [ 1 ] ; jname -> size [ 0 ] = 1 ; jname -> size [ 1 ] = obj ->
TreeInternal . Base . NameInternal -> size [ 1 ] + 4 ; ac0ugu5nlz ( jname ,
b_kstr ) ; loop_ub = obj -> TreeInternal . Base . NameInternal -> size [ 1 ]
; for ( b_kstr = 0 ; b_kstr < loop_ub ; b_kstr ++ ) { jname -> data [ b_kstr
] = obj -> TreeInternal . Base . NameInternal -> data [ b_kstr ] ; } jname ->
data [ loop_ub ] = '_' ; jname -> data [ loop_ub + 1 ] = 'j' ; jname -> data
[ loop_ub + 2 ] = 'n' ; jname -> data [ loop_ub + 3 ] = 't' ; obj ->
TreeInternal . Base . JointInternal = j32lrgnqkz ( & obj_p -> _pobj1 [ 10 ] ,
jname ) ; obj -> TreeInternal . Base . CollisionsInternal = aydneur4h5so ( &
obj -> TreeInternal . _pobj0 [ 10 ] , 0.0 ) ; obj -> TreeInternal . Base .
Index = 0.0 ; clllcb3tqp ( & obj -> IKInternal , & obj -> TreeInternal ) ;
b0l0vcvht3 ( & jname ) ; } static void ljrzulvsuz ( iyg0swfnbf * pStruct ) {
gunzkbl0qg ( & pStruct -> Type , 2 ) ; cy4r1g1cm1 ( & pStruct ->
MotionSubspace , 2 ) ; } static void azpme0b1ng ( gtd4jhsf2r * pStruct ) {
bbp43aslv1 ( & pStruct -> CollisionGeometries , 2 ) ; } static void
lt1ngaczuv ( gxcsgl11sl * pStruct ) { gunzkbl0qg ( & pStruct -> NameInternal
, 2 ) ; ljrzulvsuz ( & pStruct -> JointInternal ) ; azpme0b1ng ( & pStruct ->
CollisionsInternal ) ; } static void m4davgb45zzoph ( gxcsgl11sl pMatrix [ 10
] ) { int32_T i ; for ( i = 0 ; i < 10 ; i ++ ) { lt1ngaczuv ( & pMatrix [ i
] ) ; } } static void nm1vytfqlzestmw ( kp1en3mw3x * pStruct ) { lt1ngaczuv (
& pStruct -> Base ) ; m4davgb45zzoph ( pStruct -> _pobj0 ) ; } static void
l353migxc4h ( exm4lytzjq * pStruct ) { nm1vytfqlzestmw ( & pStruct ->
TreeInternal ) ; } static gtd4jhsf2r * aydneur4h5 ( gtd4jhsf2r * obj ) { void
* defaultCollisionObj_GeometryInternal ; gtd4jhsf2r * b_obj ; mqyxc3drwd *
obj_p ; naq1wbp3ki * e ; real_T c ; int32_T b_i ; int32_T d ; bbp43aslv1 ( &
e , 2 ) ; b_obj = obj ; obj -> MaxElements = 0.0 ; b_i = e -> size [ 0 ] * e
-> size [ 1 ] ; e -> size [ 1 ] = ( int32_T ) obj -> MaxElements ; keuyu41tq3
( e , b_i ) ; b_i = obj -> CollisionGeometries -> size [ 0 ] * obj ->
CollisionGeometries -> size [ 1 ] ; obj -> CollisionGeometries -> size [ 0 ]
= 1 ; obj -> CollisionGeometries -> size [ 1 ] = e -> size [ 1 ] ; keuyu41tq3
( obj -> CollisionGeometries , b_i ) ; defaultCollisionObj_GeometryInternal =
0 ; obj_p = & obj -> _pobj0 ; obj -> _pobj0 . CollisionPrimitive =
defaultCollisionObj_GeometryInternal ; obj -> _pobj0 . matlabCodegenIsDeleted
= false ; c = obj -> MaxElements ; d = ( int32_T ) c - 1 ; mepjkxapz0 ( & e )
; for ( b_i = 0 ; b_i <= d ; b_i ++ ) { obj -> CollisionGeometries -> data [
b_i ] = obj_p ; } return b_obj ; } static gxcsgl11sl * mhyfpzbtel (
gxcsgl11sl * obj ) { e2b0f4s35s * switch_expression ; gxcsgl11sl * b_obj ;
int32_T b_kstr ; int32_T loop_ub ; char_T b_p [ 9 ] ; char_T b [ 8 ] ; int8_T
msubspace_data [ 36 ] ; int8_T tmp [ 6 ] ; boolean_T b_bool ; static const
char_T tmp_p [ 10 ] = { 'd' , 'u' , 'm' , 'm' , 'y' , 'b' , 'o' , 'd' , 'y' ,
'5' } ; static const char_T tmp_e [ 5 ] = { 'f' , 'i' , 'x' , 'e' , 'd' } ;
static const char_T tmp_i [ 8 ] = { 'r' , 'e' , 'v' , 'o' , 'l' , 'u' , 't' ,
'e' } ; static const char_T tmp_m [ 9 ] = { 'p' , 'r' , 'i' , 's' , 'm' , 'a'
, 't' , 'i' , 'c' } ; int32_T exitg1 ; b_obj = obj ; b_kstr = obj ->
NameInternal -> size [ 0 ] * obj -> NameInternal -> size [ 1 ] ; obj ->
NameInternal -> size [ 0 ] = 1 ; obj -> NameInternal -> size [ 1 ] = 10 ;
ac0ugu5nlz ( obj -> NameInternal , b_kstr ) ; for ( b_kstr = 0 ; b_kstr < 10
; b_kstr ++ ) { obj -> NameInternal -> data [ b_kstr ] = tmp_p [ b_kstr ] ; }
b_kstr = obj -> JointInternal . Type -> size [ 0 ] * obj -> JointInternal .
Type -> size [ 1 ] ; obj -> JointInternal . Type -> size [ 0 ] = 1 ; obj ->
JointInternal . Type -> size [ 1 ] = 5 ; ac0ugu5nlz ( obj -> JointInternal .
Type , b_kstr ) ; for ( b_kstr = 0 ; b_kstr < 5 ; b_kstr ++ ) { obj ->
JointInternal . Type -> data [ b_kstr ] = tmp_e [ b_kstr ] ; } gunzkbl0qg ( &
switch_expression , 2 ) ; b_kstr = switch_expression -> size [ 0 ] *
switch_expression -> size [ 1 ] ; switch_expression -> size [ 0 ] = 1 ;
switch_expression -> size [ 1 ] = obj -> JointInternal . Type -> size [ 1 ] ;
ac0ugu5nlz ( switch_expression , b_kstr ) ; loop_ub = obj -> JointInternal .
Type -> size [ 1 ] - 1 ; for ( b_kstr = 0 ; b_kstr <= loop_ub ; b_kstr ++ ) {
switch_expression -> data [ b_kstr ] = obj -> JointInternal . Type -> data [
b_kstr ] ; } for ( b_kstr = 0 ; b_kstr < 8 ; b_kstr ++ ) { b [ b_kstr ] =
tmp_i [ b_kstr ] ; } b_bool = false ; if ( switch_expression -> size [ 1 ] !=
8 ) { } else { b_kstr = 1 ; do { exitg1 = 0 ; if ( b_kstr - 1 < 8 ) { if (
switch_expression -> data [ b_kstr - 1 ] != b [ b_kstr - 1 ] ) { exitg1 = 1 ;
} else { b_kstr ++ ; } } else { b_bool = true ; exitg1 = 1 ; } } while (
exitg1 == 0 ) ; } if ( b_bool ) { b_kstr = 0 ; } else { for ( b_kstr = 0 ;
b_kstr < 9 ; b_kstr ++ ) { b_p [ b_kstr ] = tmp_m [ b_kstr ] ; } if (
switch_expression -> size [ 1 ] != 9 ) { } else { b_kstr = 1 ; do { exitg1 =
0 ; if ( b_kstr - 1 < 9 ) { if ( switch_expression -> data [ b_kstr - 1 ] !=
b_p [ b_kstr - 1 ] ) { exitg1 = 1 ; } else { b_kstr ++ ; } } else { b_bool =
true ; exitg1 = 1 ; } } while ( exitg1 == 0 ) ; } if ( b_bool ) { b_kstr = 1
; } else { b_kstr = - 1 ; } } b0l0vcvht3 ( & switch_expression ) ; switch (
b_kstr ) { case 0 : tmp [ 0 ] = 0 ; tmp [ 1 ] = 0 ; tmp [ 2 ] = 1 ; tmp [ 3 ]
= 0 ; tmp [ 4 ] = 0 ; tmp [ 5 ] = 0 ; for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr
++ ) { msubspace_data [ b_kstr ] = tmp [ b_kstr ] ; } obj -> JointInternal .
PositionNumber = 1.0 ; obj -> JointInternal . JointAxisInternal [ 0 ] = 0.0 ;
obj -> JointInternal . JointAxisInternal [ 1 ] = 0.0 ; obj -> JointInternal .
JointAxisInternal [ 2 ] = 1.0 ; break ; case 1 : tmp [ 0 ] = 0 ; tmp [ 1 ] =
0 ; tmp [ 2 ] = 0 ; tmp [ 3 ] = 0 ; tmp [ 4 ] = 0 ; tmp [ 5 ] = 1 ; for (
b_kstr = 0 ; b_kstr < 6 ; b_kstr ++ ) { msubspace_data [ b_kstr ] = tmp [
b_kstr ] ; } obj -> JointInternal . PositionNumber = 1.0 ; obj ->
JointInternal . JointAxisInternal [ 0 ] = 0.0 ; obj -> JointInternal .
JointAxisInternal [ 1 ] = 0.0 ; obj -> JointInternal . JointAxisInternal [ 2
] = 1.0 ; break ; default : for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr ++ ) {
msubspace_data [ b_kstr ] = 0 ; } obj -> JointInternal . PositionNumber = 0.0
; obj -> JointInternal . JointAxisInternal [ 0 ] = 0.0 ; obj -> JointInternal
. JointAxisInternal [ 1 ] = 0.0 ; obj -> JointInternal . JointAxisInternal [
2 ] = 0.0 ; break ; } b_kstr = obj -> JointInternal . MotionSubspace -> size
[ 0 ] * obj -> JointInternal . MotionSubspace -> size [ 1 ] ; obj ->
JointInternal . MotionSubspace -> size [ 0 ] = 6 ; obj -> JointInternal .
MotionSubspace -> size [ 1 ] = 1 ; ier0p3wwtw ( obj -> JointInternal .
MotionSubspace , b_kstr ) ; for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr ++ ) { obj
-> JointInternal . MotionSubspace -> data [ b_kstr ] = msubspace_data [
b_kstr ] ; } obj -> Index = - 1.0 ; obj -> ParentIndex = - 1.0 ; aydneur4h5 (
& obj -> CollisionsInternal ) ; return b_obj ; } static void dpajaj4gpx (
kp1en3mw3x * obj , gxcsgl11sl * iobj_0 ) { e2b0f4s35s * switch_expression ;
int32_T b_kstr ; int32_T loop_ub ; char_T b_p [ 9 ] ; char_T b [ 8 ] ; int8_T
msubspace_data [ 36 ] ; int8_T tmp [ 6 ] ; boolean_T b_bool ; static const
char_T tmp_p [ 10 ] = { 'd' , 'u' , 'm' , 'm' , 'y' , 'b' , 'o' , 'd' , 'y' ,
'1' } ; static const char_T tmp_e [ 5 ] = { 'f' , 'i' , 'x' , 'e' , 'd' } ;
static const char_T tmp_i [ 8 ] = { 'r' , 'e' , 'v' , 'o' , 'l' , 'u' , 't' ,
'e' } ; static const char_T tmp_m [ 9 ] = { 'p' , 'r' , 'i' , 's' , 'm' , 'a'
, 't' , 'i' , 'c' } ; static const char_T tmp_g [ 10 ] = { 'd' , 'u' , 'm' ,
'm' , 'y' , 'b' , 'o' , 'd' , 'y' , '2' } ; static const char_T tmp_j [ 10 ]
= { 'd' , 'u' , 'm' , 'm' , 'y' , 'b' , 'o' , 'd' , 'y' , '3' } ; static
const char_T tmp_f [ 10 ] = { 'd' , 'u' , 'm' , 'm' , 'y' , 'b' , 'o' , 'd' ,
'y' , '4' } ; int32_T exitg1 ; b_kstr = iobj_0 [ 0 ] . NameInternal -> size [
0 ] * iobj_0 [ 0 ] . NameInternal -> size [ 1 ] ; iobj_0 [ 0 ] . NameInternal
-> size [ 0 ] = 1 ; iobj_0 [ 0 ] . NameInternal -> size [ 1 ] = 10 ;
ac0ugu5nlz ( iobj_0 [ 0 ] . NameInternal , b_kstr ) ; for ( b_kstr = 0 ;
b_kstr < 10 ; b_kstr ++ ) { iobj_0 [ 0 ] . NameInternal -> data [ b_kstr ] =
tmp_p [ b_kstr ] ; } b_kstr = iobj_0 [ 0 ] . JointInternal . Type -> size [ 0
] * iobj_0 [ 0 ] . JointInternal . Type -> size [ 1 ] ; iobj_0 [ 0 ] .
JointInternal . Type -> size [ 0 ] = 1 ; iobj_0 [ 0 ] . JointInternal . Type
-> size [ 1 ] = 5 ; ac0ugu5nlz ( iobj_0 [ 0 ] . JointInternal . Type , b_kstr
) ; for ( b_kstr = 0 ; b_kstr < 5 ; b_kstr ++ ) { iobj_0 [ 0 ] .
JointInternal . Type -> data [ b_kstr ] = tmp_e [ b_kstr ] ; } gunzkbl0qg ( &
switch_expression , 2 ) ; b_kstr = switch_expression -> size [ 0 ] *
switch_expression -> size [ 1 ] ; switch_expression -> size [ 0 ] = 1 ;
switch_expression -> size [ 1 ] = iobj_0 [ 0 ] . JointInternal . Type -> size
[ 1 ] ; ac0ugu5nlz ( switch_expression , b_kstr ) ; loop_ub = iobj_0 [ 0 ] .
JointInternal . Type -> size [ 1 ] - 1 ; for ( b_kstr = 0 ; b_kstr <= loop_ub
; b_kstr ++ ) { switch_expression -> data [ b_kstr ] = iobj_0 [ 0 ] .
JointInternal . Type -> data [ b_kstr ] ; } for ( b_kstr = 0 ; b_kstr < 8 ;
b_kstr ++ ) { b [ b_kstr ] = tmp_i [ b_kstr ] ; } b_bool = false ; if (
switch_expression -> size [ 1 ] != 8 ) { } else { b_kstr = 1 ; do { exitg1 =
0 ; if ( b_kstr - 1 < 8 ) { if ( switch_expression -> data [ b_kstr - 1 ] !=
b [ b_kstr - 1 ] ) { exitg1 = 1 ; } else { b_kstr ++ ; } } else { b_bool =
true ; exitg1 = 1 ; } } while ( exitg1 == 0 ) ; } if ( b_bool ) { b_kstr = 0
; } else { for ( b_kstr = 0 ; b_kstr < 9 ; b_kstr ++ ) { b_p [ b_kstr ] =
tmp_m [ b_kstr ] ; } if ( switch_expression -> size [ 1 ] != 9 ) { } else {
b_kstr = 1 ; do { exitg1 = 0 ; if ( b_kstr - 1 < 9 ) { if ( switch_expression
-> data [ b_kstr - 1 ] != b_p [ b_kstr - 1 ] ) { exitg1 = 1 ; } else { b_kstr
++ ; } } else { b_bool = true ; exitg1 = 1 ; } } while ( exitg1 == 0 ) ; } if
( b_bool ) { b_kstr = 1 ; } else { b_kstr = - 1 ; } } switch ( b_kstr ) {
case 0 : tmp [ 0 ] = 0 ; tmp [ 1 ] = 0 ; tmp [ 2 ] = 1 ; tmp [ 3 ] = 0 ; tmp
[ 4 ] = 0 ; tmp [ 5 ] = 0 ; for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr ++ ) {
msubspace_data [ b_kstr ] = tmp [ b_kstr ] ; } iobj_0 [ 0 ] . JointInternal .
PositionNumber = 1.0 ; iobj_0 [ 0 ] . JointInternal . JointAxisInternal [ 0 ]
= 0.0 ; iobj_0 [ 0 ] . JointInternal . JointAxisInternal [ 1 ] = 0.0 ; iobj_0
[ 0 ] . JointInternal . JointAxisInternal [ 2 ] = 1.0 ; break ; case 1 : tmp
[ 0 ] = 0 ; tmp [ 1 ] = 0 ; tmp [ 2 ] = 0 ; tmp [ 3 ] = 0 ; tmp [ 4 ] = 0 ;
tmp [ 5 ] = 1 ; for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr ++ ) { msubspace_data
[ b_kstr ] = tmp [ b_kstr ] ; } iobj_0 [ 0 ] . JointInternal . PositionNumber
= 1.0 ; iobj_0 [ 0 ] . JointInternal . JointAxisInternal [ 0 ] = 0.0 ; iobj_0
[ 0 ] . JointInternal . JointAxisInternal [ 1 ] = 0.0 ; iobj_0 [ 0 ] .
JointInternal . JointAxisInternal [ 2 ] = 1.0 ; break ; default : for (
b_kstr = 0 ; b_kstr < 6 ; b_kstr ++ ) { msubspace_data [ b_kstr ] = 0 ; }
iobj_0 [ 0 ] . JointInternal . PositionNumber = 0.0 ; iobj_0 [ 0 ] .
JointInternal . JointAxisInternal [ 0 ] = 0.0 ; iobj_0 [ 0 ] . JointInternal
. JointAxisInternal [ 1 ] = 0.0 ; iobj_0 [ 0 ] . JointInternal .
JointAxisInternal [ 2 ] = 0.0 ; break ; } b_kstr = iobj_0 [ 0 ] .
JointInternal . MotionSubspace -> size [ 0 ] * iobj_0 [ 0 ] . JointInternal .
MotionSubspace -> size [ 1 ] ; iobj_0 [ 0 ] . JointInternal . MotionSubspace
-> size [ 0 ] = 6 ; iobj_0 [ 0 ] . JointInternal . MotionSubspace -> size [ 1
] = 1 ; ier0p3wwtw ( iobj_0 [ 0 ] . JointInternal . MotionSubspace , b_kstr )
; for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr ++ ) { iobj_0 [ 0 ] . JointInternal
. MotionSubspace -> data [ b_kstr ] = msubspace_data [ b_kstr ] ; } iobj_0 [
0 ] . Index = - 1.0 ; iobj_0 [ 0 ] . ParentIndex = - 1.0 ; aydneur4h5 ( &
iobj_0 [ 0 ] . CollisionsInternal ) ; obj -> Bodies [ 0 ] = & iobj_0 [ 0 ] ;
b_kstr = iobj_0 [ 1 ] . NameInternal -> size [ 0 ] * iobj_0 [ 1 ] .
NameInternal -> size [ 1 ] ; iobj_0 [ 1 ] . NameInternal -> size [ 0 ] = 1 ;
iobj_0 [ 1 ] . NameInternal -> size [ 1 ] = 10 ; ac0ugu5nlz ( iobj_0 [ 1 ] .
NameInternal , b_kstr ) ; for ( b_kstr = 0 ; b_kstr < 10 ; b_kstr ++ ) {
iobj_0 [ 1 ] . NameInternal -> data [ b_kstr ] = tmp_g [ b_kstr ] ; } b_kstr
= iobj_0 [ 1 ] . JointInternal . Type -> size [ 0 ] * iobj_0 [ 1 ] .
JointInternal . Type -> size [ 1 ] ; iobj_0 [ 1 ] . JointInternal . Type ->
size [ 0 ] = 1 ; iobj_0 [ 1 ] . JointInternal . Type -> size [ 1 ] = 5 ;
ac0ugu5nlz ( iobj_0 [ 1 ] . JointInternal . Type , b_kstr ) ; for ( b_kstr =
0 ; b_kstr < 5 ; b_kstr ++ ) { iobj_0 [ 1 ] . JointInternal . Type -> data [
b_kstr ] = tmp_e [ b_kstr ] ; } b_kstr = switch_expression -> size [ 0 ] *
switch_expression -> size [ 1 ] ; switch_expression -> size [ 0 ] = 1 ;
switch_expression -> size [ 1 ] = iobj_0 [ 1 ] . JointInternal . Type -> size
[ 1 ] ; ac0ugu5nlz ( switch_expression , b_kstr ) ; loop_ub = iobj_0 [ 1 ] .
JointInternal . Type -> size [ 1 ] - 1 ; for ( b_kstr = 0 ; b_kstr <= loop_ub
; b_kstr ++ ) { switch_expression -> data [ b_kstr ] = iobj_0 [ 1 ] .
JointInternal . Type -> data [ b_kstr ] ; } b_bool = false ; if (
switch_expression -> size [ 1 ] != 8 ) { } else { b_kstr = 1 ; do { exitg1 =
0 ; if ( b_kstr - 1 < 8 ) { if ( switch_expression -> data [ b_kstr - 1 ] !=
b [ b_kstr - 1 ] ) { exitg1 = 1 ; } else { b_kstr ++ ; } } else { b_bool =
true ; exitg1 = 1 ; } } while ( exitg1 == 0 ) ; } if ( b_bool ) { b_kstr = 0
; } else { for ( b_kstr = 0 ; b_kstr < 9 ; b_kstr ++ ) { b_p [ b_kstr ] =
tmp_m [ b_kstr ] ; } if ( switch_expression -> size [ 1 ] != 9 ) { } else {
b_kstr = 1 ; do { exitg1 = 0 ; if ( b_kstr - 1 < 9 ) { if ( switch_expression
-> data [ b_kstr - 1 ] != b_p [ b_kstr - 1 ] ) { exitg1 = 1 ; } else { b_kstr
++ ; } } else { b_bool = true ; exitg1 = 1 ; } } while ( exitg1 == 0 ) ; } if
( b_bool ) { b_kstr = 1 ; } else { b_kstr = - 1 ; } } switch ( b_kstr ) {
case 0 : tmp [ 0 ] = 0 ; tmp [ 1 ] = 0 ; tmp [ 2 ] = 1 ; tmp [ 3 ] = 0 ; tmp
[ 4 ] = 0 ; tmp [ 5 ] = 0 ; for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr ++ ) {
msubspace_data [ b_kstr ] = tmp [ b_kstr ] ; } iobj_0 [ 1 ] . JointInternal .
PositionNumber = 1.0 ; iobj_0 [ 1 ] . JointInternal . JointAxisInternal [ 0 ]
= 0.0 ; iobj_0 [ 1 ] . JointInternal . JointAxisInternal [ 1 ] = 0.0 ; iobj_0
[ 1 ] . JointInternal . JointAxisInternal [ 2 ] = 1.0 ; break ; case 1 : tmp
[ 0 ] = 0 ; tmp [ 1 ] = 0 ; tmp [ 2 ] = 0 ; tmp [ 3 ] = 0 ; tmp [ 4 ] = 0 ;
tmp [ 5 ] = 1 ; for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr ++ ) { msubspace_data
[ b_kstr ] = tmp [ b_kstr ] ; } iobj_0 [ 1 ] . JointInternal . PositionNumber
= 1.0 ; iobj_0 [ 1 ] . JointInternal . JointAxisInternal [ 0 ] = 0.0 ; iobj_0
[ 1 ] . JointInternal . JointAxisInternal [ 1 ] = 0.0 ; iobj_0 [ 1 ] .
JointInternal . JointAxisInternal [ 2 ] = 1.0 ; break ; default : for (
b_kstr = 0 ; b_kstr < 6 ; b_kstr ++ ) { msubspace_data [ b_kstr ] = 0 ; }
iobj_0 [ 1 ] . JointInternal . PositionNumber = 0.0 ; iobj_0 [ 1 ] .
JointInternal . JointAxisInternal [ 0 ] = 0.0 ; iobj_0 [ 1 ] . JointInternal
. JointAxisInternal [ 1 ] = 0.0 ; iobj_0 [ 1 ] . JointInternal .
JointAxisInternal [ 2 ] = 0.0 ; break ; } b_kstr = iobj_0 [ 1 ] .
JointInternal . MotionSubspace -> size [ 0 ] * iobj_0 [ 1 ] . JointInternal .
MotionSubspace -> size [ 1 ] ; iobj_0 [ 1 ] . JointInternal . MotionSubspace
-> size [ 0 ] = 6 ; iobj_0 [ 1 ] . JointInternal . MotionSubspace -> size [ 1
] = 1 ; ier0p3wwtw ( iobj_0 [ 1 ] . JointInternal . MotionSubspace , b_kstr )
; for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr ++ ) { iobj_0 [ 1 ] . JointInternal
. MotionSubspace -> data [ b_kstr ] = msubspace_data [ b_kstr ] ; } iobj_0 [
1 ] . Index = - 1.0 ; iobj_0 [ 1 ] . ParentIndex = - 1.0 ; aydneur4h5 ( &
iobj_0 [ 1 ] . CollisionsInternal ) ; obj -> Bodies [ 1 ] = & iobj_0 [ 1 ] ;
b_kstr = iobj_0 [ 2 ] . NameInternal -> size [ 0 ] * iobj_0 [ 2 ] .
NameInternal -> size [ 1 ] ; iobj_0 [ 2 ] . NameInternal -> size [ 0 ] = 1 ;
iobj_0 [ 2 ] . NameInternal -> size [ 1 ] = 10 ; ac0ugu5nlz ( iobj_0 [ 2 ] .
NameInternal , b_kstr ) ; for ( b_kstr = 0 ; b_kstr < 10 ; b_kstr ++ ) {
iobj_0 [ 2 ] . NameInternal -> data [ b_kstr ] = tmp_j [ b_kstr ] ; } b_kstr
= iobj_0 [ 2 ] . JointInternal . Type -> size [ 0 ] * iobj_0 [ 2 ] .
JointInternal . Type -> size [ 1 ] ; iobj_0 [ 2 ] . JointInternal . Type ->
size [ 0 ] = 1 ; iobj_0 [ 2 ] . JointInternal . Type -> size [ 1 ] = 5 ;
ac0ugu5nlz ( iobj_0 [ 2 ] . JointInternal . Type , b_kstr ) ; for ( b_kstr =
0 ; b_kstr < 5 ; b_kstr ++ ) { iobj_0 [ 2 ] . JointInternal . Type -> data [
b_kstr ] = tmp_e [ b_kstr ] ; } b_kstr = switch_expression -> size [ 0 ] *
switch_expression -> size [ 1 ] ; switch_expression -> size [ 0 ] = 1 ;
switch_expression -> size [ 1 ] = iobj_0 [ 2 ] . JointInternal . Type -> size
[ 1 ] ; ac0ugu5nlz ( switch_expression , b_kstr ) ; loop_ub = iobj_0 [ 2 ] .
JointInternal . Type -> size [ 1 ] - 1 ; for ( b_kstr = 0 ; b_kstr <= loop_ub
; b_kstr ++ ) { switch_expression -> data [ b_kstr ] = iobj_0 [ 2 ] .
JointInternal . Type -> data [ b_kstr ] ; } b_bool = false ; if (
switch_expression -> size [ 1 ] != 8 ) { } else { b_kstr = 1 ; do { exitg1 =
0 ; if ( b_kstr - 1 < 8 ) { if ( switch_expression -> data [ b_kstr - 1 ] !=
b [ b_kstr - 1 ] ) { exitg1 = 1 ; } else { b_kstr ++ ; } } else { b_bool =
true ; exitg1 = 1 ; } } while ( exitg1 == 0 ) ; } if ( b_bool ) { b_kstr = 0
; } else { for ( b_kstr = 0 ; b_kstr < 9 ; b_kstr ++ ) { b_p [ b_kstr ] =
tmp_m [ b_kstr ] ; } if ( switch_expression -> size [ 1 ] != 9 ) { } else {
b_kstr = 1 ; do { exitg1 = 0 ; if ( b_kstr - 1 < 9 ) { if ( switch_expression
-> data [ b_kstr - 1 ] != b_p [ b_kstr - 1 ] ) { exitg1 = 1 ; } else { b_kstr
++ ; } } else { b_bool = true ; exitg1 = 1 ; } } while ( exitg1 == 0 ) ; } if
( b_bool ) { b_kstr = 1 ; } else { b_kstr = - 1 ; } } switch ( b_kstr ) {
case 0 : tmp [ 0 ] = 0 ; tmp [ 1 ] = 0 ; tmp [ 2 ] = 1 ; tmp [ 3 ] = 0 ; tmp
[ 4 ] = 0 ; tmp [ 5 ] = 0 ; for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr ++ ) {
msubspace_data [ b_kstr ] = tmp [ b_kstr ] ; } iobj_0 [ 2 ] . JointInternal .
PositionNumber = 1.0 ; iobj_0 [ 2 ] . JointInternal . JointAxisInternal [ 0 ]
= 0.0 ; iobj_0 [ 2 ] . JointInternal . JointAxisInternal [ 1 ] = 0.0 ; iobj_0
[ 2 ] . JointInternal . JointAxisInternal [ 2 ] = 1.0 ; break ; case 1 : tmp
[ 0 ] = 0 ; tmp [ 1 ] = 0 ; tmp [ 2 ] = 0 ; tmp [ 3 ] = 0 ; tmp [ 4 ] = 0 ;
tmp [ 5 ] = 1 ; for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr ++ ) { msubspace_data
[ b_kstr ] = tmp [ b_kstr ] ; } iobj_0 [ 2 ] . JointInternal . PositionNumber
= 1.0 ; iobj_0 [ 2 ] . JointInternal . JointAxisInternal [ 0 ] = 0.0 ; iobj_0
[ 2 ] . JointInternal . JointAxisInternal [ 1 ] = 0.0 ; iobj_0 [ 2 ] .
JointInternal . JointAxisInternal [ 2 ] = 1.0 ; break ; default : for (
b_kstr = 0 ; b_kstr < 6 ; b_kstr ++ ) { msubspace_data [ b_kstr ] = 0 ; }
iobj_0 [ 2 ] . JointInternal . PositionNumber = 0.0 ; iobj_0 [ 2 ] .
JointInternal . JointAxisInternal [ 0 ] = 0.0 ; iobj_0 [ 2 ] . JointInternal
. JointAxisInternal [ 1 ] = 0.0 ; iobj_0 [ 2 ] . JointInternal .
JointAxisInternal [ 2 ] = 0.0 ; break ; } b_kstr = iobj_0 [ 2 ] .
JointInternal . MotionSubspace -> size [ 0 ] * iobj_0 [ 2 ] . JointInternal .
MotionSubspace -> size [ 1 ] ; iobj_0 [ 2 ] . JointInternal . MotionSubspace
-> size [ 0 ] = 6 ; iobj_0 [ 2 ] . JointInternal . MotionSubspace -> size [ 1
] = 1 ; ier0p3wwtw ( iobj_0 [ 2 ] . JointInternal . MotionSubspace , b_kstr )
; for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr ++ ) { iobj_0 [ 2 ] . JointInternal
. MotionSubspace -> data [ b_kstr ] = msubspace_data [ b_kstr ] ; } iobj_0 [
2 ] . Index = - 1.0 ; iobj_0 [ 2 ] . ParentIndex = - 1.0 ; aydneur4h5 ( &
iobj_0 [ 2 ] . CollisionsInternal ) ; obj -> Bodies [ 2 ] = & iobj_0 [ 2 ] ;
b_kstr = iobj_0 [ 3 ] . NameInternal -> size [ 0 ] * iobj_0 [ 3 ] .
NameInternal -> size [ 1 ] ; iobj_0 [ 3 ] . NameInternal -> size [ 0 ] = 1 ;
iobj_0 [ 3 ] . NameInternal -> size [ 1 ] = 10 ; ac0ugu5nlz ( iobj_0 [ 3 ] .
NameInternal , b_kstr ) ; for ( b_kstr = 0 ; b_kstr < 10 ; b_kstr ++ ) {
iobj_0 [ 3 ] . NameInternal -> data [ b_kstr ] = tmp_f [ b_kstr ] ; } b_kstr
= iobj_0 [ 3 ] . JointInternal . Type -> size [ 0 ] * iobj_0 [ 3 ] .
JointInternal . Type -> size [ 1 ] ; iobj_0 [ 3 ] . JointInternal . Type ->
size [ 0 ] = 1 ; iobj_0 [ 3 ] . JointInternal . Type -> size [ 1 ] = 5 ;
ac0ugu5nlz ( iobj_0 [ 3 ] . JointInternal . Type , b_kstr ) ; for ( b_kstr =
0 ; b_kstr < 5 ; b_kstr ++ ) { iobj_0 [ 3 ] . JointInternal . Type -> data [
b_kstr ] = tmp_e [ b_kstr ] ; } b_kstr = switch_expression -> size [ 0 ] *
switch_expression -> size [ 1 ] ; switch_expression -> size [ 0 ] = 1 ;
switch_expression -> size [ 1 ] = iobj_0 [ 3 ] . JointInternal . Type -> size
[ 1 ] ; ac0ugu5nlz ( switch_expression , b_kstr ) ; loop_ub = iobj_0 [ 3 ] .
JointInternal . Type -> size [ 1 ] - 1 ; for ( b_kstr = 0 ; b_kstr <= loop_ub
; b_kstr ++ ) { switch_expression -> data [ b_kstr ] = iobj_0 [ 3 ] .
JointInternal . Type -> data [ b_kstr ] ; } b_bool = false ; if (
switch_expression -> size [ 1 ] != 8 ) { } else { b_kstr = 1 ; do { exitg1 =
0 ; if ( b_kstr - 1 < 8 ) { if ( switch_expression -> data [ b_kstr - 1 ] !=
b [ b_kstr - 1 ] ) { exitg1 = 1 ; } else { b_kstr ++ ; } } else { b_bool =
true ; exitg1 = 1 ; } } while ( exitg1 == 0 ) ; } if ( b_bool ) { b_kstr = 0
; } else { for ( b_kstr = 0 ; b_kstr < 9 ; b_kstr ++ ) { b_p [ b_kstr ] =
tmp_m [ b_kstr ] ; } if ( switch_expression -> size [ 1 ] != 9 ) { } else {
b_kstr = 1 ; do { exitg1 = 0 ; if ( b_kstr - 1 < 9 ) { if ( switch_expression
-> data [ b_kstr - 1 ] != b_p [ b_kstr - 1 ] ) { exitg1 = 1 ; } else { b_kstr
++ ; } } else { b_bool = true ; exitg1 = 1 ; } } while ( exitg1 == 0 ) ; } if
( b_bool ) { b_kstr = 1 ; } else { b_kstr = - 1 ; } } b0l0vcvht3 ( &
switch_expression ) ; switch ( b_kstr ) { case 0 : tmp [ 0 ] = 0 ; tmp [ 1 ]
= 0 ; tmp [ 2 ] = 1 ; tmp [ 3 ] = 0 ; tmp [ 4 ] = 0 ; tmp [ 5 ] = 0 ; for (
b_kstr = 0 ; b_kstr < 6 ; b_kstr ++ ) { msubspace_data [ b_kstr ] = tmp [
b_kstr ] ; } iobj_0 [ 3 ] . JointInternal . PositionNumber = 1.0 ; iobj_0 [ 3
] . JointInternal . JointAxisInternal [ 0 ] = 0.0 ; iobj_0 [ 3 ] .
JointInternal . JointAxisInternal [ 1 ] = 0.0 ; iobj_0 [ 3 ] . JointInternal
. JointAxisInternal [ 2 ] = 1.0 ; break ; case 1 : tmp [ 0 ] = 0 ; tmp [ 1 ]
= 0 ; tmp [ 2 ] = 0 ; tmp [ 3 ] = 0 ; tmp [ 4 ] = 0 ; tmp [ 5 ] = 1 ; for (
b_kstr = 0 ; b_kstr < 6 ; b_kstr ++ ) { msubspace_data [ b_kstr ] = tmp [
b_kstr ] ; } iobj_0 [ 3 ] . JointInternal . PositionNumber = 1.0 ; iobj_0 [ 3
] . JointInternal . JointAxisInternal [ 0 ] = 0.0 ; iobj_0 [ 3 ] .
JointInternal . JointAxisInternal [ 1 ] = 0.0 ; iobj_0 [ 3 ] . JointInternal
. JointAxisInternal [ 2 ] = 1.0 ; break ; default : for ( b_kstr = 0 ; b_kstr
< 6 ; b_kstr ++ ) { msubspace_data [ b_kstr ] = 0 ; } iobj_0 [ 3 ] .
JointInternal . PositionNumber = 0.0 ; iobj_0 [ 3 ] . JointInternal .
JointAxisInternal [ 0 ] = 0.0 ; iobj_0 [ 3 ] . JointInternal .
JointAxisInternal [ 1 ] = 0.0 ; iobj_0 [ 3 ] . JointInternal .
JointAxisInternal [ 2 ] = 0.0 ; break ; } b_kstr = iobj_0 [ 3 ] .
JointInternal . MotionSubspace -> size [ 0 ] * iobj_0 [ 3 ] . JointInternal .
MotionSubspace -> size [ 1 ] ; iobj_0 [ 3 ] . JointInternal . MotionSubspace
-> size [ 0 ] = 6 ; iobj_0 [ 3 ] . JointInternal . MotionSubspace -> size [ 1
] = 1 ; ier0p3wwtw ( iobj_0 [ 3 ] . JointInternal . MotionSubspace , b_kstr )
; for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr ++ ) { iobj_0 [ 3 ] . JointInternal
. MotionSubspace -> data [ b_kstr ] = msubspace_data [ b_kstr ] ; } iobj_0 [
3 ] . Index = - 1.0 ; iobj_0 [ 3 ] . ParentIndex = - 1.0 ; aydneur4h5 ( &
iobj_0 [ 3 ] . CollisionsInternal ) ; obj -> Bodies [ 3 ] = & iobj_0 [ 3 ] ;
obj -> Bodies [ 4 ] = mhyfpzbtel ( & iobj_0 [ 4 ] ) ; } static gxcsgl11sl *
mhyfpzbtelc ( gxcsgl11sl * obj ) { e2b0f4s35s * switch_expression ;
gxcsgl11sl * b_obj ; int32_T b_kstr ; int32_T loop_ub ; char_T b_p [ 9 ] ;
char_T b [ 8 ] ; int8_T msubspace_data [ 36 ] ; int8_T tmp [ 6 ] ; boolean_T
b_bool ; static const char_T tmp_p [ 5 ] = { 'B' , 'o' , 'd' , 'y' , '3' } ;
static const char_T tmp_e [ 8 ] = { 'r' , 'e' , 'v' , 'o' , 'l' , 'u' , 't' ,
'e' } ; static const char_T tmp_i [ 9 ] = { 'p' , 'r' , 'i' , 's' , 'm' , 'a'
, 't' , 'i' , 'c' } ; static const real_T tmp_m [ 16 ] = {
6.123233995736766E-17 , 0.0 , - 1.0 , 0.0 , - 1.0 , - 1.6081226496766366E-16
, - 6.123233995736766E-17 , 0.0 , - 1.6081226496766366E-16 , 1.0 , -
9.8469112778142665E-33 , 0.0 , - 5.5511151231257827E-17 , -
0.12964538766168227 , 0.20102726089780065 , 1.0 } ; static const real_T tmp_g
[ 16 ] = { 1.0 , 0.0 , 0.0 , 0.0 , 0.0 , 1.0 , 0.0 , 0.0 , 0.0 , 0.0 , 1.0 ,
0.0 , 0.0 , 0.0 , 0.0 , 1.0 } ; static const real_T tmp_j [ 36 ] = { 0.0 ,
0.0 , 1.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 ,
0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 ,
0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 } ; int32_T exitg1 ;
b_obj = obj ; b_kstr = obj -> NameInternal -> size [ 0 ] * obj ->
NameInternal -> size [ 1 ] ; obj -> NameInternal -> size [ 0 ] = 1 ; obj ->
NameInternal -> size [ 1 ] = 5 ; ac0ugu5nlz ( obj -> NameInternal , b_kstr )
; for ( b_kstr = 0 ; b_kstr < 5 ; b_kstr ++ ) { obj -> NameInternal -> data [
b_kstr ] = tmp_p [ b_kstr ] ; } obj -> ParentIndex = 2.0 ; b_kstr = obj ->
JointInternal . Type -> size [ 0 ] * obj -> JointInternal . Type -> size [ 1
] ; obj -> JointInternal . Type -> size [ 0 ] = 1 ; obj -> JointInternal .
Type -> size [ 1 ] = 8 ; ac0ugu5nlz ( obj -> JointInternal . Type , b_kstr )
; for ( b_kstr = 0 ; b_kstr < 8 ; b_kstr ++ ) { obj -> JointInternal . Type
-> data [ b_kstr ] = tmp_e [ b_kstr ] ; } gunzkbl0qg ( & switch_expression ,
2 ) ; b_kstr = switch_expression -> size [ 0 ] * switch_expression -> size [
1 ] ; switch_expression -> size [ 0 ] = 1 ; switch_expression -> size [ 1 ] =
obj -> JointInternal . Type -> size [ 1 ] ; ac0ugu5nlz ( switch_expression ,
b_kstr ) ; loop_ub = obj -> JointInternal . Type -> size [ 1 ] - 1 ; for (
b_kstr = 0 ; b_kstr <= loop_ub ; b_kstr ++ ) { switch_expression -> data [
b_kstr ] = obj -> JointInternal . Type -> data [ b_kstr ] ; } for ( b_kstr =
0 ; b_kstr < 8 ; b_kstr ++ ) { b [ b_kstr ] = tmp_e [ b_kstr ] ; } b_bool =
false ; if ( switch_expression -> size [ 1 ] != 8 ) { } else { b_kstr = 1 ;
do { exitg1 = 0 ; if ( b_kstr - 1 < 8 ) { if ( switch_expression -> data [
b_kstr - 1 ] != b [ b_kstr - 1 ] ) { exitg1 = 1 ; } else { b_kstr ++ ; } }
else { b_bool = true ; exitg1 = 1 ; } } while ( exitg1 == 0 ) ; } if ( b_bool
) { b_kstr = 0 ; } else { for ( b_kstr = 0 ; b_kstr < 9 ; b_kstr ++ ) { b_p [
b_kstr ] = tmp_i [ b_kstr ] ; } if ( switch_expression -> size [ 1 ] != 9 ) {
} else { b_kstr = 1 ; do { exitg1 = 0 ; if ( b_kstr - 1 < 9 ) { if (
switch_expression -> data [ b_kstr - 1 ] != b_p [ b_kstr - 1 ] ) { exitg1 = 1
; } else { b_kstr ++ ; } } else { b_bool = true ; exitg1 = 1 ; } } while (
exitg1 == 0 ) ; } if ( b_bool ) { b_kstr = 1 ; } else { b_kstr = - 1 ; } }
b0l0vcvht3 ( & switch_expression ) ; switch ( b_kstr ) { case 0 : tmp [ 0 ] =
0 ; tmp [ 1 ] = 0 ; tmp [ 2 ] = 1 ; tmp [ 3 ] = 0 ; tmp [ 4 ] = 0 ; tmp [ 5 ]
= 0 ; for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr ++ ) { msubspace_data [ b_kstr ]
= tmp [ b_kstr ] ; } obj -> JointInternal . PositionNumber = 1.0 ; obj ->
JointInternal . JointAxisInternal [ 0 ] = 0.0 ; obj -> JointInternal .
JointAxisInternal [ 1 ] = 0.0 ; obj -> JointInternal . JointAxisInternal [ 2
] = 1.0 ; break ; case 1 : tmp [ 0 ] = 0 ; tmp [ 1 ] = 0 ; tmp [ 2 ] = 0 ;
tmp [ 3 ] = 0 ; tmp [ 4 ] = 0 ; tmp [ 5 ] = 1 ; for ( b_kstr = 0 ; b_kstr < 6
; b_kstr ++ ) { msubspace_data [ b_kstr ] = tmp [ b_kstr ] ; } obj ->
JointInternal . PositionNumber = 1.0 ; obj -> JointInternal .
JointAxisInternal [ 0 ] = 0.0 ; obj -> JointInternal . JointAxisInternal [ 1
] = 0.0 ; obj -> JointInternal . JointAxisInternal [ 2 ] = 1.0 ; break ;
default : for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr ++ ) { msubspace_data [
b_kstr ] = 0 ; } obj -> JointInternal . PositionNumber = 0.0 ; obj ->
JointInternal . JointAxisInternal [ 0 ] = 0.0 ; obj -> JointInternal .
JointAxisInternal [ 1 ] = 0.0 ; obj -> JointInternal . JointAxisInternal [ 2
] = 0.0 ; break ; } b_kstr = obj -> JointInternal . MotionSubspace -> size [
0 ] * obj -> JointInternal . MotionSubspace -> size [ 1 ] ; obj ->
JointInternal . MotionSubspace -> size [ 0 ] = 6 ; obj -> JointInternal .
MotionSubspace -> size [ 1 ] = 1 ; ier0p3wwtw ( obj -> JointInternal .
MotionSubspace , b_kstr ) ; for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr ++ ) { obj
-> JointInternal . MotionSubspace -> data [ b_kstr ] = msubspace_data [
b_kstr ] ; } for ( b_kstr = 0 ; b_kstr < 16 ; b_kstr ++ ) { obj ->
JointInternal . JointToParentTransform [ b_kstr ] = tmp_m [ b_kstr ] ; } for
( b_kstr = 0 ; b_kstr < 16 ; b_kstr ++ ) { obj -> JointInternal .
ChildToJointTransform [ b_kstr ] = tmp_g [ b_kstr ] ; } b_kstr = obj ->
JointInternal . MotionSubspace -> size [ 0 ] * obj -> JointInternal .
MotionSubspace -> size [ 1 ] ; obj -> JointInternal . MotionSubspace -> size
[ 0 ] = 6 ; obj -> JointInternal . MotionSubspace -> size [ 1 ] = 1 ;
ier0p3wwtw ( obj -> JointInternal . MotionSubspace , b_kstr ) ; for ( b_kstr
= 0 ; b_kstr < 6 ; b_kstr ++ ) { obj -> JointInternal . MotionSubspace ->
data [ b_kstr ] = tmp_j [ b_kstr ] ; } obj -> JointInternal .
JointAxisInternal [ 0 ] = 0.0 ; obj -> JointInternal . JointAxisInternal [ 1
] = 0.0 ; obj -> JointInternal . JointAxisInternal [ 2 ] = 1.0 ; aydneur4h5 (
& obj -> CollisionsInternal ) ; return b_obj ; } static gxcsgl11sl *
mhyfpzbtelc0 ( gxcsgl11sl * obj ) { e2b0f4s35s * switch_expression ;
gxcsgl11sl * b_obj ; int32_T b_kstr ; int32_T loop_ub ; char_T b_p [ 9 ] ;
char_T b [ 8 ] ; int8_T msubspace_data [ 36 ] ; int8_T tmp [ 6 ] ; boolean_T
b_bool ; static const char_T tmp_p [ 5 ] = { 'B' , 'o' , 'd' , 'y' , '4' } ;
static const char_T tmp_e [ 8 ] = { 'r' , 'e' , 'v' , 'o' , 'l' , 'u' , 't' ,
'e' } ; static const char_T tmp_i [ 9 ] = { 'p' , 'r' , 'i' , 's' , 'm' , 'a'
, 't' , 'i' , 'c' } ; static const real_T tmp_m [ 16 ] = {
6.123233995736766E-17 , 0.0 , - 1.0 , 0.0 , 1.0 , 9.4941075965749281E-16 ,
6.123233995736766E-17 , 0.0 , 9.4941075965749281E-16 , - 1.0 ,
5.8134642394530281E-32 , 0.0 , - 1.3877787807814457E-16 ,
0.038414905179222407 , - 0.050000000000000447 , 1.0 } ; static const real_T
tmp_g [ 16 ] = { 1.0 , 0.0 , 0.0 , 0.0 , 0.0 , 1.0 , 0.0 , 0.0 , 0.0 , 0.0 ,
1.0 , 0.0 , 0.0 , 0.0 , 0.0 , 1.0 } ; static const real_T tmp_j [ 36 ] = {
0.0 , 0.0 , 1.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 ,
0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 ,
0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 } ; int32_T exitg1
; b_obj = obj ; b_kstr = obj -> NameInternal -> size [ 0 ] * obj ->
NameInternal -> size [ 1 ] ; obj -> NameInternal -> size [ 0 ] = 1 ; obj ->
NameInternal -> size [ 1 ] = 5 ; ac0ugu5nlz ( obj -> NameInternal , b_kstr )
; for ( b_kstr = 0 ; b_kstr < 5 ; b_kstr ++ ) { obj -> NameInternal -> data [
b_kstr ] = tmp_p [ b_kstr ] ; } obj -> ParentIndex = 3.0 ; b_kstr = obj ->
JointInternal . Type -> size [ 0 ] * obj -> JointInternal . Type -> size [ 1
] ; obj -> JointInternal . Type -> size [ 0 ] = 1 ; obj -> JointInternal .
Type -> size [ 1 ] = 8 ; ac0ugu5nlz ( obj -> JointInternal . Type , b_kstr )
; for ( b_kstr = 0 ; b_kstr < 8 ; b_kstr ++ ) { obj -> JointInternal . Type
-> data [ b_kstr ] = tmp_e [ b_kstr ] ; } gunzkbl0qg ( & switch_expression ,
2 ) ; b_kstr = switch_expression -> size [ 0 ] * switch_expression -> size [
1 ] ; switch_expression -> size [ 0 ] = 1 ; switch_expression -> size [ 1 ] =
obj -> JointInternal . Type -> size [ 1 ] ; ac0ugu5nlz ( switch_expression ,
b_kstr ) ; loop_ub = obj -> JointInternal . Type -> size [ 1 ] - 1 ; for (
b_kstr = 0 ; b_kstr <= loop_ub ; b_kstr ++ ) { switch_expression -> data [
b_kstr ] = obj -> JointInternal . Type -> data [ b_kstr ] ; } for ( b_kstr =
0 ; b_kstr < 8 ; b_kstr ++ ) { b [ b_kstr ] = tmp_e [ b_kstr ] ; } b_bool =
false ; if ( switch_expression -> size [ 1 ] != 8 ) { } else { b_kstr = 1 ;
do { exitg1 = 0 ; if ( b_kstr - 1 < 8 ) { if ( switch_expression -> data [
b_kstr - 1 ] != b [ b_kstr - 1 ] ) { exitg1 = 1 ; } else { b_kstr ++ ; } }
else { b_bool = true ; exitg1 = 1 ; } } while ( exitg1 == 0 ) ; } if ( b_bool
) { b_kstr = 0 ; } else { for ( b_kstr = 0 ; b_kstr < 9 ; b_kstr ++ ) { b_p [
b_kstr ] = tmp_i [ b_kstr ] ; } if ( switch_expression -> size [ 1 ] != 9 ) {
} else { b_kstr = 1 ; do { exitg1 = 0 ; if ( b_kstr - 1 < 9 ) { if (
switch_expression -> data [ b_kstr - 1 ] != b_p [ b_kstr - 1 ] ) { exitg1 = 1
; } else { b_kstr ++ ; } } else { b_bool = true ; exitg1 = 1 ; } } while (
exitg1 == 0 ) ; } if ( b_bool ) { b_kstr = 1 ; } else { b_kstr = - 1 ; } }
b0l0vcvht3 ( & switch_expression ) ; switch ( b_kstr ) { case 0 : tmp [ 0 ] =
0 ; tmp [ 1 ] = 0 ; tmp [ 2 ] = 1 ; tmp [ 3 ] = 0 ; tmp [ 4 ] = 0 ; tmp [ 5 ]
= 0 ; for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr ++ ) { msubspace_data [ b_kstr ]
= tmp [ b_kstr ] ; } obj -> JointInternal . PositionNumber = 1.0 ; obj ->
JointInternal . JointAxisInternal [ 0 ] = 0.0 ; obj -> JointInternal .
JointAxisInternal [ 1 ] = 0.0 ; obj -> JointInternal . JointAxisInternal [ 2
] = 1.0 ; break ; case 1 : tmp [ 0 ] = 0 ; tmp [ 1 ] = 0 ; tmp [ 2 ] = 0 ;
tmp [ 3 ] = 0 ; tmp [ 4 ] = 0 ; tmp [ 5 ] = 1 ; for ( b_kstr = 0 ; b_kstr < 6
; b_kstr ++ ) { msubspace_data [ b_kstr ] = tmp [ b_kstr ] ; } obj ->
JointInternal . PositionNumber = 1.0 ; obj -> JointInternal .
JointAxisInternal [ 0 ] = 0.0 ; obj -> JointInternal . JointAxisInternal [ 1
] = 0.0 ; obj -> JointInternal . JointAxisInternal [ 2 ] = 1.0 ; break ;
default : for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr ++ ) { msubspace_data [
b_kstr ] = 0 ; } obj -> JointInternal . PositionNumber = 0.0 ; obj ->
JointInternal . JointAxisInternal [ 0 ] = 0.0 ; obj -> JointInternal .
JointAxisInternal [ 1 ] = 0.0 ; obj -> JointInternal . JointAxisInternal [ 2
] = 0.0 ; break ; } b_kstr = obj -> JointInternal . MotionSubspace -> size [
0 ] * obj -> JointInternal . MotionSubspace -> size [ 1 ] ; obj ->
JointInternal . MotionSubspace -> size [ 0 ] = 6 ; obj -> JointInternal .
MotionSubspace -> size [ 1 ] = 1 ; ier0p3wwtw ( obj -> JointInternal .
MotionSubspace , b_kstr ) ; for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr ++ ) { obj
-> JointInternal . MotionSubspace -> data [ b_kstr ] = msubspace_data [
b_kstr ] ; } for ( b_kstr = 0 ; b_kstr < 16 ; b_kstr ++ ) { obj ->
JointInternal . JointToParentTransform [ b_kstr ] = tmp_m [ b_kstr ] ; } for
( b_kstr = 0 ; b_kstr < 16 ; b_kstr ++ ) { obj -> JointInternal .
ChildToJointTransform [ b_kstr ] = tmp_g [ b_kstr ] ; } b_kstr = obj ->
JointInternal . MotionSubspace -> size [ 0 ] * obj -> JointInternal .
MotionSubspace -> size [ 1 ] ; obj -> JointInternal . MotionSubspace -> size
[ 0 ] = 6 ; obj -> JointInternal . MotionSubspace -> size [ 1 ] = 1 ;
ier0p3wwtw ( obj -> JointInternal . MotionSubspace , b_kstr ) ; for ( b_kstr
= 0 ; b_kstr < 6 ; b_kstr ++ ) { obj -> JointInternal . MotionSubspace ->
data [ b_kstr ] = tmp_j [ b_kstr ] ; } obj -> JointInternal .
JointAxisInternal [ 0 ] = 0.0 ; obj -> JointInternal . JointAxisInternal [ 1
] = 0.0 ; obj -> JointInternal . JointAxisInternal [ 2 ] = 1.0 ; aydneur4h5 (
& obj -> CollisionsInternal ) ; return b_obj ; } static gxcsgl11sl *
mhyfpzbtelc0w ( gxcsgl11sl * obj ) { e2b0f4s35s * switch_expression ;
gxcsgl11sl * b_obj ; int32_T b_kstr ; int32_T loop_ub ; char_T b_p [ 9 ] ;
char_T b [ 8 ] ; int8_T msubspace_data [ 36 ] ; int8_T tmp [ 6 ] ; boolean_T
b_bool ; static const char_T tmp_p [ 5 ] = { 'B' , 'o' , 'd' , 'y' , '5' } ;
static const char_T tmp_e [ 8 ] = { 'r' , 'e' , 'v' , 'o' , 'l' , 'u' , 't' ,
'e' } ; static const char_T tmp_i [ 9 ] = { 'p' , 'r' , 'i' , 's' , 'm' , 'a'
, 't' , 'i' , 'c' } ; static const real_T tmp_m [ 16 ] = {
6.123233995736766E-17 , - 1.0 , - 0.0 , 0.0 , 6.123233995736766E-17 ,
3.749399456654644E-33 , 1.0 , 0.0 , - 1.0 , - 6.123233995736766E-17 ,
6.123233995736766E-17 , 0.0 , - 0.056650758675274054 , 3.4220484771503661E-16
, 0.26254402400728288 , 1.0 } ; static const real_T tmp_g [ 16 ] = { 1.0 ,
0.0 , 0.0 , 0.0 , 0.0 , 1.0 , 0.0 , 0.0 , 0.0 , 0.0 , 1.0 , 0.0 , 0.0 , 0.0 ,
0.0 , 1.0 } ; static const real_T tmp_j [ 36 ] = { 0.0 , 0.0 , 1.0 , 0.0 ,
0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 ,
0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 ,
0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 } ; int32_T exitg1 ; b_obj = obj ; b_kstr =
obj -> NameInternal -> size [ 0 ] * obj -> NameInternal -> size [ 1 ] ; obj
-> NameInternal -> size [ 0 ] = 1 ; obj -> NameInternal -> size [ 1 ] = 5 ;
ac0ugu5nlz ( obj -> NameInternal , b_kstr ) ; for ( b_kstr = 0 ; b_kstr < 5 ;
b_kstr ++ ) { obj -> NameInternal -> data [ b_kstr ] = tmp_p [ b_kstr ] ; }
obj -> ParentIndex = 4.0 ; b_kstr = obj -> JointInternal . Type -> size [ 0 ]
* obj -> JointInternal . Type -> size [ 1 ] ; obj -> JointInternal . Type ->
size [ 0 ] = 1 ; obj -> JointInternal . Type -> size [ 1 ] = 8 ; ac0ugu5nlz (
obj -> JointInternal . Type , b_kstr ) ; for ( b_kstr = 0 ; b_kstr < 8 ;
b_kstr ++ ) { obj -> JointInternal . Type -> data [ b_kstr ] = tmp_e [ b_kstr
] ; } gunzkbl0qg ( & switch_expression , 2 ) ; b_kstr = switch_expression ->
size [ 0 ] * switch_expression -> size [ 1 ] ; switch_expression -> size [ 0
] = 1 ; switch_expression -> size [ 1 ] = obj -> JointInternal . Type -> size
[ 1 ] ; ac0ugu5nlz ( switch_expression , b_kstr ) ; loop_ub = obj ->
JointInternal . Type -> size [ 1 ] - 1 ; for ( b_kstr = 0 ; b_kstr <= loop_ub
; b_kstr ++ ) { switch_expression -> data [ b_kstr ] = obj -> JointInternal .
Type -> data [ b_kstr ] ; } for ( b_kstr = 0 ; b_kstr < 8 ; b_kstr ++ ) { b [
b_kstr ] = tmp_e [ b_kstr ] ; } b_bool = false ; if ( switch_expression ->
size [ 1 ] != 8 ) { } else { b_kstr = 1 ; do { exitg1 = 0 ; if ( b_kstr - 1 <
8 ) { if ( switch_expression -> data [ b_kstr - 1 ] != b [ b_kstr - 1 ] ) {
exitg1 = 1 ; } else { b_kstr ++ ; } } else { b_bool = true ; exitg1 = 1 ; } }
while ( exitg1 == 0 ) ; } if ( b_bool ) { b_kstr = 0 ; } else { for ( b_kstr
= 0 ; b_kstr < 9 ; b_kstr ++ ) { b_p [ b_kstr ] = tmp_i [ b_kstr ] ; } if (
switch_expression -> size [ 1 ] != 9 ) { } else { b_kstr = 1 ; do { exitg1 =
0 ; if ( b_kstr - 1 < 9 ) { if ( switch_expression -> data [ b_kstr - 1 ] !=
b_p [ b_kstr - 1 ] ) { exitg1 = 1 ; } else { b_kstr ++ ; } } else { b_bool =
true ; exitg1 = 1 ; } } while ( exitg1 == 0 ) ; } if ( b_bool ) { b_kstr = 1
; } else { b_kstr = - 1 ; } } b0l0vcvht3 ( & switch_expression ) ; switch (
b_kstr ) { case 0 : tmp [ 0 ] = 0 ; tmp [ 1 ] = 0 ; tmp [ 2 ] = 1 ; tmp [ 3 ]
= 0 ; tmp [ 4 ] = 0 ; tmp [ 5 ] = 0 ; for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr
++ ) { msubspace_data [ b_kstr ] = tmp [ b_kstr ] ; } obj -> JointInternal .
PositionNumber = 1.0 ; obj -> JointInternal . JointAxisInternal [ 0 ] = 0.0 ;
obj -> JointInternal . JointAxisInternal [ 1 ] = 0.0 ; obj -> JointInternal .
JointAxisInternal [ 2 ] = 1.0 ; break ; case 1 : tmp [ 0 ] = 0 ; tmp [ 1 ] =
0 ; tmp [ 2 ] = 0 ; tmp [ 3 ] = 0 ; tmp [ 4 ] = 0 ; tmp [ 5 ] = 1 ; for (
b_kstr = 0 ; b_kstr < 6 ; b_kstr ++ ) { msubspace_data [ b_kstr ] = tmp [
b_kstr ] ; } obj -> JointInternal . PositionNumber = 1.0 ; obj ->
JointInternal . JointAxisInternal [ 0 ] = 0.0 ; obj -> JointInternal .
JointAxisInternal [ 1 ] = 0.0 ; obj -> JointInternal . JointAxisInternal [ 2
] = 1.0 ; break ; default : for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr ++ ) {
msubspace_data [ b_kstr ] = 0 ; } obj -> JointInternal . PositionNumber = 0.0
; obj -> JointInternal . JointAxisInternal [ 0 ] = 0.0 ; obj -> JointInternal
. JointAxisInternal [ 1 ] = 0.0 ; obj -> JointInternal . JointAxisInternal [
2 ] = 0.0 ; break ; } b_kstr = obj -> JointInternal . MotionSubspace -> size
[ 0 ] * obj -> JointInternal . MotionSubspace -> size [ 1 ] ; obj ->
JointInternal . MotionSubspace -> size [ 0 ] = 6 ; obj -> JointInternal .
MotionSubspace -> size [ 1 ] = 1 ; ier0p3wwtw ( obj -> JointInternal .
MotionSubspace , b_kstr ) ; for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr ++ ) { obj
-> JointInternal . MotionSubspace -> data [ b_kstr ] = msubspace_data [
b_kstr ] ; } for ( b_kstr = 0 ; b_kstr < 16 ; b_kstr ++ ) { obj ->
JointInternal . JointToParentTransform [ b_kstr ] = tmp_m [ b_kstr ] ; } for
( b_kstr = 0 ; b_kstr < 16 ; b_kstr ++ ) { obj -> JointInternal .
ChildToJointTransform [ b_kstr ] = tmp_g [ b_kstr ] ; } b_kstr = obj ->
JointInternal . MotionSubspace -> size [ 0 ] * obj -> JointInternal .
MotionSubspace -> size [ 1 ] ; obj -> JointInternal . MotionSubspace -> size
[ 0 ] = 6 ; obj -> JointInternal . MotionSubspace -> size [ 1 ] = 1 ;
ier0p3wwtw ( obj -> JointInternal . MotionSubspace , b_kstr ) ; for ( b_kstr
= 0 ; b_kstr < 6 ; b_kstr ++ ) { obj -> JointInternal . MotionSubspace ->
data [ b_kstr ] = tmp_j [ b_kstr ] ; } obj -> JointInternal .
JointAxisInternal [ 0 ] = 0.0 ; obj -> JointInternal . JointAxisInternal [ 1
] = 0.0 ; obj -> JointInternal . JointAxisInternal [ 2 ] = 1.0 ; aydneur4h5 (
& obj -> CollisionsInternal ) ; return b_obj ; } static void g1slahjfob (
exm4lytzjq * obj ) { e2b0f4s35s * switch_expression ; kp1en3mw3x * obj_p ;
int32_T b_kstr ; int32_T loop_ub ; char_T b_p [ 9 ] ; char_T b [ 8 ] ; int8_T
msubspace_data [ 36 ] ; int8_T tmp [ 6 ] ; boolean_T b_bool ; static const
char_T tmp_p [ 5 ] = { 'B' , 'o' , 'd' , 'y' , '1' } ; static const char_T
tmp_e [ 8 ] = { 'r' , 'e' , 'v' , 'o' , 'l' , 'u' , 't' , 'e' } ; static
const char_T tmp_i [ 9 ] = { 'p' , 'r' , 'i' , 's' , 'm' , 'a' , 't' , 'i' ,
'c' } ; static const real_T tmp_m [ 16 ] = { 6.123233995736766E-17 , 0.0 ,
1.0 , 0.0 , 1.0 , 6.123233995736766E-17 , - 6.123233995736766E-17 , 0.0 , -
6.123233995736766E-17 , 1.0 , 3.749399456654644E-33 , 0.0 ,
0.0065704530241911842 , 0.04712085191226531 , 0.019427065864845966 , 1.0 } ;
static const real_T tmp_g [ 16 ] = { 1.0 , 0.0 , 0.0 , 0.0 , 0.0 , 1.0 , 0.0
, 0.0 , 0.0 , 0.0 , 1.0 , 0.0 , 0.0 , 0.0 , 0.0 , 1.0 } ; static const real_T
tmp_j [ 36 ] = { 0.0 , 0.0 , 1.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 ,
0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 ,
0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 }
; static const char_T tmp_f [ 5 ] = { 'B' , 'o' , 'd' , 'y' , '2' } ; static
const real_T tmp_c [ 16 ] = { 6.123233995736766E-17 , 0.0 , 1.0 , 0.0 , 1.0 ,
- 1.6081226496766366E-16 , - 6.123233995736766E-17 , 0.0 ,
1.6081226496766366E-16 , 1.0 , - 9.8469112778142665E-33 , 0.0 ,
2.7755575615628914E-17 , - 0.040001000000000037 , 0.13000000000000009 , 1.0 }
; static const int8_T tmp_k [ 10 ] = { 1 , 2 , 3 , 4 , 5 , 1 , 2 , 3 , 4 , 5
} ; static const char_T tmp_b [ 5 ] = { 'f' , 'i' , 'x' , 'e' , 'd' } ;
int32_T exitg1 ; obj -> isInitialized = 1 ; obj_p = & obj -> TreeInternal ;
obj -> TreeInternal . NumBodies = 5.0 ; dpajaj4gpx ( & obj -> TreeInternal ,
& obj -> TreeInternal . _pobj0 [ 0 ] ) ; b_kstr = obj_p -> _pobj0 [ 5 ] .
NameInternal -> size [ 0 ] * obj_p -> _pobj0 [ 5 ] . NameInternal -> size [ 1
] ; obj_p -> _pobj0 [ 5 ] . NameInternal -> size [ 0 ] = 1 ; obj_p -> _pobj0
[ 5 ] . NameInternal -> size [ 1 ] = 5 ; ac0ugu5nlz ( obj_p -> _pobj0 [ 5 ] .
NameInternal , b_kstr ) ; for ( b_kstr = 0 ; b_kstr < 5 ; b_kstr ++ ) { obj_p
-> _pobj0 [ 5 ] . NameInternal -> data [ b_kstr ] = tmp_p [ b_kstr ] ; }
obj_p -> _pobj0 [ 5 ] . ParentIndex = 0.0 ; b_kstr = obj -> TreeInternal .
_pobj0 [ 5 ] . JointInternal . Type -> size [ 0 ] * obj -> TreeInternal .
_pobj0 [ 5 ] . JointInternal . Type -> size [ 1 ] ; obj -> TreeInternal .
_pobj0 [ 5 ] . JointInternal . Type -> size [ 0 ] = 1 ; obj -> TreeInternal .
_pobj0 [ 5 ] . JointInternal . Type -> size [ 1 ] = 8 ; ac0ugu5nlz ( obj ->
TreeInternal . _pobj0 [ 5 ] . JointInternal . Type , b_kstr ) ; for ( b_kstr
= 0 ; b_kstr < 8 ; b_kstr ++ ) { obj -> TreeInternal . _pobj0 [ 5 ] .
JointInternal . Type -> data [ b_kstr ] = tmp_e [ b_kstr ] ; } gunzkbl0qg ( &
switch_expression , 2 ) ; b_kstr = switch_expression -> size [ 0 ] *
switch_expression -> size [ 1 ] ; switch_expression -> size [ 0 ] = 1 ;
switch_expression -> size [ 1 ] = obj -> TreeInternal . _pobj0 [ 5 ] .
JointInternal . Type -> size [ 1 ] ; ac0ugu5nlz ( switch_expression , b_kstr
) ; loop_ub = obj -> TreeInternal . _pobj0 [ 5 ] . JointInternal . Type ->
size [ 1 ] - 1 ; for ( b_kstr = 0 ; b_kstr <= loop_ub ; b_kstr ++ ) {
switch_expression -> data [ b_kstr ] = obj -> TreeInternal . _pobj0 [ 5 ] .
JointInternal . Type -> data [ b_kstr ] ; } for ( b_kstr = 0 ; b_kstr < 8 ;
b_kstr ++ ) { b [ b_kstr ] = tmp_e [ b_kstr ] ; } b_bool = false ; if (
switch_expression -> size [ 1 ] != 8 ) { } else { b_kstr = 1 ; do { exitg1 =
0 ; if ( b_kstr - 1 < 8 ) { if ( switch_expression -> data [ b_kstr - 1 ] !=
b [ b_kstr - 1 ] ) { exitg1 = 1 ; } else { b_kstr ++ ; } } else { b_bool =
true ; exitg1 = 1 ; } } while ( exitg1 == 0 ) ; } if ( b_bool ) { b_kstr = 0
; } else { for ( b_kstr = 0 ; b_kstr < 9 ; b_kstr ++ ) { b_p [ b_kstr ] =
tmp_i [ b_kstr ] ; } if ( switch_expression -> size [ 1 ] != 9 ) { } else {
b_kstr = 1 ; do { exitg1 = 0 ; if ( b_kstr - 1 < 9 ) { if ( switch_expression
-> data [ b_kstr - 1 ] != b_p [ b_kstr - 1 ] ) { exitg1 = 1 ; } else { b_kstr
++ ; } } else { b_bool = true ; exitg1 = 1 ; } } while ( exitg1 == 0 ) ; } if
( b_bool ) { b_kstr = 1 ; } else { b_kstr = - 1 ; } } switch ( b_kstr ) {
case 0 : tmp [ 0 ] = 0 ; tmp [ 1 ] = 0 ; tmp [ 2 ] = 1 ; tmp [ 3 ] = 0 ; tmp
[ 4 ] = 0 ; tmp [ 5 ] = 0 ; for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr ++ ) {
msubspace_data [ b_kstr ] = tmp [ b_kstr ] ; } obj -> TreeInternal . _pobj0 [
5 ] . JointInternal . PositionNumber = 1.0 ; obj -> TreeInternal . _pobj0 [ 5
] . JointInternal . JointAxisInternal [ 0 ] = 0.0 ; obj -> TreeInternal .
_pobj0 [ 5 ] . JointInternal . JointAxisInternal [ 1 ] = 0.0 ; obj ->
TreeInternal . _pobj0 [ 5 ] . JointInternal . JointAxisInternal [ 2 ] = 1.0 ;
break ; case 1 : tmp [ 0 ] = 0 ; tmp [ 1 ] = 0 ; tmp [ 2 ] = 0 ; tmp [ 3 ] =
0 ; tmp [ 4 ] = 0 ; tmp [ 5 ] = 1 ; for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr ++
) { msubspace_data [ b_kstr ] = tmp [ b_kstr ] ; } obj -> TreeInternal .
_pobj0 [ 5 ] . JointInternal . PositionNumber = 1.0 ; obj -> TreeInternal .
_pobj0 [ 5 ] . JointInternal . JointAxisInternal [ 0 ] = 0.0 ; obj ->
TreeInternal . _pobj0 [ 5 ] . JointInternal . JointAxisInternal [ 1 ] = 0.0 ;
obj -> TreeInternal . _pobj0 [ 5 ] . JointInternal . JointAxisInternal [ 2 ]
= 1.0 ; break ; default : for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr ++ ) {
msubspace_data [ b_kstr ] = 0 ; } obj -> TreeInternal . _pobj0 [ 5 ] .
JointInternal . PositionNumber = 0.0 ; obj -> TreeInternal . _pobj0 [ 5 ] .
JointInternal . JointAxisInternal [ 0 ] = 0.0 ; obj -> TreeInternal . _pobj0
[ 5 ] . JointInternal . JointAxisInternal [ 1 ] = 0.0 ; obj -> TreeInternal .
_pobj0 [ 5 ] . JointInternal . JointAxisInternal [ 2 ] = 0.0 ; break ; }
b_kstr = obj -> TreeInternal . _pobj0 [ 5 ] . JointInternal . MotionSubspace
-> size [ 0 ] * obj -> TreeInternal . _pobj0 [ 5 ] . JointInternal .
MotionSubspace -> size [ 1 ] ; obj -> TreeInternal . _pobj0 [ 5 ] .
JointInternal . MotionSubspace -> size [ 0 ] = 6 ; obj -> TreeInternal .
_pobj0 [ 5 ] . JointInternal . MotionSubspace -> size [ 1 ] = 1 ; ier0p3wwtw
( obj -> TreeInternal . _pobj0 [ 5 ] . JointInternal . MotionSubspace ,
b_kstr ) ; for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr ++ ) { obj -> TreeInternal
. _pobj0 [ 5 ] . JointInternal . MotionSubspace -> data [ b_kstr ] =
msubspace_data [ b_kstr ] ; } for ( b_kstr = 0 ; b_kstr < 16 ; b_kstr ++ ) {
obj_p -> _pobj0 [ 5 ] . JointInternal . JointToParentTransform [ b_kstr ] =
tmp_m [ b_kstr ] ; } for ( b_kstr = 0 ; b_kstr < 16 ; b_kstr ++ ) { obj_p ->
_pobj0 [ 5 ] . JointInternal . ChildToJointTransform [ b_kstr ] = tmp_g [
b_kstr ] ; } b_kstr = obj_p -> _pobj0 [ 5 ] . JointInternal . MotionSubspace
-> size [ 0 ] * obj_p -> _pobj0 [ 5 ] . JointInternal . MotionSubspace ->
size [ 1 ] ; obj_p -> _pobj0 [ 5 ] . JointInternal . MotionSubspace -> size [
0 ] = 6 ; obj_p -> _pobj0 [ 5 ] . JointInternal . MotionSubspace -> size [ 1
] = 1 ; ier0p3wwtw ( obj_p -> _pobj0 [ 5 ] . JointInternal . MotionSubspace ,
b_kstr ) ; for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr ++ ) { obj_p -> _pobj0 [ 5
] . JointInternal . MotionSubspace -> data [ b_kstr ] = tmp_j [ b_kstr ] ; }
obj_p -> _pobj0 [ 5 ] . JointInternal . JointAxisInternal [ 0 ] = 0.0 ; obj_p
-> _pobj0 [ 5 ] . JointInternal . JointAxisInternal [ 1 ] = 0.0 ; obj_p ->
_pobj0 [ 5 ] . JointInternal . JointAxisInternal [ 2 ] = 1.0 ; aydneur4h5 ( &
obj_p -> _pobj0 [ 5 ] . CollisionsInternal ) ; obj -> TreeInternal . Bodies [
0 ] = & obj_p -> _pobj0 [ 5 ] ; obj -> TreeInternal . Bodies [ 0 ] -> Index =
1.0 ; b_kstr = obj_p -> _pobj0 [ 6 ] . NameInternal -> size [ 0 ] * obj_p ->
_pobj0 [ 6 ] . NameInternal -> size [ 1 ] ; obj_p -> _pobj0 [ 6 ] .
NameInternal -> size [ 0 ] = 1 ; obj_p -> _pobj0 [ 6 ] . NameInternal -> size
[ 1 ] = 5 ; ac0ugu5nlz ( obj_p -> _pobj0 [ 6 ] . NameInternal , b_kstr ) ;
for ( b_kstr = 0 ; b_kstr < 5 ; b_kstr ++ ) { obj_p -> _pobj0 [ 6 ] .
NameInternal -> data [ b_kstr ] = tmp_f [ b_kstr ] ; } obj_p -> _pobj0 [ 6 ]
. ParentIndex = 1.0 ; b_kstr = obj -> TreeInternal . _pobj0 [ 6 ] .
JointInternal . Type -> size [ 0 ] * obj -> TreeInternal . _pobj0 [ 6 ] .
JointInternal . Type -> size [ 1 ] ; obj -> TreeInternal . _pobj0 [ 6 ] .
JointInternal . Type -> size [ 0 ] = 1 ; obj -> TreeInternal . _pobj0 [ 6 ] .
JointInternal . Type -> size [ 1 ] = 8 ; ac0ugu5nlz ( obj -> TreeInternal .
_pobj0 [ 6 ] . JointInternal . Type , b_kstr ) ; for ( b_kstr = 0 ; b_kstr <
8 ; b_kstr ++ ) { obj -> TreeInternal . _pobj0 [ 6 ] . JointInternal . Type
-> data [ b_kstr ] = tmp_e [ b_kstr ] ; } b_kstr = switch_expression -> size
[ 0 ] * switch_expression -> size [ 1 ] ; switch_expression -> size [ 0 ] = 1
; switch_expression -> size [ 1 ] = obj -> TreeInternal . _pobj0 [ 6 ] .
JointInternal . Type -> size [ 1 ] ; ac0ugu5nlz ( switch_expression , b_kstr
) ; loop_ub = obj -> TreeInternal . _pobj0 [ 6 ] . JointInternal . Type ->
size [ 1 ] - 1 ; for ( b_kstr = 0 ; b_kstr <= loop_ub ; b_kstr ++ ) {
switch_expression -> data [ b_kstr ] = obj -> TreeInternal . _pobj0 [ 6 ] .
JointInternal . Type -> data [ b_kstr ] ; } b_bool = false ; if (
switch_expression -> size [ 1 ] != 8 ) { } else { b_kstr = 1 ; do { exitg1 =
0 ; if ( b_kstr - 1 < 8 ) { if ( switch_expression -> data [ b_kstr - 1 ] !=
b [ b_kstr - 1 ] ) { exitg1 = 1 ; } else { b_kstr ++ ; } } else { b_bool =
true ; exitg1 = 1 ; } } while ( exitg1 == 0 ) ; } if ( b_bool ) { b_kstr = 0
; } else { for ( b_kstr = 0 ; b_kstr < 9 ; b_kstr ++ ) { b_p [ b_kstr ] =
tmp_i [ b_kstr ] ; } if ( switch_expression -> size [ 1 ] != 9 ) { } else {
b_kstr = 1 ; do { exitg1 = 0 ; if ( b_kstr - 1 < 9 ) { if ( switch_expression
-> data [ b_kstr - 1 ] != b_p [ b_kstr - 1 ] ) { exitg1 = 1 ; } else { b_kstr
++ ; } } else { b_bool = true ; exitg1 = 1 ; } } while ( exitg1 == 0 ) ; } if
( b_bool ) { b_kstr = 1 ; } else { b_kstr = - 1 ; } } switch ( b_kstr ) {
case 0 : tmp [ 0 ] = 0 ; tmp [ 1 ] = 0 ; tmp [ 2 ] = 1 ; tmp [ 3 ] = 0 ; tmp
[ 4 ] = 0 ; tmp [ 5 ] = 0 ; for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr ++ ) {
msubspace_data [ b_kstr ] = tmp [ b_kstr ] ; } obj -> TreeInternal . _pobj0 [
6 ] . JointInternal . PositionNumber = 1.0 ; obj -> TreeInternal . _pobj0 [ 6
] . JointInternal . JointAxisInternal [ 0 ] = 0.0 ; obj -> TreeInternal .
_pobj0 [ 6 ] . JointInternal . JointAxisInternal [ 1 ] = 0.0 ; obj ->
TreeInternal . _pobj0 [ 6 ] . JointInternal . JointAxisInternal [ 2 ] = 1.0 ;
break ; case 1 : tmp [ 0 ] = 0 ; tmp [ 1 ] = 0 ; tmp [ 2 ] = 0 ; tmp [ 3 ] =
0 ; tmp [ 4 ] = 0 ; tmp [ 5 ] = 1 ; for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr ++
) { msubspace_data [ b_kstr ] = tmp [ b_kstr ] ; } obj -> TreeInternal .
_pobj0 [ 6 ] . JointInternal . PositionNumber = 1.0 ; obj -> TreeInternal .
_pobj0 [ 6 ] . JointInternal . JointAxisInternal [ 0 ] = 0.0 ; obj ->
TreeInternal . _pobj0 [ 6 ] . JointInternal . JointAxisInternal [ 1 ] = 0.0 ;
obj -> TreeInternal . _pobj0 [ 6 ] . JointInternal . JointAxisInternal [ 2 ]
= 1.0 ; break ; default : for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr ++ ) {
msubspace_data [ b_kstr ] = 0 ; } obj -> TreeInternal . _pobj0 [ 6 ] .
JointInternal . PositionNumber = 0.0 ; obj -> TreeInternal . _pobj0 [ 6 ] .
JointInternal . JointAxisInternal [ 0 ] = 0.0 ; obj -> TreeInternal . _pobj0
[ 6 ] . JointInternal . JointAxisInternal [ 1 ] = 0.0 ; obj -> TreeInternal .
_pobj0 [ 6 ] . JointInternal . JointAxisInternal [ 2 ] = 0.0 ; break ; }
b_kstr = obj -> TreeInternal . _pobj0 [ 6 ] . JointInternal . MotionSubspace
-> size [ 0 ] * obj -> TreeInternal . _pobj0 [ 6 ] . JointInternal .
MotionSubspace -> size [ 1 ] ; obj -> TreeInternal . _pobj0 [ 6 ] .
JointInternal . MotionSubspace -> size [ 0 ] = 6 ; obj -> TreeInternal .
_pobj0 [ 6 ] . JointInternal . MotionSubspace -> size [ 1 ] = 1 ; ier0p3wwtw
( obj -> TreeInternal . _pobj0 [ 6 ] . JointInternal . MotionSubspace ,
b_kstr ) ; for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr ++ ) { obj -> TreeInternal
. _pobj0 [ 6 ] . JointInternal . MotionSubspace -> data [ b_kstr ] =
msubspace_data [ b_kstr ] ; } for ( b_kstr = 0 ; b_kstr < 16 ; b_kstr ++ ) {
obj_p -> _pobj0 [ 6 ] . JointInternal . JointToParentTransform [ b_kstr ] =
tmp_c [ b_kstr ] ; } for ( b_kstr = 0 ; b_kstr < 16 ; b_kstr ++ ) { obj_p ->
_pobj0 [ 6 ] . JointInternal . ChildToJointTransform [ b_kstr ] = tmp_g [
b_kstr ] ; } b_kstr = obj_p -> _pobj0 [ 6 ] . JointInternal . MotionSubspace
-> size [ 0 ] * obj_p -> _pobj0 [ 6 ] . JointInternal . MotionSubspace ->
size [ 1 ] ; obj_p -> _pobj0 [ 6 ] . JointInternal . MotionSubspace -> size [
0 ] = 6 ; obj_p -> _pobj0 [ 6 ] . JointInternal . MotionSubspace -> size [ 1
] = 1 ; ier0p3wwtw ( obj_p -> _pobj0 [ 6 ] . JointInternal . MotionSubspace ,
b_kstr ) ; for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr ++ ) { obj_p -> _pobj0 [ 6
] . JointInternal . MotionSubspace -> data [ b_kstr ] = tmp_j [ b_kstr ] ; }
obj_p -> _pobj0 [ 6 ] . JointInternal . JointAxisInternal [ 0 ] = 0.0 ; obj_p
-> _pobj0 [ 6 ] . JointInternal . JointAxisInternal [ 1 ] = 0.0 ; obj_p ->
_pobj0 [ 6 ] . JointInternal . JointAxisInternal [ 2 ] = 1.0 ; aydneur4h5 ( &
obj_p -> _pobj0 [ 6 ] . CollisionsInternal ) ; obj -> TreeInternal . Bodies [
1 ] = & obj_p -> _pobj0 [ 6 ] ; obj -> TreeInternal . Bodies [ 1 ] -> Index =
2.0 ; obj -> TreeInternal . Bodies [ 2 ] = mhyfpzbtelc ( & obj ->
TreeInternal . _pobj0 [ 7 ] ) ; obj -> TreeInternal . Bodies [ 2 ] -> Index =
3.0 ; obj -> TreeInternal . Bodies [ 3 ] = mhyfpzbtelc0 ( & obj ->
TreeInternal . _pobj0 [ 8 ] ) ; obj -> TreeInternal . Bodies [ 3 ] -> Index =
4.0 ; obj -> TreeInternal . Bodies [ 4 ] = mhyfpzbtelc0w ( & obj ->
TreeInternal . _pobj0 [ 9 ] ) ; obj -> TreeInternal . Bodies [ 4 ] -> Index =
5.0 ; obj -> TreeInternal . PositionNumber = 5.0 ; obj -> TreeInternal .
VelocityNumber = 5.0 ; for ( b_kstr = 0 ; b_kstr < 10 ; b_kstr ++ ) { obj ->
TreeInternal . PositionDoFMap [ b_kstr ] = tmp_k [ b_kstr ] ; } b_kstr =
obj_p -> Base . NameInternal -> size [ 0 ] * obj_p -> Base . NameInternal ->
size [ 1 ] ; obj_p -> Base . NameInternal -> size [ 0 ] = 1 ; obj_p -> Base .
NameInternal -> size [ 1 ] = 4 ; ac0ugu5nlz ( obj_p -> Base . NameInternal ,
b_kstr ) ; obj_p -> Base . NameInternal -> data [ 0 ] = 'B' ; obj_p -> Base .
NameInternal -> data [ 1 ] = 'a' ; obj_p -> Base . NameInternal -> data [ 2 ]
= 's' ; obj_p -> Base . NameInternal -> data [ 3 ] = 'e' ; obj_p -> Base .
ParentIndex = - 1.0 ; b_kstr = obj -> TreeInternal . Base . JointInternal .
Type -> size [ 0 ] * obj -> TreeInternal . Base . JointInternal . Type ->
size [ 1 ] ; obj -> TreeInternal . Base . JointInternal . Type -> size [ 0 ]
= 1 ; obj -> TreeInternal . Base . JointInternal . Type -> size [ 1 ] = 5 ;
ac0ugu5nlz ( obj -> TreeInternal . Base . JointInternal . Type , b_kstr ) ;
for ( b_kstr = 0 ; b_kstr < 5 ; b_kstr ++ ) { obj -> TreeInternal . Base .
JointInternal . Type -> data [ b_kstr ] = tmp_b [ b_kstr ] ; } b_kstr =
switch_expression -> size [ 0 ] * switch_expression -> size [ 1 ] ;
switch_expression -> size [ 0 ] = 1 ; switch_expression -> size [ 1 ] = obj
-> TreeInternal . Base . JointInternal . Type -> size [ 1 ] ; ac0ugu5nlz (
switch_expression , b_kstr ) ; loop_ub = obj -> TreeInternal . Base .
JointInternal . Type -> size [ 1 ] - 1 ; for ( b_kstr = 0 ; b_kstr <= loop_ub
; b_kstr ++ ) { switch_expression -> data [ b_kstr ] = obj -> TreeInternal .
Base . JointInternal . Type -> data [ b_kstr ] ; } b_bool = false ; if (
switch_expression -> size [ 1 ] != 8 ) { } else { b_kstr = 1 ; do { exitg1 =
0 ; if ( b_kstr - 1 < 8 ) { if ( switch_expression -> data [ b_kstr - 1 ] !=
b [ b_kstr - 1 ] ) { exitg1 = 1 ; } else { b_kstr ++ ; } } else { b_bool =
true ; exitg1 = 1 ; } } while ( exitg1 == 0 ) ; } if ( b_bool ) { b_kstr = 0
; } else { for ( b_kstr = 0 ; b_kstr < 9 ; b_kstr ++ ) { b_p [ b_kstr ] =
tmp_i [ b_kstr ] ; } if ( switch_expression -> size [ 1 ] != 9 ) { } else {
b_kstr = 1 ; do { exitg1 = 0 ; if ( b_kstr - 1 < 9 ) { if ( switch_expression
-> data [ b_kstr - 1 ] != b_p [ b_kstr - 1 ] ) { exitg1 = 1 ; } else { b_kstr
++ ; } } else { b_bool = true ; exitg1 = 1 ; } } while ( exitg1 == 0 ) ; } if
( b_bool ) { b_kstr = 1 ; } else { b_kstr = - 1 ; } } b0l0vcvht3 ( &
switch_expression ) ; switch ( b_kstr ) { case 0 : tmp [ 0 ] = 0 ; tmp [ 1 ]
= 0 ; tmp [ 2 ] = 1 ; tmp [ 3 ] = 0 ; tmp [ 4 ] = 0 ; tmp [ 5 ] = 0 ; for (
b_kstr = 0 ; b_kstr < 6 ; b_kstr ++ ) { msubspace_data [ b_kstr ] = tmp [
b_kstr ] ; } obj -> TreeInternal . Base . JointInternal . PositionNumber =
1.0 ; obj -> TreeInternal . Base . JointInternal . JointAxisInternal [ 0 ] =
0.0 ; obj -> TreeInternal . Base . JointInternal . JointAxisInternal [ 1 ] =
0.0 ; obj -> TreeInternal . Base . JointInternal . JointAxisInternal [ 2 ] =
1.0 ; break ; case 1 : tmp [ 0 ] = 0 ; tmp [ 1 ] = 0 ; tmp [ 2 ] = 0 ; tmp [
3 ] = 0 ; tmp [ 4 ] = 0 ; tmp [ 5 ] = 1 ; for ( b_kstr = 0 ; b_kstr < 6 ;
b_kstr ++ ) { msubspace_data [ b_kstr ] = tmp [ b_kstr ] ; } obj ->
TreeInternal . Base . JointInternal . PositionNumber = 1.0 ; obj ->
TreeInternal . Base . JointInternal . JointAxisInternal [ 0 ] = 0.0 ; obj ->
TreeInternal . Base . JointInternal . JointAxisInternal [ 1 ] = 0.0 ; obj ->
TreeInternal . Base . JointInternal . JointAxisInternal [ 2 ] = 1.0 ; break ;
default : for ( b_kstr = 0 ; b_kstr < 6 ; b_kstr ++ ) { msubspace_data [
b_kstr ] = 0 ; } obj -> TreeInternal . Base . JointInternal . PositionNumber
= 0.0 ; obj -> TreeInternal . Base . JointInternal . JointAxisInternal [ 0 ]
= 0.0 ; obj -> TreeInternal . Base . JointInternal . JointAxisInternal [ 1 ]
= 0.0 ; obj -> TreeInternal . Base . JointInternal . JointAxisInternal [ 2 ]
= 0.0 ; break ; } b_kstr = obj -> TreeInternal . Base . JointInternal .
MotionSubspace -> size [ 0 ] * obj -> TreeInternal . Base . JointInternal .
MotionSubspace -> size [ 1 ] ; obj -> TreeInternal . Base . JointInternal .
MotionSubspace -> size [ 0 ] = 6 ; obj -> TreeInternal . Base . JointInternal
. MotionSubspace -> size [ 1 ] = 1 ; ier0p3wwtw ( obj -> TreeInternal . Base
. JointInternal . MotionSubspace , b_kstr ) ; for ( b_kstr = 0 ; b_kstr < 6 ;
b_kstr ++ ) { obj -> TreeInternal . Base . JointInternal . MotionSubspace ->
data [ b_kstr ] = msubspace_data [ b_kstr ] ; } aydneur4h5 ( & obj_p -> Base
. CollisionsInternal ) ; obj -> TreeInternal . Base . Index = 0.0 ; } static
void mqbow5axkl ( iyg0swfnbfo * pStruct ) { gunzkbl0qg ( & pStruct -> Type ,
2 ) ; } static void lqdzki1nok ( gxcsgl11sl3 * pStruct ) { gunzkbl0qg ( &
pStruct -> NameInternal , 2 ) ; mqbow5axkl ( & pStruct -> JointInternal ) ;
azpme0b1ng ( & pStruct -> CollisionsInternal ) ; } static void
m4davgb45zzophb ( gxcsgl11sl3 pMatrix [ 10 ] ) { int32_T i ; for ( i = 0 ; i
< 10 ; i ++ ) { lqdzki1nok ( & pMatrix [ i ] ) ; } } static void lstqfey1q1 (
kp1en3mw3xl * pStruct ) { lqdzki1nok ( & pStruct -> Base ) ; m4davgb45zzophb
( pStruct -> _pobj0 ) ; } static void l353migxc4hk ( gsvdge1jib * pStruct ) {
lstqfey1q1 ( & pStruct -> TreeInternal ) ; } static void dpajaj4gpxk (
kp1en3mw3xl * obj , gxcsgl11sl3 * iobj_0 ) { e2b0f4s35s * switch_expression ;
int32_T b_kstr ; int32_T loop_ub ; char_T b_p [ 9 ] ; char_T b [ 8 ] ;
boolean_T b_bool ; static const char_T tmp [ 10 ] = { 'd' , 'u' , 'm' , 'm' ,
'y' , 'b' , 'o' , 'd' , 'y' , '1' } ; static const char_T tmp_p [ 5 ] = { 'f'
, 'i' , 'x' , 'e' , 'd' } ; static const char_T tmp_e [ 8 ] = { 'r' , 'e' ,
'v' , 'o' , 'l' , 'u' , 't' , 'e' } ; static const char_T tmp_i [ 9 ] = { 'p'
, 'r' , 'i' , 's' , 'm' , 'a' , 't' , 'i' , 'c' } ; static const char_T tmp_m
[ 10 ] = { 'd' , 'u' , 'm' , 'm' , 'y' , 'b' , 'o' , 'd' , 'y' , '2' } ;
static const char_T tmp_g [ 10 ] = { 'd' , 'u' , 'm' , 'm' , 'y' , 'b' , 'o'
, 'd' , 'y' , '3' } ; static const char_T tmp_j [ 10 ] = { 'd' , 'u' , 'm' ,
'm' , 'y' , 'b' , 'o' , 'd' , 'y' , '4' } ; static const char_T tmp_f [ 10 ]
= { 'd' , 'u' , 'm' , 'm' , 'y' , 'b' , 'o' , 'd' , 'y' , '5' } ; int32_T
exitg1 ; b_kstr = iobj_0 [ 0 ] . NameInternal -> size [ 0 ] * iobj_0 [ 0 ] .
NameInternal -> size [ 1 ] ; iobj_0 [ 0 ] . NameInternal -> size [ 0 ] = 1 ;
iobj_0 [ 0 ] . NameInternal -> size [ 1 ] = 10 ; ac0ugu5nlz ( iobj_0 [ 0 ] .
NameInternal , b_kstr ) ; for ( b_kstr = 0 ; b_kstr < 10 ; b_kstr ++ ) {
iobj_0 [ 0 ] . NameInternal -> data [ b_kstr ] = tmp [ b_kstr ] ; } b_kstr =
iobj_0 [ 0 ] . JointInternal . Type -> size [ 0 ] * iobj_0 [ 0 ] .
JointInternal . Type -> size [ 1 ] ; iobj_0 [ 0 ] . JointInternal . Type ->
size [ 0 ] = 1 ; iobj_0 [ 0 ] . JointInternal . Type -> size [ 1 ] = 5 ;
ac0ugu5nlz ( iobj_0 [ 0 ] . JointInternal . Type , b_kstr ) ; for ( b_kstr =
0 ; b_kstr < 5 ; b_kstr ++ ) { iobj_0 [ 0 ] . JointInternal . Type -> data [
b_kstr ] = tmp_p [ b_kstr ] ; } gunzkbl0qg ( & switch_expression , 2 ) ;
b_kstr = switch_expression -> size [ 0 ] * switch_expression -> size [ 1 ] ;
switch_expression -> size [ 0 ] = 1 ; switch_expression -> size [ 1 ] =
iobj_0 [ 0 ] . JointInternal . Type -> size [ 1 ] ; ac0ugu5nlz (
switch_expression , b_kstr ) ; loop_ub = iobj_0 [ 0 ] . JointInternal . Type
-> size [ 1 ] - 1 ; for ( b_kstr = 0 ; b_kstr <= loop_ub ; b_kstr ++ ) {
switch_expression -> data [ b_kstr ] = iobj_0 [ 0 ] . JointInternal . Type ->
data [ b_kstr ] ; } for ( b_kstr = 0 ; b_kstr < 8 ; b_kstr ++ ) { b [ b_kstr
] = tmp_e [ b_kstr ] ; } b_bool = false ; if ( switch_expression -> size [ 1
] != 8 ) { } else { b_kstr = 1 ; do { exitg1 = 0 ; if ( b_kstr - 1 < 8 ) { if
( switch_expression -> data [ b_kstr - 1 ] != b [ b_kstr - 1 ] ) { exitg1 = 1
; } else { b_kstr ++ ; } } else { b_bool = true ; exitg1 = 1 ; } } while (
exitg1 == 0 ) ; } if ( b_bool ) { b_kstr = 0 ; } else { for ( b_kstr = 0 ;
b_kstr < 9 ; b_kstr ++ ) { b_p [ b_kstr ] = tmp_i [ b_kstr ] ; } if (
switch_expression -> size [ 1 ] != 9 ) { } else { b_kstr = 1 ; do { exitg1 =
0 ; if ( b_kstr - 1 < 9 ) { if ( switch_expression -> data [ b_kstr - 1 ] !=
b_p [ b_kstr - 1 ] ) { exitg1 = 1 ; } else { b_kstr ++ ; } } else { b_bool =
true ; exitg1 = 1 ; } } while ( exitg1 == 0 ) ; } if ( b_bool ) { b_kstr = 1
; } else { b_kstr = - 1 ; } } switch ( b_kstr ) { case 0 : iobj_0 [ 0 ] .
JointInternal . PositionNumber = 1.0 ; iobj_0 [ 0 ] . JointInternal .
JointAxisInternal [ 0 ] = 0.0 ; iobj_0 [ 0 ] . JointInternal .
JointAxisInternal [ 1 ] = 0.0 ; iobj_0 [ 0 ] . JointInternal .
JointAxisInternal [ 2 ] = 1.0 ; break ; case 1 : iobj_0 [ 0 ] . JointInternal
. PositionNumber = 1.0 ; iobj_0 [ 0 ] . JointInternal . JointAxisInternal [ 0
] = 0.0 ; iobj_0 [ 0 ] . JointInternal . JointAxisInternal [ 1 ] = 0.0 ;
iobj_0 [ 0 ] . JointInternal . JointAxisInternal [ 2 ] = 1.0 ; break ;
default : iobj_0 [ 0 ] . JointInternal . PositionNumber = 0.0 ; iobj_0 [ 0 ]
. JointInternal . JointAxisInternal [ 0 ] = 0.0 ; iobj_0 [ 0 ] .
JointInternal . JointAxisInternal [ 1 ] = 0.0 ; iobj_0 [ 0 ] . JointInternal
. JointAxisInternal [ 2 ] = 0.0 ; break ; } iobj_0 [ 0 ] . ParentIndex = -
1.0 ; aydneur4h5 ( & iobj_0 [ 0 ] . CollisionsInternal ) ; obj -> Bodies [ 0
] = & iobj_0 [ 0 ] ; b_kstr = iobj_0 [ 1 ] . NameInternal -> size [ 0 ] *
iobj_0 [ 1 ] . NameInternal -> size [ 1 ] ; iobj_0 [ 1 ] . NameInternal ->
size [ 0 ] = 1 ; iobj_0 [ 1 ] . NameInternal -> size [ 1 ] = 10 ; ac0ugu5nlz
( iobj_0 [ 1 ] . NameInternal , b_kstr ) ; for ( b_kstr = 0 ; b_kstr < 10 ;
b_kstr ++ ) { iobj_0 [ 1 ] . NameInternal -> data [ b_kstr ] = tmp_m [ b_kstr
] ; } b_kstr = iobj_0 [ 1 ] . JointInternal . Type -> size [ 0 ] * iobj_0 [ 1
] . JointInternal . Type -> size [ 1 ] ; iobj_0 [ 1 ] . JointInternal . Type
-> size [ 0 ] = 1 ; iobj_0 [ 1 ] . JointInternal . Type -> size [ 1 ] = 5 ;
ac0ugu5nlz ( iobj_0 [ 1 ] . JointInternal . Type , b_kstr ) ; for ( b_kstr =
0 ; b_kstr < 5 ; b_kstr ++ ) { iobj_0 [ 1 ] . JointInternal . Type -> data [
b_kstr ] = tmp_p [ b_kstr ] ; } b_kstr = switch_expression -> size [ 0 ] *
switch_expression -> size [ 1 ] ; switch_expression -> size [ 0 ] = 1 ;
switch_expression -> size [ 1 ] = iobj_0 [ 1 ] . JointInternal . Type -> size
[ 1 ] ; ac0ugu5nlz ( switch_expression , b_kstr ) ; loop_ub = iobj_0 [ 1 ] .
JointInternal . Type -> size [ 1 ] - 1 ; for ( b_kstr = 0 ; b_kstr <= loop_ub
; b_kstr ++ ) { switch_expression -> data [ b_kstr ] = iobj_0 [ 1 ] .
JointInternal . Type -> data [ b_kstr ] ; } b_bool = false ; if (
switch_expression -> size [ 1 ] != 8 ) { } else { b_kstr = 1 ; do { exitg1 =
0 ; if ( b_kstr - 1 < 8 ) { if ( switch_expression -> data [ b_kstr - 1 ] !=
b [ b_kstr - 1 ] ) { exitg1 = 1 ; } else { b_kstr ++ ; } } else { b_bool =
true ; exitg1 = 1 ; } } while ( exitg1 == 0 ) ; } if ( b_bool ) { b_kstr = 0
; } else { for ( b_kstr = 0 ; b_kstr < 9 ; b_kstr ++ ) { b_p [ b_kstr ] =
tmp_i [ b_kstr ] ; } if ( switch_expression -> size [ 1 ] != 9 ) { } else {
b_kstr = 1 ; do { exitg1 = 0 ; if ( b_kstr - 1 < 9 ) { if ( switch_expression
-> data [ b_kstr - 1 ] != b_p [ b_kstr - 1 ] ) { exitg1 = 1 ; } else { b_kstr
++ ; } } else { b_bool = true ; exitg1 = 1 ; } } while ( exitg1 == 0 ) ; } if
( b_bool ) { b_kstr = 1 ; } else { b_kstr = - 1 ; } } switch ( b_kstr ) {
case 0 : iobj_0 [ 1 ] . JointInternal . PositionNumber = 1.0 ; iobj_0 [ 1 ] .
JointInternal . JointAxisInternal [ 0 ] = 0.0 ; iobj_0 [ 1 ] . JointInternal
. JointAxisInternal [ 1 ] = 0.0 ; iobj_0 [ 1 ] . JointInternal .
JointAxisInternal [ 2 ] = 1.0 ; break ; case 1 : iobj_0 [ 1 ] . JointInternal
. PositionNumber = 1.0 ; iobj_0 [ 1 ] . JointInternal . JointAxisInternal [ 0
] = 0.0 ; iobj_0 [ 1 ] . JointInternal . JointAxisInternal [ 1 ] = 0.0 ;
iobj_0 [ 1 ] . JointInternal . JointAxisInternal [ 2 ] = 1.0 ; break ;
default : iobj_0 [ 1 ] . JointInternal . PositionNumber = 0.0 ; iobj_0 [ 1 ]
. JointInternal . JointAxisInternal [ 0 ] = 0.0 ; iobj_0 [ 1 ] .
JointInternal . JointAxisInternal [ 1 ] = 0.0 ; iobj_0 [ 1 ] . JointInternal
. JointAxisInternal [ 2 ] = 0.0 ; break ; } iobj_0 [ 1 ] . ParentIndex = -
1.0 ; aydneur4h5 ( & iobj_0 [ 1 ] . CollisionsInternal ) ; obj -> Bodies [ 1
] = & iobj_0 [ 1 ] ; b_kstr = iobj_0 [ 2 ] . NameInternal -> size [ 0 ] *
iobj_0 [ 2 ] . NameInternal -> size [ 1 ] ; iobj_0 [ 2 ] . NameInternal ->
size [ 0 ] = 1 ; iobj_0 [ 2 ] . NameInternal -> size [ 1 ] = 10 ; ac0ugu5nlz
( iobj_0 [ 2 ] . NameInternal , b_kstr ) ; for ( b_kstr = 0 ; b_kstr < 10 ;
b_kstr ++ ) { iobj_0 [ 2 ] . NameInternal -> data [ b_kstr ] = tmp_g [ b_kstr
] ; } b_kstr = iobj_0 [ 2 ] . JointInternal . Type -> size [ 0 ] * iobj_0 [ 2
] . JointInternal . Type -> size [ 1 ] ; iobj_0 [ 2 ] . JointInternal . Type
-> size [ 0 ] = 1 ; iobj_0 [ 2 ] . JointInternal . Type -> size [ 1 ] = 5 ;
ac0ugu5nlz ( iobj_0 [ 2 ] . JointInternal . Type , b_kstr ) ; for ( b_kstr =
0 ; b_kstr < 5 ; b_kstr ++ ) { iobj_0 [ 2 ] . JointInternal . Type -> data [
b_kstr ] = tmp_p [ b_kstr ] ; } b_kstr = switch_expression -> size [ 0 ] *
switch_expression -> size [ 1 ] ; switch_expression -> size [ 0 ] = 1 ;
switch_expression -> size [ 1 ] = iobj_0 [ 2 ] . JointInternal . Type -> size
[ 1 ] ; ac0ugu5nlz ( switch_expression , b_kstr ) ; loop_ub = iobj_0 [ 2 ] .
JointInternal . Type -> size [ 1 ] - 1 ; for ( b_kstr = 0 ; b_kstr <= loop_ub
; b_kstr ++ ) { switch_expression -> data [ b_kstr ] = iobj_0 [ 2 ] .
JointInternal . Type -> data [ b_kstr ] ; } b_bool = false ; if (
switch_expression -> size [ 1 ] != 8 ) { } else { b_kstr = 1 ; do { exitg1 =
0 ; if ( b_kstr - 1 < 8 ) { if ( switch_expression -> data [ b_kstr - 1 ] !=
b [ b_kstr - 1 ] ) { exitg1 = 1 ; } else { b_kstr ++ ; } } else { b_bool =
true ; exitg1 = 1 ; } } while ( exitg1 == 0 ) ; } if ( b_bool ) { b_kstr = 0
; } else { for ( b_kstr = 0 ; b_kstr < 9 ; b_kstr ++ ) { b_p [ b_kstr ] =
tmp_i [ b_kstr ] ; } if ( switch_expression -> size [ 1 ] != 9 ) { } else {
b_kstr = 1 ; do { exitg1 = 0 ; if ( b_kstr - 1 < 9 ) { if ( switch_expression
-> data [ b_kstr - 1 ] != b_p [ b_kstr - 1 ] ) { exitg1 = 1 ; } else { b_kstr
++ ; } } else { b_bool = true ; exitg1 = 1 ; } } while ( exitg1 == 0 ) ; } if
( b_bool ) { b_kstr = 1 ; } else { b_kstr = - 1 ; } } switch ( b_kstr ) {
case 0 : iobj_0 [ 2 ] . JointInternal . PositionNumber = 1.0 ; iobj_0 [ 2 ] .
JointInternal . JointAxisInternal [ 0 ] = 0.0 ; iobj_0 [ 2 ] . JointInternal
. JointAxisInternal [ 1 ] = 0.0 ; iobj_0 [ 2 ] . JointInternal .
JointAxisInternal [ 2 ] = 1.0 ; break ; case 1 : iobj_0 [ 2 ] . JointInternal
. PositionNumber = 1.0 ; iobj_0 [ 2 ] . JointInternal . JointAxisInternal [ 0
] = 0.0 ; iobj_0 [ 2 ] . JointInternal . JointAxisInternal [ 1 ] = 0.0 ;
iobj_0 [ 2 ] . JointInternal . JointAxisInternal [ 2 ] = 1.0 ; break ;
default : iobj_0 [ 2 ] . JointInternal . PositionNumber = 0.0 ; iobj_0 [ 2 ]
. JointInternal . JointAxisInternal [ 0 ] = 0.0 ; iobj_0 [ 2 ] .
JointInternal . JointAxisInternal [ 1 ] = 0.0 ; iobj_0 [ 2 ] . JointInternal
. JointAxisInternal [ 2 ] = 0.0 ; break ; } iobj_0 [ 2 ] . ParentIndex = -
1.0 ; aydneur4h5 ( & iobj_0 [ 2 ] . CollisionsInternal ) ; obj -> Bodies [ 2
] = & iobj_0 [ 2 ] ; b_kstr = iobj_0 [ 3 ] . NameInternal -> size [ 0 ] *
iobj_0 [ 3 ] . NameInternal -> size [ 1 ] ; iobj_0 [ 3 ] . NameInternal ->
size [ 0 ] = 1 ; iobj_0 [ 3 ] . NameInternal -> size [ 1 ] = 10 ; ac0ugu5nlz
( iobj_0 [ 3 ] . NameInternal , b_kstr ) ; for ( b_kstr = 0 ; b_kstr < 10 ;
b_kstr ++ ) { iobj_0 [ 3 ] . NameInternal -> data [ b_kstr ] = tmp_j [ b_kstr
] ; } b_kstr = iobj_0 [ 3 ] . JointInternal . Type -> size [ 0 ] * iobj_0 [ 3
] . JointInternal . Type -> size [ 1 ] ; iobj_0 [ 3 ] . JointInternal . Type
-> size [ 0 ] = 1 ; iobj_0 [ 3 ] . JointInternal . Type -> size [ 1 ] = 5 ;
ac0ugu5nlz ( iobj_0 [ 3 ] . JointInternal . Type , b_kstr ) ; for ( b_kstr =
0 ; b_kstr < 5 ; b_kstr ++ ) { iobj_0 [ 3 ] . JointInternal . Type -> data [
b_kstr ] = tmp_p [ b_kstr ] ; } b_kstr = switch_expression -> size [ 0 ] *
switch_expression -> size [ 1 ] ; switch_expression -> size [ 0 ] = 1 ;
switch_expression -> size [ 1 ] = iobj_0 [ 3 ] . JointInternal . Type -> size
[ 1 ] ; ac0ugu5nlz ( switch_expression , b_kstr ) ; loop_ub = iobj_0 [ 3 ] .
JointInternal . Type -> size [ 1 ] - 1 ; for ( b_kstr = 0 ; b_kstr <= loop_ub
; b_kstr ++ ) { switch_expression -> data [ b_kstr ] = iobj_0 [ 3 ] .
JointInternal . Type -> data [ b_kstr ] ; } b_bool = false ; if (
switch_expression -> size [ 1 ] != 8 ) { } else { b_kstr = 1 ; do { exitg1 =
0 ; if ( b_kstr - 1 < 8 ) { if ( switch_expression -> data [ b_kstr - 1 ] !=
b [ b_kstr - 1 ] ) { exitg1 = 1 ; } else { b_kstr ++ ; } } else { b_bool =
true ; exitg1 = 1 ; } } while ( exitg1 == 0 ) ; } if ( b_bool ) { b_kstr = 0
; } else { for ( b_kstr = 0 ; b_kstr < 9 ; b_kstr ++ ) { b_p [ b_kstr ] =
tmp_i [ b_kstr ] ; } if ( switch_expression -> size [ 1 ] != 9 ) { } else {
b_kstr = 1 ; do { exitg1 = 0 ; if ( b_kstr - 1 < 9 ) { if ( switch_expression
-> data [ b_kstr - 1 ] != b_p [ b_kstr - 1 ] ) { exitg1 = 1 ; } else { b_kstr
++ ; } } else { b_bool = true ; exitg1 = 1 ; } } while ( exitg1 == 0 ) ; } if
( b_bool ) { b_kstr = 1 ; } else { b_kstr = - 1 ; } } switch ( b_kstr ) {
case 0 : iobj_0 [ 3 ] . JointInternal . PositionNumber = 1.0 ; iobj_0 [ 3 ] .
JointInternal . JointAxisInternal [ 0 ] = 0.0 ; iobj_0 [ 3 ] . JointInternal
. JointAxisInternal [ 1 ] = 0.0 ; iobj_0 [ 3 ] . JointInternal .
JointAxisInternal [ 2 ] = 1.0 ; break ; case 1 : iobj_0 [ 3 ] . JointInternal
. PositionNumber = 1.0 ; iobj_0 [ 3 ] . JointInternal . JointAxisInternal [ 0
] = 0.0 ; iobj_0 [ 3 ] . JointInternal . JointAxisInternal [ 1 ] = 0.0 ;
iobj_0 [ 3 ] . JointInternal . JointAxisInternal [ 2 ] = 1.0 ; break ;
default : iobj_0 [ 3 ] . JointInternal . PositionNumber = 0.0 ; iobj_0 [ 3 ]
. JointInternal . JointAxisInternal [ 0 ] = 0.0 ; iobj_0 [ 3 ] .
JointInternal . JointAxisInternal [ 1 ] = 0.0 ; iobj_0 [ 3 ] . JointInternal
. JointAxisInternal [ 2 ] = 0.0 ; break ; } iobj_0 [ 3 ] . ParentIndex = -
1.0 ; aydneur4h5 ( & iobj_0 [ 3 ] . CollisionsInternal ) ; obj -> Bodies [ 3
] = & iobj_0 [ 3 ] ; b_kstr = iobj_0 [ 4 ] . NameInternal -> size [ 0 ] *
iobj_0 [ 4 ] . NameInternal -> size [ 1 ] ; iobj_0 [ 4 ] . NameInternal ->
size [ 0 ] = 1 ; iobj_0 [ 4 ] . NameInternal -> size [ 1 ] = 10 ; ac0ugu5nlz
( iobj_0 [ 4 ] . NameInternal , b_kstr ) ; for ( b_kstr = 0 ; b_kstr < 10 ;
b_kstr ++ ) { iobj_0 [ 4 ] . NameInternal -> data [ b_kstr ] = tmp_f [ b_kstr
] ; } b_kstr = iobj_0 [ 4 ] . JointInternal . Type -> size [ 0 ] * iobj_0 [ 4
] . JointInternal . Type -> size [ 1 ] ; iobj_0 [ 4 ] . JointInternal . Type
-> size [ 0 ] = 1 ; iobj_0 [ 4 ] . JointInternal . Type -> size [ 1 ] = 5 ;
ac0ugu5nlz ( iobj_0 [ 4 ] . JointInternal . Type , b_kstr ) ; for ( b_kstr =
0 ; b_kstr < 5 ; b_kstr ++ ) { iobj_0 [ 4 ] . JointInternal . Type -> data [
b_kstr ] = tmp_p [ b_kstr ] ; } b_kstr = switch_expression -> size [ 0 ] *
switch_expression -> size [ 1 ] ; switch_expression -> size [ 0 ] = 1 ;
switch_expression -> size [ 1 ] = iobj_0 [ 4 ] . JointInternal . Type -> size
[ 1 ] ; ac0ugu5nlz ( switch_expression , b_kstr ) ; loop_ub = iobj_0 [ 4 ] .
JointInternal . Type -> size [ 1 ] - 1 ; for ( b_kstr = 0 ; b_kstr <= loop_ub
; b_kstr ++ ) { switch_expression -> data [ b_kstr ] = iobj_0 [ 4 ] .
JointInternal . Type -> data [ b_kstr ] ; } b_bool = false ; if (
switch_expression -> size [ 1 ] != 8 ) { } else { b_kstr = 1 ; do { exitg1 =
0 ; if ( b_kstr - 1 < 8 ) { if ( switch_expression -> data [ b_kstr - 1 ] !=
b [ b_kstr - 1 ] ) { exitg1 = 1 ; } else { b_kstr ++ ; } } else { b_bool =
true ; exitg1 = 1 ; } } while ( exitg1 == 0 ) ; } if ( b_bool ) { b_kstr = 0
; } else { for ( b_kstr = 0 ; b_kstr < 9 ; b_kstr ++ ) { b_p [ b_kstr ] =
tmp_i [ b_kstr ] ; } if ( switch_expression -> size [ 1 ] != 9 ) { } else {
b_kstr = 1 ; do { exitg1 = 0 ; if ( b_kstr - 1 < 9 ) { if ( switch_expression
-> data [ b_kstr - 1 ] != b_p [ b_kstr - 1 ] ) { exitg1 = 1 ; } else { b_kstr
++ ; } } else { b_bool = true ; exitg1 = 1 ; } } while ( exitg1 == 0 ) ; } if
( b_bool ) { b_kstr = 1 ; } else { b_kstr = - 1 ; } } b0l0vcvht3 ( &
switch_expression ) ; switch ( b_kstr ) { case 0 : iobj_0 [ 4 ] .
JointInternal . PositionNumber = 1.0 ; iobj_0 [ 4 ] . JointInternal .
JointAxisInternal [ 0 ] = 0.0 ; iobj_0 [ 4 ] . JointInternal .
JointAxisInternal [ 1 ] = 0.0 ; iobj_0 [ 4 ] . JointInternal .
JointAxisInternal [ 2 ] = 1.0 ; break ; case 1 : iobj_0 [ 4 ] . JointInternal
. PositionNumber = 1.0 ; iobj_0 [ 4 ] . JointInternal . JointAxisInternal [ 0
] = 0.0 ; iobj_0 [ 4 ] . JointInternal . JointAxisInternal [ 1 ] = 0.0 ;
iobj_0 [ 4 ] . JointInternal . JointAxisInternal [ 2 ] = 1.0 ; break ;
default : iobj_0 [ 4 ] . JointInternal . PositionNumber = 0.0 ; iobj_0 [ 4 ]
. JointInternal . JointAxisInternal [ 0 ] = 0.0 ; iobj_0 [ 4 ] .
JointInternal . JointAxisInternal [ 1 ] = 0.0 ; iobj_0 [ 4 ] . JointInternal
. JointAxisInternal [ 2 ] = 0.0 ; break ; } iobj_0 [ 4 ] . ParentIndex = -
1.0 ; aydneur4h5 ( & iobj_0 [ 4 ] . CollisionsInternal ) ; obj -> Bodies [ 4
] = & iobj_0 [ 4 ] ; } static gxcsgl11sl3 * mhyfpzbtelc0wa ( gxcsgl11sl3 *
obj ) { e2b0f4s35s * switch_expression ; gxcsgl11sl3 * b_obj ; int32_T b_kstr
; int32_T loop_ub ; char_T b_p [ 9 ] ; char_T b [ 8 ] ; boolean_T b_bool ;
static const char_T tmp [ 5 ] = { 'B' , 'o' , 'd' , 'y' , '4' } ; static
const char_T tmp_p [ 8 ] = { 'r' , 'e' , 'v' , 'o' , 'l' , 'u' , 't' , 'e' }
; static const char_T tmp_e [ 9 ] = { 'p' , 'r' , 'i' , 's' , 'm' , 'a' , 't'
, 'i' , 'c' } ; static const real_T tmp_i [ 16 ] = { 6.123233995736766E-17 ,
0.0 , - 1.0 , 0.0 , 1.0 , 9.4941075965749281E-16 , 6.123233995736766E-17 ,
0.0 , 9.4941075965749281E-16 , - 1.0 , 5.8134642394530281E-32 , 0.0 , -
1.3877787807814457E-16 , 0.038414905179222407 , - 0.050000000000000447 , 1.0
} ; static const real_T tmp_m [ 16 ] = { 1.0 , 0.0 , 0.0 , 0.0 , 0.0 , 1.0 ,
0.0 , 0.0 , 0.0 , 0.0 , 1.0 , 0.0 , 0.0 , 0.0 , 0.0 , 1.0 } ; int32_T exitg1
; b_obj = obj ; b_kstr = obj -> NameInternal -> size [ 0 ] * obj ->
NameInternal -> size [ 1 ] ; obj -> NameInternal -> size [ 0 ] = 1 ; obj ->
NameInternal -> size [ 1 ] = 5 ; ac0ugu5nlz ( obj -> NameInternal , b_kstr )
; for ( b_kstr = 0 ; b_kstr < 5 ; b_kstr ++ ) { obj -> NameInternal -> data [
b_kstr ] = tmp [ b_kstr ] ; } obj -> ParentIndex = 3.0 ; b_kstr = obj ->
JointInternal . Type -> size [ 0 ] * obj -> JointInternal . Type -> size [ 1
] ; obj -> JointInternal . Type -> size [ 0 ] = 1 ; obj -> JointInternal .
Type -> size [ 1 ] = 8 ; ac0ugu5nlz ( obj -> JointInternal . Type , b_kstr )
; for ( b_kstr = 0 ; b_kstr < 8 ; b_kstr ++ ) { obj -> JointInternal . Type
-> data [ b_kstr ] = tmp_p [ b_kstr ] ; } gunzkbl0qg ( & switch_expression ,
2 ) ; b_kstr = switch_expression -> size [ 0 ] * switch_expression -> size [
1 ] ; switch_expression -> size [ 0 ] = 1 ; switch_expression -> size [ 1 ] =
obj -> JointInternal . Type -> size [ 1 ] ; ac0ugu5nlz ( switch_expression ,
b_kstr ) ; loop_ub = obj -> JointInternal . Type -> size [ 1 ] - 1 ; for (
b_kstr = 0 ; b_kstr <= loop_ub ; b_kstr ++ ) { switch_expression -> data [
b_kstr ] = obj -> JointInternal . Type -> data [ b_kstr ] ; } for ( b_kstr =
0 ; b_kstr < 8 ; b_kstr ++ ) { b [ b_kstr ] = tmp_p [ b_kstr ] ; } b_bool =
false ; if ( switch_expression -> size [ 1 ] != 8 ) { } else { b_kstr = 1 ;
do { exitg1 = 0 ; if ( b_kstr - 1 < 8 ) { if ( switch_expression -> data [
b_kstr - 1 ] != b [ b_kstr - 1 ] ) { exitg1 = 1 ; } else { b_kstr ++ ; } }
else { b_bool = true ; exitg1 = 1 ; } } while ( exitg1 == 0 ) ; } if ( b_bool
) { b_kstr = 0 ; } else { for ( b_kstr = 0 ; b_kstr < 9 ; b_kstr ++ ) { b_p [
b_kstr ] = tmp_e [ b_kstr ] ; } if ( switch_expression -> size [ 1 ] != 9 ) {
} else { b_kstr = 1 ; do { exitg1 = 0 ; if ( b_kstr - 1 < 9 ) { if (
switch_expression -> data [ b_kstr - 1 ] != b_p [ b_kstr - 1 ] ) { exitg1 = 1
; } else { b_kstr ++ ; } } else { b_bool = true ; exitg1 = 1 ; } } while (
exitg1 == 0 ) ; } if ( b_bool ) { b_kstr = 1 ; } else { b_kstr = - 1 ; } }
b0l0vcvht3 ( & switch_expression ) ; switch ( b_kstr ) { case 0 : obj ->
JointInternal . PositionNumber = 1.0 ; obj -> JointInternal .
JointAxisInternal [ 0 ] = 0.0 ; obj -> JointInternal . JointAxisInternal [ 1
] = 0.0 ; obj -> JointInternal . JointAxisInternal [ 2 ] = 1.0 ; break ; case
1 : obj -> JointInternal . PositionNumber = 1.0 ; obj -> JointInternal .
JointAxisInternal [ 0 ] = 0.0 ; obj -> JointInternal . JointAxisInternal [ 1
] = 0.0 ; obj -> JointInternal . JointAxisInternal [ 2 ] = 1.0 ; break ;
default : obj -> JointInternal . PositionNumber = 0.0 ; obj -> JointInternal
. JointAxisInternal [ 0 ] = 0.0 ; obj -> JointInternal . JointAxisInternal [
1 ] = 0.0 ; obj -> JointInternal . JointAxisInternal [ 2 ] = 0.0 ; break ; }
for ( b_kstr = 0 ; b_kstr < 16 ; b_kstr ++ ) { obj -> JointInternal .
JointToParentTransform [ b_kstr ] = tmp_i [ b_kstr ] ; } for ( b_kstr = 0 ;
b_kstr < 16 ; b_kstr ++ ) { obj -> JointInternal . ChildToJointTransform [
b_kstr ] = tmp_m [ b_kstr ] ; } obj -> JointInternal . JointAxisInternal [ 0
] = 0.0 ; obj -> JointInternal . JointAxisInternal [ 1 ] = 0.0 ; obj ->
JointInternal . JointAxisInternal [ 2 ] = 1.0 ; aydneur4h5 ( & obj ->
CollisionsInternal ) ; return b_obj ; } static gxcsgl11sl3 * mhyfpzbtelc0waz
( gxcsgl11sl3 * obj ) { e2b0f4s35s * switch_expression ; gxcsgl11sl3 * b_obj
; int32_T b_kstr ; int32_T loop_ub ; char_T b_p [ 9 ] ; char_T b [ 8 ] ;
boolean_T b_bool ; static const char_T tmp [ 5 ] = { 'B' , 'o' , 'd' , 'y' ,
'5' } ; static const char_T tmp_p [ 8 ] = { 'r' , 'e' , 'v' , 'o' , 'l' , 'u'
, 't' , 'e' } ; static const char_T tmp_e [ 9 ] = { 'p' , 'r' , 'i' , 's' ,
'm' , 'a' , 't' , 'i' , 'c' } ; static const real_T tmp_i [ 16 ] = {
6.123233995736766E-17 , - 1.0 , - 0.0 , 0.0 , 6.123233995736766E-17 ,
3.749399456654644E-33 , 1.0 , 0.0 , - 1.0 , - 6.123233995736766E-17 ,
6.123233995736766E-17 , 0.0 , - 0.056650758675274054 , 3.4220484771503661E-16
, 0.26254402400728288 , 1.0 } ; static const real_T tmp_m [ 16 ] = { 1.0 ,
0.0 , 0.0 , 0.0 , 0.0 , 1.0 , 0.0 , 0.0 , 0.0 , 0.0 , 1.0 , 0.0 , 0.0 , 0.0 ,
0.0 , 1.0 } ; int32_T exitg1 ; b_obj = obj ; b_kstr = obj -> NameInternal ->
size [ 0 ] * obj -> NameInternal -> size [ 1 ] ; obj -> NameInternal -> size
[ 0 ] = 1 ; obj -> NameInternal -> size [ 1 ] = 5 ; ac0ugu5nlz ( obj ->
NameInternal , b_kstr ) ; for ( b_kstr = 0 ; b_kstr < 5 ; b_kstr ++ ) { obj
-> NameInternal -> data [ b_kstr ] = tmp [ b_kstr ] ; } obj -> ParentIndex =
4.0 ; b_kstr = obj -> JointInternal . Type -> size [ 0 ] * obj ->
JointInternal . Type -> size [ 1 ] ; obj -> JointInternal . Type -> size [ 0
] = 1 ; obj -> JointInternal . Type -> size [ 1 ] = 8 ; ac0ugu5nlz ( obj ->
JointInternal . Type , b_kstr ) ; for ( b_kstr = 0 ; b_kstr < 8 ; b_kstr ++ )
{ obj -> JointInternal . Type -> data [ b_kstr ] = tmp_p [ b_kstr ] ; }
gunzkbl0qg ( & switch_expression , 2 ) ; b_kstr = switch_expression -> size [
0 ] * switch_expression -> size [ 1 ] ; switch_expression -> size [ 0 ] = 1 ;
switch_expression -> size [ 1 ] = obj -> JointInternal . Type -> size [ 1 ] ;
ac0ugu5nlz ( switch_expression , b_kstr ) ; loop_ub = obj -> JointInternal .
Type -> size [ 1 ] - 1 ; for ( b_kstr = 0 ; b_kstr <= loop_ub ; b_kstr ++ ) {
switch_expression -> data [ b_kstr ] = obj -> JointInternal . Type -> data [
b_kstr ] ; } for ( b_kstr = 0 ; b_kstr < 8 ; b_kstr ++ ) { b [ b_kstr ] =
tmp_p [ b_kstr ] ; } b_bool = false ; if ( switch_expression -> size [ 1 ] !=
8 ) { } else { b_kstr = 1 ; do { exitg1 = 0 ; if ( b_kstr - 1 < 8 ) { if (
switch_expression -> data [ b_kstr - 1 ] != b [ b_kstr - 1 ] ) { exitg1 = 1 ;
} else { b_kstr ++ ; } } else { b_bool = true ; exitg1 = 1 ; } } while (
exitg1 == 0 ) ; } if ( b_bool ) { b_kstr = 0 ; } else { for ( b_kstr = 0 ;
b_kstr < 9 ; b_kstr ++ ) { b_p [ b_kstr ] = tmp_e [ b_kstr ] ; } if (
switch_expression -> size [ 1 ] != 9 ) { } else { b_kstr = 1 ; do { exitg1 =
0 ; if ( b_kstr - 1 < 9 ) { if ( switch_expression -> data [ b_kstr - 1 ] !=
b_p [ b_kstr - 1 ] ) { exitg1 = 1 ; } else { b_kstr ++ ; } } else { b_bool =
true ; exitg1 = 1 ; } } while ( exitg1 == 0 ) ; } if ( b_bool ) { b_kstr = 1
; } else { b_kstr = - 1 ; } } b0l0vcvht3 ( & switch_expression ) ; switch (
b_kstr ) { case 0 : obj -> JointInternal . PositionNumber = 1.0 ; obj ->
JointInternal . JointAxisInternal [ 0 ] = 0.0 ; obj -> JointInternal .
JointAxisInternal [ 1 ] = 0.0 ; obj -> JointInternal . JointAxisInternal [ 2
] = 1.0 ; break ; case 1 : obj -> JointInternal . PositionNumber = 1.0 ; obj
-> JointInternal . JointAxisInternal [ 0 ] = 0.0 ; obj -> JointInternal .
JointAxisInternal [ 1 ] = 0.0 ; obj -> JointInternal . JointAxisInternal [ 2
] = 1.0 ; break ; default : obj -> JointInternal . PositionNumber = 0.0 ; obj
-> JointInternal . JointAxisInternal [ 0 ] = 0.0 ; obj -> JointInternal .
JointAxisInternal [ 1 ] = 0.0 ; obj -> JointInternal . JointAxisInternal [ 2
] = 0.0 ; break ; } for ( b_kstr = 0 ; b_kstr < 16 ; b_kstr ++ ) { obj ->
JointInternal . JointToParentTransform [ b_kstr ] = tmp_i [ b_kstr ] ; } for
( b_kstr = 0 ; b_kstr < 16 ; b_kstr ++ ) { obj -> JointInternal .
ChildToJointTransform [ b_kstr ] = tmp_m [ b_kstr ] ; } obj -> JointInternal
. JointAxisInternal [ 0 ] = 0.0 ; obj -> JointInternal . JointAxisInternal [
1 ] = 0.0 ; obj -> JointInternal . JointAxisInternal [ 2 ] = 1.0 ; aydneur4h5
( & obj -> CollisionsInternal ) ; return b_obj ; } static void g1slahjfob0 (
gsvdge1jib * obj ) { e2b0f4s35s * switch_expression ; kp1en3mw3xl * obj_p ;
int32_T b_kstr ; int32_T loop_ub ; char_T b_p [ 9 ] ; char_T b [ 8 ] ;
boolean_T b_bool ; static const char_T tmp [ 5 ] = { 'B' , 'o' , 'd' , 'y' ,
'1' } ; static const char_T tmp_p [ 8 ] = { 'r' , 'e' , 'v' , 'o' , 'l' , 'u'
, 't' , 'e' } ; static const char_T tmp_e [ 9 ] = { 'p' , 'r' , 'i' , 's' ,
'm' , 'a' , 't' , 'i' , 'c' } ; static const real_T tmp_i [ 16 ] = {
6.123233995736766E-17 , 0.0 , 1.0 , 0.0 , 1.0 , 6.123233995736766E-17 , -
6.123233995736766E-17 , 0.0 , - 6.123233995736766E-17 , 1.0 ,
3.749399456654644E-33 , 0.0 , 0.0065704530241911842 , 0.04712085191226531 ,
0.019427065864845966 , 1.0 } ; static const real_T tmp_m [ 16 ] = { 1.0 , 0.0
, 0.0 , 0.0 , 0.0 , 1.0 , 0.0 , 0.0 , 0.0 , 0.0 , 1.0 , 0.0 , 0.0 , 0.0 , 0.0
, 1.0 } ; static const char_T tmp_g [ 5 ] = { 'B' , 'o' , 'd' , 'y' , '2' } ;
static const real_T tmp_j [ 16 ] = { 6.123233995736766E-17 , 0.0 , 1.0 , 0.0
, 1.0 , - 1.6081226496766366E-16 , - 6.123233995736766E-17 , 0.0 ,
1.6081226496766366E-16 , 1.0 , - 9.8469112778142665E-33 , 0.0 ,
2.7755575615628914E-17 , - 0.040001000000000037 , 0.13000000000000009 , 1.0 }
; static const char_T tmp_f [ 5 ] = { 'B' , 'o' , 'd' , 'y' , '3' } ; static
const real_T tmp_c [ 16 ] = { 6.123233995736766E-17 , 0.0 , - 1.0 , 0.0 , -
1.0 , - 1.6081226496766366E-16 , - 6.123233995736766E-17 , 0.0 , -
1.6081226496766366E-16 , 1.0 , - 9.8469112778142665E-33 , 0.0 , -
5.5511151231257827E-17 , - 0.12964538766168227 , 0.20102726089780065 , 1.0 }
; static const char_T tmp_k [ 5 ] = { 'f' , 'i' , 'x' , 'e' , 'd' } ; int32_T
exitg1 ; obj -> isInitialized = 1 ; obj_p = & obj -> TreeInternal ; obj ->
TreeInternal . NumBodies = 5.0 ; dpajaj4gpxk ( & obj -> TreeInternal , & obj
-> TreeInternal . _pobj0 [ 0 ] ) ; b_kstr = obj_p -> _pobj0 [ 5 ] .
NameInternal -> size [ 0 ] * obj_p -> _pobj0 [ 5 ] . NameInternal -> size [ 1
] ; obj_p -> _pobj0 [ 5 ] . NameInternal -> size [ 0 ] = 1 ; obj_p -> _pobj0
[ 5 ] . NameInternal -> size [ 1 ] = 5 ; ac0ugu5nlz ( obj_p -> _pobj0 [ 5 ] .
NameInternal , b_kstr ) ; for ( b_kstr = 0 ; b_kstr < 5 ; b_kstr ++ ) { obj_p
-> _pobj0 [ 5 ] . NameInternal -> data [ b_kstr ] = tmp [ b_kstr ] ; } obj_p
-> _pobj0 [ 5 ] . ParentIndex = 0.0 ; b_kstr = obj -> TreeInternal . _pobj0 [
5 ] . JointInternal . Type -> size [ 0 ] * obj -> TreeInternal . _pobj0 [ 5 ]
. JointInternal . Type -> size [ 1 ] ; obj -> TreeInternal . _pobj0 [ 5 ] .
JointInternal . Type -> size [ 0 ] = 1 ; obj -> TreeInternal . _pobj0 [ 5 ] .
JointInternal . Type -> size [ 1 ] = 8 ; ac0ugu5nlz ( obj -> TreeInternal .
_pobj0 [ 5 ] . JointInternal . Type , b_kstr ) ; for ( b_kstr = 0 ; b_kstr <
8 ; b_kstr ++ ) { obj -> TreeInternal . _pobj0 [ 5 ] . JointInternal . Type
-> data [ b_kstr ] = tmp_p [ b_kstr ] ; } gunzkbl0qg ( & switch_expression ,
2 ) ; b_kstr = switch_expression -> size [ 0 ] * switch_expression -> size [
1 ] ; switch_expression -> size [ 0 ] = 1 ; switch_expression -> size [ 1 ] =
obj -> TreeInternal . _pobj0 [ 5 ] . JointInternal . Type -> size [ 1 ] ;
ac0ugu5nlz ( switch_expression , b_kstr ) ; loop_ub = obj -> TreeInternal .
_pobj0 [ 5 ] . JointInternal . Type -> size [ 1 ] - 1 ; for ( b_kstr = 0 ;
b_kstr <= loop_ub ; b_kstr ++ ) { switch_expression -> data [ b_kstr ] = obj
-> TreeInternal . _pobj0 [ 5 ] . JointInternal . Type -> data [ b_kstr ] ; }
for ( b_kstr = 0 ; b_kstr < 8 ; b_kstr ++ ) { b [ b_kstr ] = tmp_p [ b_kstr ]
; } b_bool = false ; if ( switch_expression -> size [ 1 ] != 8 ) { } else {
b_kstr = 1 ; do { exitg1 = 0 ; if ( b_kstr - 1 < 8 ) { if ( switch_expression
-> data [ b_kstr - 1 ] != b [ b_kstr - 1 ] ) { exitg1 = 1 ; } else { b_kstr
++ ; } } else { b_bool = true ; exitg1 = 1 ; } } while ( exitg1 == 0 ) ; } if
( b_bool ) { b_kstr = 0 ; } else { for ( b_kstr = 0 ; b_kstr < 9 ; b_kstr ++
) { b_p [ b_kstr ] = tmp_e [ b_kstr ] ; } if ( switch_expression -> size [ 1
] != 9 ) { } else { b_kstr = 1 ; do { exitg1 = 0 ; if ( b_kstr - 1 < 9 ) { if
( switch_expression -> data [ b_kstr - 1 ] != b_p [ b_kstr - 1 ] ) { exitg1 =
1 ; } else { b_kstr ++ ; } } else { b_bool = true ; exitg1 = 1 ; } } while (
exitg1 == 0 ) ; } if ( b_bool ) { b_kstr = 1 ; } else { b_kstr = - 1 ; } }
switch ( b_kstr ) { case 0 : obj -> TreeInternal . _pobj0 [ 5 ] .
JointInternal . PositionNumber = 1.0 ; obj -> TreeInternal . _pobj0 [ 5 ] .
JointInternal . JointAxisInternal [ 0 ] = 0.0 ; obj -> TreeInternal . _pobj0
[ 5 ] . JointInternal . JointAxisInternal [ 1 ] = 0.0 ; obj -> TreeInternal .
_pobj0 [ 5 ] . JointInternal . JointAxisInternal [ 2 ] = 1.0 ; break ; case 1
: obj -> TreeInternal . _pobj0 [ 5 ] . JointInternal . PositionNumber = 1.0 ;
obj -> TreeInternal . _pobj0 [ 5 ] . JointInternal . JointAxisInternal [ 0 ]
= 0.0 ; obj -> TreeInternal . _pobj0 [ 5 ] . JointInternal .
JointAxisInternal [ 1 ] = 0.0 ; obj -> TreeInternal . _pobj0 [ 5 ] .
JointInternal . JointAxisInternal [ 2 ] = 1.0 ; break ; default : obj ->
TreeInternal . _pobj0 [ 5 ] . JointInternal . PositionNumber = 0.0 ; obj ->
TreeInternal . _pobj0 [ 5 ] . JointInternal . JointAxisInternal [ 0 ] = 0.0 ;
obj -> TreeInternal . _pobj0 [ 5 ] . JointInternal . JointAxisInternal [ 1 ]
= 0.0 ; obj -> TreeInternal . _pobj0 [ 5 ] . JointInternal .
JointAxisInternal [ 2 ] = 0.0 ; break ; } for ( b_kstr = 0 ; b_kstr < 16 ;
b_kstr ++ ) { obj_p -> _pobj0 [ 5 ] . JointInternal . JointToParentTransform
[ b_kstr ] = tmp_i [ b_kstr ] ; } for ( b_kstr = 0 ; b_kstr < 16 ; b_kstr ++
) { obj_p -> _pobj0 [ 5 ] . JointInternal . ChildToJointTransform [ b_kstr ]
= tmp_m [ b_kstr ] ; } obj_p -> _pobj0 [ 5 ] . JointInternal .
JointAxisInternal [ 0 ] = 0.0 ; obj_p -> _pobj0 [ 5 ] . JointInternal .
JointAxisInternal [ 1 ] = 0.0 ; obj_p -> _pobj0 [ 5 ] . JointInternal .
JointAxisInternal [ 2 ] = 1.0 ; aydneur4h5 ( & obj_p -> _pobj0 [ 5 ] .
CollisionsInternal ) ; obj -> TreeInternal . Bodies [ 0 ] = & obj_p -> _pobj0
[ 5 ] ; b_kstr = obj_p -> _pobj0 [ 6 ] . NameInternal -> size [ 0 ] * obj_p
-> _pobj0 [ 6 ] . NameInternal -> size [ 1 ] ; obj_p -> _pobj0 [ 6 ] .
NameInternal -> size [ 0 ] = 1 ; obj_p -> _pobj0 [ 6 ] . NameInternal -> size
[ 1 ] = 5 ; ac0ugu5nlz ( obj_p -> _pobj0 [ 6 ] . NameInternal , b_kstr ) ;
for ( b_kstr = 0 ; b_kstr < 5 ; b_kstr ++ ) { obj_p -> _pobj0 [ 6 ] .
NameInternal -> data [ b_kstr ] = tmp_g [ b_kstr ] ; } obj_p -> _pobj0 [ 6 ]
. ParentIndex = 1.0 ; b_kstr = obj -> TreeInternal . _pobj0 [ 6 ] .
JointInternal . Type -> size [ 0 ] * obj -> TreeInternal . _pobj0 [ 6 ] .
JointInternal . Type -> size [ 1 ] ; obj -> TreeInternal . _pobj0 [ 6 ] .
JointInternal . Type -> size [ 0 ] = 1 ; obj -> TreeInternal . _pobj0 [ 6 ] .
JointInternal . Type -> size [ 1 ] = 8 ; ac0ugu5nlz ( obj -> TreeInternal .
_pobj0 [ 6 ] . JointInternal . Type , b_kstr ) ; for ( b_kstr = 0 ; b_kstr <
8 ; b_kstr ++ ) { obj -> TreeInternal . _pobj0 [ 6 ] . JointInternal . Type
-> data [ b_kstr ] = tmp_p [ b_kstr ] ; } b_kstr = switch_expression -> size
[ 0 ] * switch_expression -> size [ 1 ] ; switch_expression -> size [ 0 ] = 1
; switch_expression -> size [ 1 ] = obj -> TreeInternal . _pobj0 [ 6 ] .
JointInternal . Type -> size [ 1 ] ; ac0ugu5nlz ( switch_expression , b_kstr
) ; loop_ub = obj -> TreeInternal . _pobj0 [ 6 ] . JointInternal . Type ->
size [ 1 ] - 1 ; for ( b_kstr = 0 ; b_kstr <= loop_ub ; b_kstr ++ ) {
switch_expression -> data [ b_kstr ] = obj -> TreeInternal . _pobj0 [ 6 ] .
JointInternal . Type -> data [ b_kstr ] ; } b_bool = false ; if (
switch_expression -> size [ 1 ] != 8 ) { } else { b_kstr = 1 ; do { exitg1 =
0 ; if ( b_kstr - 1 < 8 ) { if ( switch_expression -> data [ b_kstr - 1 ] !=
b [ b_kstr - 1 ] ) { exitg1 = 1 ; } else { b_kstr ++ ; } } else { b_bool =
true ; exitg1 = 1 ; } } while ( exitg1 == 0 ) ; } if ( b_bool ) { b_kstr = 0
; } else { for ( b_kstr = 0 ; b_kstr < 9 ; b_kstr ++ ) { b_p [ b_kstr ] =
tmp_e [ b_kstr ] ; } if ( switch_expression -> size [ 1 ] != 9 ) { } else {
b_kstr = 1 ; do { exitg1 = 0 ; if ( b_kstr - 1 < 9 ) { if ( switch_expression
-> data [ b_kstr - 1 ] != b_p [ b_kstr - 1 ] ) { exitg1 = 1 ; } else { b_kstr
++ ; } } else { b_bool = true ; exitg1 = 1 ; } } while ( exitg1 == 0 ) ; } if
( b_bool ) { b_kstr = 1 ; } else { b_kstr = - 1 ; } } switch ( b_kstr ) {
case 0 : obj -> TreeInternal . _pobj0 [ 6 ] . JointInternal . PositionNumber
= 1.0 ; obj -> TreeInternal . _pobj0 [ 6 ] . JointInternal .
JointAxisInternal [ 0 ] = 0.0 ; obj -> TreeInternal . _pobj0 [ 6 ] .
JointInternal . JointAxisInternal [ 1 ] = 0.0 ; obj -> TreeInternal . _pobj0
[ 6 ] . JointInternal . JointAxisInternal [ 2 ] = 1.0 ; break ; case 1 : obj
-> TreeInternal . _pobj0 [ 6 ] . JointInternal . PositionNumber = 1.0 ; obj
-> TreeInternal . _pobj0 [ 6 ] . JointInternal . JointAxisInternal [ 0 ] =
0.0 ; obj -> TreeInternal . _pobj0 [ 6 ] . JointInternal . JointAxisInternal
[ 1 ] = 0.0 ; obj -> TreeInternal . _pobj0 [ 6 ] . JointInternal .
JointAxisInternal [ 2 ] = 1.0 ; break ; default : obj -> TreeInternal .
_pobj0 [ 6 ] . JointInternal . PositionNumber = 0.0 ; obj -> TreeInternal .
_pobj0 [ 6 ] . JointInternal . JointAxisInternal [ 0 ] = 0.0 ; obj ->
TreeInternal . _pobj0 [ 6 ] . JointInternal . JointAxisInternal [ 1 ] = 0.0 ;
obj -> TreeInternal . _pobj0 [ 6 ] . JointInternal . JointAxisInternal [ 2 ]
= 0.0 ; break ; } for ( b_kstr = 0 ; b_kstr < 16 ; b_kstr ++ ) { obj_p ->
_pobj0 [ 6 ] . JointInternal . JointToParentTransform [ b_kstr ] = tmp_j [
b_kstr ] ; } for ( b_kstr = 0 ; b_kstr < 16 ; b_kstr ++ ) { obj_p -> _pobj0 [
6 ] . JointInternal . ChildToJointTransform [ b_kstr ] = tmp_m [ b_kstr ] ; }
obj_p -> _pobj0 [ 6 ] . JointInternal . JointAxisInternal [ 0 ] = 0.0 ; obj_p
-> _pobj0 [ 6 ] . JointInternal . JointAxisInternal [ 1 ] = 0.0 ; obj_p ->
_pobj0 [ 6 ] . JointInternal . JointAxisInternal [ 2 ] = 1.0 ; aydneur4h5 ( &
obj_p -> _pobj0 [ 6 ] . CollisionsInternal ) ; obj -> TreeInternal . Bodies [
1 ] = & obj_p -> _pobj0 [ 6 ] ; b_kstr = obj_p -> _pobj0 [ 7 ] . NameInternal
-> size [ 0 ] * obj_p -> _pobj0 [ 7 ] . NameInternal -> size [ 1 ] ; obj_p ->
_pobj0 [ 7 ] . NameInternal -> size [ 0 ] = 1 ; obj_p -> _pobj0 [ 7 ] .
NameInternal -> size [ 1 ] = 5 ; ac0ugu5nlz ( obj_p -> _pobj0 [ 7 ] .
NameInternal , b_kstr ) ; for ( b_kstr = 0 ; b_kstr < 5 ; b_kstr ++ ) { obj_p
-> _pobj0 [ 7 ] . NameInternal -> data [ b_kstr ] = tmp_f [ b_kstr ] ; }
obj_p -> _pobj0 [ 7 ] . ParentIndex = 2.0 ; b_kstr = obj -> TreeInternal .
_pobj0 [ 7 ] . JointInternal . Type -> size [ 0 ] * obj -> TreeInternal .
_pobj0 [ 7 ] . JointInternal . Type -> size [ 1 ] ; obj -> TreeInternal .
_pobj0 [ 7 ] . JointInternal . Type -> size [ 0 ] = 1 ; obj -> TreeInternal .
_pobj0 [ 7 ] . JointInternal . Type -> size [ 1 ] = 8 ; ac0ugu5nlz ( obj ->
TreeInternal . _pobj0 [ 7 ] . JointInternal . Type , b_kstr ) ; for ( b_kstr
= 0 ; b_kstr < 8 ; b_kstr ++ ) { obj -> TreeInternal . _pobj0 [ 7 ] .
JointInternal . Type -> data [ b_kstr ] = tmp_p [ b_kstr ] ; } b_kstr =
switch_expression -> size [ 0 ] * switch_expression -> size [ 1 ] ;
switch_expression -> size [ 0 ] = 1 ; switch_expression -> size [ 1 ] = obj
-> TreeInternal . _pobj0 [ 7 ] . JointInternal . Type -> size [ 1 ] ;
ac0ugu5nlz ( switch_expression , b_kstr ) ; loop_ub = obj -> TreeInternal .
_pobj0 [ 7 ] . JointInternal . Type -> size [ 1 ] - 1 ; for ( b_kstr = 0 ;
b_kstr <= loop_ub ; b_kstr ++ ) { switch_expression -> data [ b_kstr ] = obj
-> TreeInternal . _pobj0 [ 7 ] . JointInternal . Type -> data [ b_kstr ] ; }
b_bool = false ; if ( switch_expression -> size [ 1 ] != 8 ) { } else {
b_kstr = 1 ; do { exitg1 = 0 ; if ( b_kstr - 1 < 8 ) { if ( switch_expression
-> data [ b_kstr - 1 ] != b [ b_kstr - 1 ] ) { exitg1 = 1 ; } else { b_kstr
++ ; } } else { b_bool = true ; exitg1 = 1 ; } } while ( exitg1 == 0 ) ; } if
( b_bool ) { b_kstr = 0 ; } else { for ( b_kstr = 0 ; b_kstr < 9 ; b_kstr ++
) { b_p [ b_kstr ] = tmp_e [ b_kstr ] ; } if ( switch_expression -> size [ 1
] != 9 ) { } else { b_kstr = 1 ; do { exitg1 = 0 ; if ( b_kstr - 1 < 9 ) { if
( switch_expression -> data [ b_kstr - 1 ] != b_p [ b_kstr - 1 ] ) { exitg1 =
1 ; } else { b_kstr ++ ; } } else { b_bool = true ; exitg1 = 1 ; } } while (
exitg1 == 0 ) ; } if ( b_bool ) { b_kstr = 1 ; } else { b_kstr = - 1 ; } }
switch ( b_kstr ) { case 0 : obj -> TreeInternal . _pobj0 [ 7 ] .
JointInternal . PositionNumber = 1.0 ; obj -> TreeInternal . _pobj0 [ 7 ] .
JointInternal . JointAxisInternal [ 0 ] = 0.0 ; obj -> TreeInternal . _pobj0
[ 7 ] . JointInternal . JointAxisInternal [ 1 ] = 0.0 ; obj -> TreeInternal .
_pobj0 [ 7 ] . JointInternal . JointAxisInternal [ 2 ] = 1.0 ; break ; case 1
: obj -> TreeInternal . _pobj0 [ 7 ] . JointInternal . PositionNumber = 1.0 ;
obj -> TreeInternal . _pobj0 [ 7 ] . JointInternal . JointAxisInternal [ 0 ]
= 0.0 ; obj -> TreeInternal . _pobj0 [ 7 ] . JointInternal .
JointAxisInternal [ 1 ] = 0.0 ; obj -> TreeInternal . _pobj0 [ 7 ] .
JointInternal . JointAxisInternal [ 2 ] = 1.0 ; break ; default : obj ->
TreeInternal . _pobj0 [ 7 ] . JointInternal . PositionNumber = 0.0 ; obj ->
TreeInternal . _pobj0 [ 7 ] . JointInternal . JointAxisInternal [ 0 ] = 0.0 ;
obj -> TreeInternal . _pobj0 [ 7 ] . JointInternal . JointAxisInternal [ 1 ]
= 0.0 ; obj -> TreeInternal . _pobj0 [ 7 ] . JointInternal .
JointAxisInternal [ 2 ] = 0.0 ; break ; } for ( b_kstr = 0 ; b_kstr < 16 ;
b_kstr ++ ) { obj_p -> _pobj0 [ 7 ] . JointInternal . JointToParentTransform
[ b_kstr ] = tmp_c [ b_kstr ] ; } for ( b_kstr = 0 ; b_kstr < 16 ; b_kstr ++
) { obj_p -> _pobj0 [ 7 ] . JointInternal . ChildToJointTransform [ b_kstr ]
= tmp_m [ b_kstr ] ; } obj_p -> _pobj0 [ 7 ] . JointInternal .
JointAxisInternal [ 0 ] = 0.0 ; obj_p -> _pobj0 [ 7 ] . JointInternal .
JointAxisInternal [ 1 ] = 0.0 ; obj_p -> _pobj0 [ 7 ] . JointInternal .
JointAxisInternal [ 2 ] = 1.0 ; aydneur4h5 ( & obj_p -> _pobj0 [ 7 ] .
CollisionsInternal ) ; obj -> TreeInternal . Bodies [ 2 ] = & obj_p -> _pobj0
[ 7 ] ; obj -> TreeInternal . Bodies [ 3 ] = mhyfpzbtelc0wa ( & obj ->
TreeInternal . _pobj0 [ 8 ] ) ; obj -> TreeInternal . Bodies [ 4 ] =
mhyfpzbtelc0waz ( & obj -> TreeInternal . _pobj0 [ 9 ] ) ; obj ->
TreeInternal . PositionNumber = 5.0 ; b_kstr = obj_p -> Base . NameInternal
-> size [ 0 ] * obj_p -> Base . NameInternal -> size [ 1 ] ; obj_p -> Base .
NameInternal -> size [ 0 ] = 1 ; obj_p -> Base . NameInternal -> size [ 1 ] =
4 ; ac0ugu5nlz ( obj_p -> Base . NameInternal , b_kstr ) ; obj_p -> Base .
NameInternal -> data [ 0 ] = 'B' ; obj_p -> Base . NameInternal -> data [ 1 ]
= 'a' ; obj_p -> Base . NameInternal -> data [ 2 ] = 's' ; obj_p -> Base .
NameInternal -> data [ 3 ] = 'e' ; obj_p -> Base . ParentIndex = - 1.0 ;
b_kstr = obj -> TreeInternal . Base . JointInternal . Type -> size [ 0 ] *
obj -> TreeInternal . Base . JointInternal . Type -> size [ 1 ] ; obj ->
TreeInternal . Base . JointInternal . Type -> size [ 0 ] = 1 ; obj ->
TreeInternal . Base . JointInternal . Type -> size [ 1 ] = 5 ; ac0ugu5nlz (
obj -> TreeInternal . Base . JointInternal . Type , b_kstr ) ; for ( b_kstr =
0 ; b_kstr < 5 ; b_kstr ++ ) { obj -> TreeInternal . Base . JointInternal .
Type -> data [ b_kstr ] = tmp_k [ b_kstr ] ; } b_kstr = switch_expression ->
size [ 0 ] * switch_expression -> size [ 1 ] ; switch_expression -> size [ 0
] = 1 ; switch_expression -> size [ 1 ] = obj -> TreeInternal . Base .
JointInternal . Type -> size [ 1 ] ; ac0ugu5nlz ( switch_expression , b_kstr
) ; loop_ub = obj -> TreeInternal . Base . JointInternal . Type -> size [ 1 ]
- 1 ; for ( b_kstr = 0 ; b_kstr <= loop_ub ; b_kstr ++ ) { switch_expression
-> data [ b_kstr ] = obj -> TreeInternal . Base . JointInternal . Type ->
data [ b_kstr ] ; } b_bool = false ; if ( switch_expression -> size [ 1 ] !=
8 ) { } else { b_kstr = 1 ; do { exitg1 = 0 ; if ( b_kstr - 1 < 8 ) { if (
switch_expression -> data [ b_kstr - 1 ] != b [ b_kstr - 1 ] ) { exitg1 = 1 ;
} else { b_kstr ++ ; } } else { b_bool = true ; exitg1 = 1 ; } } while (
exitg1 == 0 ) ; } if ( b_bool ) { b_kstr = 0 ; } else { for ( b_kstr = 0 ;
b_kstr < 9 ; b_kstr ++ ) { b_p [ b_kstr ] = tmp_e [ b_kstr ] ; } if (
switch_expression -> size [ 1 ] != 9 ) { } else { b_kstr = 1 ; do { exitg1 =
0 ; if ( b_kstr - 1 < 9 ) { if ( switch_expression -> data [ b_kstr - 1 ] !=
b_p [ b_kstr - 1 ] ) { exitg1 = 1 ; } else { b_kstr ++ ; } } else { b_bool =
true ; exitg1 = 1 ; } } while ( exitg1 == 0 ) ; } if ( b_bool ) { b_kstr = 1
; } else { b_kstr = - 1 ; } } b0l0vcvht3 ( & switch_expression ) ; switch (
b_kstr ) { case 0 : obj -> TreeInternal . Base . JointInternal .
PositionNumber = 1.0 ; obj -> TreeInternal . Base . JointInternal .
JointAxisInternal [ 0 ] = 0.0 ; obj -> TreeInternal . Base . JointInternal .
JointAxisInternal [ 1 ] = 0.0 ; obj -> TreeInternal . Base . JointInternal .
JointAxisInternal [ 2 ] = 1.0 ; break ; case 1 : obj -> TreeInternal . Base .
JointInternal . PositionNumber = 1.0 ; obj -> TreeInternal . Base .
JointInternal . JointAxisInternal [ 0 ] = 0.0 ; obj -> TreeInternal . Base .
JointInternal . JointAxisInternal [ 1 ] = 0.0 ; obj -> TreeInternal . Base .
JointInternal . JointAxisInternal [ 2 ] = 1.0 ; break ; default : obj ->
TreeInternal . Base . JointInternal . PositionNumber = 0.0 ; obj ->
TreeInternal . Base . JointInternal . JointAxisInternal [ 0 ] = 0.0 ; obj ->
TreeInternal . Base . JointInternal . JointAxisInternal [ 1 ] = 0.0 ; obj ->
TreeInternal . Base . JointInternal . JointAxisInternal [ 2 ] = 0.0 ; break ;
} aydneur4h5 ( & obj_p -> Base . CollisionsInternal ) ; } static void
ntmkpsyod5y ( const real_T pp_breaks [ 9 ] , const real_T pp_coefs [ 96 ] ,
real_T x , real_T v [ 3 ] ) { real_T xloc ; int32_T high_i ; int32_T ic0 ;
int32_T low_i ; int32_T low_ip1 ; if ( muDoubleScalarIsNaN ( x ) ) { v [ 0 ]
= x ; v [ 1 ] = x ; v [ 2 ] = x ; } else { low_i = 0 ; low_ip1 = 1 ; high_i =
9 ; while ( high_i > low_ip1 + 1 ) { ic0 = ( ( low_i + high_i ) + 1 ) >> 1 ;
if ( x >= pp_breaks [ ic0 - 1 ] ) { low_i = ic0 - 1 ; low_ip1 = ic0 ; } else
{ high_i = ic0 ; } } low_ip1 = low_i * 3 ; xloc = x - pp_breaks [ low_i ] ; v
[ 0 ] = pp_coefs [ low_ip1 ] ; v [ 1 ] = pp_coefs [ low_ip1 + 1 ] ; v [ 2 ] =
pp_coefs [ low_ip1 + 2 ] ; for ( high_i = 0 ; high_i < 3 ; high_i ++ ) { ic0
= ( ( high_i + 1 ) * 24 + low_ip1 ) - 1 ; v [ 0 ] = xloc * v [ 0 ] + pp_coefs
[ ic0 + 1 ] ; v [ 1 ] = xloc * v [ 1 ] + pp_coefs [ ic0 + 2 ] ; v [ 2 ] =
xloc * v [ 2 ] + pp_coefs [ ic0 + 3 ] ; } } } static void jkqy2d3rp1 (
itgfp4rmev * obj , moo4o4s0qn * limits ) { e2b0f4s35s * a ; gxcsgl11sl35 *
body ; iyg0swfnbfoc * obj_p ; real_T k ; real_T pnum ; int32_T b_kstr ;
int32_T c ; int32_T i ; int32_T limits_p ; int32_T loop_ub ; char_T b [ 5 ] ;
boolean_T b_bool ; static const char_T tmp [ 5 ] = { 'f' , 'i' , 'x' , 'e' ,
'd' } ; int32_T exitg1 ; int32_T i_p ; i_p = limits -> size [ 0 ] * limits ->
size [ 1 ] ; limits -> size [ 0 ] = ( int32_T ) obj -> PositionNumber ;
limits -> size [ 1 ] = 2 ; ier0p3wwtw ( limits , i_p ) ; loop_ub = ( (
int32_T ) obj -> PositionNumber << 1 ) - 1 ; if ( loop_ub >= 0 ) { memset ( &
limits -> data [ 0 ] , 0 , ( loop_ub + 1 ) * sizeof ( real_T ) ) ; } k = 1.0
; pnum = obj -> NumBodies ; c = ( int32_T ) pnum - 1 ; if ( ( int32_T ) pnum
- 1 >= 0 ) { for ( i_p = 0 ; i_p < 5 ; i_p ++ ) { b [ i_p ] = tmp [ i_p ] ; }
} gunzkbl0qg ( & a , 2 ) ; for ( limits_p = 0 ; limits_p <= c ; limits_p ++ )
{ body = obj -> Bodies [ limits_p ] ; i_p = a -> size [ 0 ] * a -> size [ 1 ]
; a -> size [ 0 ] = 1 ; a -> size [ 1 ] = body -> JointInternal -> Type ->
size [ 1 ] ; ac0ugu5nlz ( a , i_p ) ; loop_ub = body -> JointInternal -> Type
-> size [ 1 ] - 1 ; for ( i_p = 0 ; i_p <= loop_ub ; i_p ++ ) { a -> data [
i_p ] = body -> JointInternal -> Type -> data [ i_p ] ; } b_bool = false ; if
( a -> size [ 1 ] != 5 ) { } else { b_kstr = 1 ; do { exitg1 = 0 ; if (
b_kstr - 1 < 5 ) { if ( a -> data [ b_kstr - 1 ] != b [ b_kstr - 1 ] ) {
exitg1 = 1 ; } else { b_kstr ++ ; } } else { b_bool = true ; exitg1 = 1 ; } }
while ( exitg1 == 0 ) ; } if ( ! b_bool ) { pnum = body -> JointInternal ->
PositionNumber ; if ( k > ( k + pnum ) - 1.0 ) { b_kstr = 0 ; } else { b_kstr
= ( int32_T ) k - 1 ; } obj_p = body -> JointInternal ; loop_ub = obj_p ->
PositionLimitsInternal -> size [ 0 ] ; for ( i_p = 0 ; i_p < 2 ; i_p ++ ) {
for ( i = 0 ; i < loop_ub ; i ++ ) { limits -> data [ ( b_kstr + i ) + limits
-> size [ 0 ] * i_p ] = obj_p -> PositionLimitsInternal -> data [ obj_p ->
PositionLimitsInternal -> size [ 0 ] * i_p + i ] ; } } k += pnum ; } }
b0l0vcvht3 ( & a ) ; } static void lscqsvg2j5 ( ksusmq01tx * * pEmxArray ,
int32_T numDimensions ) { ksusmq01tx * emxArray ; int32_T i ; * pEmxArray = (
ksusmq01tx * ) malloc ( sizeof ( ksusmq01tx ) ) ; emxArray = * pEmxArray ;
emxArray -> data = ( int8_T * ) NULL ; emxArray -> numDimensions =
numDimensions ; emxArray -> size = ( int32_T * ) malloc ( sizeof ( int32_T )
* numDimensions ) ; emxArray -> allocatedSize = 0 ; emxArray -> canFreeData =
true ; for ( i = 0 ; i < numDimensions ; i ++ ) { emxArray -> size [ i ] = 0
; } } static void nmpbytu0qq ( ksusmq01tx * emxArray , int32_T oldNumel ) {
int32_T i ; int32_T newNumel ; void * newData ; if ( oldNumel < 0 ) {
oldNumel = 0 ; } newNumel = 1 ; for ( i = 0 ; i < emxArray -> numDimensions ;
i ++ ) { newNumel *= emxArray -> size [ i ] ; } if ( newNumel > emxArray ->
allocatedSize ) { i = emxArray -> allocatedSize ; if ( i < 16 ) { i = 16 ; }
while ( i < newNumel ) { if ( i > 1073741823 ) { i = MAX_int32_T ; } else { i
<<= 1 ; } } newData = calloc ( ( uint32_T ) i , sizeof ( int8_T ) ) ; if (
emxArray -> data != NULL ) { memcpy ( newData , emxArray -> data , sizeof (
int8_T ) * oldNumel ) ; if ( emxArray -> canFreeData ) { free ( emxArray ->
data ) ; } } emxArray -> data = ( int8_T * ) newData ; emxArray ->
allocatedSize = i ; emxArray -> canFreeData = true ; } } static void
adwdjvxler ( ksusmq01tx * * pEmxArray ) { if ( * pEmxArray != ( ksusmq01tx *
) NULL ) { if ( ( ( * pEmxArray ) -> data != ( int8_T * ) NULL ) && ( *
pEmxArray ) -> canFreeData ) { free ( ( * pEmxArray ) -> data ) ; } free ( (
* pEmxArray ) -> size ) ; free ( * pEmxArray ) ; * pEmxArray = ( ksusmq01tx *
) NULL ; } } static void ku0om0mcw0 ( fgmfslti0b * * pEmxArray , int32_T
numDimensions ) { fgmfslti0b * emxArray ; int32_T i ; * pEmxArray = (
fgmfslti0b * ) malloc ( sizeof ( fgmfslti0b ) ) ; emxArray = * pEmxArray ;
emxArray -> data = ( csbe03lymu * ) NULL ; emxArray -> numDimensions =
numDimensions ; emxArray -> size = ( int32_T * ) malloc ( sizeof ( int32_T )
* numDimensions ) ; emxArray -> allocatedSize = 0 ; emxArray -> canFreeData =
true ; for ( i = 0 ; i < numDimensions ; i ++ ) { emxArray -> size [ i ] = 0
; } } static void pvxko1qdkz0yx ( boolean_T in1 [ 5 ] , const real_T in2 [ 5
] , const moo4o4s0qn * in3 ) { int32_T i ; int32_T stride_0_0 ; stride_0_0 =
( in3 -> size [ 0 ] != 1 ) ; for ( i = 0 ; i < 5 ; i ++ ) { in1 [ i ] = ( in2
[ i ] <= in3 -> data [ i * stride_0_0 + in3 -> size [ 0 ] ] +
4.4408920985006262E-16 ) ; } } static void pvxko1qdkz0y ( boolean_T in1 [ 5 ]
, const real_T in2 [ 5 ] , const moo4o4s0qn * in3 ) { int32_T i ; int32_T
stride_0_0 ; stride_0_0 = ( in3 -> size [ 0 ] != 1 ) ; for ( i = 0 ; i < 5 ;
i ++ ) { in1 [ i ] = ( in2 [ i ] >= in3 -> data [ i * stride_0_0 ] -
4.4408920985006262E-16 ) ; } } static void aeyt1tjqck ( const boolean_T x [ 5
] , int32_T i_data [ ] , int32_T * i_size ) { int32_T b_ii ; int32_T idx ;
boolean_T exitg1 ; idx = 0 ; b_ii = 1 ; exitg1 = false ; while ( ( ! exitg1 )
&& ( b_ii - 1 < 5 ) ) { if ( x [ b_ii - 1 ] ) { idx ++ ; i_data [ idx - 1 ] =
b_ii ; if ( idx >= 5 ) { exitg1 = true ; } else { b_ii ++ ; } } else { b_ii
++ ; } } if ( idx < 1 ) { idx = 0 ; } * i_size = idx ; } static void
or5i2fegiq ( real_T * tstart_tv_sec , real_T * tstart_tv_nsec ) {
coderTimespec b_timespec ; if ( ! rtDW . mkp2eepxcj ) { rtDW . mkp2eepxcj =
true ; coderInitTimeFunctions ( & rtDW . ndveltha3i ) ; }
coderTimeClockGettimeMonotonic ( & b_timespec , rtDW . ndveltha3i ) ; *
tstart_tv_sec = b_timespec . tv_sec ; * tstart_tv_nsec = b_timespec . tv_nsec
; } static void l32nija4f2 ( itgfp4rmev * obj , gxcsgl11sl35 * body ,
moo4o4s0qn * indices ) { real_T i ; int32_T i_p ; int32_T loop_ub ; i_p =
indices -> size [ 0 ] * indices -> size [ 1 ] ; indices -> size [ 0 ] = 1 ;
indices -> size [ 1 ] = ( int32_T ) ( obj -> NumBodies + 1.0 ) ; ier0p3wwtw (
indices , i_p ) ; loop_ub = ( int32_T ) ( obj -> NumBodies + 1.0 ) - 1 ; if (
loop_ub >= 0 ) { memset ( & indices -> data [ 0 ] , 0 , ( loop_ub + 1 ) *
sizeof ( real_T ) ) ; } i = 2.0 ; indices -> data [ 0 ] = body -> Index ;
while ( body -> ParentIndex > 0.0 ) { body = obj -> Bodies [ ( int32_T ) body
-> ParentIndex - 1 ] ; indices -> data [ ( int32_T ) i - 1 ] = body -> Index
; i ++ ; } if ( body -> Index > 0.0 ) { indices -> data [ ( int32_T ) i - 1 ]
= body -> ParentIndex ; i ++ ; } loop_ub = ( int32_T ) ( i - 1.0 ) ; for (
i_p = 0 ; i_p < loop_ub ; i_p ++ ) { } i_p = indices -> size [ 0 ] * indices
-> size [ 1 ] ; indices -> size [ 0 ] = 1 ; indices -> size [ 1 ] = ( int32_T
) ( i - 1.0 ) ; ier0p3wwtw ( indices , i_p ) ; } static void lkcdsp2izk (
itgfp4rmev * obj , gxcsgl11sl35 * body1 , gxcsgl11sl35 * body2 , moo4o4s0qn *
indices ) { moo4o4s0qn * ancestorIndices1 ; moo4o4s0qn * ancestorIndices2 ;
int32_T b_i ; int32_T d ; int32_T h ; int32_T j ; int32_T minPathLength ;
int32_T tmp ; boolean_T exitg1 ; cy4r1g1cm1 ( & ancestorIndices1 , 2 ) ;
cy4r1g1cm1 ( & ancestorIndices2 , 2 ) ; l32nija4f2 ( obj , body1 ,
ancestorIndices1 ) ; l32nija4f2 ( obj , body2 , ancestorIndices2 ) ;
minPathLength = ( int32_T ) muDoubleScalarMin ( ancestorIndices1 -> size [ 1
] , ancestorIndices2 -> size [ 1 ] ) ; b_i = 0 ; exitg1 = false ; while ( ( !
exitg1 ) && ( b_i <= minPathLength - 2 ) ) { if ( ancestorIndices1 -> data [
( ancestorIndices1 -> size [ 1 ] - b_i ) - 2 ] != ancestorIndices2 -> data [
( ancestorIndices2 -> size [ 1 ] - b_i ) - 2 ] ) { minPathLength = b_i + 1 ;
exitg1 = true ; } else { b_i ++ ; } } d = ancestorIndices1 -> size [ 1 ] -
minPathLength ; if ( d < 1 ) { b_i = - 1 ; } else { b_i = d - 1 ; } d =
ancestorIndices2 -> size [ 1 ] - minPathLength ; if ( d < 1 ) { j = 0 ; h = 1
; d = - 1 ; } else { j = d - 1 ; h = - 1 ; d = 0 ; } tmp = indices -> size [
0 ] * indices -> size [ 1 ] ; indices -> size [ 0 ] = 1 ; indices -> size [ 1
] = ( div_s32 ( d - j , h ) + b_i ) + 3 ; ier0p3wwtw ( indices , tmp ) ; if (
b_i >= 0 ) { memcpy ( & indices -> data [ 0 ] , & ancestorIndices1 -> data [
0 ] , ( b_i + 1 ) * sizeof ( real_T ) ) ; } indices -> data [ b_i + 1 ] =
ancestorIndices1 -> data [ ancestorIndices1 -> size [ 1 ] - minPathLength ] ;
minPathLength = div_s32 ( d - j , h ) ; njzmd0hlqd ( & ancestorIndices1 ) ;
for ( d = 0 ; d <= minPathLength ; d ++ ) { indices -> data [ ( d + b_i ) + 2
] = ancestorIndices2 -> data [ h * d + j ] ; } njzmd0hlqd ( &
ancestorIndices2 ) ; } static void ocuijkr1g1jm ( const iyg0swfnbfoc * obj ,
real_T ax [ 3 ] ) { int32_T b_kstr ; char_T b_p [ 9 ] ; char_T b [ 8 ] ;
boolean_T b_bool ; static const char_T tmp [ 8 ] = { 'r' , 'e' , 'v' , 'o' ,
'l' , 'u' , 't' , 'e' } ; static const char_T tmp_p [ 9 ] = { 'p' , 'r' , 'i'
, 's' , 'm' , 'a' , 't' , 'i' , 'c' } ; int32_T exitg1 ; boolean_T guard1 =
false ; for ( b_kstr = 0 ; b_kstr < 8 ; b_kstr ++ ) { b [ b_kstr ] = tmp [
b_kstr ] ; } b_bool = false ; if ( obj -> Type -> size [ 1 ] != 8 ) { } else
{ b_kstr = 1 ; do { exitg1 = 0 ; if ( b_kstr - 1 < 8 ) { if ( obj -> Type ->
data [ b_kstr - 1 ] != b [ b_kstr - 1 ] ) { exitg1 = 1 ; } else { b_kstr ++ ;
} } else { b_bool = true ; exitg1 = 1 ; } } while ( exitg1 == 0 ) ; } guard1
= false ; if ( b_bool ) { guard1 = true ; } else { for ( b_kstr = 0 ; b_kstr
< 9 ; b_kstr ++ ) { b_p [ b_kstr ] = tmp_p [ b_kstr ] ; } if ( obj -> Type ->
size [ 1 ] != 9 ) { } else { b_kstr = 1 ; do { exitg1 = 0 ; if ( b_kstr - 1 <
9 ) { if ( obj -> Type -> data [ b_kstr - 1 ] != b_p [ b_kstr - 1 ] ) {
exitg1 = 1 ; } else { b_kstr ++ ; } } else { b_bool = true ; exitg1 = 1 ; } }
while ( exitg1 == 0 ) ; } if ( b_bool ) { guard1 = true ; } else { ax [ 0 ] =
( rtNaN ) ; ax [ 1 ] = ( rtNaN ) ; ax [ 2 ] = ( rtNaN ) ; } } if ( guard1 ) {
ax [ 0 ] = obj -> JointAxisInternal [ 0 ] ; ax [ 1 ] = obj ->
JointAxisInternal [ 1 ] ; ax [ 2 ] = obj -> JointAxisInternal [ 2 ] ; } }
static void gxlkpqr51s ( real_T varargin_1 , real_T varargin_2 , real_T
varargin_3 , real_T varargin_4 , real_T varargin_5 , real_T varargin_6 ,
real_T varargin_7 , real_T varargin_8 , real_T varargin_9 , real_T y [ 9 ] )
{ y [ 0 ] = varargin_1 ; y [ 1 ] = varargin_2 ; y [ 2 ] = varargin_3 ; y [ 3
] = varargin_4 ; y [ 4 ] = varargin_5 ; y [ 5 ] = varargin_6 ; y [ 6 ] =
varargin_7 ; y [ 7 ] = varargin_8 ; y [ 8 ] = varargin_9 ; } static void
knqlderc2u ( const real_T A [ 36 ] , const moo4o4s0qn * B_p , moo4o4s0qn * C
) { real_T s ; int32_T b_i ; int32_T b_j ; int32_T b_k ; int32_T boffset ;
int32_T coffset ; int32_T n ; n = B_p -> size [ 1 ] - 1 ; b_j = C -> size [ 0
] * C -> size [ 1 ] ; C -> size [ 0 ] = 6 ; C -> size [ 1 ] = B_p -> size [ 1
] ; ier0p3wwtw ( C , b_j ) ; for ( b_j = 0 ; b_j <= n ; b_j ++ ) { coffset =
b_j * 6 - 1 ; boffset = b_j * 6 - 1 ; for ( b_i = 0 ; b_i < 6 ; b_i ++ ) { s
= 0.0 ; for ( b_k = 0 ; b_k < 6 ; b_k ++ ) { s += A [ b_k * 6 + b_i ] * B_p
-> data [ ( boffset + b_k ) + 1 ] ; } C -> data [ ( coffset + b_i ) + 1 ] = s
; } } } static void kyxgrilagz ( itgfp4rmev * obj , const real_T qv [ 5 ] ,
const e2b0f4s35s * body1Name , real_T T_data [ ] , int32_T T_size [ 2 ] ,
moo4o4s0qn * Jac ) { e2b0f4s35s * body2Name ; gxcsgl11sl35 * body1 ;
gxcsgl11sl35 * body2 ; iyg0swfnbfoc * joint ; moo4o4s0qn * b ; moo4o4s0qn *
kinematicPathIndices ; moo4o4s0qn * tmp ; real_T Tj_e [ 36 ] ; real_T T1 [ 16
] ; real_T T1j [ 16 ] ; real_T Tc2p [ 16 ] ; real_T Tj [ 16 ] ; real_T Tj_p [
16 ] ; real_T b_e [ 16 ] ; real_T R [ 9 ] ; real_T tempR [ 9 ] ; real_T
result_data [ 4 ] ; real_T v [ 3 ] ; real_T axang_idx_2 ; real_T bid1 ;
real_T bid2 ; real_T qidx_idx_1 ; int32_T Jac_p ; int32_T c ; int32_T f ;
int32_T g ; int32_T i ; int32_T loop_ub ; char_T b_i [ 8 ] ; char_T b_p [ 5 ]
; boolean_T b_bool ; boolean_T nextBodyIsParent ; static const char_T tmp_p [
5 ] = { 'f' , 'i' , 'x' , 'e' , 'd' } ; static const char_T tmp_e [ 8 ] = {
'r' , 'e' , 'v' , 'o' , 'l' , 'u' , 't' , 'e' } ; moo4o4s0qn * Jac_e ;
int32_T exitg1 ; gunzkbl0qg ( & body2Name , 2 ) ; i = body2Name -> size [ 0 ]
* body2Name -> size [ 1 ] ; body2Name -> size [ 0 ] = 1 ; body2Name -> size [
1 ] = obj -> Base . NameInternal -> size [ 1 ] ; ac0ugu5nlz ( body2Name , i )
; loop_ub = obj -> Base . NameInternal -> size [ 1 ] - 1 ; for ( i = 0 ; i <=
loop_ub ; i ++ ) { body2Name -> data [ i ] = obj -> Base . NameInternal ->
data [ i ] ; } bid1 = lgt1s4cluf ( obj , body1Name ) ; bid2 = lgt1s4cluf (
obj , body2Name ) ; if ( bid1 == 0.0 ) { body1 = & obj -> Base ; } else {
body1 = obj -> Bodies [ ( int32_T ) bid1 - 1 ] ; } if ( bid2 == 0.0 ) { body2
= & obj -> Base ; } else { body2 = obj -> Bodies [ ( int32_T ) bid2 - 1 ] ; }
cy4r1g1cm1 ( & kinematicPathIndices , 2 ) ; lkcdsp2izk ( obj , body1 , body2
, kinematicPathIndices ) ; memset ( & T1 [ 0 ] , 0 , sizeof ( real_T ) << 4U
) ; T1 [ 0 ] = 1.0 ; T1 [ 5 ] = 1.0 ; T1 [ 10 ] = 1.0 ; T1 [ 15 ] = 1.0 ; i =
Jac -> size [ 0 ] * Jac -> size [ 1 ] ; Jac -> size [ 0 ] = 6 ; Jac -> size [
1 ] = ( int32_T ) obj -> PositionNumber ; ier0p3wwtw ( Jac , i ) ; loop_ub =
6 * ( int32_T ) obj -> PositionNumber - 1 ; if ( loop_ub >= 0 ) { memset ( &
Jac -> data [ 0 ] , 0 , ( loop_ub + 1 ) * sizeof ( real_T ) ) ; } c =
kinematicPathIndices -> size [ 1 ] - 2 ; if ( kinematicPathIndices -> size [
1 ] - 2 >= 0 ) { for ( i = 0 ; i < 5 ; i ++ ) { b_p [ i ] = tmp_p [ i ] ; } }
cy4r1g1cm1 ( & b , 2 ) ; cy4r1g1cm1 ( & tmp , 2 ) ; for ( Jac_p = 0 ; Jac_p
<= c ; Jac_p ++ ) { if ( kinematicPathIndices -> data [ Jac_p ] != 0.0 ) {
body1 = obj -> Bodies [ ( int32_T ) kinematicPathIndices -> data [ Jac_p ] -
1 ] ; } else { body1 = & obj -> Base ; } if ( kinematicPathIndices -> data [
Jac_p + 1 ] != 0.0 ) { body2 = obj -> Bodies [ ( int32_T )
kinematicPathIndices -> data [ Jac_p + 1 ] - 1 ] ; } else { body2 = & obj ->
Base ; } nextBodyIsParent = ( body2 -> Index == body1 -> ParentIndex ) ; if (
nextBodyIsParent ) { body2 = body1 ; bid1 = 1.0 ; } else { bid1 = - 1.0 ; }
joint = body2 -> JointInternal ; i = body2Name -> size [ 0 ] * body2Name ->
size [ 1 ] ; body2Name -> size [ 0 ] = 1 ; body2Name -> size [ 1 ] = joint ->
Type -> size [ 1 ] ; ac0ugu5nlz ( body2Name , i ) ; loop_ub = joint -> Type
-> size [ 1 ] - 1 ; for ( i = 0 ; i <= loop_ub ; i ++ ) { body2Name -> data [
i ] = joint -> Type -> data [ i ] ; } b_bool = false ; if ( body2Name -> size
[ 1 ] != 5 ) { } else { i = 1 ; do { exitg1 = 0 ; if ( i - 1 < 5 ) { if (
body2Name -> data [ i - 1 ] != b_p [ i - 1 ] ) { exitg1 = 1 ; } else { i ++ ;
} } else { b_bool = true ; exitg1 = 1 ; } } while ( exitg1 == 0 ) ; } if (
b_bool ) { for ( i = 0 ; i < 16 ; i ++ ) { Tj [ i ] = joint ->
JointToParentTransform [ i ] ; } i = body2Name -> size [ 0 ] * body2Name ->
size [ 1 ] ; body2Name -> size [ 0 ] = 1 ; body2Name -> size [ 1 ] = joint ->
Type -> size [ 1 ] ; ac0ugu5nlz ( body2Name , i ) ; loop_ub = joint -> Type
-> size [ 1 ] - 1 ; for ( i = 0 ; i <= loop_ub ; i ++ ) { body2Name -> data [
i ] = joint -> Type -> data [ i ] ; } b_bool = false ; if ( body2Name -> size
[ 1 ] != 5 ) { } else { i = 1 ; do { exitg1 = 0 ; if ( i - 1 < 5 ) { if (
body2Name -> data [ i - 1 ] != b_p [ i - 1 ] ) { exitg1 = 1 ; } else { i ++ ;
} } else { b_bool = true ; exitg1 = 1 ; } } while ( exitg1 == 0 ) ; } if (
b_bool ) { bid2 = 0.0 ; } else { for ( i = 0 ; i < 8 ; i ++ ) { b_i [ i ] =
tmp_e [ i ] ; } if ( body2Name -> size [ 1 ] != 8 ) { } else { i = 1 ; do {
exitg1 = 0 ; if ( i - 1 < 8 ) { if ( body2Name -> data [ i - 1 ] != b_i [ i -
1 ] ) { exitg1 = 1 ; } else { i ++ ; } } else { b_bool = true ; exitg1 = 1 ;
} } while ( exitg1 == 0 ) ; } if ( b_bool ) { bid2 = 1.0 ; } else { bid2 = -
1.0 ; } } switch ( ( int32_T ) bid2 ) { case 0 : memset ( & T1j [ 0 ] , 0 ,
sizeof ( real_T ) << 4U ) ; T1j [ 0 ] = 1.0 ; T1j [ 5 ] = 1.0 ; T1j [ 10 ] =
1.0 ; T1j [ 15 ] = 1.0 ; break ; case 1 : ocuijkr1g1jm ( joint , v ) ; bid1 =
v [ 0 ] ; qidx_idx_1 = v [ 1 ] ; axang_idx_2 = v [ 2 ] ; bid2 = 1.0 /
muDoubleScalarSqrt ( ( bid1 * bid1 + qidx_idx_1 * qidx_idx_1 ) + axang_idx_2
* axang_idx_2 ) ; v [ 0 ] = bid1 * bid2 ; v [ 1 ] = qidx_idx_1 * bid2 ; v [ 2
] = axang_idx_2 * bid2 ; gxlkpqr51s ( v [ 0 ] * v [ 0 ] * 0.0 + 1.0 , v [ 0 ]
* v [ 1 ] * 0.0 - v [ 2 ] * 0.0 , v [ 0 ] * v [ 2 ] * 0.0 + v [ 1 ] * 0.0 , v
[ 0 ] * v [ 1 ] * 0.0 + v [ 2 ] * 0.0 , v [ 1 ] * v [ 1 ] * 0.0 + 1.0 , v [ 1
] * v [ 2 ] * 0.0 - v [ 0 ] * 0.0 , v [ 0 ] * v [ 2 ] * 0.0 - v [ 1 ] * 0.0 ,
v [ 1 ] * v [ 2 ] * 0.0 + v [ 0 ] * 0.0 , v [ 2 ] * v [ 2 ] * 0.0 + 1.0 ,
tempR ) ; for ( g = 0 ; g < 3 ; g ++ ) { R [ g ] = tempR [ g * 3 ] ; R [ g +
3 ] = tempR [ g * 3 + 1 ] ; R [ g + 6 ] = tempR [ g * 3 + 2 ] ; } memset ( &
T1j [ 0 ] , 0 , sizeof ( real_T ) << 4U ) ; for ( i = 0 ; i < 3 ; i ++ ) {
T1j [ i << 2 ] = R [ 3 * i ] ; T1j [ ( i << 2 ) + 1 ] = R [ 3 * i + 1 ] ; T1j
[ ( i << 2 ) + 2 ] = R [ 3 * i + 2 ] ; } T1j [ 15 ] = 1.0 ; break ; default :
ocuijkr1g1jm ( joint , v ) ; memset ( & tempR [ 0 ] , 0 , 9U * sizeof (
real_T ) ) ; tempR [ 0 ] = 1.0 ; tempR [ 4 ] = 1.0 ; tempR [ 8 ] = 1.0 ; for
( i = 0 ; i < 3 ; i ++ ) { T1j [ i << 2 ] = tempR [ 3 * i ] ; T1j [ ( i << 2
) + 1 ] = tempR [ 3 * i + 1 ] ; T1j [ ( i << 2 ) + 2 ] = tempR [ 3 * i + 2 ]
; T1j [ i + 12 ] = v [ i ] * 0.0 ; } T1j [ 3 ] = 0.0 ; T1j [ 7 ] = 0.0 ; T1j
[ 11 ] = 0.0 ; T1j [ 15 ] = 1.0 ; break ; } for ( i = 0 ; i < 16 ; i ++ ) {
b_e [ i ] = joint -> ChildToJointTransform [ i ] ; } for ( i = 0 ; i < 4 ; i
++ ) { for ( f = 0 ; f < 4 ; f ++ ) { Tj_p [ i + ( f << 2 ) ] = 0.0 ; Tj_p [
i + ( f << 2 ) ] += T1j [ f << 2 ] * Tj [ i ] ; Tj_p [ i + ( f << 2 ) ] +=
T1j [ ( f << 2 ) + 1 ] * Tj [ i + 4 ] ; Tj_p [ i + ( f << 2 ) ] += T1j [ ( f
<< 2 ) + 2 ] * Tj [ i + 8 ] ; Tj_p [ i + ( f << 2 ) ] += T1j [ ( f << 2 ) + 3
] * Tj [ i + 12 ] ; } for ( f = 0 ; f < 4 ; f ++ ) { Tc2p [ i + ( f << 2 ) ]
= 0.0 ; Tc2p [ i + ( f << 2 ) ] += b_e [ f << 2 ] * Tj_p [ i ] ; Tc2p [ i + (
f << 2 ) ] += b_e [ ( f << 2 ) + 1 ] * Tj_p [ i + 4 ] ; Tc2p [ i + ( f << 2 )
] += b_e [ ( f << 2 ) + 2 ] * Tj_p [ i + 8 ] ; Tc2p [ i + ( f << 2 ) ] += b_e
[ ( f << 2 ) + 3 ] * Tj_p [ i + 12 ] ; } } } else { i = ( int32_T ) body2 ->
Index ; bid2 = obj -> PositionDoFMap [ i - 1 ] ; qidx_idx_1 = obj ->
PositionDoFMap [ i + 4 ] ; if ( bid2 > qidx_idx_1 ) { g = 0 ; f = 0 ; } else
{ g = ( int32_T ) bid2 - 1 ; f = ( int32_T ) qidx_idx_1 ; } for ( i = 0 ; i <
16 ; i ++ ) { Tj [ i ] = joint -> JointToParentTransform [ i ] ; } i =
body2Name -> size [ 0 ] * body2Name -> size [ 1 ] ; body2Name -> size [ 0 ] =
1 ; body2Name -> size [ 1 ] = joint -> Type -> size [ 1 ] ; ac0ugu5nlz (
body2Name , i ) ; loop_ub = joint -> Type -> size [ 1 ] - 1 ; for ( i = 0 ; i
<= loop_ub ; i ++ ) { body2Name -> data [ i ] = joint -> Type -> data [ i ] ;
} if ( body2Name -> size [ 1 ] != 5 ) { } else { i = 1 ; do { exitg1 = 0 ; if
( i - 1 < 5 ) { if ( body2Name -> data [ i - 1 ] != b_p [ i - 1 ] ) { exitg1
= 1 ; } else { i ++ ; } } else { b_bool = true ; exitg1 = 1 ; } } while (
exitg1 == 0 ) ; } if ( b_bool ) { bid2 = 0.0 ; } else { for ( i = 0 ; i < 8 ;
i ++ ) { b_i [ i ] = tmp_e [ i ] ; } if ( body2Name -> size [ 1 ] != 8 ) { }
else { i = 1 ; do { exitg1 = 0 ; if ( i - 1 < 8 ) { if ( body2Name -> data [
i - 1 ] != b_i [ i - 1 ] ) { exitg1 = 1 ; } else { i ++ ; } } else { b_bool =
true ; exitg1 = 1 ; } } while ( exitg1 == 0 ) ; } if ( b_bool ) { bid2 = 1.0
; } else { bid2 = - 1.0 ; } } switch ( ( int32_T ) bid2 ) { case 0 : memset (
& T1j [ 0 ] , 0 , sizeof ( real_T ) << 4U ) ; T1j [ 0 ] = 1.0 ; T1j [ 5 ] =
1.0 ; T1j [ 10 ] = 1.0 ; T1j [ 15 ] = 1.0 ; break ; case 1 : ocuijkr1g1jm (
joint , v ) ; result_data [ 0 ] = v [ 0 ] ; result_data [ 1 ] = v [ 1 ] ;
result_data [ 2 ] = v [ 2 ] ; if ( ( f - g != 0 ) - 1 >= 0 ) { result_data [
3 ] = qv [ g ] ; } bid2 = result_data [ 0 ] ; v [ 0 ] = bid2 * bid2 ; bid2 =
result_data [ 1 ] ; v [ 1 ] = bid2 * bid2 ; bid2 = result_data [ 2 ] ; bid2 =
1.0 / muDoubleScalarSqrt ( ( v [ 0 ] + v [ 1 ] ) + bid2 * bid2 ) ; v [ 0 ] =
result_data [ 0 ] * bid2 ; v [ 1 ] = result_data [ 1 ] * bid2 ; v [ 2 ] =
result_data [ 2 ] * bid2 ; qidx_idx_1 = result_data [ 3 ] ; bid2 =
muDoubleScalarCos ( qidx_idx_1 ) ; qidx_idx_1 = muDoubleScalarSin (
qidx_idx_1 ) ; gxlkpqr51s ( v [ 0 ] * v [ 0 ] * ( 1.0 - bid2 ) + bid2 , v [ 0
] * v [ 1 ] * ( 1.0 - bid2 ) - v [ 2 ] * qidx_idx_1 , v [ 0 ] * v [ 2 ] * (
1.0 - bid2 ) + v [ 1 ] * qidx_idx_1 , v [ 0 ] * v [ 1 ] * ( 1.0 - bid2 ) + v
[ 2 ] * qidx_idx_1 , v [ 1 ] * v [ 1 ] * ( 1.0 - bid2 ) + bid2 , v [ 1 ] * v
[ 2 ] * ( 1.0 - bid2 ) - v [ 0 ] * qidx_idx_1 , v [ 0 ] * v [ 2 ] * ( 1.0 -
bid2 ) - v [ 1 ] * qidx_idx_1 , v [ 1 ] * v [ 2 ] * ( 1.0 - bid2 ) + v [ 0 ]
* qidx_idx_1 , v [ 2 ] * v [ 2 ] * ( 1.0 - bid2 ) + bid2 , tempR ) ; for ( g
= 0 ; g < 3 ; g ++ ) { R [ g ] = tempR [ g * 3 ] ; R [ g + 3 ] = tempR [ g *
3 + 1 ] ; R [ g + 6 ] = tempR [ g * 3 + 2 ] ; } memset ( & T1j [ 0 ] , 0 ,
sizeof ( real_T ) << 4U ) ; for ( i = 0 ; i < 3 ; i ++ ) { T1j [ i << 2 ] = R
[ 3 * i ] ; T1j [ ( i << 2 ) + 1 ] = R [ 3 * i + 1 ] ; T1j [ ( i << 2 ) + 2 ]
= R [ 3 * i + 2 ] ; } T1j [ 15 ] = 1.0 ; break ; default : ocuijkr1g1jm (
joint , v ) ; memset ( & tempR [ 0 ] , 0 , 9U * sizeof ( real_T ) ) ; tempR [
0 ] = 1.0 ; tempR [ 4 ] = 1.0 ; tempR [ 8 ] = 1.0 ; bid2 = qv [ g ] ; for ( i
= 0 ; i < 3 ; i ++ ) { T1j [ i << 2 ] = tempR [ 3 * i ] ; T1j [ ( i << 2 ) +
1 ] = tempR [ 3 * i + 1 ] ; T1j [ ( i << 2 ) + 2 ] = tempR [ 3 * i + 2 ] ;
T1j [ i + 12 ] = v [ i ] * bid2 ; } T1j [ 3 ] = 0.0 ; T1j [ 7 ] = 0.0 ; T1j [
11 ] = 0.0 ; T1j [ 15 ] = 1.0 ; break ; } for ( i = 0 ; i < 16 ; i ++ ) { b_e
[ i ] = joint -> ChildToJointTransform [ i ] ; } for ( i = 0 ; i < 4 ; i ++ )
{ for ( f = 0 ; f < 4 ; f ++ ) { Tj_p [ i + ( f << 2 ) ] = 0.0 ; Tj_p [ i + (
f << 2 ) ] += T1j [ f << 2 ] * Tj [ i ] ; Tj_p [ i + ( f << 2 ) ] += T1j [ (
f << 2 ) + 1 ] * Tj [ i + 4 ] ; Tj_p [ i + ( f << 2 ) ] += T1j [ ( f << 2 ) +
2 ] * Tj [ i + 8 ] ; Tj_p [ i + ( f << 2 ) ] += T1j [ ( f << 2 ) + 3 ] * Tj [
i + 12 ] ; } for ( f = 0 ; f < 4 ; f ++ ) { Tc2p [ i + ( f << 2 ) ] = 0.0 ;
Tc2p [ i + ( f << 2 ) ] += b_e [ f << 2 ] * Tj_p [ i ] ; Tc2p [ i + ( f << 2
) ] += b_e [ ( f << 2 ) + 1 ] * Tj_p [ i + 4 ] ; Tc2p [ i + ( f << 2 ) ] +=
b_e [ ( f << 2 ) + 2 ] * Tj_p [ i + 8 ] ; Tc2p [ i + ( f << 2 ) ] += b_e [ (
f << 2 ) + 3 ] * Tj_p [ i + 12 ] ; } } i = ( int32_T ) body2 -> Index ; bid2
= obj -> VelocityDoFMap [ i - 1 ] ; qidx_idx_1 = obj -> VelocityDoFMap [ i +
4 ] ; if ( nextBodyIsParent ) { for ( i = 0 ; i < 16 ; i ++ ) { Tj [ i ] =
joint -> ChildToJointTransform [ i ] ; } } else { for ( i = 0 ; i < 16 ; i ++
) { T1j [ i ] = joint -> JointToParentTransform [ i ] ; } for ( i = 0 ; i < 3
; i ++ ) { R [ 3 * i ] = T1j [ i ] ; R [ 3 * i + 1 ] = T1j [ i + 4 ] ; R [ 3
* i + 2 ] = T1j [ i + 8 ] ; } for ( i = 0 ; i < 9 ; i ++ ) { tempR [ i ] = -
R [ i ] ; } for ( i = 0 ; i < 3 ; i ++ ) { Tj [ i << 2 ] = R [ 3 * i ] ; Tj [
( i << 2 ) + 1 ] = R [ 3 * i + 1 ] ; Tj [ ( i << 2 ) + 2 ] = R [ 3 * i + 2 ]
; Tj [ i + 12 ] = ( tempR [ i + 3 ] * T1j [ 13 ] + tempR [ i ] * T1j [ 12 ] )
+ tempR [ i + 6 ] * T1j [ 14 ] ; } Tj [ 3 ] = 0.0 ; Tj [ 7 ] = 0.0 ; Tj [ 11
] = 0.0 ; Tj [ 15 ] = 1.0 ; } for ( i = 0 ; i < 4 ; i ++ ) { for ( f = 0 ; f
< 4 ; f ++ ) { T1j [ i + ( f << 2 ) ] = 0.0 ; T1j [ i + ( f << 2 ) ] += T1 [
f << 2 ] * Tj [ i ] ; T1j [ i + ( f << 2 ) ] += T1 [ ( f << 2 ) + 1 ] * Tj [
i + 4 ] ; T1j [ i + ( f << 2 ) ] += T1 [ ( f << 2 ) + 2 ] * Tj [ i + 8 ] ;
T1j [ i + ( f << 2 ) ] += T1 [ ( f << 2 ) + 3 ] * Tj [ i + 12 ] ; } } for ( i
= 0 ; i < 3 ; i ++ ) { R [ 3 * i ] = T1j [ i ] ; R [ 3 * i + 1 ] = T1j [ i +
4 ] ; R [ 3 * i + 2 ] = T1j [ i + 8 ] ; } for ( i = 0 ; i < 9 ; i ++ ) {
tempR [ i ] = - R [ i ] ; } for ( i = 0 ; i < 3 ; i ++ ) { Tj [ i << 2 ] = R
[ 3 * i ] ; Tj [ ( i << 2 ) + 1 ] = R [ 3 * i + 1 ] ; Tj [ ( i << 2 ) + 2 ] =
R [ 3 * i + 2 ] ; Tj [ i + 12 ] = ( tempR [ i + 3 ] * T1j [ 13 ] + tempR [ i
] * T1j [ 12 ] ) + tempR [ i + 6 ] * T1j [ 14 ] ; } Tj [ 3 ] = 0.0 ; Tj [ 7 ]
= 0.0 ; Tj [ 11 ] = 0.0 ; Tj [ 15 ] = 1.0 ; i = b -> size [ 0 ] * b -> size [
1 ] ; b -> size [ 0 ] = 6 ; b -> size [ 1 ] = joint -> MotionSubspace -> size
[ 1 ] ; ier0p3wwtw ( b , i ) ; loop_ub = 6 * joint -> MotionSubspace -> size
[ 1 ] ; for ( i = 0 ; i < loop_ub ; i ++ ) { b -> data [ i ] = joint ->
MotionSubspace -> data [ i ] ; } if ( bid2 > qidx_idx_1 ) { g = 0 ; } else {
g = ( int32_T ) bid2 - 1 ; } R [ 0 ] = 0.0 ; R [ 3 ] = - Tj [ 14 ] ; R [ 6 ]
= Tj [ 13 ] ; R [ 1 ] = Tj [ 14 ] ; R [ 4 ] = 0.0 ; R [ 7 ] = - Tj [ 12 ] ; R
[ 2 ] = - Tj [ 13 ] ; R [ 5 ] = Tj [ 12 ] ; R [ 8 ] = 0.0 ; for ( i = 0 ; i <
3 ; i ++ ) { for ( f = 0 ; f < 3 ; f ++ ) { tempR [ i + 3 * f ] = 0.0 ; tempR
[ i + 3 * f ] += Tj [ f << 2 ] * R [ i ] ; tempR [ i + 3 * f ] += Tj [ ( f <<
2 ) + 1 ] * R [ i + 3 ] ; tempR [ i + 3 * f ] += Tj [ ( f << 2 ) + 2 ] * R [
i + 6 ] ; Tj_e [ f + 6 * i ] = Tj [ ( i << 2 ) + f ] ; Tj_e [ f + 6 * ( i + 3
) ] = 0.0 ; } } for ( i = 0 ; i < 3 ; i ++ ) { Tj_e [ 6 * i + 3 ] = tempR [ 3
* i ] ; Tj_e [ 6 * ( i + 3 ) + 3 ] = Tj [ i << 2 ] ; Tj_e [ 6 * i + 4 ] =
tempR [ 3 * i + 1 ] ; Tj_e [ 6 * ( i + 3 ) + 4 ] = Tj [ ( i << 2 ) + 1 ] ;
Tj_e [ 6 * i + 5 ] = tempR [ 3 * i + 2 ] ; Tj_e [ 6 * ( i + 3 ) + 5 ] = Tj [
( i << 2 ) + 2 ] ; } knqlderc2u ( Tj_e , b , tmp ) ; loop_ub = tmp -> size [
1 ] ; for ( i = 0 ; i < loop_ub ; i ++ ) { for ( f = 0 ; f < 6 ; f ++ ) { Jac
-> data [ f + 6 * ( g + i ) ] = tmp -> data [ 6 * i + f ] * bid1 ; } } } if (
nextBodyIsParent ) { for ( i = 0 ; i < 4 ; i ++ ) { for ( f = 0 ; f < 4 ; f
++ ) { Tj [ i + ( f << 2 ) ] = 0.0 ; Tj [ i + ( f << 2 ) ] += T1 [ f << 2 ] *
Tc2p [ i ] ; Tj [ i + ( f << 2 ) ] += T1 [ ( f << 2 ) + 1 ] * Tc2p [ i + 4 ]
; Tj [ i + ( f << 2 ) ] += T1 [ ( f << 2 ) + 2 ] * Tc2p [ i + 8 ] ; Tj [ i +
( f << 2 ) ] += T1 [ ( f << 2 ) + 3 ] * Tc2p [ i + 12 ] ; } } memcpy ( & T1 [
0 ] , & Tj [ 0 ] , sizeof ( real_T ) << 4U ) ; } else { for ( i = 0 ; i < 3 ;
i ++ ) { R [ 3 * i ] = Tc2p [ i ] ; R [ 3 * i + 1 ] = Tc2p [ i + 4 ] ; R [ 3
* i + 2 ] = Tc2p [ i + 8 ] ; } for ( i = 0 ; i < 9 ; i ++ ) { tempR [ i ] = -
R [ i ] ; } for ( i = 0 ; i < 3 ; i ++ ) { Tj [ i << 2 ] = R [ 3 * i ] ; Tj [
( i << 2 ) + 1 ] = R [ 3 * i + 1 ] ; Tj [ ( i << 2 ) + 2 ] = R [ 3 * i + 2 ]
; Tj [ i + 12 ] = ( tempR [ i + 3 ] * Tc2p [ 13 ] + tempR [ i ] * Tc2p [ 12 ]
) + tempR [ i + 6 ] * Tc2p [ 14 ] ; } Tj [ 3 ] = 0.0 ; Tj [ 7 ] = 0.0 ; Tj [
11 ] = 0.0 ; Tj [ 15 ] = 1.0 ; for ( i = 0 ; i < 4 ; i ++ ) { for ( f = 0 ; f
< 4 ; f ++ ) { Tc2p [ i + ( f << 2 ) ] = 0.0 ; Tc2p [ i + ( f << 2 ) ] += T1
[ f << 2 ] * Tj [ i ] ; Tc2p [ i + ( f << 2 ) ] += T1 [ ( f << 2 ) + 1 ] * Tj
[ i + 4 ] ; Tc2p [ i + ( f << 2 ) ] += T1 [ ( f << 2 ) + 2 ] * Tj [ i + 8 ] ;
Tc2p [ i + ( f << 2 ) ] += T1 [ ( f << 2 ) + 3 ] * Tj [ i + 12 ] ; } } memcpy
( & T1 [ 0 ] , & Tc2p [ 0 ] , sizeof ( real_T ) << 4U ) ; } } njzmd0hlqd ( &
tmp ) ; njzmd0hlqd ( & b ) ; b0l0vcvht3 ( & body2Name ) ; njzmd0hlqd ( &
kinematicPathIndices ) ; for ( i = 0 ; i < 3 ; i ++ ) { bid1 = T1 [ i << 2 ]
; Tj_e [ 6 * i ] = bid1 ; Tj_e [ 6 * ( i + 3 ) ] = 0.0 ; Tj_e [ 6 * i + 3 ] =
0.0 ; Tj_e [ 6 * ( i + 3 ) + 3 ] = bid1 ; bid1 = T1 [ ( i << 2 ) + 1 ] ; Tj_e
[ 6 * i + 1 ] = bid1 ; Tj_e [ 6 * ( i + 3 ) + 1 ] = 0.0 ; Tj_e [ 6 * i + 4 ]
= 0.0 ; Tj_e [ 6 * ( i + 3 ) + 4 ] = bid1 ; bid1 = T1 [ ( i << 2 ) + 2 ] ;
Tj_e [ 6 * i + 2 ] = bid1 ; Tj_e [ 6 * ( i + 3 ) + 2 ] = 0.0 ; Tj_e [ 6 * i +
5 ] = 0.0 ; Tj_e [ 6 * ( i + 3 ) + 5 ] = bid1 ; } cy4r1g1cm1 ( & Jac_e , 2 )
; i = Jac_e -> size [ 0 ] * Jac_e -> size [ 1 ] ; Jac_e -> size [ 0 ] = 6 ;
Jac_e -> size [ 1 ] = Jac -> size [ 1 ] ; ier0p3wwtw ( Jac_e , i ) ; loop_ub
= Jac -> size [ 0 ] * Jac -> size [ 1 ] - 1 ; if ( loop_ub >= 0 ) { memcpy (
& Jac_e -> data [ 0 ] , & Jac -> data [ 0 ] , ( loop_ub + 1 ) * sizeof (
real_T ) ) ; } knqlderc2u ( Tj_e , Jac_e , Jac ) ; T_size [ 0 ] = 4 ; T_size
[ 1 ] = 4 ; njzmd0hlqd ( & Jac_e ) ; memcpy ( & T_data [ 0 ] , & T1 [ 0 ] ,
sizeof ( real_T ) << 4U ) ; } static creal_T a0pew1ahvs ( const creal_T x ) {
creal_T b_x ; real_T absxr ; real_T xr ; xr = x . re ; if ( x . im == 0.0 ) {
if ( x . re < 0.0 ) { absxr = 0.0 ; xr = muDoubleScalarSqrt ( - x . re ) ; }
else { absxr = muDoubleScalarSqrt ( x . re ) ; xr = 0.0 ; } } else if ( x .
re == 0.0 ) { if ( x . im < 0.0 ) { absxr = muDoubleScalarSqrt ( - x . im /
2.0 ) ; xr = - absxr ; } else { absxr = muDoubleScalarSqrt ( x . im / 2.0 ) ;
xr = absxr ; } } else if ( muDoubleScalarIsNaN ( x . re ) ) { absxr = x . re
; } else if ( muDoubleScalarIsNaN ( x . im ) ) { absxr = x . im ; xr = x . im
; } else if ( muDoubleScalarIsInf ( x . im ) ) { absxr = muDoubleScalarAbs (
x . im ) ; xr = x . im ; } else if ( muDoubleScalarIsInf ( x . re ) ) { if (
x . re < 0.0 ) { absxr = 0.0 ; xr = x . im * - x . re ; } else { absxr = x .
re ; xr = 0.0 ; } } else { absxr = muDoubleScalarAbs ( x . re ) ; xr =
muDoubleScalarAbs ( x . im ) ; if ( ( absxr > 4.4942328371557893E+307 ) || (
xr > 4.4942328371557893E+307 ) ) { absxr *= 0.5 ; xr *= 0.5 ; xr =
muDoubleScalarHypot ( absxr , xr ) ; if ( xr > absxr ) { absxr =
muDoubleScalarSqrt ( absxr / xr + 1.0 ) * muDoubleScalarSqrt ( xr ) ; } else
{ absxr = muDoubleScalarSqrt ( xr ) * 1.4142135623730951 ; } } else { absxr =
muDoubleScalarSqrt ( ( muDoubleScalarHypot ( absxr , xr ) + absxr ) * 0.5 ) ;
} if ( x . re > 0.0 ) { xr = x . im / absxr * 0.5 ; } else { if ( x . im <
0.0 ) { xr = - absxr ; } else { xr = absxr ; } absxr = x . im / xr * 0.5 ; }
} b_x . re = absxr ; b_x . im = xr ; return b_x ; } static real_T irgxwzkbnq
( int32_T n , const real_T x [ 9 ] , int32_T ix0 ) { real_T absxk ; real_T
scale ; real_T t ; real_T y ; int32_T k ; int32_T kend ; y = 0.0 ; scale =
3.3121686421112381E-170 ; kend = ix0 + n ; for ( k = ix0 ; k < kend ; k ++ )
{ absxk = muDoubleScalarAbs ( x [ k - 1 ] ) ; if ( absxk > scale ) { t =
scale / absxk ; y = y * t * t + 1.0 ; scale = absxk ; } else { t = absxk /
scale ; y += t * t ; } } return scale * muDoubleScalarSqrt ( y ) ; } static
real_T btgcf4cqcl ( int32_T n , const real_T x [ 9 ] , int32_T ix0 , const
real_T y [ 9 ] , int32_T iy0 ) { real_T d ; int32_T k ; d = 0.0 ; for ( k = 0
; k < n ; k ++ ) { d += x [ ( ix0 + k ) - 1 ] * y [ ( iy0 + k ) - 1 ] ; }
return d ; } static void konv2omx5i ( int32_T n , real_T a , int32_T ix0 ,
const real_T y [ 9 ] , int32_T iy0 , real_T b_y [ 9 ] ) { int32_T k ; memcpy
( & b_y [ 0 ] , & y [ 0 ] , 9U * sizeof ( real_T ) ) ; if ( ! ( a == 0.0 ) )
{ for ( k = 0 ; k < n ; k ++ ) { b_y [ ( iy0 + k ) - 1 ] += b_y [ ( ix0 + k )
- 1 ] * a ; } } } static real_T irgxwzkbnql ( const real_T x [ 3 ] , int32_T
ix0 ) { real_T absxk ; real_T scale ; real_T t ; real_T y ; int32_T k ; y =
0.0 ; scale = 3.3121686421112381E-170 ; for ( k = ix0 ; k <= ix0 + 1 ; k ++ )
{ absxk = muDoubleScalarAbs ( x [ k - 1 ] ) ; if ( absxk > scale ) { t =
scale / absxk ; y = y * t * t + 1.0 ; scale = absxk ; } else { t = absxk /
scale ; y += t * t ; } } return scale * muDoubleScalarSqrt ( y ) ; } static
void konv2omx5it1w ( int32_T n , real_T a , const real_T x [ 9 ] , int32_T
ix0 , real_T y [ 3 ] , int32_T iy0 ) { int32_T k ; if ( ! ( a == 0.0 ) ) {
for ( k = 0 ; k < n ; k ++ ) { y [ ( iy0 + k ) - 1 ] += x [ ( ix0 + k ) - 1 ]
* a ; } } } static void konv2omx5it1 ( int32_T n , real_T a , const real_T x
[ 3 ] , int32_T ix0 , const real_T y [ 9 ] , int32_T iy0 , real_T b_y [ 9 ] )
{ int32_T k ; memcpy ( & b_y [ 0 ] , & y [ 0 ] , 9U * sizeof ( real_T ) ) ;
if ( ! ( a == 0.0 ) ) { for ( k = 0 ; k < n ; k ++ ) { b_y [ ( iy0 + k ) - 1
] += x [ ( ix0 + k ) - 1 ] * a ; } } } static void exvzrfriqd ( const real_T
x [ 9 ] , int32_T ix0 , int32_T iy0 , real_T b_x [ 9 ] ) { real_T temp ;
memcpy ( & b_x [ 0 ] , & x [ 0 ] , 9U * sizeof ( real_T ) ) ; temp = b_x [
ix0 - 1 ] ; b_x [ ix0 - 1 ] = b_x [ iy0 - 1 ] ; b_x [ iy0 - 1 ] = temp ; temp
= b_x [ ix0 ] ; b_x [ ix0 ] = b_x [ iy0 ] ; b_x [ iy0 ] = temp ; temp = b_x [
ix0 + 1 ] ; b_x [ ix0 + 1 ] = b_x [ iy0 + 1 ] ; b_x [ iy0 + 1 ] = temp ; }
static void bmjikbt2rd ( real_T a , real_T b , real_T * b_a , real_T * b_b ,
real_T * c , real_T * s ) { real_T absa ; real_T absb ; real_T ads ; real_T
bds ; real_T roe ; real_T scale ; roe = b ; absa = muDoubleScalarAbs ( a ) ;
absb = muDoubleScalarAbs ( b ) ; if ( absa > absb ) { roe = a ; } scale =
absa + absb ; if ( scale == 0.0 ) { * s = 0.0 ; * c = 1.0 ; * b_a = 0.0 ; *
b_b = 0.0 ; } else { ads = absa / scale ; bds = absb / scale ; * b_a =
muDoubleScalarSqrt ( ads * ads + bds * bds ) * scale ; if ( roe < 0.0 ) { *
b_a = - * b_a ; } * c = a / * b_a ; * s = b / * b_a ; if ( absa > absb ) { *
b_b = * s ; } else if ( * c != 0.0 ) { * b_b = 1.0 / * c ; } else { * b_b =
1.0 ; } } } static void nfijn1ftpq ( const real_T x [ 9 ] , int32_T ix0 ,
int32_T iy0 , real_T c , real_T s , real_T b_x [ 9 ] ) { real_T temp ; memcpy
( & b_x [ 0 ] , & x [ 0 ] , 9U * sizeof ( real_T ) ) ; temp = b_x [ ix0 - 1 ]
* c + b_x [ iy0 - 1 ] * s ; b_x [ iy0 - 1 ] = b_x [ iy0 - 1 ] * c - b_x [ ix0
- 1 ] * s ; b_x [ ix0 - 1 ] = temp ; temp = b_x [ ix0 ] * c + b_x [ iy0 ] * s
; b_x [ iy0 ] = b_x [ iy0 ] * c - b_x [ ix0 ] * s ; b_x [ ix0 ] = temp ; temp
= b_x [ ix0 + 1 ] * c + b_x [ iy0 + 1 ] * s ; b_x [ iy0 + 1 ] = b_x [ iy0 + 1
] * c - b_x [ ix0 + 1 ] * s ; b_x [ ix0 + 1 ] = temp ; } static void
cuphw2yuqi ( const real_T A [ 9 ] , real_T U [ 9 ] , real_T s [ 3 ] , real_T
V [ 9 ] ) { real_T A_e [ 9 ] ; real_T A_p [ 9 ] ; real_T e [ 3 ] ; real_T s_p
[ 3 ] ; real_T work [ 3 ] ; real_T emm1 ; real_T nrm ; real_T rt ; real_T
shift ; real_T smm1 ; real_T sqds ; real_T ztest ; real_T ztest0 ; int32_T b
; int32_T colqp1 ; int32_T m ; int32_T qjj ; int32_T qp1 ; int32_T qq ;
boolean_T apply_transform ; boolean_T exitg1 ; s_p [ 0 ] = 0.0 ; e [ 0 ] =
0.0 ; work [ 0 ] = 0.0 ; s_p [ 1 ] = 0.0 ; e [ 1 ] = 0.0 ; work [ 1 ] = 0.0 ;
s_p [ 2 ] = 0.0 ; e [ 2 ] = 0.0 ; work [ 2 ] = 0.0 ; for ( m = 0 ; m < 9 ; m
++ ) { A_p [ m ] = A [ m ] ; U [ m ] = 0.0 ; V [ m ] = 0.0 ; } for ( m = 0 ;
m < 2 ; m ++ ) { colqp1 = m + 1 ; qp1 = m + 2 ; qq = ( m * 3 + m ) + 1 ;
apply_transform = false ; nrm = irgxwzkbnq ( 3 - m , A_p , qq ) ; if ( nrm >
0.0 ) { apply_transform = true ; if ( A_p [ qq - 1 ] < 0.0 ) { s_p [ m ] = -
nrm ; } else { s_p [ m ] = nrm ; } if ( muDoubleScalarAbs ( s_p [ m ] ) >=
1.0020841800044864E-292 ) { nrm = 1.0 / s_p [ m ] ; b = ( qq - m ) - 1 ; for
( qjj = qq ; qjj <= b + 3 ; qjj ++ ) { A_p [ qjj - 1 ] *= nrm ; } } else { b
= ( qq - m ) - 1 ; for ( qjj = qq ; qjj <= b + 3 ; qjj ++ ) { A_p [ qjj - 1 ]
/= s_p [ m ] ; } } A_p [ qq - 1 ] ++ ; s_p [ m ] = - s_p [ m ] ; } else { s_p
[ m ] = 0.0 ; } for ( b = qp1 ; b < 4 ; b ++ ) { qjj = ( ( b - 1 ) * 3 + m )
+ 1 ; if ( apply_transform ) { memcpy ( & A_e [ 0 ] , & A_p [ 0 ] , 9U *
sizeof ( real_T ) ) ; konv2omx5i ( 3 - m , - ( btgcf4cqcl ( 3 - m , A_p , qq
, A_p , qjj ) / A_p [ m * 3 + m ] ) , qq , A_e , qjj , A_p ) ; } e [ b - 1 ]
= A_p [ qjj - 1 ] ; } memcpy ( & U [ ( m * 3 + colqp1 ) + - 1 ] , & A_p [ ( m
* 3 + colqp1 ) + - 1 ] , ( - colqp1 + 4 ) * sizeof ( real_T ) ) ; if ( m + 1
<= 1 ) { nrm = irgxwzkbnql ( e , 2 ) ; if ( nrm == 0.0 ) { e [ 0 ] = 0.0 ; }
else { if ( e [ 1 ] < 0.0 ) { rt = - nrm ; e [ 0 ] = - nrm ; } else { rt =
nrm ; e [ 0 ] = nrm ; } if ( muDoubleScalarAbs ( rt ) >=
1.0020841800044864E-292 ) { nrm = 1.0 / rt ; for ( qjj = qp1 ; qjj < 4 ; qjj
++ ) { e [ qjj - 1 ] *= nrm ; } } else { for ( qjj = qp1 ; qjj < 4 ; qjj ++ )
{ e [ qjj - 1 ] /= rt ; } } e [ 1 ] ++ ; e [ 0 ] = - e [ 0 ] ; for ( qq = qp1
; qq < 4 ; qq ++ ) { work [ qq - 1 ] = 0.0 ; } for ( qq = qp1 ; qq < 4 ; qq
++ ) { konv2omx5it1w ( 2 , e [ qq - 1 ] , A_p , 3 * ( qq - 1 ) + 2 , work , 2
) ; } for ( qq = qp1 ; qq < 4 ; qq ++ ) { memcpy ( & A_e [ 0 ] , & A_p [ 0 ]
, 9U * sizeof ( real_T ) ) ; konv2omx5it1 ( 2 , - e [ qq - 1 ] / e [ 1 ] ,
work , 2 , A_e , ( qq - 1 ) * 3 + 2 , A_p ) ; } } for ( colqp1 = qp1 ; colqp1
< 4 ; colqp1 ++ ) { V [ colqp1 - 1 ] = e [ colqp1 - 1 ] ; } } } m = 2 ; s_p [
2 ] = A_p [ 8 ] ; e [ 1 ] = A_p [ 7 ] ; e [ 2 ] = 0.0 ; U [ 6 ] = 0.0 ; U [ 7
] = 0.0 ; U [ 8 ] = 1.0 ; for ( colqp1 = 1 ; colqp1 >= 0 ; colqp1 -- ) { qq =
3 * colqp1 + colqp1 ; if ( s_p [ colqp1 ] != 0.0 ) { for ( b = colqp1 + 2 ; b
< 4 ; b ++ ) { qjj = ( ( b - 1 ) * 3 + colqp1 ) + 1 ; memcpy ( & A_p [ 0 ] ,
& U [ 0 ] , 9U * sizeof ( real_T ) ) ; konv2omx5i ( 3 - colqp1 , - (
btgcf4cqcl ( 3 - colqp1 , U , qq + 1 , U , qjj ) / U [ qq ] ) , qq + 1 , A_p
, qjj , U ) ; } for ( qp1 = colqp1 + 1 ; qp1 < 4 ; qp1 ++ ) { U [ ( qp1 + 3 *
colqp1 ) - 1 ] = - U [ ( 3 * colqp1 + qp1 ) - 1 ] ; } U [ qq ] ++ ; if (
colqp1 - 1 >= 0 ) { U [ 3 * colqp1 ] = 0.0 ; } } else { U [ 3 * colqp1 ] =
0.0 ; U [ 3 * colqp1 + 1 ] = 0.0 ; U [ 3 * colqp1 + 2 ] = 0.0 ; U [ qq ] =
1.0 ; } } for ( colqp1 = 2 ; colqp1 >= 0 ; colqp1 -- ) { if ( ( colqp1 + 1 <=
1 ) && ( e [ 0 ] != 0.0 ) ) { memcpy ( & A_p [ 0 ] , & V [ 0 ] , 9U * sizeof
( real_T ) ) ; konv2omx5i ( 2 , - ( btgcf4cqcl ( 2 , V , 2 , V , 5 ) / V [ 1
] ) , 2 , A_p , 5 , V ) ; memcpy ( & A_p [ 0 ] , & V [ 0 ] , 9U * sizeof (
real_T ) ) ; konv2omx5i ( 2 , - ( btgcf4cqcl ( 2 , V , 2 , V , 8 ) / V [ 1 ]
) , 2 , A_p , 8 , V ) ; } V [ 3 * colqp1 ] = 0.0 ; V [ 3 * colqp1 + 1 ] = 0.0
; V [ 3 * colqp1 + 2 ] = 0.0 ; V [ colqp1 + 3 * colqp1 ] = 1.0 ; } for ( qp1
= 0 ; qp1 < 3 ; qp1 ++ ) { smm1 = e [ qp1 ] ; if ( s_p [ qp1 ] != 0.0 ) { rt
= muDoubleScalarAbs ( s_p [ qp1 ] ) ; nrm = s_p [ qp1 ] / rt ; s_p [ qp1 ] =
rt ; if ( qp1 + 1 < 3 ) { smm1 /= nrm ; } qq = 3 * qp1 ; for ( qjj = qq + 1 ;
qjj <= qq + 3 ; qjj ++ ) { U [ qjj - 1 ] *= nrm ; } } if ( ( qp1 + 1 < 3 ) &&
( smm1 != 0.0 ) ) { rt = muDoubleScalarAbs ( smm1 ) ; nrm = rt / smm1 ; smm1
= rt ; s_p [ qp1 + 1 ] *= nrm ; colqp1 = ( qp1 + 1 ) * 3 ; for ( qjj = colqp1
+ 1 ; qjj <= colqp1 + 3 ; qjj ++ ) { V [ qjj - 1 ] *= nrm ; } } e [ qp1 ] =
smm1 ; } rt = 0.0 ; nrm = muDoubleScalarMax ( muDoubleScalarMax (
muDoubleScalarMax ( 0.0 , muDoubleScalarMax ( muDoubleScalarAbs ( s_p [ 0 ] )
, muDoubleScalarAbs ( e [ 0 ] ) ) ) , muDoubleScalarMax ( muDoubleScalarAbs (
s_p [ 1 ] ) , muDoubleScalarAbs ( e [ 1 ] ) ) ) , muDoubleScalarMax (
muDoubleScalarAbs ( s_p [ 2 ] ) , muDoubleScalarAbs ( e [ 2 ] ) ) ) ; while (
( m + 1 > 0 ) && ( ! ( rt >= 75.0 ) ) ) { colqp1 = m ; qp1 = m ; exitg1 =
false ; while ( ( ! exitg1 ) && ( qp1 > - 1 ) ) { colqp1 = qp1 ; if ( qp1 ==
0 ) { exitg1 = true ; } else { ztest0 = muDoubleScalarAbs ( e [ qp1 - 1 ] ) ;
if ( ( ztest0 <= ( muDoubleScalarAbs ( s_p [ qp1 - 1 ] ) + muDoubleScalarAbs
( s_p [ qp1 ] ) ) * 2.2204460492503131E-16 ) || ( ztest0 <=
1.0020841800044864E-292 ) || ( ( rt > 20.0 ) && ( ztest0 <=
2.2204460492503131E-16 * nrm ) ) ) { e [ qp1 - 1 ] = 0.0 ; exitg1 = true ; }
else { qp1 -- ; } } } if ( colqp1 == m ) { ztest0 = 4.0 ; } else { qp1 = m +
1 ; qq = m + 1 ; exitg1 = false ; while ( ( ! exitg1 ) && ( qq >= colqp1 ) )
{ qp1 = qq ; if ( qq == colqp1 ) { exitg1 = true ; } else { ztest0 = 0.0 ; if
( qq < m + 1 ) { ztest0 = muDoubleScalarAbs ( e [ qq - 1 ] ) ; } if ( qq >
colqp1 + 1 ) { ztest0 += muDoubleScalarAbs ( e [ qq - 2 ] ) ; } ztest =
muDoubleScalarAbs ( s_p [ qq - 1 ] ) ; if ( ( ztest <= 2.2204460492503131E-16
* ztest0 ) || ( ztest <= 1.0020841800044864E-292 ) ) { s_p [ qq - 1 ] = 0.0 ;
exitg1 = true ; } else { qq -- ; } } } if ( qp1 == colqp1 ) { ztest0 = 3.0 ;
} else if ( m + 1 == qp1 ) { ztest0 = 1.0 ; } else { ztest0 = 2.0 ; colqp1 =
qp1 ; } } switch ( ( int32_T ) ztest0 ) { case 1 : ztest0 = e [ m - 1 ] ; e [
m - 1 ] = 0.0 ; for ( qq = m ; qq >= colqp1 + 1 ; qq -- ) { smm1 = e [ 0 ] ;
bmjikbt2rd ( s_p [ qq - 1 ] , ztest0 , & s_p [ qq - 1 ] , & ztest0 , & ztest
, & sqds ) ; if ( qq > colqp1 + 1 ) { ztest0 = - sqds * e [ 0 ] ; smm1 = e [
0 ] * ztest ; } memcpy ( & A_p [ 0 ] , & V [ 0 ] , 9U * sizeof ( real_T ) ) ;
nfijn1ftpq ( A_p , ( qq - 1 ) * 3 + 1 , 3 * m + 1 , ztest , sqds , V ) ; e [
0 ] = smm1 ; } break ; case 2 : ztest0 = e [ colqp1 - 1 ] ; e [ colqp1 - 1 ]
= 0.0 ; for ( qp1 = colqp1 + 1 ; qp1 <= m + 1 ; qp1 ++ ) { bmjikbt2rd ( s_p [
qp1 - 1 ] , ztest0 , & s_p [ qp1 - 1 ] , & ztest , & sqds , & smm1 ) ; ztest0
= e [ qp1 - 1 ] * - smm1 ; e [ qp1 - 1 ] *= sqds ; memcpy ( & A_p [ 0 ] , & U
[ 0 ] , 9U * sizeof ( real_T ) ) ; nfijn1ftpq ( A_p , ( qp1 - 1 ) * 3 + 1 , (
colqp1 - 1 ) * 3 + 1 , sqds , smm1 , U ) ; } break ; case 3 : ztest =
muDoubleScalarMax ( muDoubleScalarMax ( muDoubleScalarMax ( muDoubleScalarMax
( muDoubleScalarAbs ( s_p [ m ] ) , muDoubleScalarAbs ( s_p [ m - 1 ] ) ) ,
muDoubleScalarAbs ( e [ m - 1 ] ) ) , muDoubleScalarAbs ( s_p [ colqp1 ] ) )
, muDoubleScalarAbs ( e [ colqp1 ] ) ) ; ztest0 = s_p [ m ] / ztest ; smm1 =
s_p [ m - 1 ] / ztest ; emm1 = e [ m - 1 ] / ztest ; sqds = s_p [ colqp1 ] /
ztest ; smm1 = ( ( smm1 + ztest0 ) * ( smm1 - ztest0 ) + emm1 * emm1 ) / 2.0
; emm1 *= ztest0 ; emm1 *= emm1 ; if ( ( smm1 != 0.0 ) || ( emm1 != 0.0 ) ) {
shift = muDoubleScalarSqrt ( smm1 * smm1 + emm1 ) ; if ( smm1 < 0.0 ) { shift
= - shift ; } shift = emm1 / ( smm1 + shift ) ; } else { shift = 0.0 ; }
ztest0 = ( sqds + ztest0 ) * ( sqds - ztest0 ) + shift ; ztest = e [ colqp1 ]
/ ztest * sqds ; for ( qq = colqp1 + 1 ; qq <= m ; qq ++ ) { bmjikbt2rd (
ztest0 , ztest , & sqds , & smm1 , & emm1 , & shift ) ; if ( qq > colqp1 + 1
) { e [ 0 ] = sqds ; } ztest0 = s_p [ qq - 1 ] * emm1 + e [ qq - 1 ] * shift
; e [ qq - 1 ] = e [ qq - 1 ] * emm1 - s_p [ qq - 1 ] * shift ; ztest = shift
* s_p [ qq ] ; s_p [ qq ] *= emm1 ; memcpy ( & A_p [ 0 ] , & V [ 0 ] , 9U *
sizeof ( real_T ) ) ; nfijn1ftpq ( A_p , ( qq - 1 ) * 3 + 1 , 3 * qq + 1 ,
emm1 , shift , V ) ; bmjikbt2rd ( ztest0 , ztest , & s_p [ qq - 1 ] , & sqds
, & smm1 , & emm1 ) ; ztest0 = e [ qq - 1 ] * smm1 + emm1 * s_p [ qq ] ; s_p
[ qq ] = e [ qq - 1 ] * - emm1 + smm1 * s_p [ qq ] ; ztest = emm1 * e [ qq ]
; e [ qq ] *= smm1 ; memcpy ( & A_p [ 0 ] , & U [ 0 ] , 9U * sizeof ( real_T
) ) ; nfijn1ftpq ( A_p , ( qq - 1 ) * 3 + 1 , 3 * qq + 1 , smm1 , emm1 , U )
; } e [ m - 1 ] = ztest0 ; rt ++ ; break ; default : if ( s_p [ colqp1 ] <
0.0 ) { s_p [ colqp1 ] = - s_p [ colqp1 ] ; qq = 3 * colqp1 ; for ( qjj = qq
+ 1 ; qjj <= qq + 3 ; qjj ++ ) { V [ qjj - 1 ] = - V [ qjj - 1 ] ; } } qp1 =
colqp1 + 1 ; while ( ( colqp1 + 1 < 3 ) && ( s_p [ colqp1 ] < s_p [ qp1 ] ) )
{ rt = s_p [ colqp1 ] ; s_p [ colqp1 ] = s_p [ qp1 ] ; s_p [ qp1 ] = rt ;
memcpy ( & A_p [ 0 ] , & V [ 0 ] , 9U * sizeof ( real_T ) ) ; exvzrfriqd (
A_p , 3 * colqp1 + 1 , ( colqp1 + 1 ) * 3 + 1 , V ) ; memcpy ( & A_p [ 0 ] ,
& U [ 0 ] , 9U * sizeof ( real_T ) ) ; exvzrfriqd ( A_p , 3 * colqp1 + 1 , (
colqp1 + 1 ) * 3 + 1 , U ) ; colqp1 = qp1 ; qp1 ++ ; } rt = 0.0 ; m -- ;
break ; } } s [ 0 ] = s_p [ 0 ] ; s [ 1 ] = s_p [ 1 ] ; s [ 2 ] = s_p [ 2 ] ;
} static void d3njpynb5n ( const real_T Td [ 16 ] , const real_T T_data [ ] ,
const int32_T T_size [ 2 ] , real_T errorvec [ 6 ] ) { creal_T tmp ; creal_T
u ; creal_T u_p ; creal_T v_p ; real_T T [ 9 ] ; real_T V [ 9 ] ; real_T b_U
[ 9 ] ; real_T y [ 9 ] ; real_T b_s [ 3 ] ; real_T v [ 3 ] ; real_T
vspecial_data [ 3 ] ; real_T q ; real_T t4 ; int32_T b_i ; int32_T iy ;
int32_T loop_ub ; boolean_T e ; boolean_T exitg1 ; boolean_T x ; boolean_T
xneg ; for ( iy = 0 ; iy < 3 ; iy ++ ) { T [ 3 * iy ] = T_data [ iy ] ; T [ 3
* iy + 1 ] = T_data [ iy + T_size [ 0 ] ] ; T [ 3 * iy + 2 ] = T_data [ (
T_size [ 0 ] << 1 ) + iy ] ; for ( loop_ub = 0 ; loop_ub < 3 ; loop_ub ++ ) {
y [ loop_ub + 3 * iy ] = 0.0 ; y [ loop_ub + 3 * iy ] += T [ 3 * iy ] * Td [
loop_ub ] ; y [ loop_ub + 3 * iy ] += T [ 3 * iy + 1 ] * Td [ loop_ub + 4 ] ;
y [ loop_ub + 3 * iy ] += T [ 3 * iy + 2 ] * Td [ loop_ub + 8 ] ; } } u . re
= ( ( ( y [ 0 ] + y [ 4 ] ) + y [ 8 ] ) - 1.0 ) * 0.5 ; if ( ! (
muDoubleScalarAbs ( u . re ) > 1.0 ) ) { v_p . re = muDoubleScalarAcos ( u .
re ) ; } else { u_p . re = u . re + 1.0 ; u_p . im = 0.0 ; tmp . re = 1.0 - u
. re ; tmp . im = 0.0 ; v_p . re = 2.0 * muDoubleScalarAtan2 ( ( a0pew1ahvs (
tmp ) ) . re , ( a0pew1ahvs ( u_p ) ) . re ) ; } t4 = 2.0 * muDoubleScalarSin
( v_p . re ) ; v [ 0 ] = ( y [ 5 ] - y [ 7 ] ) / t4 ; v [ 1 ] = ( y [ 6 ] - y
[ 2 ] ) / t4 ; v [ 2 ] = ( y [ 1 ] - y [ 3 ] ) / t4 ; if (
muDoubleScalarIsNaN ( v_p . re ) || muDoubleScalarIsInf ( v_p . re ) ) { t4 =
( rtNaN ) ; } else if ( v_p . re == 0.0 ) { t4 = 0.0 ; } else { t4 =
muDoubleScalarRem ( v_p . re , 3.1415926535897931 ) ; xneg = ( t4 == 0.0 ) ;
if ( ! xneg ) { q = muDoubleScalarAbs ( v_p . re / 3.1415926535897931 ) ;
xneg = ! ( muDoubleScalarAbs ( q - muDoubleScalarFloor ( q + 0.5 ) ) >
2.2204460492503131E-16 * q ) ; } if ( xneg ) { t4 = 0.0 ; } else if ( v_p .
re < 0.0 ) { t4 += 3.1415926535897931 ; } } xneg = ( t4 == 0.0 ) ; e = true ;
iy = 0 ; exitg1 = false ; while ( ( ! exitg1 ) && ( iy < 3 ) ) { if ( ! ( v [
iy ] == 0.0 ) ) { e = false ; exitg1 = true ; } else { iy ++ ; } } if ( xneg
|| e ) { loop_ub = ( xneg || e ) * 3 - 1 ; if ( loop_ub >= 0 ) { memset ( &
vspecial_data [ 0 ] , 0 , ( loop_ub + 1 ) * sizeof ( real_T ) ) ; } loop_ub =
( xneg || e ) - 1 ; for ( b_i = 0 ; b_i <= loop_ub ; b_i ++ ) { memset ( & T
[ 0 ] , 0 , 9U * sizeof ( real_T ) ) ; T [ 0 ] = 1.0 ; T [ 4 ] = 1.0 ; T [ 8
] = 1.0 ; for ( iy = 0 ; iy < 9 ; iy ++ ) { T [ iy ] -= y [ iy ] ; } x = true
; for ( iy = 0 ; iy < 9 ; iy ++ ) { if ( x ) { t4 = T [ iy ] ; if ( ( !
muDoubleScalarIsInf ( t4 ) ) && ( ! muDoubleScalarIsNaN ( t4 ) ) ) { } else {
x = false ; } } else { x = false ; } } if ( x ) { cuphw2yuqi ( T , b_U , b_s
, V ) ; } else { for ( iy = 0 ; iy < 9 ; iy ++ ) { V [ iy ] = ( rtNaN ) ; } }
vspecial_data [ 0 ] = V [ 6 ] ; vspecial_data [ 1 ] = V [ 7 ] ; vspecial_data
[ 2 ] = V [ 8 ] ; } loop_ub = 0 ; if ( xneg || e ) { for ( b_i = 0 ; b_i < 1
; b_i ++ ) { loop_ub ++ ; } } if ( loop_ub - 1 >= 0 ) { v [ 0 ] =
vspecial_data [ 0 ] ; v [ 1 ] = vspecial_data [ 1 ] ; v [ 2 ] = vspecial_data
[ 2 ] ; } } t4 = 1.0 / muDoubleScalarSqrt ( ( v [ 0 ] * v [ 0 ] + v [ 1 ] * v
[ 1 ] ) + v [ 2 ] * v [ 2 ] ) ; v [ 0 ] *= t4 ; v [ 1 ] *= t4 ; errorvec [ 0
] = v_p . re * v [ 0 ] ; errorvec [ 3 ] = Td [ 12 ] - T_data [ T_size [ 0 ] *
3 ] ; errorvec [ 1 ] = v_p . re * v [ 1 ] ; errorvec [ 4 ] = Td [ 13 ] -
T_data [ T_size [ 0 ] * 3 + 1 ] ; errorvec [ 2 ] = v [ 2 ] * t4 * v_p . re ;
errorvec [ 5 ] = Td [ 14 ] - T_data [ T_size [ 0 ] * 3 + 2 ] ; } static void
knqlderc2umb ( const real_T A [ 6 ] , const moo4o4s0qn * B_i , moo4o4s0qn * C
) { real_T s ; int32_T b_j ; int32_T b_k ; int32_T boffset ; int32_T n ; n =
B_i -> size [ 1 ] - 1 ; b_j = C -> size [ 0 ] * C -> size [ 1 ] ; C -> size [
0 ] = 1 ; C -> size [ 1 ] = B_i -> size [ 1 ] ; ier0p3wwtw ( C , b_j ) ; for
( b_j = 0 ; b_j <= n ; b_j ++ ) { boffset = b_j * 6 - 1 ; s = 0.0 ; for ( b_k
= 0 ; b_k < 6 ; b_k ++ ) { s += B_i -> data [ ( boffset + b_k ) + 1 ] * A [
b_k ] ; } C -> data [ b_j ] = s ; } } static void mp1kcw5ibf ( itipyws4dn * *
pEmxArray , int32_T numDimensions ) { itipyws4dn * emxArray ; int32_T i ; *
pEmxArray = ( itipyws4dn * ) malloc ( sizeof ( itipyws4dn ) ) ; emxArray = *
pEmxArray ; emxArray -> data = ( boolean_T * ) NULL ; emxArray ->
numDimensions = numDimensions ; emxArray -> size = ( int32_T * ) malloc (
sizeof ( int32_T ) * numDimensions ) ; emxArray -> allocatedSize = 0 ;
emxArray -> canFreeData = true ; for ( i = 0 ; i < numDimensions ; i ++ ) {
emxArray -> size [ i ] = 0 ; } } static real_T b2cutvohzkb ( const real_T x [
6 ] ) { real_T absxk ; real_T scale ; real_T t ; real_T y ; int32_T b_k ; y =
0.0 ; scale = 3.3121686421112381E-170 ; for ( b_k = 0 ; b_k < 6 ; b_k ++ ) {
absxk = muDoubleScalarAbs ( x [ b_k ] ) ; if ( absxk > scale ) { t = scale /
absxk ; y = y * t * t + 1.0 ; scale = absxk ; } else { t = absxk / scale ; y
+= t * t ; } } return scale * muDoubleScalarSqrt ( y ) ; } static void
h2drfin2nju ( moo4o4s0qn * in1 , const moo4o4s0qn * in2 ) { moo4o4s0qn *
in2_p ; int32_T i ; int32_T loop_ub ; int32_T stride_0_0 ; int32_T stride_1_0
; cy4r1g1cm1 ( & in2_p , 1 ) ; i = in2_p -> size [ 0 ] ; in2_p -> size [ 0 ]
= in1 -> size [ 0 ] == 1 ? in2 -> size [ 0 ] : in1 -> size [ 0 ] ; ier0p3wwtw
( in2_p , i ) ; stride_0_0 = ( in2 -> size [ 0 ] != 1 ) ; stride_1_0 = ( in1
-> size [ 0 ] != 1 ) ; loop_ub = in1 -> size [ 0 ] == 1 ? in2 -> size [ 0 ] :
in1 -> size [ 0 ] ; for ( i = 0 ; i < loop_ub ; i ++ ) { in2_p -> data [ i ]
= in2 -> data [ i * stride_0_0 ] - in1 -> data [ i * stride_1_0 ] ; } i = in1
-> size [ 0 ] ; in1 -> size [ 0 ] = in2_p -> size [ 0 ] ; ier0p3wwtw ( in1 ,
i ) ; loop_ub = in2_p -> size [ 0 ] ; if ( loop_ub - 1 >= 0 ) { memcpy ( &
in1 -> data [ 0 ] , & in2_p -> data [ 0 ] , loop_ub * sizeof ( real_T ) ) ; }
njzmd0hlqd ( & in2_p ) ; } static void iue3n2dlds ( itipyws4dn * emxArray ,
int32_T oldNumel ) { int32_T i ; int32_T newNumel ; void * newData ; if (
oldNumel < 0 ) { oldNumel = 0 ; } newNumel = 1 ; for ( i = 0 ; i < emxArray
-> numDimensions ; i ++ ) { newNumel *= emxArray -> size [ i ] ; } if (
newNumel > emxArray -> allocatedSize ) { i = emxArray -> allocatedSize ; if (
i < 16 ) { i = 16 ; } while ( i < newNumel ) { if ( i > 1073741823 ) { i =
MAX_int32_T ; } else { i <<= 1 ; } } newData = calloc ( ( uint32_T ) i ,
sizeof ( boolean_T ) ) ; if ( emxArray -> data != NULL ) { memcpy ( newData ,
emxArray -> data , sizeof ( boolean_T ) * oldNumel ) ; if ( emxArray ->
canFreeData ) { free ( emxArray -> data ) ; } } emxArray -> data = (
boolean_T * ) newData ; emxArray -> allocatedSize = i ; emxArray ->
canFreeData = true ; } } static real_T b43ytoj3db ( real_T tstart_tv_sec ,
real_T tstart_tv_nsec ) { coderTimespec b_timespec ; if ( ! rtDW . mkp2eepxcj
) { rtDW . mkp2eepxcj = true ; coderInitTimeFunctions ( & rtDW . ndveltha3i )
; } coderTimeClockGettimeMonotonic ( & b_timespec , rtDW . ndveltha3i ) ;
return ( b_timespec . tv_nsec - tstart_tv_nsec ) / 1.0E+9 + ( b_timespec .
tv_sec - tstart_tv_sec ) ; } static void iah2jhz5bn ( const real_T A [ 25 ] ,
const moo4o4s0qn * B_m , real_T Y_data [ ] , int32_T * Y_size ) { real_T c_x
[ 25 ] ; real_T s ; real_T smax ; int32_T c ; int32_T c_e ; int32_T c_p ;
int32_T ijA ; int32_T iy ; int32_T jA ; int32_T jj ; int32_T jp1j ; int32_T
kAcol ; int8_T b_ipiv [ 5 ] ; memcpy ( & c_x [ 0 ] , & A [ 0 ] , 25U * sizeof
( real_T ) ) ; for ( kAcol = 0 ; kAcol < 5 ; kAcol ++ ) { b_ipiv [ kAcol ] =
( int8_T ) ( kAcol + 1 ) ; } for ( kAcol = 0 ; kAcol < 4 ; kAcol ++ ) { c =
kAcol * 6 + 2 ; jj = kAcol * 6 ; c_p = 5 - kAcol ; iy = 1 ; smax =
muDoubleScalarAbs ( c_x [ jj ] ) ; for ( jA = 2 ; jA <= c_p ; jA ++ ) { s =
muDoubleScalarAbs ( c_x [ ( c + jA ) - 3 ] ) ; if ( s > smax ) { iy = jA ;
smax = s ; } } if ( c_x [ ( c + iy ) - 3 ] != 0.0 ) { if ( iy - 1 != 0 ) {
b_ipiv [ kAcol ] = ( int8_T ) ( kAcol + iy ) ; iy = ( kAcol + iy ) - 1 ; for
( jA = 0 ; jA < 5 ; jA ++ ) { smax = c_x [ jA * 5 + kAcol ] ; c_x [ kAcol +
jA * 5 ] = c_x [ jA * 5 + iy ] ; c_x [ iy + jA * 5 ] = smax ; } } iy = c -
kAcol ; for ( jA = c ; jA <= iy + 3 ; jA ++ ) { c_x [ jA - 1 ] /= c_x [ jj ]
; } } c_p = 4 - kAcol ; jA = jj ; jj += 5 ; for ( jp1j = 0 ; jp1j < c_p ;
jp1j ++ ) { smax = c_x [ jp1j * 5 + jj ] ; if ( c_x [ jp1j * 5 + jj ] != 0.0
) { iy = jA + 7 ; c_e = jA - kAcol ; for ( ijA = iy ; ijA <= c_e + 10 ; ijA
++ ) { c_x [ ijA - 1 ] += c_x [ ( ( c + ijA ) - jA ) - 8 ] * - smax ; } } jA
+= 5 ; } } * Y_size = B_m -> size [ 0 ] ; iy = B_m -> size [ 0 ] ; if ( iy -
1 >= 0 ) { memcpy ( & Y_data [ 0 ] , & B_m -> data [ 0 ] , iy * sizeof (
real_T ) ) ; } if ( b_ipiv [ 0 ] != 1 ) { smax = Y_data [ 0 ] ; Y_data [ 0 ]
= Y_data [ b_ipiv [ 0 ] - 1 ] ; Y_data [ b_ipiv [ 0 ] - 1 ] = smax ; } if (
b_ipiv [ 1 ] != 2 ) { smax = Y_data [ 1 ] ; Y_data [ 1 ] = Y_data [ b_ipiv [
1 ] - 1 ] ; Y_data [ b_ipiv [ 1 ] - 1 ] = smax ; } if ( b_ipiv [ 2 ] != 3 ) {
smax = Y_data [ 2 ] ; Y_data [ 2 ] = Y_data [ b_ipiv [ 2 ] - 1 ] ; Y_data [
b_ipiv [ 2 ] - 1 ] = smax ; } if ( b_ipiv [ 3 ] != 4 ) { smax = Y_data [ 3 ]
; Y_data [ 3 ] = Y_data [ b_ipiv [ 3 ] - 1 ] ; Y_data [ b_ipiv [ 3 ] - 1 ] =
smax ; } for ( c = 0 ; c < 5 ; c ++ ) { kAcol = 5 * c - 1 ; if ( Y_data [ c ]
!= 0.0 ) { for ( jA = c + 2 ; jA < 6 ; jA ++ ) { Y_data [ jA - 1 ] -= c_x [
jA + kAcol ] * Y_data [ c ] ; } } } for ( jA = 4 ; jA >= 0 ; jA -- ) { kAcol
= 5 * jA ; if ( Y_data [ jA ] != 0.0 ) { Y_data [ jA ] /= c_x [ jA + kAcol ]
; iy = jA - 1 ; for ( c = 0 ; c <= iy ; c ++ ) { Y_data [ c ] -= c_x [ c +
kAcol ] * Y_data [ jA ] ; } } } } static void pvxko1qdkz0 ( real_T in1_data [
] , int32_T * in1_size , const moo4o4s0qn * in2 , real_T in3 , const real_T
in4 [ 25 ] , const moo4o4s0qn * in5 ) { real_T in2_p [ 25 ] ; int32_T aux_0_1
; int32_T i ; int32_T i_p ; int32_T stride_0_0 ; int32_T stride_0_1 ;
stride_0_0 = ( in2 -> size [ 0 ] != 1 ) ; stride_0_1 = ( in2 -> size [ 1 ] !=
1 ) ; aux_0_1 = 0 ; for ( i_p = 0 ; i_p < 5 ; i_p ++ ) { for ( i = 0 ; i < 5
; i ++ ) { in2_p [ i + 5 * i_p ] = - ( in4 [ 5 * i_p + i ] * in3 + in2 ->
data [ i * stride_0_0 + in2 -> size [ 0 ] * aux_0_1 ] ) ; } aux_0_1 +=
stride_0_1 ; } iah2jhz5bn ( in2_p , in5 , in1_data , in1_size ) ; } static
void fkw0vbtdcb ( const moo4o4s0qn * a , const real_T b [ 5 ] , real_T c [ 5
] ) { int32_T acoef ; int32_T k ; acoef = ( a -> size [ 0 ] != 1 ) ; for ( k
= 0 ; k < 5 ; k ++ ) { c [ k ] = muDoubleScalarMax ( a -> data [ acoef * k ]
, b [ k ] ) ; } } static void cwpeqyyhqy ( const moo4o4s0qn * a , const
real_T b [ 5 ] , real_T c [ 5 ] ) { int32_T acoef ; int32_T k ; acoef = ( a
-> size [ 0 ] != 1 ) ; for ( k = 0 ; k < 5 ; k ++ ) { c [ k ] =
muDoubleScalarMin ( a -> data [ acoef * k ] , b [ k ] ) ; } } static void
b1xdicvyah ( itipyws4dn * * pEmxArray ) { if ( * pEmxArray != ( itipyws4dn *
) NULL ) { if ( ( ( * pEmxArray ) -> data != ( boolean_T * ) NULL ) && ( *
pEmxArray ) -> canFreeData ) { free ( ( * pEmxArray ) -> data ) ; } free ( (
* pEmxArray ) -> size ) ; free ( * pEmxArray ) ; * pEmxArray = ( itipyws4dn *
) NULL ; } } static void jfs5omen4s ( pmprofizlh * obj , real_T xSol [ 5 ] ,
iu3zpbmgcw * exitFlag , real_T * en , real_T * iter ) { e2b0f4s35s * bodyName
; itgfp4rmev * treeInternal ; itipyws4dn * x_p ; l2t3f2z1w3 * args ;
moo4o4s0qn * H0 ; moo4o4s0qn * J ; moo4o4s0qn * b ; moo4o4s0qn * ev ;
moo4o4s0qn * evprev ; moo4o4s0qn * grad ; moo4o4s0qn * tmp ; moo4o4s0qn * y ;
real_T a [ 36 ] ; real_T weightMatrix [ 36 ] ; real_T T_data [ 16 ] ; real_T
Td [ 16 ] ; real_T e [ 6 ] ; real_T step_data [ 5 ] ; real_T xprev [ 5 ] ;
real_T y_p [ 5 ] ; real_T absxk ; real_T cc ; real_T cost ; real_T d ; real_T
scale ; real_T t ; int32_T aoffset ; int32_T b_i ; int32_T boffset ; int32_T
coffset ; int32_T i ; int32_T m ; boolean_T x [ 5 ] ; boolean_T flag ; static
const real_T tmp_p [ 25 ] = { 1.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 1.0 , 0.0 ,
0.0 , 0.0 , 0.0 , 0.0 , 1.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 1.0 , 0.0 , 0.0 ,
0.0 , 0.0 , 0.0 , 1.0 } ; moo4o4s0qn * J_p ; real_T H0_p [ 25 ] ; real_T e_p
[ 6 ] ; int32_T T_size [ 2 ] ; int32_T J_e ; int32_T exitg1 ; int32_T loop_ub
; int32_T step_size ; boolean_T exitg2 ; boolean_T guard1 = false ; boolean_T
guard2 = false ; for ( i = 0 ; i < 5 ; i ++ ) { xSol [ i ] = obj ->
SeedInternal [ i ] ; } or5i2fegiq ( & obj -> TimeObjInternal . StartTime .
tv_sec , & obj -> TimeObjInternal . StartTime . tv_nsec ) ; for ( i = 0 ; i <
5 ; i ++ ) { xprev [ i ] = xSol [ i ] ; } gunzkbl0qg ( & bodyName , 2 ) ;
args = obj -> ExtraArgs ; treeInternal = args -> Robot ; J_e = bodyName ->
size [ 0 ] * bodyName -> size [ 1 ] ; bodyName -> size [ 0 ] = 1 ; bodyName
-> size [ 1 ] = args -> BodyName -> size [ 1 ] ; ac0ugu5nlz ( bodyName , J_e
) ; loop_ub = args -> BodyName -> size [ 1 ] - 1 ; for ( i = 0 ; i <= loop_ub
; i ++ ) { bodyName -> data [ i ] = args -> BodyName -> data [ i ] ; } for (
i = 0 ; i < 16 ; i ++ ) { Td [ i ] = args -> Tform [ i ] ; } for ( i = 0 ; i
< 36 ; i ++ ) { weightMatrix [ i ] = args -> WeightMatrix [ i ] ; }
cy4r1g1cm1 ( & J , 2 ) ; kyxgrilagz ( treeInternal , xSol , bodyName , T_data
, T_size , J ) ; d3njpynb5n ( Td , T_data , T_size , e ) ; J_e = args ->
ErrTemp -> size [ 0 ] ; args -> ErrTemp -> size [ 0 ] = 6 ; ier0p3wwtw ( args
-> ErrTemp , J_e ) ; for ( i = 0 ; i < 6 ; i ++ ) { args -> ErrTemp -> data [
i ] = e [ i ] ; } scale = 0.0 ; for ( i = 0 ; i < 6 ; i ++ ) { e_p [ i ] =
0.0 ; for ( loop_ub = 0 ; loop_ub < 6 ; loop_ub ++ ) { e_p [ i ] +=
weightMatrix [ 6 * i + loop_ub ] * ( 0.5 * e [ loop_ub ] ) ; } scale += e_p [
i ] * e [ i ] ; } args -> CostTemp = scale ; for ( i = 0 ; i < 6 ; i ++ ) {
e_p [ i ] = 0.0 ; for ( loop_ub = 0 ; loop_ub < 6 ; loop_ub ++ ) { e_p [ i ]
+= weightMatrix [ 6 * i + loop_ub ] * e [ loop_ub ] ; } } cy4r1g1cm1 ( & J_p
, 2 ) ; J_e = J_p -> size [ 0 ] * J_p -> size [ 1 ] ; J_p -> size [ 0 ] = 6 ;
J_p -> size [ 1 ] = J -> size [ 1 ] ; ier0p3wwtw ( J_p , J_e ) ; loop_ub = 6
* J -> size [ 1 ] ; for ( i = 0 ; i < loop_ub ; i ++ ) { J_p -> data [ i ] =
- J -> data [ i ] ; } cy4r1g1cm1 ( & tmp , 2 ) ; knqlderc2umb ( e_p , J_p ,
tmp ) ; J_e = args -> GradTemp -> size [ 0 ] ; args -> GradTemp -> size [ 0 ]
= tmp -> size [ 1 ] ; ier0p3wwtw ( args -> GradTemp , J_e ) ; loop_ub = tmp
-> size [ 1 ] ; for ( i = 0 ; i < loop_ub ; i ++ ) { args -> GradTemp -> data
[ i ] = tmp -> data [ i ] ; } cy4r1g1cm1 ( & evprev , 1 ) ; obj -> ExtraArgs
= args ; args = obj -> ExtraArgs ; J_e = evprev -> size [ 0 ] ; evprev ->
size [ 0 ] = args -> ErrTemp -> size [ 0 ] ; ier0p3wwtw ( evprev , J_e ) ;
loop_ub = args -> ErrTemp -> size [ 0 ] ; for ( i = 0 ; i < loop_ub ; i ++ )
{ evprev -> data [ i ] = args -> ErrTemp -> data [ i ] ; } d = obj ->
MaxNumIterationInternal ; b_i = 0 ; cy4r1g1cm1 ( & grad , 1 ) ; cy4r1g1cm1 (
& H0 , 2 ) ; cy4r1g1cm1 ( & ev , 1 ) ; cy4r1g1cm1 ( & y , 2 ) ; cy4r1g1cm1 (
& b , 1 ) ; mp1kcw5ibf ( & x_p , 1 ) ; do { exitg1 = 0 ; if ( b_i <= (
int32_T ) d - 1 ) { args = obj -> ExtraArgs ; treeInternal = args -> Robot ;
J_e = bodyName -> size [ 0 ] * bodyName -> size [ 1 ] ; bodyName -> size [ 0
] = 1 ; bodyName -> size [ 1 ] = args -> BodyName -> size [ 1 ] ; ac0ugu5nlz
( bodyName , J_e ) ; loop_ub = args -> BodyName -> size [ 1 ] - 1 ; for ( i =
0 ; i <= loop_ub ; i ++ ) { bodyName -> data [ i ] = args -> BodyName -> data
[ i ] ; } for ( i = 0 ; i < 16 ; i ++ ) { Td [ i ] = args -> Tform [ i ] ; }
for ( i = 0 ; i < 36 ; i ++ ) { weightMatrix [ i ] = args -> WeightMatrix [ i
] ; } kyxgrilagz ( treeInternal , xSol , bodyName , T_data , T_size , J ) ;
J_e = J_p -> size [ 0 ] * J_p -> size [ 1 ] ; J_p -> size [ 0 ] = 6 ; J_p ->
size [ 1 ] = J -> size [ 1 ] ; ier0p3wwtw ( J_p , J_e ) ; loop_ub = 6 * J ->
size [ 1 ] ; for ( i = 0 ; i < loop_ub ; i ++ ) { J_p -> data [ i ] = - J ->
data [ i ] ; } d3njpynb5n ( Td , T_data , T_size , e ) ; J_e = args ->
ErrTemp -> size [ 0 ] ; args -> ErrTemp -> size [ 0 ] = 6 ; ier0p3wwtw ( args
-> ErrTemp , J_e ) ; for ( i = 0 ; i < 6 ; i ++ ) { args -> ErrTemp -> data [
i ] = e [ i ] ; } scale = 0.0 ; for ( i = 0 ; i < 6 ; i ++ ) { e_p [ i ] =
0.0 ; for ( loop_ub = 0 ; loop_ub < 6 ; loop_ub ++ ) { e_p [ i ] +=
weightMatrix [ 6 * i + loop_ub ] * ( 0.5 * e [ loop_ub ] ) ; } scale += e_p [
i ] * e [ i ] ; } args -> CostTemp = scale ; for ( i = 0 ; i < 6 ; i ++ ) {
e_p [ i ] = 0.0 ; for ( loop_ub = 0 ; loop_ub < 6 ; loop_ub ++ ) { e_p [ i ]
+= weightMatrix [ 6 * i + loop_ub ] * e [ loop_ub ] ; } } knqlderc2umb ( e_p
, J_p , tmp ) ; J_e = args -> GradTemp -> size [ 0 ] ; args -> GradTemp ->
size [ 0 ] = tmp -> size [ 1 ] ; ier0p3wwtw ( args -> GradTemp , J_e ) ;
loop_ub = tmp -> size [ 1 ] ; for ( i = 0 ; i < loop_ub ; i ++ ) { args ->
GradTemp -> data [ i ] = tmp -> data [ i ] ; } cost = args -> CostTemp ; obj
-> ExtraArgs = args ; args = obj -> ExtraArgs ; J_e = grad -> size [ 0 ] ;
grad -> size [ 0 ] = args -> GradTemp -> size [ 0 ] ; ier0p3wwtw ( grad , J_e
) ; loop_ub = args -> GradTemp -> size [ 0 ] ; for ( i = 0 ; i < loop_ub ; i
++ ) { grad -> data [ i ] = args -> GradTemp -> data [ i ] ; } args = obj ->
ExtraArgs ; for ( i = 0 ; i < 36 ; i ++ ) { a [ i ] = args -> WeightMatrix [
i ] ; } J_e = b -> size [ 0 ] ; b -> size [ 0 ] = args -> ErrTemp -> size [ 0
] ; ier0p3wwtw ( b , J_e ) ; loop_ub = args -> ErrTemp -> size [ 0 ] ; for (
i = 0 ; i < loop_ub ; i ++ ) { b -> data [ i ] = args -> ErrTemp -> data [ i
] ; } J_e = ev -> size [ 0 ] ; ev -> size [ 0 ] = args -> ErrTemp -> size [ 0
] ; ier0p3wwtw ( ev , J_e ) ; loop_ub = args -> ErrTemp -> size [ 0 ] ; for (
i = 0 ; i < loop_ub ; i ++ ) { ev -> data [ i ] = args -> ErrTemp -> data [ i
] ; } for ( i = 0 ; i < 6 ; i ++ ) { e [ i ] = 0.0 ; for ( loop_ub = 0 ;
loop_ub < 6 ; loop_ub ++ ) { e [ i ] += a [ 6 * loop_ub + i ] * b -> data [
loop_ub ] ; } } * en = b2cutvohzkb ( e ) ; * iter = ( real_T ) b_i + 1.0 ; if
( grad -> size [ 0 ] == 0 ) { cc = 0.0 ; } else { cc = 0.0 ; if ( grad ->
size [ 0 ] == 1 ) { cc = muDoubleScalarAbs ( grad -> data [ 0 ] ) ; } else {
scale = 3.3121686421112381E-170 ; i = grad -> size [ 0 ] - 1 ; for ( loop_ub
= 0 ; loop_ub <= i ; loop_ub ++ ) { absxk = muDoubleScalarAbs ( grad -> data
[ loop_ub ] ) ; if ( absxk > scale ) { t = scale / absxk ; cc = cc * t * t +
1.0 ; scale = absxk ; } else { t = absxk / scale ; cc += t * t ; } } cc =
scale * muDoubleScalarSqrt ( cc ) ; } } flag = ( cc < obj ->
GradientTolerance ) ; if ( flag ) { * exitFlag =
robotics_core_internal_NLPSolverExitFlags_LocalMinimumFound ; exitg1 = 1 ; }
else { guard1 = false ; guard2 = false ; if ( ( real_T ) b_i + 1.0 > 1.0 ) {
for ( loop_ub = 0 ; loop_ub < 5 ; loop_ub ++ ) { cc = xSol [ loop_ub ] -
xprev [ loop_ub ] ; y_p [ loop_ub ] = muDoubleScalarAbs ( cc ) ; xprev [
loop_ub ] = cc ; } for ( i = 0 ; i < 5 ; i ++ ) { x [ i ] = ( y_p [ i ] < obj
-> StepTolerance ) ; } flag = true ; loop_ub = 0 ; exitg2 = false ; while ( (
! exitg2 ) && ( loop_ub < 5 ) ) { if ( ! x [ loop_ub ] ) { flag = false ;
exitg2 = true ; } else { loop_ub ++ ; } } if ( flag ) { * exitFlag =
robotics_core_internal_NLPSolverExitFlags_StepSizeBelowMinimum ; exitg1 = 1 ;
} else { guard2 = true ; } } else { guard2 = true ; } if ( guard2 ) { if ( (
real_T ) b_i + 1.0 > 1.0 ) { if ( ev -> size [ 0 ] == evprev -> size [ 0 ] )
{ J_e = evprev -> size [ 0 ] ; evprev -> size [ 0 ] = ev -> size [ 0 ] ;
ier0p3wwtw ( evprev , J_e ) ; loop_ub = ev -> size [ 0 ] ; for ( i = 0 ; i <
loop_ub ; i ++ ) { evprev -> data [ i ] = ev -> data [ i ] - evprev -> data [
i ] ; } } else { h2drfin2nju ( evprev , ev ) ; } i = evprev -> size [ 0 ] - 1
; J_e = b -> size [ 0 ] ; b -> size [ 0 ] = evprev -> size [ 0 ] ; ier0p3wwtw
( b , J_e ) ; for ( loop_ub = 0 ; loop_ub <= i ; loop_ub ++ ) { b -> data [
loop_ub ] = muDoubleScalarAbs ( evprev -> data [ loop_ub ] ) ; } J_e = x_p ->
size [ 0 ] ; x_p -> size [ 0 ] = b -> size [ 0 ] ; iue3n2dlds ( x_p , J_e ) ;
loop_ub = b -> size [ 0 ] ; for ( i = 0 ; i < loop_ub ; i ++ ) { x_p -> data
[ i ] = ( b -> data [ i ] < obj -> ErrorChangeTolerance ) ; } flag = true ;
loop_ub = 0 ; exitg2 = false ; while ( ( ! exitg2 ) && ( loop_ub + 1 <= x_p
-> size [ 0 ] ) ) { if ( ! x_p -> data [ loop_ub ] ) { flag = false ; exitg2
= true ; } else { loop_ub ++ ; } } if ( flag ) { * exitFlag =
robotics_core_internal_NLPSolverExitFlags_ChangeInErrorBelowMinimum ; exitg1
= 1 ; } else { guard1 = true ; } } else { guard1 = true ; } } if ( guard1 ) {
cc = b43ytoj3db ( obj -> TimeObjInternal . StartTime . tv_sec , obj ->
TimeObjInternal . StartTime . tv_nsec ) ; flag = ( cc > obj ->
MaxTimeInternal ) ; if ( flag ) { * exitFlag =
robotics_core_internal_NLPSolverExitFlags_TimeLimitExceeded ; exitg1 = 1 ; }
else { J_e = evprev -> size [ 0 ] ; evprev -> size [ 0 ] = ev -> size [ 0 ] ;
ier0p3wwtw ( evprev , J_e ) ; loop_ub = ev -> size [ 0 ] ; if ( loop_ub - 1
>= 0 ) { memcpy ( & evprev -> data [ 0 ] , & ev -> data [ 0 ] , loop_ub *
sizeof ( real_T ) ) ; } for ( i = 0 ; i < 5 ; i ++ ) { xprev [ i ] = xSol [ i
] ; } flag = obj -> UseErrorDamping ; cc = ( real_T ) flag * cost ; scale =
cc + obj -> DampingBias ; m = J_p -> size [ 1 ] ; J_e = y -> size [ 0 ] * y
-> size [ 1 ] ; y -> size [ 0 ] = J_p -> size [ 1 ] ; y -> size [ 1 ] = 6 ;
ier0p3wwtw ( y , J_e ) ; for ( i = 0 ; i < 6 ; i ++ ) { coffset = i * m - 1 ;
boffset = i * 6 - 1 ; for ( J_e = 0 ; J_e < m ; J_e ++ ) { aoffset = J_e * 6
- 1 ; absxk = 0.0 ; for ( loop_ub = 0 ; loop_ub < 6 ; loop_ub ++ ) { absxk +=
J_p -> data [ ( loop_ub + aoffset ) + 1 ] * weightMatrix [ ( loop_ub +
boffset ) + 1 ] ; } y -> data [ ( coffset + J_e ) + 1 ] = absxk ; } } m = y
-> size [ 0 ] ; aoffset = J_p -> size [ 1 ] - 1 ; J_e = H0 -> size [ 0 ] * H0
-> size [ 1 ] ; H0 -> size [ 0 ] = y -> size [ 0 ] ; H0 -> size [ 1 ] = J_p
-> size [ 1 ] ; ier0p3wwtw ( H0 , J_e ) ; for ( i = 0 ; i <= aoffset ; i ++ )
{ coffset = i * m - 1 ; boffset = i * 6 - 1 ; for ( J_e = 0 ; J_e < m ; J_e
++ ) { absxk = 0.0 ; for ( loop_ub = 0 ; loop_ub < 6 ; loop_ub ++ ) { absxk
+= y -> data [ loop_ub * y -> size [ 0 ] + J_e ] * J_p -> data [ ( boffset +
loop_ub ) + 1 ] ; } H0 -> data [ ( coffset + J_e ) + 1 ] = absxk ; } } if ( (
H0 -> size [ 0 ] == 5 ) && ( H0 -> size [ 1 ] == 5 ) ) { for ( i = 0 ; i < 5
; i ++ ) { for ( loop_ub = 0 ; loop_ub < 5 ; loop_ub ++ ) { H0_p [ loop_ub +
5 * i ] = - ( tmp_p [ 5 * i + loop_ub ] * scale + H0 -> data [ H0 -> size [ 0
] * i + loop_ub ] ) ; } } iah2jhz5bn ( H0_p , grad , step_data , & step_size
) ; } else { pvxko1qdkz0 ( step_data , & step_size , H0 , scale , tmp_p ,
grad ) ; } args = obj -> ExtraArgs ; treeInternal = args -> Robot ; J_e =
bodyName -> size [ 0 ] * bodyName -> size [ 1 ] ; bodyName -> size [ 0 ] = 1
; bodyName -> size [ 1 ] = args -> BodyName -> size [ 1 ] ; ac0ugu5nlz (
bodyName , J_e ) ; loop_ub = args -> BodyName -> size [ 1 ] - 1 ; for ( i = 0
; i <= loop_ub ; i ++ ) { bodyName -> data [ i ] = args -> BodyName -> data [
i ] ; } for ( i = 0 ; i < 16 ; i ++ ) { Td [ i ] = args -> Tform [ i ] ; }
for ( i = 0 ; i < 36 ; i ++ ) { weightMatrix [ i ] = args -> WeightMatrix [ i
] ; } for ( i = 0 ; i < 5 ; i ++ ) { y_p [ i ] = xSol [ i ] + step_data [ i ]
; } kyxgrilagz ( treeInternal , y_p , bodyName , T_data , T_size , J ) ;
d3njpynb5n ( Td , T_data , T_size , e ) ; J_e = args -> ErrTemp -> size [ 0 ]
; args -> ErrTemp -> size [ 0 ] = 6 ; ier0p3wwtw ( args -> ErrTemp , J_e ) ;
for ( i = 0 ; i < 6 ; i ++ ) { args -> ErrTemp -> data [ i ] = e [ i ] ; }
scale = 0.0 ; for ( i = 0 ; i < 6 ; i ++ ) { e_p [ i ] = 0.0 ; for ( loop_ub
= 0 ; loop_ub < 6 ; loop_ub ++ ) { e_p [ i ] += weightMatrix [ 6 * i +
loop_ub ] * ( 0.5 * e [ loop_ub ] ) ; } scale += e_p [ i ] * e [ i ] ; } args
-> CostTemp = scale ; for ( i = 0 ; i < 6 ; i ++ ) { e_p [ i ] = 0.0 ; for (
loop_ub = 0 ; loop_ub < 6 ; loop_ub ++ ) { e_p [ i ] += weightMatrix [ 6 * i
+ loop_ub ] * e [ loop_ub ] ; } } J_e = J_p -> size [ 0 ] * J_p -> size [ 1 ]
; J_p -> size [ 0 ] = 6 ; J_p -> size [ 1 ] = J -> size [ 1 ] ; ier0p3wwtw (
J_p , J_e ) ; loop_ub = 6 * J -> size [ 1 ] ; for ( i = 0 ; i < loop_ub ; i
++ ) { J_p -> data [ i ] = - J -> data [ i ] ; } knqlderc2umb ( e_p , J_p ,
tmp ) ; J_e = args -> GradTemp -> size [ 0 ] ; args -> GradTemp -> size [ 0 ]
= tmp -> size [ 1 ] ; ier0p3wwtw ( args -> GradTemp , J_e ) ; loop_ub = tmp
-> size [ 1 ] ; for ( i = 0 ; i < loop_ub ; i ++ ) { args -> GradTemp -> data
[ i ] = tmp -> data [ i ] ; } scale = args -> CostTemp ; absxk = 1.0 ; while
( scale > cost ) { absxk *= 2.5 ; scale = absxk * obj -> DampingBias + cc ;
if ( ( H0 -> size [ 0 ] == 5 ) && ( H0 -> size [ 1 ] == 5 ) ) { for ( i = 0 ;
i < 5 ; i ++ ) { for ( loop_ub = 0 ; loop_ub < 5 ; loop_ub ++ ) { H0_p [
loop_ub + 5 * i ] = - ( tmp_p [ 5 * i + loop_ub ] * scale + H0 -> data [ H0
-> size [ 0 ] * i + loop_ub ] ) ; } } iah2jhz5bn ( H0_p , grad , step_data ,
& step_size ) ; } else { pvxko1qdkz0 ( step_data , & step_size , H0 , scale ,
tmp_p , grad ) ; } args = obj -> ExtraArgs ; treeInternal = args -> Robot ;
J_e = bodyName -> size [ 0 ] * bodyName -> size [ 1 ] ; bodyName -> size [ 0
] = 1 ; bodyName -> size [ 1 ] = args -> BodyName -> size [ 1 ] ; ac0ugu5nlz
( bodyName , J_e ) ; loop_ub = args -> BodyName -> size [ 1 ] - 1 ; for ( i =
0 ; i <= loop_ub ; i ++ ) { bodyName -> data [ i ] = args -> BodyName -> data
[ i ] ; } for ( i = 0 ; i < 16 ; i ++ ) { Td [ i ] = args -> Tform [ i ] ; }
for ( i = 0 ; i < 36 ; i ++ ) { weightMatrix [ i ] = args -> WeightMatrix [ i
] ; } for ( i = 0 ; i < 5 ; i ++ ) { y_p [ i ] = xSol [ i ] + step_data [ i ]
; } kyxgrilagz ( treeInternal , y_p , bodyName , T_data , T_size , J ) ;
d3njpynb5n ( Td , T_data , T_size , e ) ; J_e = args -> ErrTemp -> size [ 0 ]
; args -> ErrTemp -> size [ 0 ] = 6 ; ier0p3wwtw ( args -> ErrTemp , J_e ) ;
for ( i = 0 ; i < 6 ; i ++ ) { args -> ErrTemp -> data [ i ] = e [ i ] ; }
scale = 0.0 ; for ( i = 0 ; i < 6 ; i ++ ) { e_p [ i ] = 0.0 ; for ( loop_ub
= 0 ; loop_ub < 6 ; loop_ub ++ ) { e_p [ i ] += weightMatrix [ 6 * i +
loop_ub ] * ( 0.5 * e [ loop_ub ] ) ; } scale += e_p [ i ] * e [ i ] ; } args
-> CostTemp = scale ; for ( i = 0 ; i < 6 ; i ++ ) { e_p [ i ] = 0.0 ; for (
loop_ub = 0 ; loop_ub < 6 ; loop_ub ++ ) { e_p [ i ] += weightMatrix [ 6 * i
+ loop_ub ] * e [ loop_ub ] ; } } J_e = J_p -> size [ 0 ] * J_p -> size [ 1 ]
; J_p -> size [ 0 ] = 6 ; J_p -> size [ 1 ] = J -> size [ 1 ] ; ier0p3wwtw (
J_p , J_e ) ; loop_ub = 6 * J -> size [ 1 ] ; for ( i = 0 ; i < loop_ub ; i
++ ) { J_p -> data [ i ] = - J -> data [ i ] ; } knqlderc2umb ( e_p , J_p ,
tmp ) ; J_e = args -> GradTemp -> size [ 0 ] ; args -> GradTemp -> size [ 0 ]
= tmp -> size [ 1 ] ; ier0p3wwtw ( args -> GradTemp , J_e ) ; loop_ub = tmp
-> size [ 1 ] ; for ( i = 0 ; i < loop_ub ; i ++ ) { args -> GradTemp -> data
[ i ] = tmp -> data [ i ] ; } scale = args -> CostTemp ; } for ( i = 0 ; i <
5 ; i ++ ) { xSol [ i ] += step_data [ i ] ; } if ( obj -> ConstraintsOn ) {
args = obj -> ExtraArgs ; loop_ub = args -> Limits -> size [ 0 ] ; J_e = grad
-> size [ 0 ] ; grad -> size [ 0 ] = loop_ub ; ier0p3wwtw ( grad , J_e ) ;
for ( i = 0 ; i < loop_ub ; i ++ ) { grad -> data [ i ] = args -> Limits ->
data [ i ] ; } if ( grad -> size [ 0 ] == 5 ) { for ( loop_ub = 0 ; loop_ub <
5 ; loop_ub ++ ) { y_p [ loop_ub ] = muDoubleScalarMax ( grad -> data [
loop_ub ] , xSol [ loop_ub ] ) ; } } else { fkw0vbtdcb ( grad , xSol , y_p )
; } loop_ub = args -> Limits -> size [ 0 ] ; J_e = grad -> size [ 0 ] ; grad
-> size [ 0 ] = loop_ub ; ier0p3wwtw ( grad , J_e ) ; for ( i = 0 ; i <
loop_ub ; i ++ ) { grad -> data [ i ] = args -> Limits -> data [ i + args ->
Limits -> size [ 0 ] ] ; } if ( grad -> size [ 0 ] == 5 ) { for ( loop_ub = 0
; loop_ub < 5 ; loop_ub ++ ) { xSol [ loop_ub ] = muDoubleScalarMin ( grad ->
data [ loop_ub ] , y_p [ loop_ub ] ) ; } } else { cwpeqyyhqy ( grad , y_p ,
xSol ) ; } } b_i ++ ; } } } } else { args = obj -> ExtraArgs ; for ( i = 0 ;
i < 36 ; i ++ ) { a [ i ] = args -> WeightMatrix [ i ] ; } J_e = b -> size [
0 ] ; b -> size [ 0 ] = args -> ErrTemp -> size [ 0 ] ; ier0p3wwtw ( b , J_e
) ; loop_ub = args -> ErrTemp -> size [ 0 ] ; for ( i = 0 ; i < loop_ub ; i
++ ) { b -> data [ i ] = args -> ErrTemp -> data [ i ] ; } for ( i = 0 ; i <
6 ; i ++ ) { e [ i ] = 0.0 ; for ( loop_ub = 0 ; loop_ub < 6 ; loop_ub ++ ) {
e [ i ] += a [ 6 * loop_ub + i ] * b -> data [ loop_ub ] ; } } * en =
b2cutvohzkb ( e ) ; * iter = obj -> MaxNumIterationInternal ; * exitFlag =
robotics_core_internal_NLPSolverExitFlags_IterationLimitExceeded ; exitg1 = 1
; } } while ( exitg1 == 0 ) ; njzmd0hlqd ( & J_p ) ; njzmd0hlqd ( & tmp ) ;
b1xdicvyah ( & x_p ) ; njzmd0hlqd ( & b ) ; njzmd0hlqd ( & J ) ; b0l0vcvht3 (
& bodyName ) ; njzmd0hlqd ( & y ) ; njzmd0hlqd ( & ev ) ; njzmd0hlqd ( & H0 )
; njzmd0hlqd ( & grad ) ; njzmd0hlqd ( & evprev ) ; } static boolean_T
himifevlz1 ( const itipyws4dn * x ) { int32_T ix ; boolean_T exitg1 ;
boolean_T y ; y = false ; ix = 0 ; exitg1 = false ; while ( ( ! exitg1 ) && (
ix + 1 <= x -> size [ 0 ] ) ) { if ( x -> data [ ix ] ) { y = true ; exitg1 =
true ; } else { ix ++ ; } } return y ; } static void h3f52mmr1n ( const
real_T varargin_1 [ 2 ] , moo4o4s0qn * r ) { real_T xi [ 257 ] ; real_T b_r ;
real_T d_u ; real_T x ; int32_T b_k ; int32_T d ; int32_T i ; uint32_T u32 [
2 ] ; static const real_T tmp [ 257 ] = { 1.0 , 0.977101701267673 ,
0.959879091800108 , 0.9451989534423 , 0.932060075959231 , 0.919991505039348 ,
0.908726440052131 , 0.898095921898344 , 0.887984660755834 , 0.878309655808918
, 0.869008688036857 , 0.860033621196332 , 0.851346258458678 ,
0.842915653112205 , 0.834716292986884 , 0.826726833946222 , 0.818929191603703
, 0.811307874312656 , 0.803849483170964 , 0.796542330422959 ,
0.789376143566025 , 0.782341832654803 , 0.775431304981187 , 0.768637315798486
, 0.761953346836795 , 0.755373506507096 , 0.748892447219157 ,
0.742505296340151 , 0.736207598126863 , 0.729995264561476 , 0.72386453346863
, 0.717811932630722 , 0.711834248878248 , 0.705928501332754 ,
0.700091918136512 , 0.694321916126117 , 0.688616083004672 , 0.682972161644995
, 0.677388036218774 , 0.671861719897082 , 0.66639134390875 ,
0.660975147776663 , 0.655611470579697 , 0.650298743110817 , 0.645035480820822
, 0.639820277453057 , 0.634651799287624 , 0.629528779924837 ,
0.624450015547027 , 0.619414360605834 , 0.614420723888914 , 0.609468064925773
, 0.604555390697468 , 0.599681752619125 , 0.594846243767987 ,
0.590047996332826 , 0.585286179263371 , 0.580559996100791 , 0.575868682972354
, 0.571211506735253 , 0.566587763256165 , 0.561996775814525 ,
0.557437893618766 , 0.552910490425833 , 0.548413963255266 , 0.543947731190026
, 0.539511234256952 , 0.535103932380458 , 0.530725304403662 ,
0.526374847171684 , 0.522052074672322 , 0.517756517229756 , 0.513487720747327
, 0.509245245995748 , 0.505028667943468 , 0.500837575126149 ,
0.49667156905249 , 0.492530263643869 , 0.488413284705458 , 0.484320269426683
, 0.480250865909047 , 0.476204732719506 , 0.47218153846773 ,
0.468180961405694 , 0.464202689048174 , 0.460246417812843 , 0.456311852678716
, 0.452398706861849 , 0.448506701507203 , 0.444635565395739 ,
0.440785034665804 , 0.436954852547985 , 0.433144769112652 , 0.429354541029442
, 0.425583931338022 , 0.421832709229496 , 0.418100649837848 ,
0.414387534040891 , 0.410693148270188 , 0.407017284329473 , 0.403359739221114
, 0.399720314980197 , 0.396098818515832 , 0.392495061459315 ,
0.388908860018789 , 0.385340034840077 , 0.381788410873393 , 0.378253817245619
, 0.374736087137891 , 0.371235057668239 , 0.367750569779032 ,
0.364282468129004 , 0.360830600989648 , 0.357394820145781 , 0.353974980800077
, 0.350570941481406 , 0.347182563956794 , 0.343809713146851 ,
0.340452257044522 , 0.337110066637006 , 0.333783015830718 , 0.330470981379163
, 0.327173842813601 , 0.323891482376391 , 0.320623784956905 ,
0.317370638029914 , 0.314131931596337 , 0.310907558126286 , 0.307697412504292
, 0.30450139197665 , 0.301319396100803 , 0.298151326696685 ,
0.294997087799962 , 0.291856585617095 , 0.288729728482183 , 0.285616426815502
, 0.282516593083708 , 0.279430141761638 , 0.276356989295668 ,
0.273297054068577 , 0.270250256365875 , 0.267216518343561 , 0.264195763997261
, 0.261187919132721 , 0.258192911337619 , 0.255210669954662 ,
0.252241126055942 , 0.249284212418529 , 0.246339863501264 , 0.24340801542275
, 0.240488605940501 , 0.237581574431238 , 0.23468686187233 ,
0.231804410824339 , 0.228934165414681 , 0.226076071322381 , 0.223230075763918
, 0.220396127480152 , 0.217574176724331 , 0.214764175251174 ,
0.211966076307031 , 0.209179834621125 , 0.206405406397881 , 0.203642749310335
, 0.200891822494657 , 0.198152586545776 , 0.195425003514135 ,
0.192709036903589 , 0.190004651670465 , 0.187311814223801 , 0.1846304924268 ,
0.181960655599523 , 0.179302274522848 , 0.176655321443735 , 0.174019770081839
, 0.171395595637506 , 0.168782774801212 , 0.166181285764482 ,
0.163591108232366 , 0.161012223437511 , 0.158444614155925 , 0.15588826472448
, 0.153343161060263 , 0.150809290681846 , 0.148286642732575 ,
0.145775208005994 , 0.143274978973514 , 0.140785949814445 , 0.138308116448551
, 0.135841476571254 , 0.133386029691669 , 0.130941777173644 , 0.12850872228 ,
0.126086870220186 , 0.123676228201597 , 0.12127680548479 , 0.11888861344291 ,
0.116511665625611 , 0.114145977827839 , 0.111791568163838 , 0.109448457146812
, 0.107116667774684 , 0.104796225622487 , 0.102487158941935 ,
0.10018949876881 , 0.0979032790388625 , 0.095628536713009 , 0.093365311912691
, 0.0911136480663738 , 0.0888735920682759 , 0.0866451944505581 ,
0.0844285095703535 , 0.082223595813203 , 0.0800305158146631 ,
0.0778493367020961 , 0.0756801303589272 , 0.0735229737139814 ,
0.0713779490588905 , 0.0692451443970068 , 0.0671246538277886 ,
0.065016577971243 , 0.0629210244377582 , 0.06083810834954 ,
0.0587679529209339 , 0.0567106901062031 , 0.0546664613248891 ,
0.0526354182767924 , 0.0506177238609479 , 0.0486135532158687 ,
0.0466230949019305 , 0.0446465522512946 , 0.0426841449164746 ,
0.0407361106559411 , 0.0388027074045262 , 0.0368842156885674 ,
0.0349809414617162 , 0.0330932194585786 , 0.0312214171919203 ,
0.0293659397581334 , 0.0275272356696031 , 0.0257058040085489 ,
0.0239022033057959 , 0.0221170627073089 , 0.0203510962300445 ,
0.0186051212757247 , 0.0168800831525432 , 0.0151770883079353 ,
0.0134974506017399 , 0.0118427578579079 , 0.0102149714397015 ,
0.00861658276939875 , 0.00705087547137324 , 0.00552240329925101 ,
0.00403797259336304 , 0.00260907274610216 , 0.0012602859304986 ,
0.000477467764609386 } ; const real_T * fitab ; int32_T exitg1 ; int32_T
exitg2 ; b_k = r -> size [ 0 ] ; r -> size [ 0 ] = ( int32_T ) varargin_1 [ 0
] ; ier0p3wwtw ( r , b_k ) ; d = ( int32_T ) varargin_1 [ 0 ] - 1 ; if ( (
int32_T ) varargin_1 [ 0 ] - 1 >= 0 ) { xi [ 0 ] = 0.0 ; xi [ 1 ] =
0.215241895984875 ; xi [ 2 ] = 0.286174591792068 ; xi [ 3 ] =
0.335737519214422 ; xi [ 4 ] = 0.375121332878378 ; xi [ 5 ] =
0.408389134611989 ; xi [ 6 ] = 0.43751840220787 ; xi [ 7 ] = 0.46363433679088
; xi [ 8 ] = 0.487443966139235 ; xi [ 9 ] = 0.50942332960209 ; xi [ 10 ] =
0.529909720661557 ; xi [ 11 ] = 0.549151702327164 ; xi [ 12 ] =
0.567338257053817 ; xi [ 13 ] = 0.584616766106378 ; xi [ 14 ] =
0.601104617755991 ; xi [ 15 ] = 0.61689699000775 ; xi [ 16 ] =
0.63207223638606 ; xi [ 17 ] = 0.646695714894993 ; xi [ 18 ] =
0.660822574244419 ; xi [ 19 ] = 0.674499822837293 ; xi [ 20 ] =
0.687767892795788 ; xi [ 21 ] = 0.700661841106814 ; xi [ 22 ] =
0.713212285190975 ; xi [ 23 ] = 0.725446140909999 ; xi [ 24 ] =
0.737387211434295 ; xi [ 25 ] = 0.749056662017815 ; xi [ 26 ] =
0.760473406430107 ; xi [ 27 ] = 0.771654424224568 ; xi [ 28 ] =
0.782615023307232 ; xi [ 29 ] = 0.793369058840623 ; xi [ 30 ] =
0.80392911698997 ; xi [ 31 ] = 0.814306670135215 ; xi [ 32 ] =
0.824512208752291 ; xi [ 33 ] = 0.834555354086381 ; xi [ 34 ] =
0.844444954909153 ; xi [ 35 ] = 0.854189171008163 ; xi [ 36 ] =
0.863795545553308 ; xi [ 37 ] = 0.87327106808886 ; xi [ 38 ] =
0.882622229585165 ; xi [ 39 ] = 0.891855070732941 ; xi [ 40 ] =
0.900975224461221 ; xi [ 41 ] = 0.909987953496718 ; xi [ 42 ] =
0.91889818364959 ; xi [ 43 ] = 0.927710533401999 ; xi [ 44 ] =
0.936429340286575 ; xi [ 45 ] = 0.945058684468165 ; xi [ 46 ] =
0.953602409881086 ; xi [ 47 ] = 0.96206414322304 ; xi [ 48 ] =
0.970447311064224 ; xi [ 49 ] = 0.978755155294224 ; xi [ 50 ] =
0.986990747099062 ; xi [ 51 ] = 0.99515699963509 ; xi [ 52 ] =
1.00325667954467 ; xi [ 53 ] = 1.01129241744 ; xi [ 54 ] = 1.01926671746548 ;
xi [ 55 ] = 1.02718196603564 ; xi [ 56 ] = 1.03504043983344 ; xi [ 57 ] =
1.04284431314415 ; xi [ 58 ] = 1.05059566459093 ; xi [ 59 ] =
1.05829648333067 ; xi [ 60 ] = 1.06594867476212 ; xi [ 61 ] =
1.07355406579244 ; xi [ 62 ] = 1.0811144097034 ; xi [ 63 ] = 1.08863139065398
; xi [ 64 ] = 1.09610662785202 ; xi [ 65 ] = 1.10354167942464 ; xi [ 66 ] =
1.11093804601357 ; xi [ 67 ] = 1.11829717411934 ; xi [ 68 ] =
1.12562045921553 ; xi [ 69 ] = 1.13290924865253 ; xi [ 70 ] =
1.14016484436815 ; xi [ 71 ] = 1.14738850542085 ; xi [ 72 ] =
1.15458145035993 ; xi [ 73 ] = 1.16174485944561 ; xi [ 74 ] =
1.16887987673083 ; xi [ 75 ] = 1.17598761201545 ; xi [ 76 ] =
1.18306914268269 ; xi [ 77 ] = 1.19012551542669 ; xi [ 78 ] =
1.19715774787944 ; xi [ 79 ] = 1.20416683014438 ; xi [ 80 ] = 1.2111537262437
; xi [ 81 ] = 1.21811937548548 ; xi [ 82 ] = 1.22506469375653 ; xi [ 83 ] =
1.23199057474614 ; xi [ 84 ] = 1.23889789110569 ; xi [ 85 ] =
1.24578749554863 ; xi [ 86 ] = 1.2526602218949 ; xi [ 87 ] = 1.25951688606371
; xi [ 88 ] = 1.26635828701823 ; xi [ 89 ] = 1.27318520766536 ; xi [ 90 ] =
1.27999841571382 ; xi [ 91 ] = 1.28679866449324 ; xi [ 92 ] =
1.29358669373695 ; xi [ 93 ] = 1.30036323033084 ; xi [ 94 ] =
1.30712898903073 ; xi [ 95 ] = 1.31388467315022 ; xi [ 96 ] =
1.32063097522106 ; xi [ 97 ] = 1.32736857762793 ; xi [ 98 ] =
1.33409815321936 ; xi [ 99 ] = 1.3408203658964 ; xi [ 100 ] =
1.34753587118059 ; xi [ 101 ] = 1.35424531676263 ; xi [ 102 ] =
1.36094934303328 ; xi [ 103 ] = 1.36764858359748 ; xi [ 104 ] =
1.37434366577317 ; xi [ 105 ] = 1.38103521107586 ; xi [ 106 ] =
1.38772383568998 ; xi [ 107 ] = 1.39441015092814 ; xi [ 108 ] =
1.40109476367925 ; xi [ 109 ] = 1.4077782768464 ; xi [ 110 ] =
1.41446128977547 ; xi [ 111 ] = 1.42114439867531 ; xi [ 112 ] =
1.42782819703026 ; xi [ 113 ] = 1.43451327600589 ; xi [ 114 ] =
1.44120022484872 ; xi [ 115 ] = 1.44788963128058 ; xi [ 116 ] =
1.45458208188841 ; xi [ 117 ] = 1.46127816251028 ; xi [ 118 ] =
1.46797845861808 ; xi [ 119 ] = 1.47468355569786 ; xi [ 120 ] =
1.48139403962819 ; xi [ 121 ] = 1.48811049705745 ; xi [ 122 ] =
1.49483351578049 ; xi [ 123 ] = 1.50156368511546 ; xi [ 124 ] =
1.50830159628131 ; xi [ 125 ] = 1.51504784277671 ; xi [ 126 ] =
1.521803020761 ; xi [ 127 ] = 1.52856772943771 ; xi [ 128 ] =
1.53534257144151 ; xi [ 129 ] = 1.542128153229 ; xi [ 130 ] =
1.54892508547417 ; xi [ 131 ] = 1.55573398346918 ; xi [ 132 ] =
1.56255546753104 ; xi [ 133 ] = 1.56939016341512 ; xi [ 134 ] =
1.57623870273591 ; xi [ 135 ] = 1.58310172339603 ; xi [ 136 ] =
1.58997987002419 ; xi [ 137 ] = 1.59687379442279 ; xi [ 138 ] =
1.60378415602609 ; xi [ 139 ] = 1.61071162236983 ; xi [ 140 ] =
1.61765686957301 ; xi [ 141 ] = 1.62462058283303 ; xi [ 142 ] =
1.63160345693487 ; xi [ 143 ] = 1.63860619677555 ; xi [ 144 ] =
1.64562951790478 ; xi [ 145 ] = 1.65267414708306 ; xi [ 146 ] =
1.65974082285818 ; xi [ 147 ] = 1.66683029616166 ; xi [ 148 ] =
1.67394333092612 ; xi [ 149 ] = 1.68108070472517 ; xi [ 150 ] =
1.68824320943719 ; xi [ 151 ] = 1.69543165193456 ; xi [ 152 ] =
1.70264685479992 ; xi [ 153 ] = 1.7098896570713 ; xi [ 154 ] =
1.71716091501782 ; xi [ 155 ] = 1.72446150294804 ; xi [ 156 ] =
1.73179231405296 ; xi [ 157 ] = 1.73915426128591 ; xi [ 158 ] =
1.74654827828172 ; xi [ 159 ] = 1.75397532031767 ; xi [ 160 ] =
1.76143636531891 ; xi [ 161 ] = 1.76893241491127 ; xi [ 162 ] =
1.77646449552452 ; xi [ 163 ] = 1.78403365954944 ; xi [ 164 ] =
1.79164098655216 ; xi [ 165 ] = 1.79928758454972 ; xi [ 166 ] =
1.80697459135082 ; xi [ 167 ] = 1.81470317596628 ; xi [ 168 ] =
1.82247454009388 ; xi [ 169 ] = 1.83028991968276 ; xi [ 170 ] =
1.83815058658281 ; xi [ 171 ] = 1.84605785028518 ; xi [ 172 ] =
1.8540130597602 ; xi [ 173 ] = 1.86201760539967 ; xi [ 174 ] =
1.87007292107127 ; xi [ 175 ] = 1.878180486293 ; xi [ 176 ] =
1.88634182853678 ; xi [ 177 ] = 1.8945585256707 ; xi [ 178 ] =
1.90283220855043 ; xi [ 179 ] = 1.91116456377125 ; xi [ 180 ] =
1.91955733659319 ; xi [ 181 ] = 1.92801233405266 ; xi [ 182 ] =
1.93653142827569 ; xi [ 183 ] = 1.94511656000868 ; xi [ 184 ] =
1.95376974238465 ; xi [ 185 ] = 1.96249306494436 ; xi [ 186 ] =
1.97128869793366 ; xi [ 187 ] = 1.98015889690048 ; xi [ 188 ] =
1.98910600761744 ; xi [ 189 ] = 1.99813247135842 ; xi [ 190 ] =
2.00724083056053 ; xi [ 191 ] = 2.0164337349062 ; xi [ 192 ] =
2.02571394786385 ; xi [ 193 ] = 2.03508435372962 ; xi [ 194 ] =
2.04454796521753 ; xi [ 195 ] = 2.05410793165065 ; xi [ 196 ] =
2.06376754781173 ; xi [ 197 ] = 2.07353026351874 ; xi [ 198 ] =
2.0833996939983 ; xi [ 199 ] = 2.09337963113879 ; xi [ 200 ] =
2.10347405571488 ; xi [ 201 ] = 2.11368715068665 ; xi [ 202 ] =
2.12402331568952 ; xi [ 203 ] = 2.13448718284602 ; xi [ 204 ] =
2.14508363404789 ; xi [ 205 ] = 2.15581781987674 ; xi [ 206 ] =
2.16669518035431 ; xi [ 207 ] = 2.17772146774029 ; xi [ 208 ] =
2.18890277162636 ; xi [ 209 ] = 2.20024554661128 ; xi [ 210 ] =
2.21175664288416 ; xi [ 211 ] = 2.22344334009251 ; xi [ 212 ] =
2.23531338492992 ; xi [ 213 ] = 2.24737503294739 ; xi [ 214 ] =
2.25963709517379 ; xi [ 215 ] = 2.27210899022838 ; xi [ 216 ] =
2.28480080272449 ; xi [ 217 ] = 2.29772334890286 ; xi [ 218 ] =
2.31088825060137 ; xi [ 219 ] = 2.32430801887113 ; xi [ 220 ] =
2.33799614879653 ; xi [ 221 ] = 2.35196722737914 ; xi [ 222 ] =
2.36623705671729 ; xi [ 223 ] = 2.38082279517208 ; xi [ 224 ] =
2.39574311978193 ; xi [ 225 ] = 2.41101841390112 ; xi [ 226 ] =
2.42667098493715 ; xi [ 227 ] = 2.44272531820036 ; xi [ 228 ] =
2.4592083743347 ; xi [ 229 ] = 2.47614993967052 ; xi [ 230 ] =
2.49358304127105 ; xi [ 231 ] = 2.51154444162669 ; xi [ 232 ] =
2.53007523215985 ; xi [ 233 ] = 2.54922155032478 ; xi [ 234 ] =
2.56903545268184 ; xi [ 235 ] = 2.58957598670829 ; xi [ 236 ] =
2.61091051848882 ; xi [ 237 ] = 2.63311639363158 ; xi [ 238 ] =
2.65628303757674 ; xi [ 239 ] = 2.68051464328574 ; xi [ 240 ] =
2.70593365612306 ; xi [ 241 ] = 2.73268535904401 ; xi [ 242 ] =
2.76094400527999 ; xi [ 243 ] = 2.79092117400193 ; xi [ 244 ] =
2.82287739682644 ; xi [ 245 ] = 2.85713873087322 ; xi [ 246 ] =
2.89412105361341 ; xi [ 247 ] = 2.93436686720889 ; xi [ 248 ] =
2.97860327988184 ; xi [ 249 ] = 3.02783779176959 ; xi [ 250 ] =
3.08352613200214 ; xi [ 251 ] = 3.147889289518 ; xi [ 252 ] = 3.2245750520478
; xi [ 253 ] = 3.32024473383983 ; xi [ 254 ] = 3.44927829856143 ; xi [ 255 ]
= 3.65415288536101 ; xi [ 256 ] = 3.91075795952492 ; fitab = & tmp [ 0 ] ; }
for ( b_k = 0 ; b_k <= d ; b_k ++ ) { do { exitg1 = 0 ; jywdovubw0d ( rtDW .
iovoxirwro , u32 ) ; i = ( int32_T ) ( ( u32 [ 1 ] >> 24U ) + 1U ) ; b_r = (
( ( real_T ) ( u32 [ 0 ] >> 3U ) * 1.6777216E+7 + ( real_T ) ( ( int32_T )
u32 [ 1 ] & 16777215 ) ) * 2.2204460492503131E-16 - 1.0 ) * xi [ i ] ; if (
muDoubleScalarAbs ( b_r ) <= xi [ i - 1 ] ) { exitg1 = 1 ; } else if ( i <
256 ) { do { exitg2 = 0 ; jywdovubw0d ( rtDW . iovoxirwro , u32 ) ; x = ( (
real_T ) ( u32 [ 0 ] >> 5U ) * 6.7108864E+7 + ( real_T ) ( u32 [ 1 ] >> 6U )
) * 1.1102230246251565E-16 ; if ( x == 0.0 ) { if ( ! isihtjjmsz ( rtDW .
iovoxirwro ) ) { rtDW . iovoxirwro [ 0 ] = 5489U ; rtDW . iovoxirwro [ 624 ]
= 624U ; } } else { exitg2 = 1 ; } } while ( exitg2 == 0 ) ; if ( ( fitab [ i
- 1 ] - fitab [ i ] ) * x + fitab [ i ] < muDoubleScalarExp ( - 0.5 * b_r *
b_r ) ) { exitg1 = 1 ; } } else { do { do { exitg2 = 0 ; jywdovubw0d ( rtDW .
iovoxirwro , u32 ) ; x = ( ( real_T ) ( u32 [ 0 ] >> 5U ) * 6.7108864E+7 + (
real_T ) ( u32 [ 1 ] >> 6U ) ) * 1.1102230246251565E-16 ; if ( x == 0.0 ) {
if ( ! isihtjjmsz ( rtDW . iovoxirwro ) ) { rtDW . iovoxirwro [ 0 ] = 5489U ;
rtDW . iovoxirwro [ 624 ] = 624U ; } } else { exitg2 = 1 ; } } while ( exitg2
== 0 ) ; x = muDoubleScalarLog ( x ) * 0.273661237329758 ; do { exitg2 = 0 ;
jywdovubw0d ( rtDW . iovoxirwro , u32 ) ; d_u = ( ( real_T ) ( u32 [ 0 ] >>
5U ) * 6.7108864E+7 + ( real_T ) ( u32 [ 1 ] >> 6U ) ) *
1.1102230246251565E-16 ; if ( d_u == 0.0 ) { if ( ! isihtjjmsz ( rtDW .
iovoxirwro ) ) { rtDW . iovoxirwro [ 0 ] = 5489U ; rtDW . iovoxirwro [ 624 ]
= 624U ; } } else { exitg2 = 1 ; } } while ( exitg2 == 0 ) ; } while ( ! ( -
2.0 * muDoubleScalarLog ( d_u ) > x * x ) ) ; if ( b_r < 0.0 ) { b_r = x -
3.65415288536101 ; } else { b_r = 3.65415288536101 - x ; } exitg1 = 1 ; } }
while ( exitg1 == 0 ) ; r -> data [ b_k ] = b_r ; } } static void h2drfin2nj
( moo4o4s0qn * in1 , const moo4o4s0qn * in2 ) { moo4o4s0qn * in1_p ; int32_T
i ; int32_T loop_ub ; int32_T stride_0_0 ; int32_T stride_1_0 ; cy4r1g1cm1 (
& in1_p , 1 ) ; i = in1_p -> size [ 0 ] ; in1_p -> size [ 0 ] = in2 -> size [
0 ] == 1 ? in1 -> size [ 0 ] : in2 -> size [ 0 ] ; ier0p3wwtw ( in1_p , i ) ;
stride_0_0 = ( in1 -> size [ 0 ] != 1 ) ; stride_1_0 = ( in2 -> size [ 0 ] !=
1 ) ; loop_ub = in2 -> size [ 0 ] == 1 ? in1 -> size [ 0 ] : in2 -> size [ 0
] ; for ( i = 0 ; i < loop_ub ; i ++ ) { in1_p -> data [ i ] = in1 -> data [
i * stride_0_0 ] - in2 -> data [ i * stride_1_0 ] ; } i = in1 -> size [ 0 ] ;
in1 -> size [ 0 ] = in1_p -> size [ 0 ] ; ier0p3wwtw ( in1 , i ) ; loop_ub =
in1_p -> size [ 0 ] ; if ( loop_ub - 1 >= 0 ) { memcpy ( & in1 -> data [ 0 ]
, & in1_p -> data [ 0 ] , loop_ub * sizeof ( real_T ) ) ; } njzmd0hlqd ( &
in1_p ) ; } static void gvjwo0dspq ( moo4o4s0qn * in1 , const moo4o4s0qn *
in2 ) { moo4o4s0qn * in2_p ; int32_T i ; int32_T loop_ub ; int32_T stride_0_0
; int32_T stride_1_0 ; cy4r1g1cm1 ( & in2_p , 1 ) ; i = in2_p -> size [ 0 ] ;
in2_p -> size [ 0 ] = in1 -> size [ 0 ] == 1 ? in2 -> size [ 0 ] : in1 ->
size [ 0 ] ; ier0p3wwtw ( in2_p , i ) ; stride_0_0 = ( in2 -> size [ 0 ] != 1
) ; stride_1_0 = ( in1 -> size [ 0 ] != 1 ) ; loop_ub = in1 -> size [ 0 ] ==
1 ? in2 -> size [ 0 ] : in1 -> size [ 0 ] ; for ( i = 0 ; i < loop_ub ; i ++
) { in2_p -> data [ i ] = in2 -> data [ i * stride_0_0 ] + in1 -> data [ i *
stride_1_0 ] ; } i = in1 -> size [ 0 ] ; in1 -> size [ 0 ] = in2_p -> size [
0 ] ; ier0p3wwtw ( in1 , i ) ; loop_ub = in2_p -> size [ 0 ] ; if ( loop_ub -
1 >= 0 ) { memcpy ( & in1 -> data [ 0 ] , & in2_p -> data [ 0 ] , loop_ub *
sizeof ( real_T ) ) ; } njzmd0hlqd ( & in2_p ) ; } static void civj2dafm1t (
real_T varargin_1 , moo4o4s0qn * r ) { real_T b_r ; int32_T b_k ; int32_T d ;
int32_T exitg1 ; uint32_T b_u [ 2 ] ; b_k = r -> size [ 0 ] ; r -> size [ 0 ]
= ( int32_T ) varargin_1 ; ier0p3wwtw ( r , b_k ) ; d = ( int32_T )
varargin_1 - 1 ; for ( b_k = 0 ; b_k <= d ; b_k ++ ) { do { exitg1 = 0 ;
jywdovubw0d ( rtDW . iovoxirwro , b_u ) ; b_r = ( ( real_T ) ( b_u [ 0 ] >>
5U ) * 6.7108864E+7 + ( real_T ) ( b_u [ 1 ] >> 6U ) ) *
1.1102230246251565E-16 ; if ( b_r == 0.0 ) { if ( ! isihtjjmsz ( rtDW .
iovoxirwro ) ) { rtDW . iovoxirwro [ 0 ] = 5489U ; rtDW . iovoxirwro [ 624 ]
= 624U ; } } else { exitg1 = 1 ; } } while ( exitg1 == 0 ) ; r -> data [ b_k
] = b_r ; } } static void pvxko1qdkz ( moo4o4s0qn * in1 , const moo4o4s0qn *
in2 , const moo4o4s0qn * in3 ) { moo4o4s0qn * in2_p ; int32_T i ; int32_T
loop_ub ; int32_T stride_0_0 ; int32_T stride_1_0 ; int32_T stride_2_0 ;
int32_T stride_3_0 ; cy4r1g1cm1 ( & in2_p , 1 ) ; i = in2_p -> size [ 0 ] ;
in2_p -> size [ 0 ] = ( ( in2 -> size [ 0 ] == 1 ? in1 -> size [ 0 ] : in2 ->
size [ 0 ] ) == 1 ? in3 -> size [ 0 ] : in2 -> size [ 0 ] == 1 ? in1 -> size
[ 0 ] : in2 -> size [ 0 ] ) == 1 ? in2 -> size [ 0 ] : ( in2 -> size [ 0 ] ==
1 ? in1 -> size [ 0 ] : in2 -> size [ 0 ] ) == 1 ? in3 -> size [ 0 ] : in2 ->
size [ 0 ] == 1 ? in1 -> size [ 0 ] : in2 -> size [ 0 ] ; ier0p3wwtw ( in2_p
, i ) ; stride_0_0 = ( in2 -> size [ 0 ] != 1 ) ; stride_1_0 = ( in3 -> size
[ 0 ] != 1 ) ; stride_2_0 = ( in1 -> size [ 0 ] != 1 ) ; stride_3_0 = ( in2
-> size [ 0 ] != 1 ) ; loop_ub = ( ( in2 -> size [ 0 ] == 1 ? in1 -> size [ 0
] : in2 -> size [ 0 ] ) == 1 ? in3 -> size [ 0 ] : in2 -> size [ 0 ] == 1 ?
in1 -> size [ 0 ] : in2 -> size [ 0 ] ) == 1 ? in2 -> size [ 0 ] : ( in2 ->
size [ 0 ] == 1 ? in1 -> size [ 0 ] : in2 -> size [ 0 ] ) == 1 ? in3 -> size
[ 0 ] : in2 -> size [ 0 ] == 1 ? in1 -> size [ 0 ] : in2 -> size [ 0 ] ; for
( i = 0 ; i < loop_ub ; i ++ ) { in2_p -> data [ i ] = ( in1 -> data [ i *
stride_2_0 ] - in2 -> data [ i * stride_3_0 ] ) * in3 -> data [ i *
stride_1_0 ] + in2 -> data [ i * stride_0_0 ] ; } i = in1 -> size [ 0 ] ; in1
-> size [ 0 ] = in2_p -> size [ 0 ] ; ier0p3wwtw ( in1 , i ) ; loop_ub =
in2_p -> size [ 0 ] ; if ( loop_ub - 1 >= 0 ) { memcpy ( & in1 -> data [ 0 ]
, & in2_p -> data [ 0 ] , loop_ub * sizeof ( real_T ) ) ; } njzmd0hlqd ( &
in2_p ) ; } static void bqde2t5zai ( pmprofizlh * obj , const real_T seed [ 5
] , real_T xSol [ 5 ] , real_T * solutionInfo_Iterations , real_T *
solutionInfo_RRAttempts , real_T * solutionInfo_Error , real_T *
solutionInfo_ExitFlag , char_T solutionInfo_Status_data [ ] , int32_T
solutionInfo_Status_size [ 2 ] ) { itgfp4rmev * obj_p ; itipyws4dn * b ;
itipyws4dn * tmp ; itipyws4dn * tmp_p ; iyg0swfnbfoc * obj_e ; l2t3f2z1w3 *
args ; moo4o4s0qn * lb ; moo4o4s0qn * newseed ; moo4o4s0qn * rn ; moo4o4s0qn
* ub ; real_T c_xSol [ 5 ] ; real_T ub_p [ 2 ] ; real_T err ; real_T iter ;
real_T lb_p ; real_T tol ; int32_T c ; int32_T i ; int32_T loop_ub ; int32_T
nx ; int32_T tmp_e ; iu3zpbmgcw exitFlag ; iu3zpbmgcw exitFlagPrev ;
boolean_T y ; static const char_T tmp_i [ 14 ] = { 'b' , 'e' , 's' , 't' ,
' ' , 'a' , 'v' , 'a' , 'i' , 'l' , 'a' , 'b' , 'l' , 'e' } ; static const
char_T tmp_m [ 7 ] = { 's' , 'u' , 'c' , 'c' , 'e' , 's' , 's' } ; boolean_T
exitg1 ; boolean_T exitg2 ; boolean_T guard1 = false ; boolean_T guard2 =
false ; boolean_T guard3 = false ; obj -> MaxNumIterationInternal = obj ->
MaxNumIteration ; obj -> MaxTimeInternal = obj -> MaxTime ; for ( i = 0 ; i <
5 ; i ++ ) { obj -> SeedInternal [ i ] = seed [ i ] ; } tol = obj ->
SolutionTolerance ; or5i2fegiq ( & obj -> TimeObj . StartTime . tv_sec , &
obj -> TimeObj . StartTime . tv_nsec ) ; jfs5omen4s ( obj , xSol , & exitFlag
, & err , & iter ) ; * solutionInfo_RRAttempts = 0.0 ; *
solutionInfo_Iterations = iter ; * solutionInfo_Error = err ; exitFlagPrev =
exitFlag ; cy4r1g1cm1 ( & newseed , 1 ) ; cy4r1g1cm1 ( & ub , 1 ) ;
cy4r1g1cm1 ( & lb , 1 ) ; cy4r1g1cm1 ( & rn , 1 ) ; mp1kcw5ibf ( & b , 1 ) ;
mp1kcw5ibf ( & tmp , 1 ) ; mp1kcw5ibf ( & tmp_p , 1 ) ; exitg1 = false ;
while ( ( ! exitg1 ) && ( obj -> RandomRestart && ( err > tol ) ) ) { obj ->
MaxNumIterationInternal -= iter ; err = b43ytoj3db ( obj -> TimeObj .
StartTime . tv_sec , obj -> TimeObj . StartTime . tv_nsec ) ; obj ->
MaxTimeInternal = obj -> MaxTime - err ; if ( obj -> MaxNumIterationInternal
<= 0.0 ) { exitFlag =
robotics_core_internal_NLPSolverExitFlags_IterationLimitExceeded ; } if ( (
exitFlag == robotics_core_internal_NLPSolverExitFlags_IterationLimitExceeded
) || ( exitFlag ==
robotics_core_internal_NLPSolverExitFlags_TimeLimitExceeded ) ) {
exitFlagPrev = exitFlag ; exitg1 = true ; } else { args = obj -> ExtraArgs ;
obj_p = args -> Robot ; tmp_e = newseed -> size [ 0 ] ; newseed -> size [ 0 ]
= ( int32_T ) obj_p -> PositionNumber ; ier0p3wwtw ( newseed , tmp_e ) ;
loop_ub = ( int32_T ) obj_p -> PositionNumber ; if ( loop_ub - 1 >= 0 ) {
memset ( & newseed -> data [ 0 ] , 0 , loop_ub * sizeof ( real_T ) ) ; } err
= obj_p -> NumBodies ; c = ( int32_T ) err - 1 ; for ( i = 0 ; i <= c ; i ++
) { err = obj_p -> PositionDoFMap [ i ] ; iter = obj_p -> PositionDoFMap [ i
+ 5 ] ; if ( err <= iter ) { obj_e = obj_p -> Bodies [ i ] -> JointInternal ;
if ( ( int32_T ) obj_e -> PositionNumber == 0 ) { tmp_e = ub -> size [ 0 ] ;
ub -> size [ 0 ] = 1 ; ier0p3wwtw ( ub , tmp_e ) ; ub -> data [ 0 ] = ( rtNaN
) ; } else { loop_ub = obj_e -> PositionLimitsInternal -> size [ 0 ] ; tmp_e
= ub -> size [ 0 ] ; ub -> size [ 0 ] = loop_ub ; ier0p3wwtw ( ub , tmp_e ) ;
for ( nx = 0 ; nx < loop_ub ; nx ++ ) { ub -> data [ nx ] = obj_e ->
PositionLimitsInternal -> data [ nx + obj_e -> PositionLimitsInternal -> size
[ 0 ] ] ; } loop_ub = obj_e -> PositionLimitsInternal -> size [ 0 ] ; tmp_e =
lb -> size [ 0 ] ; lb -> size [ 0 ] = loop_ub ; ier0p3wwtw ( lb , tmp_e ) ;
for ( nx = 0 ; nx < loop_ub ; nx ++ ) { lb -> data [ nx ] = obj_e ->
PositionLimitsInternal -> data [ nx ] ; } tmp_e = b -> size [ 0 ] ; b -> size
[ 0 ] = lb -> size [ 0 ] ; iue3n2dlds ( b , tmp_e ) ; loop_ub = lb -> size [
0 ] ; for ( nx = 0 ; nx < loop_ub ; nx ++ ) { b -> data [ nx ] =
muDoubleScalarIsInf ( lb -> data [ nx ] ) ; } tmp_e = tmp -> size [ 0 ] ; tmp
-> size [ 0 ] = lb -> size [ 0 ] ; iue3n2dlds ( tmp , tmp_e ) ; loop_ub = lb
-> size [ 0 ] ; for ( nx = 0 ; nx < loop_ub ; nx ++ ) { tmp -> data [ nx ] =
muDoubleScalarIsNaN ( lb -> data [ nx ] ) ; } loop_ub = b -> size [ 0 ] ; for
( nx = 0 ; nx < loop_ub ; nx ++ ) { b -> data [ nx ] = ( ( ! b -> data [ nx ]
) && ( ! tmp -> data [ nx ] ) ) ; } y = true ; loop_ub = 0 ; exitg2 = false ;
while ( ( ! exitg2 ) && ( loop_ub + 1 <= b -> size [ 0 ] ) ) { if ( ! b ->
data [ loop_ub ] ) { y = false ; exitg2 = true ; } else { loop_ub ++ ; } }
guard1 = false ; guard2 = false ; guard3 = false ; if ( y ) { tmp_e = b ->
size [ 0 ] ; b -> size [ 0 ] = ub -> size [ 0 ] ; iue3n2dlds ( b , tmp_e ) ;
loop_ub = ub -> size [ 0 ] ; for ( nx = 0 ; nx < loop_ub ; nx ++ ) { b ->
data [ nx ] = muDoubleScalarIsInf ( ub -> data [ nx ] ) ; } tmp_e = tmp ->
size [ 0 ] ; tmp -> size [ 0 ] = ub -> size [ 0 ] ; iue3n2dlds ( tmp , tmp_e
) ; loop_ub = ub -> size [ 0 ] ; for ( nx = 0 ; nx < loop_ub ; nx ++ ) { tmp
-> data [ nx ] = muDoubleScalarIsNaN ( ub -> data [ nx ] ) ; } loop_ub = b ->
size [ 0 ] ; for ( nx = 0 ; nx < loop_ub ; nx ++ ) { b -> data [ nx ] = ( ( !
b -> data [ nx ] ) && ( ! tmp -> data [ nx ] ) ) ; } loop_ub = 0 ; exitg2 =
false ; while ( ( ! exitg2 ) && ( loop_ub + 1 <= b -> size [ 0 ] ) ) { if ( !
b -> data [ loop_ub ] ) { y = false ; exitg2 = true ; } else { loop_ub ++ ; }
} if ( y ) { civj2dafm1t ( obj_e -> PositionNumber , rn ) ; if ( ( ub -> size
[ 0 ] == lb -> size [ 0 ] ) && ( ( ub -> size [ 0 ] == 1 ? lb -> size [ 0 ] :
ub -> size [ 0 ] ) == rn -> size [ 0 ] ) && ( ( rn -> size [ 0 ] == 1 ? ub ->
size [ 0 ] == 1 ? lb -> size [ 0 ] : ub -> size [ 0 ] : rn -> size [ 0 ] ) ==
lb -> size [ 0 ] ) ) { tmp_e = ub -> size [ 0 ] ; ub -> size [ 0 ] = lb ->
size [ 0 ] ; ier0p3wwtw ( ub , tmp_e ) ; loop_ub = lb -> size [ 0 ] ; for (
nx = 0 ; nx < loop_ub ; nx ++ ) { lb_p = lb -> data [ nx ] ; ub -> data [ nx
] = ( ub -> data [ nx ] - lb_p ) * rn -> data [ nx ] + lb_p ; } } else {
pvxko1qdkz ( ub , lb , rn ) ; } } else { guard3 = true ; } } else { guard3 =
true ; } if ( guard3 ) { tmp_e = b -> size [ 0 ] ; b -> size [ 0 ] = lb ->
size [ 0 ] ; iue3n2dlds ( b , tmp_e ) ; loop_ub = lb -> size [ 0 ] ; for ( nx
= 0 ; nx < loop_ub ; nx ++ ) { b -> data [ nx ] = muDoubleScalarIsInf ( lb ->
data [ nx ] ) ; } tmp_e = tmp -> size [ 0 ] ; tmp -> size [ 0 ] = lb -> size
[ 0 ] ; iue3n2dlds ( tmp , tmp_e ) ; loop_ub = lb -> size [ 0 ] ; for ( nx =
0 ; nx < loop_ub ; nx ++ ) { tmp -> data [ nx ] = muDoubleScalarIsNaN ( lb ->
data [ nx ] ) ; } loop_ub = b -> size [ 0 ] ; for ( nx = 0 ; nx < loop_ub ;
nx ++ ) { b -> data [ nx ] = ( ( ! b -> data [ nx ] ) && ( ! tmp -> data [ nx
] ) ) ; } y = true ; loop_ub = 0 ; exitg2 = false ; while ( ( ! exitg2 ) && (
loop_ub + 1 <= b -> size [ 0 ] ) ) { if ( ! b -> data [ loop_ub ] ) { y =
false ; exitg2 = true ; } else { loop_ub ++ ; } } if ( y ) { tmp_e = tmp ->
size [ 0 ] ; tmp -> size [ 0 ] = ub -> size [ 0 ] ; iue3n2dlds ( tmp , tmp_e
) ; loop_ub = ub -> size [ 0 ] ; for ( nx = 0 ; nx < loop_ub ; nx ++ ) { tmp
-> data [ nx ] = muDoubleScalarIsInf ( ub -> data [ nx ] ) ; } tmp_e = b ->
size [ 0 ] ; b -> size [ 0 ] = ub -> size [ 0 ] ; iue3n2dlds ( b , tmp_e ) ;
loop_ub = ub -> size [ 0 ] ; for ( nx = 0 ; nx < loop_ub ; nx ++ ) { b ->
data [ nx ] = muDoubleScalarIsNaN ( ub -> data [ nx ] ) ; } tmp_e = tmp_p ->
size [ 0 ] ; tmp_p -> size [ 0 ] = tmp -> size [ 0 ] ; iue3n2dlds ( tmp_p ,
tmp_e ) ; loop_ub = tmp -> size [ 0 ] ; for ( nx = 0 ; nx < loop_ub ; nx ++ )
{ tmp_p -> data [ nx ] = ( tmp -> data [ nx ] || b -> data [ nx ] ) ; } if (
himifevlz1 ( tmp_p ) ) { ub_p [ 0 ] = lb -> size [ 0 ] ; ub_p [ 1 ] = 1.0 ;
h3f52mmr1n ( ub_p , rn ) ; nx = rn -> size [ 0 ] - 1 ; tmp_e = ub -> size [ 0
] ; ub -> size [ 0 ] = rn -> size [ 0 ] ; ier0p3wwtw ( ub , tmp_e ) ; for (
loop_ub = 0 ; loop_ub <= nx ; loop_ub ++ ) { ub -> data [ loop_ub ] =
muDoubleScalarAbs ( rn -> data [ loop_ub ] ) ; } if ( lb -> size [ 0 ] == ub
-> size [ 0 ] ) { tmp_e = ub -> size [ 0 ] ; ub -> size [ 0 ] = lb -> size [
0 ] ; ier0p3wwtw ( ub , tmp_e ) ; loop_ub = lb -> size [ 0 ] ; for ( nx = 0 ;
nx < loop_ub ; nx ++ ) { ub -> data [ nx ] += lb -> data [ nx ] ; } } else {
gvjwo0dspq ( ub , lb ) ; } } else { guard2 = true ; } } else { guard2 = true
; } } if ( guard2 ) { tmp_e = tmp -> size [ 0 ] ; tmp -> size [ 0 ] = lb ->
size [ 0 ] ; iue3n2dlds ( tmp , tmp_e ) ; loop_ub = lb -> size [ 0 ] ; for (
nx = 0 ; nx < loop_ub ; nx ++ ) { tmp -> data [ nx ] = muDoubleScalarIsInf (
lb -> data [ nx ] ) ; } tmp_e = b -> size [ 0 ] ; b -> size [ 0 ] = lb ->
size [ 0 ] ; iue3n2dlds ( b , tmp_e ) ; loop_ub = lb -> size [ 0 ] ; for ( nx
= 0 ; nx < loop_ub ; nx ++ ) { b -> data [ nx ] = muDoubleScalarIsNaN ( lb ->
data [ nx ] ) ; } tmp_e = tmp_p -> size [ 0 ] ; tmp_p -> size [ 0 ] = tmp ->
size [ 0 ] ; iue3n2dlds ( tmp_p , tmp_e ) ; loop_ub = tmp -> size [ 0 ] ; for
( nx = 0 ; nx < loop_ub ; nx ++ ) { tmp_p -> data [ nx ] = ( tmp -> data [ nx
] || b -> data [ nx ] ) ; } if ( himifevlz1 ( tmp_p ) ) { tmp_e = b -> size [
0 ] ; b -> size [ 0 ] = ub -> size [ 0 ] ; iue3n2dlds ( b , tmp_e ) ; loop_ub
= ub -> size [ 0 ] ; for ( nx = 0 ; nx < loop_ub ; nx ++ ) { b -> data [ nx ]
= muDoubleScalarIsInf ( ub -> data [ nx ] ) ; } tmp_e = tmp -> size [ 0 ] ;
tmp -> size [ 0 ] = ub -> size [ 0 ] ; iue3n2dlds ( tmp , tmp_e ) ; loop_ub =
ub -> size [ 0 ] ; for ( nx = 0 ; nx < loop_ub ; nx ++ ) { tmp -> data [ nx ]
= muDoubleScalarIsNaN ( ub -> data [ nx ] ) ; } loop_ub = b -> size [ 0 ] ;
for ( nx = 0 ; nx < loop_ub ; nx ++ ) { b -> data [ nx ] = ( ( ! b -> data [
nx ] ) && ( ! tmp -> data [ nx ] ) ) ; } y = true ; loop_ub = 0 ; exitg2 =
false ; while ( ( ! exitg2 ) && ( loop_ub + 1 <= b -> size [ 0 ] ) ) { if ( !
b -> data [ loop_ub ] ) { y = false ; exitg2 = true ; } else { loop_ub ++ ; }
} if ( y ) { ub_p [ 0 ] = ub -> size [ 0 ] ; ub_p [ 1 ] = 1.0 ; h3f52mmr1n (
ub_p , rn ) ; nx = rn -> size [ 0 ] - 1 ; tmp_e = lb -> size [ 0 ] ; lb ->
size [ 0 ] = rn -> size [ 0 ] ; ier0p3wwtw ( lb , tmp_e ) ; for ( loop_ub = 0
; loop_ub <= nx ; loop_ub ++ ) { lb -> data [ loop_ub ] = muDoubleScalarAbs (
rn -> data [ loop_ub ] ) ; } if ( ub -> size [ 0 ] == lb -> size [ 0 ] ) {
loop_ub = ub -> size [ 0 ] ; for ( nx = 0 ; nx < loop_ub ; nx ++ ) { ub ->
data [ nx ] -= lb -> data [ nx ] ; } } else { h2drfin2nj ( ub , lb ) ; } }
else { guard1 = true ; } } else { guard1 = true ; } } if ( guard1 ) { ub_p [
0 ] = ub -> size [ 0 ] ; ub_p [ 1 ] = 1.0 ; h3f52mmr1n ( ub_p , ub ) ; } } if
( err > iter ) { loop_ub = 0 ; nx = 0 ; } else { loop_ub = ( int32_T ) err -
1 ; nx = ( int32_T ) iter ; } tmp_e = nx - loop_ub ; for ( nx = 0 ; nx <
tmp_e ; nx ++ ) { newseed -> data [ loop_ub + nx ] = ub -> data [ nx ] ; } }
} for ( nx = 0 ; nx < 5 ; nx ++ ) { obj -> SeedInternal [ nx ] = newseed ->
data [ nx ] ; } jfs5omen4s ( obj , c_xSol , & exitFlag , & err , & iter ) ;
if ( err < * solutionInfo_Error ) { for ( i = 0 ; i < 5 ; i ++ ) { xSol [ i ]
= c_xSol [ i ] ; } * solutionInfo_Error = err ; exitFlagPrev = exitFlag ; } (
* solutionInfo_RRAttempts ) ++ ; * solutionInfo_Iterations += iter ; } }
b1xdicvyah ( & tmp_p ) ; b1xdicvyah ( & tmp ) ; b1xdicvyah ( & b ) ;
njzmd0hlqd ( & rn ) ; njzmd0hlqd ( & lb ) ; njzmd0hlqd ( & ub ) ; njzmd0hlqd
( & newseed ) ; * solutionInfo_ExitFlag = exitFlagPrev ; if ( *
solutionInfo_Error < tol ) { solutionInfo_Status_size [ 0 ] = 1 ;
solutionInfo_Status_size [ 1 ] = 7 ; for ( nx = 0 ; nx < 7 ; nx ++ ) {
solutionInfo_Status_data [ nx ] = tmp_m [ nx ] ; } } else {
solutionInfo_Status_size [ 0 ] = 1 ; solutionInfo_Status_size [ 1 ] = 14 ;
for ( nx = 0 ; nx < 14 ; nx ++ ) { solutionInfo_Status_data [ nx ] = tmp_i [
nx ] ; } } } static void jw4vvjgwpp ( iidpvf4tee * * pEmxArray , int32_T
numDimensions ) { iidpvf4tee * emxArray ; int32_T i ; * pEmxArray = (
iidpvf4tee * ) malloc ( sizeof ( iidpvf4tee ) ) ; emxArray = * pEmxArray ;
emxArray -> data = ( int32_T * ) NULL ; emxArray -> numDimensions =
numDimensions ; emxArray -> size = ( int32_T * ) malloc ( sizeof ( int32_T )
* numDimensions ) ; emxArray -> allocatedSize = 0 ; emxArray -> canFreeData =
true ; for ( i = 0 ; i < numDimensions ; i ++ ) { emxArray -> size [ i ] = 0
; } } static void f4i2s4lxoo ( iidpvf4tee * emxArray , int32_T oldNumel ) {
int32_T i ; int32_T newNumel ; void * newData ; if ( oldNumel < 0 ) {
oldNumel = 0 ; } newNumel = 1 ; for ( i = 0 ; i < emxArray -> numDimensions ;
i ++ ) { newNumel *= emxArray -> size [ i ] ; } if ( newNumel > emxArray ->
allocatedSize ) { i = emxArray -> allocatedSize ; if ( i < 16 ) { i = 16 ; }
while ( i < newNumel ) { if ( i > 1073741823 ) { i = MAX_int32_T ; } else { i
<<= 1 ; } } newData = calloc ( ( uint32_T ) i , sizeof ( int32_T ) ) ; if (
emxArray -> data != NULL ) { memcpy ( newData , emxArray -> data , sizeof (
int32_T ) * oldNumel ) ; if ( emxArray -> canFreeData ) { free ( emxArray ->
data ) ; } } emxArray -> data = ( int32_T * ) newData ; emxArray ->
allocatedSize = i ; emxArray -> canFreeData = true ; } } static void
g0pzyoia5l ( iidpvf4tee * * pEmxArray ) { if ( * pEmxArray != ( iidpvf4tee *
) NULL ) { if ( ( ( * pEmxArray ) -> data != ( int32_T * ) NULL ) && ( *
pEmxArray ) -> canFreeData ) { free ( ( * pEmxArray ) -> data ) ; } free ( (
* pEmxArray ) -> size ) ; free ( * pEmxArray ) ; * pEmxArray = ( iidpvf4tee *
) NULL ; } } static void muadc51of1 ( izqiyoa4ub * * pEmxArray , int32_T
numDimensions ) { izqiyoa4ub * emxArray ; int32_T i ; * pEmxArray = (
izqiyoa4ub * ) malloc ( sizeof ( izqiyoa4ub ) ) ; emxArray = * pEmxArray ;
emxArray -> data = ( uint32_T * ) NULL ; emxArray -> numDimensions =
numDimensions ; emxArray -> size = ( int32_T * ) malloc ( sizeof ( int32_T )
* numDimensions ) ; emxArray -> allocatedSize = 0 ; emxArray -> canFreeData =
true ; for ( i = 0 ; i < numDimensions ; i ++ ) { emxArray -> size [ i ] = 0
; } } static void ghsky5aveh ( izqiyoa4ub * emxArray , int32_T oldNumel ) {
int32_T i ; int32_T newNumel ; void * newData ; if ( oldNumel < 0 ) {
oldNumel = 0 ; } newNumel = 1 ; for ( i = 0 ; i < emxArray -> numDimensions ;
i ++ ) { newNumel *= emxArray -> size [ i ] ; } if ( newNumel > emxArray ->
allocatedSize ) { i = emxArray -> allocatedSize ; if ( i < 16 ) { i = 16 ; }
while ( i < newNumel ) { if ( i > 1073741823 ) { i = MAX_int32_T ; } else { i
<<= 1 ; } } newData = calloc ( ( uint32_T ) i , sizeof ( uint32_T ) ) ; if (
emxArray -> data != NULL ) { memcpy ( newData , emxArray -> data , sizeof (
uint32_T ) * oldNumel ) ; if ( emxArray -> canFreeData ) { free ( emxArray ->
data ) ; } } emxArray -> data = ( uint32_T * ) newData ; emxArray ->
allocatedSize = i ; emxArray -> canFreeData = true ; } } static void
npfzq14tu1 ( izqiyoa4ub * * pEmxArray ) { if ( * pEmxArray != ( izqiyoa4ub *
) NULL ) { if ( ( ( * pEmxArray ) -> data != ( uint32_T * ) NULL ) && ( *
pEmxArray ) -> canFreeData ) { free ( ( * pEmxArray ) -> data ) ; } free ( (
* pEmxArray ) -> size ) ; free ( * pEmxArray ) ; * pEmxArray = ( izqiyoa4ub *
) NULL ; } } static void g30rxyn4gkf ( iabjthfi1p * obj , real_T initialGuess
[ 5 ] , real_T * solutionInfo_Iterations , real_T *
solutionInfo_NumRandomRestarts , real_T * solutionInfo_PoseErrorNorm , real_T
* solutionInfo_ExitFlag , char_T solutionInfo_Status_data [ ] , int32_T
solutionInfo_Status_size [ 2 ] ) { e2b0f4s35s * endEffectorName ;
gxcsgl11sl35 * body ; iidpvf4tee * h ; itgfp4rmev * obj_p ; izqiyoa4ub * y ;
moo4o4s0qn * bodyIndices ; moo4o4s0qn * e ; moo4o4s0qn * limits ; moo4o4s0qn
* positionIndices ; real_T qvSolRaw [ 5 ] ; real_T apnd ; real_T bid ; real_T
cdiff ; real_T ndbl ; real_T numPositions ; int32_T
indicesUpperBoundViolation_data [ 5 ] ; int32_T tmp_data [ 5 ] ; int32_T b_k
; int32_T c ; int32_T indicesUpperBoundViolation ; int32_T
indicesUpperBoundViolation_size_idx_0 ; int32_T loop_ub ; int32_T nm1d2 ;
int32_T tmp_size ; boolean_T lbOK [ 5 ] ; boolean_T ubOK [ 5 ] ; boolean_T
ubOK_p [ 5 ] ; boolean_T exitg1 ; boolean_T guard1 = false ; boolean_T y_p ;
cy4r1g1cm1 ( & limits , 2 ) ; obj_p = obj -> RigidBodyTreeInternal ;
jkqy2d3rp1 ( obj_p , limits ) ; if ( limits -> size [ 0 ] == 5 ) { for ( b_k
= 0 ; b_k < 5 ; b_k ++ ) { ubOK [ b_k ] = ( initialGuess [ b_k ] <= limits ->
data [ b_k + limits -> size [ 0 ] ] + 4.4408920985006262E-16 ) ; } } else {
pvxko1qdkz0yx ( ubOK , initialGuess , limits ) ; } if ( limits -> size [ 0 ]
== 5 ) { for ( b_k = 0 ; b_k < 5 ; b_k ++ ) { lbOK [ b_k ] = ( initialGuess [
b_k ] >= limits -> data [ b_k ] - 4.4408920985006262E-16 ) ; } } else {
pvxko1qdkz0y ( lbOK , initialGuess , limits ) ; } y_p = true ; b_k = 0 ;
exitg1 = false ; while ( ( ! exitg1 ) && ( b_k < 5 ) ) { if ( ! ubOK [ b_k ]
) { y_p = false ; exitg1 = true ; } else { b_k ++ ; } } guard1 = false ; if (
y_p ) { b_k = 0 ; exitg1 = false ; while ( ( ! exitg1 ) && ( b_k < 5 ) ) { if
( ! lbOK [ b_k ] ) { y_p = false ; exitg1 = true ; } else { b_k ++ ; } } if (
y_p ) { } else { guard1 = true ; } } else { guard1 = true ; } if ( guard1 ) {
for ( b_k = 0 ; b_k < 5 ; b_k ++ ) { ubOK_p [ b_k ] = ! ubOK [ b_k ] ; }
aeyt1tjqck ( ubOK_p , tmp_data , & tmp_size ) ;
indicesUpperBoundViolation_size_idx_0 = tmp_size ; loop_ub = tmp_size ; if (
loop_ub - 1 >= 0 ) { memcpy ( & indicesUpperBoundViolation_data [ 0 ] , &
tmp_data [ 0 ] , loop_ub * sizeof ( int32_T ) ) ; } for ( b_k = 0 ; b_k <
indicesUpperBoundViolation_size_idx_0 ; b_k ++ ) { indicesUpperBoundViolation
= indicesUpperBoundViolation_data [ b_k ] ; initialGuess [
indicesUpperBoundViolation - 1 ] = limits -> data [ (
indicesUpperBoundViolation + limits -> size [ 0 ] ) - 1 ] ; } for ( b_k = 0 ;
b_k < 5 ; b_k ++ ) { ubOK [ b_k ] = ! lbOK [ b_k ] ; } aeyt1tjqck ( ubOK ,
tmp_data , & tmp_size ) ; indicesUpperBoundViolation_size_idx_0 = tmp_size ;
loop_ub = tmp_size ; if ( loop_ub - 1 >= 0 ) { memcpy ( &
indicesUpperBoundViolation_data [ 0 ] , & tmp_data [ 0 ] , loop_ub * sizeof (
int32_T ) ) ; } for ( b_k = 0 ; b_k < indicesUpperBoundViolation_size_idx_0 ;
b_k ++ ) { indicesUpperBoundViolation = indicesUpperBoundViolation_data [ b_k
] ; initialGuess [ indicesUpperBoundViolation - 1 ] = limits -> data [
indicesUpperBoundViolation - 1 ] ; } } gunzkbl0qg ( & endEffectorName , 2 ) ;
bqde2t5zai ( obj -> Solver , initialGuess , qvSolRaw ,
solutionInfo_Iterations , solutionInfo_NumRandomRestarts ,
solutionInfo_PoseErrorNorm , solutionInfo_ExitFlag , solutionInfo_Status_data
, solutionInfo_Status_size ) ; obj_p = obj -> RigidBodyTreeInternal ; nm1d2 =
endEffectorName -> size [ 0 ] * endEffectorName -> size [ 1 ] ;
endEffectorName -> size [ 0 ] = 1 ; endEffectorName -> size [ 1 ] = obj ->
Solver -> ExtraArgs -> BodyName -> size [ 1 ] ; ac0ugu5nlz ( endEffectorName
, nm1d2 ) ; loop_ub = obj -> Solver -> ExtraArgs -> BodyName -> size [ 1 ] -
1 ; for ( b_k = 0 ; b_k <= loop_ub ; b_k ++ ) { endEffectorName -> data [ b_k
] = obj -> Solver -> ExtraArgs -> BodyName -> data [ b_k ] ; } cy4r1g1cm1 ( &
bodyIndices , 1 ) ; nm1d2 = bodyIndices -> size [ 0 ] ; bodyIndices -> size [
0 ] = ( int32_T ) obj_p -> NumBodies ; ier0p3wwtw ( bodyIndices , nm1d2 ) ;
loop_ub = ( int32_T ) obj_p -> NumBodies ; if ( loop_ub - 1 >= 0 ) { memset (
& bodyIndices -> data [ 0 ] , 0 , loop_ub * sizeof ( real_T ) ) ; } bid =
lgt1s4cluf ( obj_p , endEffectorName ) ; b0l0vcvht3 ( & endEffectorName ) ;
if ( bid == 0.0 ) { nm1d2 = bodyIndices -> size [ 0 ] ; bodyIndices -> size [
0 ] = 1 ; ier0p3wwtw ( bodyIndices , nm1d2 ) ; bodyIndices -> data [ 0 ] =
0.0 ; } else { body = obj_p -> Bodies [ ( int32_T ) bid - 1 ] ; bid = 1.0 ;
while ( body -> ParentIndex != 0.0 ) { bodyIndices -> data [ ( int32_T ) bid
- 1 ] = body -> Index ; body = obj_p -> Bodies [ ( int32_T ) body ->
ParentIndex - 1 ] ; bid ++ ; } if ( bid - 1.0 < 1.0 ) {
indicesUpperBoundViolation_size_idx_0 = - 1 ; } else {
indicesUpperBoundViolation_size_idx_0 = ( int32_T ) ( bid - 1.0 ) - 1 ; }
nm1d2 = bodyIndices -> size [ 0 ] ; bodyIndices -> size [ 0 ] =
indicesUpperBoundViolation_size_idx_0 + 3 ; ier0p3wwtw ( bodyIndices , nm1d2
) ; bodyIndices -> data [ indicesUpperBoundViolation_size_idx_0 + 1 ] = body
-> Index ; bodyIndices -> data [ indicesUpperBoundViolation_size_idx_0 + 2 ]
= 0.0 ; } obj_p = obj -> RigidBodyTreeInternal ; b_k = bodyIndices -> size [
0 ] - 1 ; indicesUpperBoundViolation_size_idx_0 = 0 ; for (
indicesUpperBoundViolation = 0 ; indicesUpperBoundViolation <= b_k ;
indicesUpperBoundViolation ++ ) { if ( bodyIndices -> data [
indicesUpperBoundViolation ] != 0.0 ) { indicesUpperBoundViolation_size_idx_0
++ ; } } jw4vvjgwpp ( & h , 1 ) ; nm1d2 = h -> size [ 0 ] ; h -> size [ 0 ] =
indicesUpperBoundViolation_size_idx_0 ; f4i2s4lxoo ( h , nm1d2 ) ;
indicesUpperBoundViolation_size_idx_0 = 0 ; for ( indicesUpperBoundViolation
= 0 ; indicesUpperBoundViolation <= b_k ; indicesUpperBoundViolation ++ ) {
if ( bodyIndices -> data [ indicesUpperBoundViolation ] != 0.0 ) { h -> data
[ indicesUpperBoundViolation_size_idx_0 ] = indicesUpperBoundViolation + 1 ;
indicesUpperBoundViolation_size_idx_0 ++ ; } } nm1d2 = limits -> size [ 0 ] *
limits -> size [ 1 ] ; limits -> size [ 0 ] = h -> size [ 0 ] ; limits ->
size [ 1 ] = 2 ; ier0p3wwtw ( limits , nm1d2 ) ; loop_ub = h -> size [ 0 ] ;
for ( b_k = 0 ; b_k < 2 ; b_k ++ ) { for ( indicesUpperBoundViolation = 0 ;
indicesUpperBoundViolation < loop_ub ; indicesUpperBoundViolation ++ ) {
limits -> data [ indicesUpperBoundViolation + limits -> size [ 0 ] * b_k ] =
obj_p -> PositionDoFMap [ ( ( int32_T ) bodyIndices -> data [ h -> data [
indicesUpperBoundViolation ] - 1 ] + 5 * b_k ) - 1 ] ; } } g0pzyoia5l ( & h )
; njzmd0hlqd ( & bodyIndices ) ; cy4r1g1cm1 ( & positionIndices , 2 ) ; nm1d2
= positionIndices -> size [ 0 ] * positionIndices -> size [ 1 ] ;
positionIndices -> size [ 0 ] = 1 ; positionIndices -> size [ 1 ] = ( int32_T
) obj_p -> PositionNumber ; ier0p3wwtw ( positionIndices , nm1d2 ) ; loop_ub
= ( int32_T ) obj_p -> PositionNumber - 1 ; if ( loop_ub >= 0 ) { memset ( &
positionIndices -> data [ 0 ] , 0 , ( loop_ub + 1 ) * sizeof ( real_T ) ) ; }
bid = 0.0 ; indicesUpperBoundViolation_size_idx_0 = limits -> size [ 0 ] - 1
; cy4r1g1cm1 ( & e , 2 ) ; muadc51of1 ( & y , 2 ) ; for (
indicesUpperBoundViolation = 0 ; indicesUpperBoundViolation <=
indicesUpperBoundViolation_size_idx_0 ; indicesUpperBoundViolation ++ ) {
numPositions = ( limits -> data [ indicesUpperBoundViolation + limits -> size
[ 0 ] ] - limits -> data [ indicesUpperBoundViolation ] ) + 1.0 ; if (
numPositions > 0.0 ) { if ( numPositions < 1.0 ) { y -> size [ 0 ] = 1 ; y ->
size [ 1 ] = 0 ; } else { nm1d2 = y -> size [ 0 ] * y -> size [ 1 ] ; y ->
size [ 0 ] = 1 ; y -> size [ 1 ] = ( int32_T ) ( numPositions - 1.0 ) + 1 ;
ghsky5aveh ( y , nm1d2 ) ; loop_ub = ( int32_T ) ( numPositions - 1.0 ) ; for
( b_k = 0 ; b_k <= loop_ub ; b_k ++ ) { y -> data [ b_k ] = b_k + 1U ; } } if
( muDoubleScalarIsNaN ( limits -> data [ indicesUpperBoundViolation ] ) ||
muDoubleScalarIsNaN ( limits -> data [ indicesUpperBoundViolation + limits ->
size [ 0 ] ] ) ) { nm1d2 = e -> size [ 0 ] * e -> size [ 1 ] ; e -> size [ 0
] = 1 ; e -> size [ 1 ] = 1 ; ier0p3wwtw ( e , nm1d2 ) ; e -> data [ 0 ] = (
rtNaN ) ; } else if ( limits -> data [ indicesUpperBoundViolation + limits ->
size [ 0 ] ] < limits -> data [ indicesUpperBoundViolation ] ) { e -> size [
0 ] = 1 ; e -> size [ 1 ] = 0 ; } else if ( ( muDoubleScalarIsInf ( limits ->
data [ indicesUpperBoundViolation ] ) || muDoubleScalarIsInf ( limits -> data
[ indicesUpperBoundViolation + limits -> size [ 0 ] ] ) ) && ( limits -> data
[ indicesUpperBoundViolation + limits -> size [ 0 ] ] == limits -> data [
indicesUpperBoundViolation ] ) ) { nm1d2 = e -> size [ 0 ] * e -> size [ 1 ]
; e -> size [ 0 ] = 1 ; e -> size [ 1 ] = 1 ; ier0p3wwtw ( e , nm1d2 ) ; e ->
data [ 0 ] = ( rtNaN ) ; } else if ( muDoubleScalarFloor ( limits -> data [
indicesUpperBoundViolation ] ) == limits -> data [ indicesUpperBoundViolation
] ) { nm1d2 = e -> size [ 0 ] * e -> size [ 1 ] ; e -> size [ 0 ] = 1 ; e ->
size [ 1 ] = ( int32_T ) ( limits -> data [ indicesUpperBoundViolation +
limits -> size [ 0 ] ] - limits -> data [ indicesUpperBoundViolation ] ) + 1
; ier0p3wwtw ( e , nm1d2 ) ; loop_ub = ( int32_T ) ( limits -> data [
indicesUpperBoundViolation + limits -> size [ 0 ] ] - limits -> data [
indicesUpperBoundViolation ] ) ; for ( b_k = 0 ; b_k <= loop_ub ; b_k ++ ) {
e -> data [ b_k ] = limits -> data [ indicesUpperBoundViolation ] + ( real_T
) b_k ; } } else { ndbl = muDoubleScalarFloor ( ( limits -> data [
indicesUpperBoundViolation + limits -> size [ 0 ] ] - limits -> data [
indicesUpperBoundViolation ] ) + 0.5 ) ; apnd = limits -> data [
indicesUpperBoundViolation ] + ndbl ; cdiff = apnd - limits -> data [
indicesUpperBoundViolation + limits -> size [ 0 ] ] ; if ( muDoubleScalarAbs
( cdiff ) < muDoubleScalarMax ( muDoubleScalarAbs ( limits -> data [
indicesUpperBoundViolation ] ) , muDoubleScalarAbs ( limits -> data [
indicesUpperBoundViolation + limits -> size [ 0 ] ] ) ) *
4.4408920985006262E-16 ) { ndbl ++ ; apnd = limits -> data [
indicesUpperBoundViolation + limits -> size [ 0 ] ] ; } else if ( cdiff > 0.0
) { apnd = ( ndbl - 1.0 ) + limits -> data [ indicesUpperBoundViolation ] ; }
else { ndbl ++ ; } if ( ndbl >= 0.0 ) { loop_ub = ( int32_T ) ndbl ; } else {
loop_ub = 0 ; } nm1d2 = e -> size [ 0 ] * e -> size [ 1 ] ; e -> size [ 0 ] =
1 ; e -> size [ 1 ] = loop_ub ; ier0p3wwtw ( e , nm1d2 ) ; if ( loop_ub > 0 )
{ e -> data [ 0 ] = limits -> data [ indicesUpperBoundViolation ] ; if (
loop_ub > 1 ) { e -> data [ loop_ub - 1 ] = apnd ; nm1d2 = ( loop_ub - 1 ) /
2 ; c = nm1d2 - 2 ; for ( b_k = 0 ; b_k <= c ; b_k ++ ) { e -> data [ b_k + 1
] = ( real_T ) ( b_k + 1 ) + limits -> data [ indicesUpperBoundViolation ] ;
e -> data [ ( loop_ub - b_k ) - 2 ] = apnd - ( real_T ) ( b_k + 1 ) ; } if (
nm1d2 << 1 == loop_ub - 1 ) { e -> data [ nm1d2 ] = ( limits -> data [
indicesUpperBoundViolation ] + apnd ) / 2.0 ; } else { e -> data [ nm1d2 ] =
limits -> data [ indicesUpperBoundViolation ] + ( real_T ) nm1d2 ; e -> data
[ nm1d2 + 1 ] = apnd - ( real_T ) nm1d2 ; } } } } loop_ub = e -> size [ 1 ] -
1 ; for ( b_k = 0 ; b_k <= loop_ub ; b_k ++ ) { positionIndices -> data [ (
int32_T ) ( bid + ( real_T ) y -> data [ b_k ] ) - 1 ] = e -> data [ b_k ] ;
} bid += numPositions ; } } npfzq14tu1 ( & y ) ; njzmd0hlqd ( & e ) ;
njzmd0hlqd ( & limits ) ; if ( bid < 1.0 ) { positionIndices -> size [ 1 ] =
0 ; } else { nm1d2 = positionIndices -> size [ 0 ] * positionIndices -> size
[ 1 ] ; positionIndices -> size [ 1 ] = ( int32_T ) bid ; ier0p3wwtw (
positionIndices , nm1d2 ) ; } loop_ub = positionIndices -> size [ 1 ] ; for (
b_k = 0 ; b_k < loop_ub ; b_k ++ ) { bid = positionIndices -> data [ b_k ] ;
initialGuess [ ( int32_T ) bid - 1 ] = qvSolRaw [ ( int32_T ) bid - 1 ] ; }
njzmd0hlqd ( & positionIndices ) ; } static void e3cpkwfxpp ( iabjthfi1p *
obj , const real_T tform [ 16 ] , const real_T weights [ 6 ] , const real_T
initialGuess [ 5 ] , real_T QSol [ 5 ] ) { l2t3f2z1w3 * args ; real_T
weightMatrix [ 36 ] ; real_T expl_temp ; real_T expl_temp_e ; real_T
expl_temp_i ; real_T expl_temp_p ; int32_T i ; char_T expl_temp_data [ 14 ] ;
static const char_T tmp [ 5 ] = { 'B' , 'o' , 'd' , 'y' , '5' } ; int32_T
expl_temp_size [ 2 ] ; memset ( & weightMatrix [ 0 ] , 0 , 36U * sizeof (
real_T ) ) ; for ( i = 0 ; i < 6 ; i ++ ) { weightMatrix [ i + 6 * i ] =
weights [ i ] ; } args = obj -> Solver -> ExtraArgs ; for ( i = 0 ; i < 36 ;
i ++ ) { args -> WeightMatrix [ i ] = weightMatrix [ i ] ; } i = args ->
BodyName -> size [ 0 ] * args -> BodyName -> size [ 1 ] ; args -> BodyName ->
size [ 0 ] = 1 ; args -> BodyName -> size [ 1 ] = 5 ; ac0ugu5nlz ( args ->
BodyName , i ) ; for ( i = 0 ; i < 5 ; i ++ ) { args -> BodyName -> data [ i
] = tmp [ i ] ; } for ( i = 0 ; i < 16 ; i ++ ) { args -> Tform [ i ] = tform
[ i ] ; } for ( i = 0 ; i < 5 ; i ++ ) { QSol [ i ] = initialGuess [ i ] ; }
g30rxyn4gkf ( obj , QSol , & expl_temp , & expl_temp_p , & expl_temp_e , &
expl_temp_i , expl_temp_data , expl_temp_size ) ; } static void k5uooz0d10 (
fgmfslti0b * emxArray , int32_T oldNumel ) { int32_T i ; int32_T newNumel ;
void * newData ; if ( oldNumel < 0 ) { oldNumel = 0 ; } newNumel = 1 ; for (
i = 0 ; i < emxArray -> numDimensions ; i ++ ) { newNumel *= emxArray -> size
[ i ] ; } if ( newNumel > emxArray -> allocatedSize ) { i = emxArray ->
allocatedSize ; if ( i < 16 ) { i = 16 ; } while ( i < newNumel ) { if ( i >
1073741823 ) { i = MAX_int32_T ; } else { i <<= 1 ; } } newData = calloc ( (
uint32_T ) i , sizeof ( csbe03lymu ) ) ; if ( emxArray -> data != NULL ) {
memcpy ( newData , emxArray -> data , sizeof ( csbe03lymu ) * oldNumel ) ; if
( emxArray -> canFreeData ) { free ( emxArray -> data ) ; } } emxArray ->
data = ( csbe03lymu * ) newData ; emxArray -> allocatedSize = i ; emxArray ->
canFreeData = true ; } } static void ocuijkr1g1 ( const iyg0swfnbf * obj ,
real_T ax [ 3 ] ) { int32_T b_kstr ; char_T b_p [ 9 ] ; char_T b [ 8 ] ;
boolean_T b_bool ; static const char_T tmp [ 8 ] = { 'r' , 'e' , 'v' , 'o' ,
'l' , 'u' , 't' , 'e' } ; static const char_T tmp_p [ 9 ] = { 'p' , 'r' , 'i'
, 's' , 'm' , 'a' , 't' , 'i' , 'c' } ; int32_T exitg1 ; boolean_T guard1 =
false ; for ( b_kstr = 0 ; b_kstr < 8 ; b_kstr ++ ) { b [ b_kstr ] = tmp [
b_kstr ] ; } b_bool = false ; if ( obj -> Type -> size [ 1 ] != 8 ) { } else
{ b_kstr = 1 ; do { exitg1 = 0 ; if ( b_kstr - 1 < 8 ) { if ( obj -> Type ->
data [ b_kstr - 1 ] != b [ b_kstr - 1 ] ) { exitg1 = 1 ; } else { b_kstr ++ ;
} } else { b_bool = true ; exitg1 = 1 ; } } while ( exitg1 == 0 ) ; } guard1
= false ; if ( b_bool ) { guard1 = true ; } else { for ( b_kstr = 0 ; b_kstr
< 9 ; b_kstr ++ ) { b_p [ b_kstr ] = tmp_p [ b_kstr ] ; } if ( obj -> Type ->
size [ 1 ] != 9 ) { } else { b_kstr = 1 ; do { exitg1 = 0 ; if ( b_kstr - 1 <
9 ) { if ( obj -> Type -> data [ b_kstr - 1 ] != b_p [ b_kstr - 1 ] ) {
exitg1 = 1 ; } else { b_kstr ++ ; } } else { b_bool = true ; exitg1 = 1 ; } }
while ( exitg1 == 0 ) ; } if ( b_bool ) { guard1 = true ; } else { ax [ 0 ] =
( rtNaN ) ; ax [ 1 ] = ( rtNaN ) ; ax [ 2 ] = ( rtNaN ) ; } } if ( guard1 ) {
ax [ 0 ] = obj -> JointAxisInternal [ 0 ] ; ax [ 1 ] = obj ->
JointAxisInternal [ 1 ] ; ax [ 2 ] = obj -> JointAxisInternal [ 2 ] ; } }
static void evz05l0h04 ( kp1en3mw3x * obj , const real_T qvec [ 5 ] ,
fgmfslti0b * Ttree ) { csbe03lymu expl_temp ; e2b0f4s35s * switch_expression
; gxcsgl11sl * body ; real_T a [ 16 ] ; real_T a_p [ 16 ] ; real_T b [ 16 ] ;
real_T b_p [ 16 ] ; real_T R [ 9 ] ; real_T tempR [ 9 ] ; real_T result_data
[ 4 ] ; real_T v [ 3 ] ; real_T cth ; real_T k ; real_T n ; real_T theta ;
int32_T b_jtilecol ; int32_T d ; int32_T e ; int32_T i ; int32_T loop_ub ;
int32_T ntilecols ; char_T b_i [ 8 ] ; char_T b_e [ 5 ] ; boolean_T b_bool ;
static const int8_T tmp [ 16 ] = { 1 , 0 , 0 , 0 , 0 , 1 , 0 , 0 , 0 , 0 , 1
, 0 , 0 , 0 , 0 , 1 } ; static const char_T tmp_p [ 5 ] = { 'f' , 'i' , 'x' ,
'e' , 'd' } ; static const char_T tmp_e [ 8 ] = { 'r' , 'e' , 'v' , 'o' , 'l'
, 'u' , 't' , 'e' } ; int32_T exitg1 ; n = obj -> NumBodies ; for ( i = 0 ; i
< 16 ; i ++ ) { expl_temp . f1 [ i ] = tmp [ i ] ; } i = Ttree -> size [ 0 ]
* Ttree -> size [ 1 ] ; Ttree -> size [ 0 ] = 1 ; Ttree -> size [ 1 ] = (
int32_T ) n ; k5uooz0d10 ( Ttree , i ) ; if ( ( int32_T ) n != 0 ) {
ntilecols = ( int32_T ) n - 1 ; for ( b_jtilecol = 0 ; b_jtilecol <=
ntilecols ; b_jtilecol ++ ) { Ttree -> data [ b_jtilecol ] = expl_temp ; } }
k = 1.0 ; ntilecols = ( int32_T ) n - 1 ; if ( ( int32_T ) n - 1 >= 0 ) { for
( i = 0 ; i < 5 ; i ++ ) { b_e [ i ] = tmp_p [ i ] ; } } gunzkbl0qg ( &
switch_expression , 2 ) ; for ( b_jtilecol = 0 ; b_jtilecol <= ntilecols ;
b_jtilecol ++ ) { body = obj -> Bodies [ b_jtilecol ] ; n = body ->
JointInternal . PositionNumber ; cth = ( k + n ) - 1.0 ; if ( k > cth ) { e =
0 ; d = 0 ; } else { e = ( int32_T ) k - 1 ; d = ( int32_T ) cth ; } for ( i
= 0 ; i < 16 ; i ++ ) { a [ i ] = body -> JointInternal .
JointToParentTransform [ i ] ; } i = switch_expression -> size [ 0 ] *
switch_expression -> size [ 1 ] ; switch_expression -> size [ 0 ] = 1 ;
switch_expression -> size [ 1 ] = body -> JointInternal . Type -> size [ 1 ]
; ac0ugu5nlz ( switch_expression , i ) ; loop_ub = body -> JointInternal .
Type -> size [ 1 ] - 1 ; for ( i = 0 ; i <= loop_ub ; i ++ ) {
switch_expression -> data [ i ] = body -> JointInternal . Type -> data [ i ]
; } b_bool = false ; if ( switch_expression -> size [ 1 ] != 5 ) { } else { i
= 1 ; do { exitg1 = 0 ; if ( i - 1 < 5 ) { if ( switch_expression -> data [ i
- 1 ] != b_e [ i - 1 ] ) { exitg1 = 1 ; } else { i ++ ; } } else { b_bool =
true ; exitg1 = 1 ; } } while ( exitg1 == 0 ) ; } if ( b_bool ) { cth = 0.0 ;
} else { for ( i = 0 ; i < 8 ; i ++ ) { b_i [ i ] = tmp_e [ i ] ; } if (
switch_expression -> size [ 1 ] != 8 ) { } else { i = 1 ; do { exitg1 = 0 ;
if ( i - 1 < 8 ) { if ( switch_expression -> data [ i - 1 ] != b_i [ i - 1 ]
) { exitg1 = 1 ; } else { i ++ ; } } else { b_bool = true ; exitg1 = 1 ; } }
while ( exitg1 == 0 ) ; } if ( b_bool ) { cth = 1.0 ; } else { cth = - 1.0 ;
} } switch ( ( int32_T ) cth ) { case 0 : memset ( & b [ 0 ] , 0 , sizeof (
real_T ) << 4U ) ; b [ 0 ] = 1.0 ; b [ 5 ] = 1.0 ; b [ 10 ] = 1.0 ; b [ 15 ]
= 1.0 ; break ; case 1 : ocuijkr1g1 ( & body -> JointInternal , v ) ;
result_data [ 0 ] = v [ 0 ] ; result_data [ 1 ] = v [ 1 ] ; result_data [ 2 ]
= v [ 2 ] ; if ( ( d - e != 0 ) - 1 >= 0 ) { result_data [ 3 ] = qvec [ e ] ;
} cth = result_data [ 0 ] ; v [ 0 ] = cth * cth ; cth = result_data [ 1 ] ; v
[ 1 ] = cth * cth ; cth = result_data [ 2 ] ; cth = 1.0 / muDoubleScalarSqrt
( ( v [ 0 ] + v [ 1 ] ) + cth * cth ) ; v [ 0 ] = result_data [ 0 ] * cth ; v
[ 1 ] = result_data [ 1 ] * cth ; v [ 2 ] = result_data [ 2 ] * cth ; theta =
result_data [ 3 ] ; cth = muDoubleScalarCos ( theta ) ; theta =
muDoubleScalarSin ( theta ) ; tempR [ 0 ] = v [ 0 ] * v [ 0 ] * ( 1.0 - cth )
+ cth ; tempR [ 1 ] = v [ 0 ] * v [ 1 ] * ( 1.0 - cth ) - v [ 2 ] * theta ;
tempR [ 2 ] = v [ 0 ] * v [ 2 ] * ( 1.0 - cth ) + v [ 1 ] * theta ; tempR [ 3
] = v [ 0 ] * v [ 1 ] * ( 1.0 - cth ) + v [ 2 ] * theta ; tempR [ 4 ] = v [ 1
] * v [ 1 ] * ( 1.0 - cth ) + cth ; tempR [ 5 ] = v [ 1 ] * v [ 2 ] * ( 1.0 -
cth ) - v [ 0 ] * theta ; tempR [ 6 ] = v [ 0 ] * v [ 2 ] * ( 1.0 - cth ) - v
[ 1 ] * theta ; tempR [ 7 ] = v [ 1 ] * v [ 2 ] * ( 1.0 - cth ) + v [ 0 ] *
theta ; tempR [ 8 ] = v [ 2 ] * v [ 2 ] * ( 1.0 - cth ) + cth ; for ( d = 0 ;
d < 3 ; d ++ ) { R [ d ] = tempR [ d * 3 ] ; R [ d + 3 ] = tempR [ d * 3 + 1
] ; R [ d + 6 ] = tempR [ d * 3 + 2 ] ; } memset ( & b [ 0 ] , 0 , sizeof (
real_T ) << 4U ) ; for ( i = 0 ; i < 3 ; i ++ ) { b [ i << 2 ] = R [ 3 * i ]
; b [ ( i << 2 ) + 1 ] = R [ 3 * i + 1 ] ; b [ ( i << 2 ) + 2 ] = R [ 3 * i +
2 ] ; } b [ 15 ] = 1.0 ; break ; default : ocuijkr1g1 ( & body ->
JointInternal , v ) ; memset ( & tempR [ 0 ] , 0 , 9U * sizeof ( real_T ) ) ;
tempR [ 0 ] = 1.0 ; tempR [ 4 ] = 1.0 ; tempR [ 8 ] = 1.0 ; cth = qvec [ e ]
; for ( i = 0 ; i < 3 ; i ++ ) { b [ i << 2 ] = tempR [ 3 * i ] ; b [ ( i <<
2 ) + 1 ] = tempR [ 3 * i + 1 ] ; b [ ( i << 2 ) + 2 ] = tempR [ 3 * i + 2 ]
; b [ i + 12 ] = v [ i ] * cth ; } b [ 3 ] = 0.0 ; b [ 7 ] = 0.0 ; b [ 11 ] =
0.0 ; b [ 15 ] = 1.0 ; break ; } for ( i = 0 ; i < 16 ; i ++ ) { b_p [ i ] =
body -> JointInternal . ChildToJointTransform [ i ] ; } for ( i = 0 ; i < 4 ;
i ++ ) { for ( d = 0 ; d < 4 ; d ++ ) { a_p [ i + ( d << 2 ) ] = 0.0 ; a_p [
i + ( d << 2 ) ] += b [ d << 2 ] * a [ i ] ; a_p [ i + ( d << 2 ) ] += b [ (
d << 2 ) + 1 ] * a [ i + 4 ] ; a_p [ i + ( d << 2 ) ] += b [ ( d << 2 ) + 2 ]
* a [ i + 8 ] ; a_p [ i + ( d << 2 ) ] += b [ ( d << 2 ) + 3 ] * a [ i + 12 ]
; } for ( d = 0 ; d < 4 ; d ++ ) { Ttree -> data [ b_jtilecol ] . f1 [ i + (
d << 2 ) ] = 0.0 ; Ttree -> data [ b_jtilecol ] . f1 [ i + ( d << 2 ) ] =
Ttree -> data [ b_jtilecol ] . f1 [ ( d << 2 ) + i ] + b_p [ d << 2 ] * a_p [
i ] ; Ttree -> data [ b_jtilecol ] . f1 [ i + ( d << 2 ) ] = b_p [ ( d << 2 )
+ 1 ] * a_p [ i + 4 ] + Ttree -> data [ b_jtilecol ] . f1 [ ( d << 2 ) + i ]
; Ttree -> data [ b_jtilecol ] . f1 [ i + ( d << 2 ) ] = b_p [ ( d << 2 ) + 2
] * a_p [ i + 8 ] + Ttree -> data [ b_jtilecol ] . f1 [ ( d << 2 ) + i ] ;
Ttree -> data [ b_jtilecol ] . f1 [ i + ( d << 2 ) ] = b_p [ ( d << 2 ) + 3 ]
* a_p [ i + 12 ] + Ttree -> data [ b_jtilecol ] . f1 [ ( d << 2 ) + i ] ; } }
k += n ; if ( body -> ParentIndex > 0.0 ) { for ( i = 0 ; i < 16 ; i ++ ) { a
[ i ] = Ttree -> data [ ( int32_T ) body -> ParentIndex - 1 ] . f1 [ i ] ; }
for ( i = 0 ; i < 4 ; i ++ ) { for ( d = 0 ; d < 4 ; d ++ ) { a_p [ i + ( d
<< 2 ) ] = 0.0 ; a_p [ i + ( d << 2 ) ] += Ttree -> data [ b_jtilecol ] . f1
[ d << 2 ] * a [ i ] ; a_p [ i + ( d << 2 ) ] += Ttree -> data [ b_jtilecol ]
. f1 [ ( d << 2 ) + 1 ] * a [ i + 4 ] ; a_p [ i + ( d << 2 ) ] += Ttree ->
data [ b_jtilecol ] . f1 [ ( d << 2 ) + 2 ] * a [ i + 8 ] ; a_p [ i + ( d <<
2 ) ] += Ttree -> data [ b_jtilecol ] . f1 [ ( d << 2 ) + 3 ] * a [ i + 12 ]
; } } memcpy ( & Ttree -> data [ b_jtilecol ] . f1 [ 0 ] , & a_p [ 0 ] ,
sizeof ( real_T ) << 4U ) ; } } b0l0vcvht3 ( & switch_expression ) ; } static
void ocuijkr1g1j ( const iyg0swfnbfo * obj , real_T ax [ 3 ] ) { int32_T
b_kstr ; char_T b_p [ 9 ] ; char_T b [ 8 ] ; boolean_T b_bool ; static const
char_T tmp [ 8 ] = { 'r' , 'e' , 'v' , 'o' , 'l' , 'u' , 't' , 'e' } ; static
const char_T tmp_p [ 9 ] = { 'p' , 'r' , 'i' , 's' , 'm' , 'a' , 't' , 'i' ,
'c' } ; int32_T exitg1 ; boolean_T guard1 = false ; for ( b_kstr = 0 ; b_kstr
< 8 ; b_kstr ++ ) { b [ b_kstr ] = tmp [ b_kstr ] ; } b_bool = false ; if (
obj -> Type -> size [ 1 ] != 8 ) { } else { b_kstr = 1 ; do { exitg1 = 0 ; if
( b_kstr - 1 < 8 ) { if ( obj -> Type -> data [ b_kstr - 1 ] != b [ b_kstr -
1 ] ) { exitg1 = 1 ; } else { b_kstr ++ ; } } else { b_bool = true ; exitg1 =
1 ; } } while ( exitg1 == 0 ) ; } guard1 = false ; if ( b_bool ) { guard1 =
true ; } else { for ( b_kstr = 0 ; b_kstr < 9 ; b_kstr ++ ) { b_p [ b_kstr ]
= tmp_p [ b_kstr ] ; } if ( obj -> Type -> size [ 1 ] != 9 ) { } else {
b_kstr = 1 ; do { exitg1 = 0 ; if ( b_kstr - 1 < 9 ) { if ( obj -> Type ->
data [ b_kstr - 1 ] != b_p [ b_kstr - 1 ] ) { exitg1 = 1 ; } else { b_kstr ++
; } } else { b_bool = true ; exitg1 = 1 ; } } while ( exitg1 == 0 ) ; } if (
b_bool ) { guard1 = true ; } else { ax [ 0 ] = ( rtNaN ) ; ax [ 1 ] = ( rtNaN
) ; ax [ 2 ] = ( rtNaN ) ; } } if ( guard1 ) { ax [ 0 ] = obj ->
JointAxisInternal [ 0 ] ; ax [ 1 ] = obj -> JointAxisInternal [ 1 ] ; ax [ 2
] = obj -> JointAxisInternal [ 2 ] ; } } static void nzox4rsktc ( fgmfslti0b
* * pEmxArray ) { if ( * pEmxArray != ( fgmfslti0b * ) NULL ) { if ( ( ( *
pEmxArray ) -> data != ( csbe03lymu * ) NULL ) && ( * pEmxArray ) ->
canFreeData ) { free ( ( * pEmxArray ) -> data ) ; } free ( ( * pEmxArray )
-> size ) ; free ( * pEmxArray ) ; * pEmxArray = ( fgmfslti0b * ) NULL ; } }
static void juzhbp4evd ( gxcsgl11sl35 * pStruct ) { b0l0vcvht3 ( & pStruct ->
NameInternal ) ; } static void juzhbp4evdmo ( gtd4jhsf2rw * pStruct ) {
mepjkxapz0 ( & pStruct -> CollisionGeometries ) ; } static void khxkdsmcld (
gtd4jhsf2rw pMatrix [ 11 ] ) { int32_T i ; for ( i = 0 ; i < 11 ; i ++ ) {
juzhbp4evdmo ( & pMatrix [ i ] ) ; } } static void aribxozslp ( iyg0swfnbfoc
* pStruct ) { b0l0vcvht3 ( & pStruct -> Type ) ; njzmd0hlqd ( & pStruct ->
MotionSubspace ) ; b0l0vcvht3 ( & pStruct -> NameInternal ) ; njzmd0hlqd ( &
pStruct -> PositionLimitsInternal ) ; njzmd0hlqd ( & pStruct ->
HomePositionInternal ) ; } static void bid1osq2cg ( iyg0swfnbfoc pMatrix [ 11
] ) { int32_T i ; for ( i = 0 ; i < 11 ; i ++ ) { aribxozslp ( & pMatrix [ i
] ) ; } } static void khxkdsmcldw ( gxcsgl11sl35 pMatrix [ 10 ] ) { int32_T i
; for ( i = 0 ; i < 10 ; i ++ ) { juzhbp4evd ( & pMatrix [ i ] ) ; } } static
void juzhbp4evdm ( kp1en3mw3xln * pStruct ) { juzhbp4evd ( & pStruct -> Base
) ; khxkdsmcld ( pStruct -> _pobj0 ) ; bid1osq2cg ( pStruct -> _pobj1 ) ;
khxkdsmcldw ( pStruct -> _pobj2 ) ; } static void juzhbp4evdmo5 ( l2t3f2z1w3
* pStruct ) { njzmd0hlqd ( & pStruct -> Limits ) ; b0l0vcvht3 ( & pStruct ->
BodyName ) ; njzmd0hlqd ( & pStruct -> ErrTemp ) ; njzmd0hlqd ( & pStruct ->
GradTemp ) ; } static void gbw5gf1tdg ( iyg0swfnbfoc pMatrix [ 10 ] ) {
int32_T i ; for ( i = 0 ; i < 10 ; i ++ ) { aribxozslp ( & pMatrix [ i ] ) ;
} } static void khxkdsmcldwh ( gxcsgl11sl35 pMatrix [ 5 ] ) { int32_T i ; for
( i = 0 ; i < 5 ; i ++ ) { juzhbp4evd ( & pMatrix [ i ] ) ; } } static void
khxkdsmcldwho ( gtd4jhsf2rw pMatrix [ 6 ] ) { int32_T i ; for ( i = 0 ; i < 6
; i ++ ) { juzhbp4evdmo ( & pMatrix [ i ] ) ; } } static void a0paw2qkcg (
iyg0swfnbfoc pMatrix [ 6 ] ) { int32_T i ; for ( i = 0 ; i < 6 ; i ++ ) {
aribxozslp ( & pMatrix [ i ] ) ; } } static void juzhbp4evdmo5g ( itgfp4rmev
* pStruct ) { juzhbp4evd ( & pStruct -> Base ) ; khxkdsmcldwh ( pStruct ->
_pobj0 ) ; khxkdsmcldwho ( pStruct -> _pobj1 ) ; a0paw2qkcg ( pStruct ->
_pobj2 ) ; } static void ahaxxg3t2t ( iabjthfi1p * pStruct ) { njzmd0hlqd ( &
pStruct -> Limits ) ; juzhbp4evdmo5 ( & pStruct -> _pobj0 ) ; gbw5gf1tdg (
pStruct -> _pobj1 ) ; khxkdsmcldwh ( pStruct -> _pobj2 ) ; khxkdsmcld (
pStruct -> _pobj3 ) ; juzhbp4evdmo5g ( & pStruct -> _pobj4 ) ; } static void
oh1nyigqv2 ( gh04rvpx0o * pStruct ) { juzhbp4evdm ( & pStruct -> TreeInternal
) ; ahaxxg3t2t ( & pStruct -> IKInternal ) ; } static void nxlivroytl (
iyg0swfnbf * pStruct ) { b0l0vcvht3 ( & pStruct -> Type ) ; njzmd0hlqd ( &
pStruct -> MotionSubspace ) ; } static void gk3x1bjsmm ( gtd4jhsf2r * pStruct
) { mepjkxapz0 ( & pStruct -> CollisionGeometries ) ; } static void
juzhbp4evdmo5gl ( gxcsgl11sl * pStruct ) { b0l0vcvht3 ( & pStruct ->
NameInternal ) ; nxlivroytl ( & pStruct -> JointInternal ) ; gk3x1bjsmm ( &
pStruct -> CollisionsInternal ) ; } static void khxkdsmcldwhoy ( gxcsgl11sl
pMatrix [ 10 ] ) { int32_T i ; for ( i = 0 ; i < 10 ; i ++ ) {
juzhbp4evdmo5gl ( & pMatrix [ i ] ) ; } } static void fmoeizylmr ( kp1en3mw3x
* pStruct ) { juzhbp4evdmo5gl ( & pStruct -> Base ) ; khxkdsmcldwhoy (
pStruct -> _pobj0 ) ; } static void oh1nyigqv24 ( exm4lytzjq * pStruct ) {
fmoeizylmr ( & pStruct -> TreeInternal ) ; } static void os2w0ymkwg (
iyg0swfnbfo * pStruct ) { b0l0vcvht3 ( & pStruct -> Type ) ; } static void
j4fdhx0u05 ( gxcsgl11sl3 * pStruct ) { b0l0vcvht3 ( & pStruct -> NameInternal
) ; os2w0ymkwg ( & pStruct -> JointInternal ) ; gk3x1bjsmm ( & pStruct ->
CollisionsInternal ) ; } static void khxkdsmcldwhoyw ( gxcsgl11sl3 pMatrix [
10 ] ) { int32_T i ; for ( i = 0 ; i < 10 ; i ++ ) { j4fdhx0u05 ( & pMatrix [
i ] ) ; } } static void olsrt3fqep ( kp1en3mw3xl * pStruct ) { j4fdhx0u05 ( &
pStruct -> Base ) ; khxkdsmcldwhoyw ( pStruct -> _pobj0 ) ; } static void
oh1nyigqv241 ( gsvdge1jib * pStruct ) { olsrt3fqep ( & pStruct ->
TreeInternal ) ; } void MdlStart ( void ) { NeModelParameters modelParameters
; NeModelParameters modelParameters_p ; NeslSimulationData * tmp_e ;
NeslSimulator * tmp ; NeuDiagnosticManager * diagnosticManager ;
NeuDiagnosticTree * diagnosticTree ; NeuDiagnosticTree * diagnosticTree_p ;
char * msg ; char * msg_p ; real_T tmp_i ; int32_T i ; boolean_T tmp_p ;
boolean_T val ; static const uint32_T tmp_m [ 625 ] = { 5489U , 1301868182U ,
2938499221U , 2950281878U , 1875628136U , 751856242U , 944701696U ,
2243192071U , 694061057U , 219885934U , 2066767472U , 3182869408U ,
485472502U , 2336857883U , 1071588843U , 3418470598U , 951210697U ,
3693558366U , 2923482051U , 1793174584U , 2982310801U , 1586906132U ,
1951078751U , 1808158765U , 1733897588U , 431328322U , 4202539044U ,
530658942U , 1714810322U , 3025256284U , 3342585396U , 1937033938U ,
2640572511U , 1654299090U , 3692403553U , 4233871309U , 3497650794U ,
862629010U , 2943236032U , 2426458545U , 1603307207U , 1133453895U ,
3099196360U , 2208657629U , 2747653927U , 931059398U , 761573964U ,
3157853227U , 785880413U , 730313442U , 124945756U , 2937117055U ,
3295982469U , 1724353043U , 3021675344U , 3884886417U , 4010150098U ,
4056961966U , 699635835U , 2681338818U , 1339167484U , 720757518U ,
2800161476U , 2376097373U , 1532957371U , 3902664099U , 1238982754U ,
3725394514U , 3449176889U , 3570962471U , 4287636090U , 4087307012U ,
3603343627U , 202242161U , 2995682783U , 1620962684U , 3704723357U ,
371613603U , 2814834333U , 2111005706U , 624778151U , 2094172212U ,
4284947003U , 1211977835U , 991917094U , 1570449747U , 2962370480U ,
1259410321U , 170182696U , 146300961U , 2836829791U , 619452428U ,
2723670296U , 1881399711U , 1161269684U , 1675188680U , 4132175277U ,
780088327U , 3409462821U , 1036518241U , 1834958505U , 3048448173U ,
161811569U , 618488316U , 44795092U , 3918322701U , 1924681712U , 3239478144U
, 383254043U , 4042306580U , 2146983041U , 3992780527U , 3518029708U ,
3545545436U , 3901231469U , 1896136409U , 2028528556U , 2339662006U ,
501326714U , 2060962201U , 2502746480U , 561575027U , 581893337U ,
3393774360U , 1778912547U , 3626131687U , 2175155826U , 319853231U ,
986875531U , 819755096U , 2915734330U , 2688355739U , 3482074849U , 2736559U
, 2296975761U , 1029741190U , 2876812646U , 690154749U , 579200347U ,
4027461746U , 1285330465U , 2701024045U , 4117700889U , 759495121U ,
3332270341U , 2313004527U , 2277067795U , 4131855432U , 2722057515U ,
1264804546U , 3848622725U , 2211267957U , 4100593547U , 959123777U ,
2130745407U , 3194437393U , 486673947U , 1377371204U , 17472727U , 352317554U
, 3955548058U , 159652094U , 1232063192U , 3835177280U , 49423123U ,
3083993636U , 733092U , 2120519771U , 2573409834U , 1112952433U , 3239502554U
, 761045320U , 1087580692U , 2540165110U , 641058802U , 1792435497U ,
2261799288U , 1579184083U , 627146892U , 2165744623U , 2200142389U ,
2167590760U , 2381418376U , 1793358889U , 3081659520U , 1663384067U ,
2009658756U , 2689600308U , 739136266U , 2304581039U , 3529067263U ,
591360555U , 525209271U , 3131882996U , 294230224U , 2076220115U ,
3113580446U , 1245621585U , 1386885462U , 3203270426U , 123512128U ,
12350217U , 354956375U , 4282398238U , 3356876605U , 3888857667U , 157639694U
, 2616064085U , 1563068963U , 2762125883U , 4045394511U , 4180452559U ,
3294769488U , 1684529556U , 1002945951U , 3181438866U , 22506664U ,
691783457U , 2685221343U , 171579916U , 3878728600U , 2475806724U ,
2030324028U , 3331164912U , 1708711359U , 1970023127U , 2859691344U ,
2588476477U , 2748146879U , 136111222U , 2967685492U , 909517429U ,
2835297809U , 3206906216U , 3186870716U , 341264097U , 2542035121U ,
3353277068U , 548223577U , 3170936588U , 1678403446U , 297435620U ,
2337555430U , 466603495U , 1132321815U , 1208589219U , 696392160U ,
894244439U , 2562678859U , 470224582U , 3306867480U , 201364898U ,
2075966438U , 1767227936U , 2929737987U , 3674877796U , 2654196643U ,
3692734598U , 3528895099U , 2796780123U , 3048728353U , 842329300U ,
191554730U , 2922459673U , 3489020079U , 3979110629U , 1022523848U ,
2202932467U , 3583655201U , 3565113719U , 587085778U , 4176046313U ,
3013713762U , 950944241U , 396426791U , 3784844662U , 3477431613U ,
3594592395U , 2782043838U , 3392093507U , 3106564952U , 2829419931U ,
1358665591U , 2206918825U , 3170783123U , 31522386U , 2988194168U ,
1782249537U , 1105080928U , 843500134U , 1225290080U , 1521001832U ,
3605886097U , 2802786495U , 2728923319U , 3996284304U , 903417639U ,
1171249804U , 1020374987U , 2824535874U , 423621996U , 1988534473U ,
2493544470U , 1008604435U , 1756003503U , 1488867287U , 1386808992U ,
732088248U , 1780630732U , 2482101014U , 976561178U , 1543448953U ,
2602866064U , 2021139923U , 1952599828U , 2360242564U , 2117959962U ,
2753061860U , 2388623612U , 4138193781U , 2962920654U , 2284970429U ,
766920861U , 3457264692U , 2879611383U , 815055854U , 2332929068U ,
1254853997U , 3740375268U , 3799380844U , 4091048725U , 2006331129U ,
1982546212U , 686850534U , 1907447564U , 2682801776U , 2780821066U ,
998290361U , 1342433871U , 4195430425U , 607905174U , 3902331779U ,
2454067926U , 1708133115U , 1170874362U , 2008609376U , 3260320415U ,
2211196135U , 433538229U , 2728786374U , 2189520818U , 262554063U ,
1182318347U , 3710237267U , 1221022450U , 715966018U , 2417068910U ,
2591870721U , 2870691989U , 3418190842U , 4238214053U , 1540704231U ,
1575580968U , 2095917976U , 4078310857U , 2313532447U , 2110690783U ,
4056346629U , 4061784526U , 1123218514U , 551538993U , 597148360U ,
4120175196U , 3581618160U , 3181170517U , 422862282U , 3227524138U ,
1713114790U , 662317149U , 1230418732U , 928171837U , 1324564878U ,
1928816105U , 1786535431U , 2878099422U , 3290185549U , 539474248U ,
1657512683U , 552370646U , 1671741683U , 3655312128U , 1552739510U ,
2605208763U , 1441755014U , 181878989U , 3124053868U , 1447103986U ,
3183906156U , 1728556020U , 3502241336U , 3055466967U , 1013272474U ,
818402132U , 1715099063U , 2900113506U , 397254517U , 4194863039U ,
1009068739U , 232864647U , 2540223708U , 2608288560U , 2415367765U ,
478404847U , 3455100648U , 3182600021U , 2115988978U , 434269567U ,
4117179324U , 3461774077U , 887256537U , 3545801025U , 286388911U ,
3451742129U , 1981164769U , 786667016U , 3310123729U , 3097811076U ,
2224235657U , 2959658883U , 3370969234U , 2514770915U , 3345656436U ,
2677010851U , 2206236470U , 271648054U , 2342188545U , 4292848611U ,
3646533909U , 3754009956U , 3803931226U , 4160647125U , 1477814055U ,
4043852216U , 1876372354U , 3133294443U , 3871104810U , 3177020907U ,
2074304428U , 3479393793U , 759562891U , 164128153U , 1839069216U ,
2114162633U , 3989947309U , 3611054956U , 1333547922U , 835429831U ,
494987340U , 171987910U , 1252001001U , 370809172U , 3508925425U ,
2535703112U , 1276855041U , 1922855120U , 835673414U , 3030664304U ,
613287117U , 171219893U , 3423096126U , 3376881639U , 2287770315U ,
1658692645U , 1262815245U , 3957234326U , 1168096164U , 2968737525U ,
2655813712U , 2132313144U , 3976047964U , 326516571U , 353088456U ,
3679188938U , 3205649712U , 2654036126U , 1249024881U , 880166166U ,
691800469U , 2229503665U , 1673458056U , 4032208375U , 1851778863U ,
2563757330U , 376742205U , 1794655231U , 340247333U , 1505873033U ,
396524441U , 879666767U , 3335579166U , 3260764261U , 3335999539U ,
506221798U , 4214658741U , 975887814U , 2080536343U , 3360539560U ,
571586418U , 138896374U , 4234352651U , 2737620262U , 3928362291U ,
1516365296U , 38056726U , 3599462320U , 3585007266U , 3850961033U ,
471667319U , 1536883193U , 2310166751U , 1861637689U , 2530999841U ,
4139843801U , 2710569485U , 827578615U , 2012334720U , 2907369459U ,
3029312804U , 2820112398U , 1965028045U , 35518606U , 2478379033U ,
643747771U , 1924139484U , 4123405127U , 3811735531U , 3429660832U ,
3285177704U , 1948416081U , 1311525291U , 1183517742U , 1739192232U ,
3979815115U , 2567840007U , 4116821529U , 213304419U , 4125718577U ,
1473064925U , 2442436592U , 1893310111U , 4195361916U , 3747569474U ,
828465101U , 2991227658U , 750582866U , 1205170309U , 1409813056U ,
678418130U , 1171531016U , 3821236156U , 354504587U , 4202874632U ,
3882511497U , 1893248677U , 1903078632U , 26340130U , 2069166240U ,
3657122492U , 3725758099U , 831344905U , 811453383U , 3447711422U ,
2434543565U , 4166886888U , 3358210805U , 4142984013U , 2988152326U ,
3527824853U , 982082992U , 2809155763U , 190157081U , 3340214818U ,
2365432395U , 2548636180U , 2894533366U , 3474657421U , 2372634704U ,
2845748389U , 43024175U , 2774226648U , 1987702864U , 3186502468U ,
453610222U , 4204736567U , 1392892630U , 2471323686U , 2470534280U ,
3541393095U , 4269885866U , 3909911300U , 759132955U , 1482612480U ,
667715263U , 1795580598U , 2337923983U , 3390586366U , 581426223U ,
1515718634U , 476374295U , 705213300U , 363062054U , 2084697697U ,
2407503428U , 2292957699U , 2426213835U , 2199989172U , 1987356470U ,
4026755612U , 2147252133U , 270400031U , 1367820199U , 2369854699U ,
2844269403U , 79981964U , 624U } ; { bool externalInputIsInDatasetFormat =
false ; void * pISigstreamManager = rt_GetISigstreamManager ( rtS ) ;
rtwISigstreamManagerGetInputIsInDatasetFormat ( pISigstreamManager , &
externalInputIsInDatasetFormat ) ; if ( externalInputIsInDatasetFormat ) { }
} memset ( & rtDW . fymvqkxpsu . AccelerationBoundaryCondition [ 0 ] , 0 ,
10U * sizeof ( real_T ) ) ; rtDW . fymvqkxpsu . isInitialized = 0 ; rtDW .
paf4jizn5q = true ; if ( rtDW . fymvqkxpsu . isInitialized == 1 ) { rtDW .
fymvqkxpsu . TunablePropsChanged = true ; } memcpy ( & rtDW . fymvqkxpsu .
Waypoints [ 0 ] , & rtP . PolynomialTrajectory_Waypoints [ 0 ] , 21U * sizeof
( real_T ) ) ; if ( rtDW . fymvqkxpsu . isInitialized == 1 ) { rtDW .
fymvqkxpsu . TunablePropsChanged = true ; } for ( i = 0 ; i < 7 ; i ++ ) {
rtDW . fymvqkxpsu . TimePoints [ i ] = rtP . PolynomialTrajectory_TimePoints
[ i ] ; } if ( rtDW . fymvqkxpsu . isInitialized == 1 ) { rtDW . fymvqkxpsu .
TunablePropsChanged = true ; } memcpy ( & rtDW . fymvqkxpsu .
VelocityBoundaryCondition [ 0 ] , & rtP .
PolynomialTrajectory_VelocityBoundaryCondition [ 0 ] , 21U * sizeof ( real_T
) ) ; rtDW . fymvqkxpsu . isInitialized = 1 ; rtDW . fymvqkxpsu .
inputVarSize . f1 [ 0 ] = 1U ; rtDW . fymvqkxpsu . inputVarSize . f1 [ 1 ] =
1U ; for ( i = 0 ; i < 6 ; i ++ ) { rtDW . fymvqkxpsu . inputVarSize . f1 [ i
+ 2 ] = 1U ; } rtDW . fymvqkxpsu . TunablePropsChanged = false ; rtDW .
df2e0pg2dx . isInitialized = 0 ; rtDW . a5bv3potn3 = true ; rtDW . df2e0pg2dx
. isInitialized = 1 ; l353migxc4 ( & rtDW . h50oa4paoh ) ; for ( i = 0 ; i <
6 ; i ++ ) { rtDW . h50oa4paoh . IKInternal . _pobj4 . _pobj1 [ i ] . _pobj0
. matlabCodegenIsDeleted = true ; } for ( i = 0 ; i < 11 ; i ++ ) { rtDW .
h50oa4paoh . IKInternal . _pobj3 [ i ] . _pobj0 . matlabCodegenIsDeleted =
true ; } for ( i = 0 ; i < 11 ; i ++ ) { rtDW . h50oa4paoh . TreeInternal .
_pobj0 [ i ] . _pobj0 . matlabCodegenIsDeleted = true ; } rtDW . h50oa4paoh .
IKInternal . matlabCodegenIsDeleted = true ; rtDW . h50oa4paoh .
matlabCodegenIsDeleted = true ; rtDW . fz2ttztfrx = 7U ; rtDW . gmdfw45vlb =
true ; rtDW . apqphginxx = 1144108930U ; rtDW . lvfg2ialf5 = true ; rtDW .
a424fqcnvz [ 0 ] = 362436069U ; rtDW . a424fqcnvz [ 1 ] = 521288629U ; rtDW .
n1jgscci0o = true ; memcpy ( & rtDW . iovoxirwro [ 0 ] , & tmp_m [ 0 ] , 625U
* sizeof ( uint32_T ) ) ; rtDW . cueoevswm1 = true ; rtDW . coliwj5sya = 0U ;
rtDW . idgjtzemzw = true ; rtDW . frbywcoc2g [ 0 ] = 362436069U ; rtDW .
frbywcoc2g [ 1 ] = 521288629U ; rtDW . fs53o4lsci = true ; rtDW . h50oa4paoh
. isInitialized = 0 ; rtDW . h50oa4paoh . matlabCodegenIsDeleted = false ;
rtDW . chxdltntn1 = true ; g1slahjfob0o ( & rtDW . h50oa4paoh ) ; l353migxc4h
( & rtDW . au4tbeh3wp ) ; for ( i = 0 ; i < 10 ; i ++ ) { rtDW . au4tbeh3wp .
TreeInternal . _pobj0 [ i ] . CollisionsInternal . _pobj0 .
matlabCodegenIsDeleted = true ; } rtDW . au4tbeh3wp . TreeInternal . Base .
CollisionsInternal . _pobj0 . matlabCodegenIsDeleted = true ; rtDW .
au4tbeh3wp . isInitialized = 0 ; rtDW . kkhkendrtu = true ; g1slahjfob ( &
rtDW . au4tbeh3wp ) ; tmp = nesl_lease_simulator (
"Jacobian/Subsystem/Solver Configuration_1" , 1 , 0 ) ; rtDW . m2zu25uvwa = (
void * ) tmp ; tmp_p = pointer_is_null ( rtDW . m2zu25uvwa ) ; if ( tmp_p ) {
Jacobian_9d5357ce_1_gateway ( ) ; tmp = nesl_lease_simulator (
"Jacobian/Subsystem/Solver Configuration_1" , 1 , 0 ) ; rtDW . m2zu25uvwa = (
void * ) tmp ; } slsaSaveRawMemoryForSimTargetOP ( rtS ,
"Jacobian/Subsystem/Solver Configuration_110" , ( void * * ) ( & rtDW .
m2zu25uvwa ) , 0U * sizeof ( real_T ) , nesl_save_simdata ,
nesl_restore_simdata ) ; tmp_e = nesl_create_simulation_data ( ) ; rtDW .
igg4nbzrjn = ( void * ) tmp_e ; diagnosticManager = rtw_create_diagnostics (
) ; rtDW . m1h5n4uw0s = ( void * ) diagnosticManager ; modelParameters .
mSolverType = NE_SOLVER_TYPE_DAE ; modelParameters . mSolverTolerance = 0.001
; modelParameters . mSolverAbsTol = 0.001 ; modelParameters . mSolverRelTol =
0.001 ; modelParameters . mVariableStepSolver = true ; modelParameters .
mIsUsingODEN = false ; modelParameters . mSolverModifyAbsTol =
NE_MODIFY_ABS_TOL_MAYBE ; modelParameters . mFixedStepSize = 0.001 ;
modelParameters . mStartTime = 0.0 ; modelParameters . mLoadInitialState =
false ; modelParameters . mUseSimState = false ; modelParameters .
mLinTrimCompile = false ; modelParameters . mLoggingMode = SSC_LOGGING_NONE ;
modelParameters . mRTWModifiedTimeStamp = 6.39256706E+8 ; modelParameters .
mZcDisabled = false ; tmp_i = 0.001 ; modelParameters . mSolverTolerance =
tmp_i ; tmp_i = 0.0 ; modelParameters . mFixedStepSize = tmp_i ; tmp_p = true
; modelParameters . mVariableStepSolver = tmp_p ; tmp_p = false ;
modelParameters . mIsUsingODEN = tmp_p ; val = false ; tmp_p =
slIsRapidAcceleratorSimulating ( ) ; if ( tmp_p ) { tmp_p =
ssGetGlobalInitialStatesAvailable ( rtS ) ; val = ( tmp_p &&
ssIsFirstInitCond ( rtS ) ) ; } modelParameters . mLoadInitialState = val ;
modelParameters . mZcDisabled = false ; diagnosticManager = (
NeuDiagnosticManager * ) rtDW . m1h5n4uw0s ; diagnosticTree =
neu_diagnostic_manager_get_initial_tree ( diagnosticManager ) ; i =
nesl_initialize_simulator ( ( NeslSimulator * ) rtDW . m2zu25uvwa , &
modelParameters , diagnosticManager ) ; if ( i != 0 ) { tmp_p =
error_buffer_is_empty ( ssGetErrorStatus ( rtS ) ) ; if ( tmp_p ) { msg =
rtw_diagnostics_msg ( diagnosticTree ) ; ssSetErrorStatus ( rtS , msg ) ; } }
l353migxc4hk ( & rtDW . nbtjvvk0iu ) ; for ( i = 0 ; i < 10 ; i ++ ) { rtDW .
nbtjvvk0iu . TreeInternal . _pobj0 [ i ] . CollisionsInternal . _pobj0 .
matlabCodegenIsDeleted = true ; } rtDW . nbtjvvk0iu . TreeInternal . Base .
CollisionsInternal . _pobj0 . matlabCodegenIsDeleted = true ; rtDW .
nbtjvvk0iu . isInitialized = 0 ; rtDW . i2pqjw3yac = true ; g1slahjfob0 ( &
rtDW . nbtjvvk0iu ) ; tmp = nesl_lease_simulator (
"Jacobian/Subsystem/Solver Configuration_1" , 0 , 0 ) ; rtDW . hxun4zugta = (
void * ) tmp ; tmp_p = pointer_is_null ( rtDW . hxun4zugta ) ; if ( tmp_p ) {
Jacobian_9d5357ce_1_gateway ( ) ; tmp = nesl_lease_simulator (
"Jacobian/Subsystem/Solver Configuration_1" , 0 , 0 ) ; rtDW . hxun4zugta = (
void * ) tmp ; } slsaSaveRawMemoryForSimTargetOP ( rtS ,
"Jacobian/Subsystem/Solver Configuration_100" , ( void * * ) ( & rtDW .
hxun4zugta ) , 0U * sizeof ( real_T ) , nesl_save_simdata ,
nesl_restore_simdata ) ; tmp_e = nesl_create_simulation_data ( ) ; rtDW .
oebpmsajkl = ( void * ) tmp_e ; diagnosticManager = rtw_create_diagnostics (
) ; rtDW . jjwd1cr3xx = ( void * ) diagnosticManager ; modelParameters_p .
mSolverType = NE_SOLVER_TYPE_DAE ; modelParameters_p . mSolverTolerance =
0.001 ; modelParameters_p . mSolverAbsTol = 0.001 ; modelParameters_p .
mSolverRelTol = 0.001 ; modelParameters_p . mVariableStepSolver = true ;
modelParameters_p . mIsUsingODEN = false ; modelParameters_p .
mSolverModifyAbsTol = NE_MODIFY_ABS_TOL_MAYBE ; modelParameters_p .
mFixedStepSize = 0.001 ; modelParameters_p . mStartTime = 0.0 ;
modelParameters_p . mLoadInitialState = false ; modelParameters_p .
mUseSimState = false ; modelParameters_p . mLinTrimCompile = false ;
modelParameters_p . mLoggingMode = SSC_LOGGING_NONE ; modelParameters_p .
mRTWModifiedTimeStamp = 6.39256706E+8 ; modelParameters_p . mZcDisabled =
false ; tmp_i = 0.001 ; modelParameters_p . mSolverTolerance = tmp_i ; tmp_i
= 0.0 ; modelParameters_p . mFixedStepSize = tmp_i ; tmp_p = true ;
modelParameters_p . mVariableStepSolver = tmp_p ; tmp_p = false ;
modelParameters_p . mIsUsingODEN = tmp_p ; val = false ; tmp_p =
slIsRapidAcceleratorSimulating ( ) ; if ( tmp_p ) { tmp_p =
ssGetGlobalInitialStatesAvailable ( rtS ) ; val = ( tmp_p &&
ssIsFirstInitCond ( rtS ) ) ; } modelParameters_p . mLoadInitialState = val ;
modelParameters_p . mZcDisabled = false ; diagnosticManager = (
NeuDiagnosticManager * ) rtDW . jjwd1cr3xx ; diagnosticTree_p =
neu_diagnostic_manager_get_initial_tree ( diagnosticManager ) ; i =
nesl_initialize_simulator ( ( NeslSimulator * ) rtDW . hxun4zugta , &
modelParameters_p , diagnosticManager ) ; if ( i != 0 ) { tmp_p =
error_buffer_is_empty ( ssGetErrorStatus ( rtS ) ) ; if ( tmp_p ) { msg_p =
rtw_diagnostics_msg ( diagnosticTree_p ) ; ssSetErrorStatus ( rtS , msg_p ) ;
} } } void MdlOutputs ( int_T tid ) { NeslSimulationData * simulationData ;
NeuDiagnosticManager * diagnosticManager ; NeuDiagnosticTree * diagnosticTree
; NeuDiagnosticTree * diagnosticTree_p ; char * msg ; char * msg_p ;
csbe03lymu expl_temp ; e2b0f4s35s * bname ; fgmfslti0b * Ttree ; gxcsgl11sl *
body ; gxcsgl11sl3 * body_p ; iabjthfi1p * obj ; kp1en3mw3x * obj_p ;
kp1en3mw3xl * obj_e ; ksusmq01tx * b_gradTmp ; moo4o4s0qn * b ; moo4o4s0qn *
b_p ; moo4o4s0qn * tmp_g ; moo4o4s0qn * tmp_m ; real_T b_newCoefs [ 96 ] ;
real_T dCoefs [ 96 ] ; real_T ddCoefs [ 96 ] ; real_T coefsWithFlatStart [ 84
] ; real_T coefMat [ 72 ] ; real_T T [ 36 ] ; real_T tmp [ 20 ] ; real_T
tmp_e [ 20 ] ; real_T T1 [ 16 ] ; real_T T2 [ 16 ] ; real_T Tdh [ 16 ] ;
real_T newBreaks_p [ 16 ] ; real_T out [ 16 ] ; real_T ckevwcwhlm [ 12 ] ;
real_T coeffMat [ 12 ] ; real_T newBreaks [ 9 ] ; real_T tempR [ 9 ] ; real_T
breaksWithFlatStart [ 8 ] ; real_T chainmask [ 5 ] ; real_T result_data [ 4 ]
; real_T v [ 3 ] ; real_T b_coeffVec_idx_0 ; real_T b_coeffVec_idx_1 ; real_T
b_coeffVec_idx_2 ; real_T finalTime ; real_T kucwwqtnmc ; real_T time ;
real_T time_e ; real_T time_i ; real_T time_p ; real_T tmp_j ; int32_T b_i ;
int32_T b_i_p ; int32_T d ; int32_T iacol ; int32_T ibcol ; int32_T loop_ub ;
int32_T ntilecols ; int_T tmp_i [ 6 ] ; int_T tmp_p [ 6 ] ; char_T b_m [ 8 ]
; char_T a [ 5 ] ; char_T b_e [ 4 ] ; boolean_T p ; boolean_T p_p ; static
const char_T tmp_f [ 5 ] = { 'B' , 'o' , 'd' , 'y' , '5' } ; static const
char_T tmp_c [ 5 ] = { 'f' , 'i' , 'x' , 'e' , 'd' } ; static const int8_T
tmp_k [ 16 ] = { 1 , 0 , 0 , 0 , 0 , 1 , 0 , 0 , 0 , 0 , 1 , 0 , 0 , 0 , 0 ,
1 } ; static const char_T tmp_b [ 8 ] = { 'r' , 'e' , 'v' , 'o' , 'l' , 'u' ,
't' , 'e' } ; moo4o4s0qn * b_g ; int32_T exitg2 ; boolean_T exitg1 ;
kucwwqtnmc = ssGetT ( rtS ) ; p = false ; p_p = true ; ntilecols = 0 ; exitg1
= false ; while ( ( ! exitg1 ) && ( ntilecols < 21 ) ) { if ( ! ( rtDW .
fymvqkxpsu . Waypoints [ ntilecols ] == rtP . PolynomialTrajectory_Waypoints
[ ntilecols ] ) ) { p_p = false ; exitg1 = true ; } else { ntilecols ++ ; } }
if ( p_p ) { p = true ; } if ( ! p ) { if ( rtDW . fymvqkxpsu . isInitialized
== 1 ) { rtDW . fymvqkxpsu . TunablePropsChanged = true ; } memcpy ( & rtDW .
fymvqkxpsu . Waypoints [ 0 ] , & rtP . PolynomialTrajectory_Waypoints [ 0 ] ,
21U * sizeof ( real_T ) ) ; } p = false ; p_p = true ; ntilecols = 0 ; exitg1
= false ; while ( ( ! exitg1 ) && ( ntilecols < 7 ) ) { if ( ! ( rtDW .
fymvqkxpsu . TimePoints [ ntilecols ] == rtP .
PolynomialTrajectory_TimePoints [ ntilecols ] ) ) { p_p = false ; exitg1 =
true ; } else { ntilecols ++ ; } } if ( p_p ) { p = true ; } if ( ! p ) { if
( rtDW . fymvqkxpsu . isInitialized == 1 ) { rtDW . fymvqkxpsu .
TunablePropsChanged = true ; } for ( b_i_p = 0 ; b_i_p < 7 ; b_i_p ++ ) {
rtDW . fymvqkxpsu . TimePoints [ b_i_p ] = rtP .
PolynomialTrajectory_TimePoints [ b_i_p ] ; } } p = false ; p_p = true ;
ntilecols = 0 ; exitg1 = false ; while ( ( ! exitg1 ) && ( ntilecols < 21 ) )
{ if ( ! ( rtDW . fymvqkxpsu . VelocityBoundaryCondition [ ntilecols ] == rtP
. PolynomialTrajectory_VelocityBoundaryCondition [ ntilecols ] ) ) { p_p =
false ; exitg1 = true ; } else { ntilecols ++ ; } } if ( p_p ) { p = true ; }
if ( ! p ) { if ( rtDW . fymvqkxpsu . isInitialized == 1 ) { rtDW .
fymvqkxpsu . TunablePropsChanged = true ; } memcpy ( & rtDW . fymvqkxpsu .
VelocityBoundaryCondition [ 0 ] , & rtP .
PolynomialTrajectory_VelocityBoundaryCondition [ 0 ] , 21U * sizeof ( real_T
) ) ; } if ( rtDW . fymvqkxpsu . TunablePropsChanged ) { rtDW . fymvqkxpsu .
TunablePropsChanged = false ; } ntilecols = 0 ; exitg1 = false ; while ( ( !
exitg1 ) && ( ntilecols < 8 ) ) { if ( rtDW . fymvqkxpsu . inputVarSize . f1
[ ntilecols ] != 1U ) { for ( b_i_p = 0 ; b_i_p < 8 ; b_i_p ++ ) { rtDW .
fymvqkxpsu . inputVarSize . f1 [ b_i_p ] = 1U ; } exitg1 = true ; } else {
ntilecols ++ ; } } memset ( & coefMat [ 0 ] , 0 , 72U * sizeof ( real_T ) ) ;
for ( b_i = 0 ; b_i < 6 ; b_i ++ ) { finalTime = rtDW . fymvqkxpsu .
TimePoints [ b_i + 1 ] - rtDW . fymvqkxpsu . TimePoints [ b_i ] ; for (
ntilecols = 0 ; ntilecols < 3 ; ntilecols ++ ) { b_coeffVec_idx_0 = rtDW .
fymvqkxpsu . Waypoints [ b_i * 3 + ntilecols ] ; b_coeffVec_idx_1 = rtDW .
fymvqkxpsu . VelocityBoundaryCondition [ b_i * 3 + ntilecols ] ;
b_coeffVec_idx_2 = rtDW . fymvqkxpsu . Waypoints [ ( b_i + 1 ) * 3 +
ntilecols ] - ( finalTime * b_coeffVec_idx_1 + b_coeffVec_idx_0 ) ; tmp_j =
rtDW . fymvqkxpsu . VelocityBoundaryCondition [ ( b_i + 1 ) * 3 + ntilecols ]
- ( 0.0 * b_coeffVec_idx_0 + b_coeffVec_idx_1 ) ; b_i_p = ( b_i * 3 +
ntilecols ) + 1 ; coefMat [ b_i_p - 1 ] = 1.0 / ( finalTime * finalTime ) *
tmp_j + - 2.0 / muDoubleScalarPower ( finalTime , 3.0 ) * b_coeffVec_idx_2 ;
coefMat [ b_i_p + 17 ] = 3.0 / ( finalTime * finalTime ) * b_coeffVec_idx_2 +
- 1.0 / finalTime * tmp_j ; coefMat [ b_i_p + 35 ] = b_coeffVec_idx_1 ;
coefMat [ b_i_p + 53 ] = b_coeffVec_idx_0 ; } } memset ( & coeffMat [ 0 ] , 0
, 12U * sizeof ( real_T ) ) ; for ( b_i_p = 0 ; b_i_p < 3 ; b_i_p ++ ) {
coeffMat [ b_i_p + 9 ] = 0.0 ; coeffMat [ b_i_p + 9 ] += coefMat [ b_i_p ] *
0.0 ; coeffMat [ b_i_p + 9 ] += coefMat [ b_i_p + 18 ] * 0.0 ; coeffMat [
b_i_p + 9 ] += coefMat [ b_i_p + 36 ] * 0.0 ; coeffMat [ b_i_p + 9 ] +=
coefMat [ b_i_p + 54 ] ; } memset ( & coefsWithFlatStart [ 0 ] , 0 , 84U *
sizeof ( real_T ) ) ; for ( b_i_p = 0 ; b_i_p < 4 ; b_i_p ++ ) {
coefsWithFlatStart [ 21 * b_i_p ] = coeffMat [ 3 * b_i_p ] ;
coefsWithFlatStart [ 21 * b_i_p + 1 ] = coeffMat [ 3 * b_i_p + 1 ] ;
coefsWithFlatStart [ 21 * b_i_p + 2 ] = coeffMat [ 3 * b_i_p + 2 ] ; for ( d
= 0 ; d < 18 ; d ++ ) { coefsWithFlatStart [ ( ( d + 4 ) + 21 * b_i_p ) - 1 ]
= coefMat [ 18 * b_i_p + d ] ; } } breaksWithFlatStart [ 0 ] = rtDW .
fymvqkxpsu . TimePoints [ 0 ] - 1.0 ; for ( b_i_p = 0 ; b_i_p < 7 ; b_i_p ++
) { breaksWithFlatStart [ b_i_p + 1 ] = rtDW . fymvqkxpsu . TimePoints [
b_i_p ] ; } finalTime = breaksWithFlatStart [ 7 ] - breaksWithFlatStart [ 6 ]
; b_coeffVec_idx_0 = muDoubleScalarPower ( finalTime , 3.0 ) ;
b_coeffVec_idx_1 = muDoubleScalarPower ( finalTime , 2.0 ) ; b_coeffVec_idx_2
= muDoubleScalarPower ( finalTime , 1.0 ) ; finalTime = muDoubleScalarPower (
finalTime , 0.0 ) ; memset ( & coeffMat [ 0 ] , 0 , 12U * sizeof ( real_T ) )
; for ( b_i_p = 0 ; b_i_p < 3 ; b_i_p ++ ) { coeffMat [ b_i_p + 9 ] = 0.0 ;
coeffMat [ b_i_p + 9 ] += coefsWithFlatStart [ b_i_p + 18 ] *
b_coeffVec_idx_0 ; coeffMat [ b_i_p + 9 ] += coefsWithFlatStart [ b_i_p + 39
] * b_coeffVec_idx_1 ; coeffMat [ b_i_p + 9 ] += coefsWithFlatStart [ b_i_p +
60 ] * b_coeffVec_idx_2 ; coeffMat [ b_i_p + 9 ] += coefsWithFlatStart [
b_i_p + 81 ] * finalTime ; } memset ( & b_newCoefs [ 0 ] , 0 , 96U * sizeof (
real_T ) ) ; for ( b_i_p = 0 ; b_i_p < 4 ; b_i_p ++ ) { for ( d = 0 ; d < 21
; d ++ ) { b_newCoefs [ ( ( d + 1 ) + 24 * b_i_p ) - 1 ] = coefsWithFlatStart
[ 21 * b_i_p + d ] ; } b_newCoefs [ 24 * b_i_p + 21 ] = coeffMat [ 3 * b_i_p
] ; b_newCoefs [ 24 * b_i_p + 22 ] = coeffMat [ 3 * b_i_p + 1 ] ; b_newCoefs
[ 24 * b_i_p + 23 ] = coeffMat [ 3 * b_i_p + 2 ] ; } memcpy ( & tempR [ 0 ] ,
& breaksWithFlatStart [ 0 ] , sizeof ( real_T ) << 3U ) ; tempR [ 8 ] =
breaksWithFlatStart [ 7 ] + 1.0 ; memcpy ( & newBreaks [ 0 ] , & tempR [ 0 ]
, 9U * sizeof ( real_T ) ) ; finalTime = 0.01 ; if ( kucwwqtnmc > tempR [ 7 ]
) { b_i = 1 ; d = 1 ; } else { b_i = 0 ; d = 0 ; } if ( ( b_i != 0 ) && ( d
!= 0 ) ) { finalTime = muDoubleScalarMin ( ( kucwwqtnmc - tempR [ 7 ] ) / 2.0
, 0.01 ) ; } newBreaks [ 7 ] = tempR [ 7 ] + finalTime ; memset ( & dCoefs [
0 ] , 0 , 96U * sizeof ( real_T ) ) ; for ( b_i = 0 ; b_i < 3 ; b_i ++ ) {
for ( b_i_p = 0 ; b_i_p < 24 ; b_i_p ++ ) { dCoefs [ b_i_p + 24 * ( b_i + 1 )
] = b_newCoefs [ b_i * 24 + b_i_p ] * ( real_T ) ( 3 - b_i ) ; } } memset ( &
ddCoefs [ 0 ] , 0 , 96U * sizeof ( real_T ) ) ; for ( b_i = 0 ; b_i < 3 ; b_i
++ ) { for ( b_i_p = 0 ; b_i_p < 24 ; b_i_p ++ ) { ddCoefs [ b_i_p + 24 * (
b_i + 1 ) ] = dCoefs [ b_i * 24 + b_i_p ] * ( real_T ) ( 3 - b_i ) ; } }
ntmkpsyod5y ( newBreaks , dCoefs , kucwwqtnmc , rtB . jduggdofo3 ) ;
ntmkpsyod5y ( newBreaks , ddCoefs , kucwwqtnmc , rtB . pwxyrrsugo ) ; memset
( & T2 [ 0 ] , 0 , sizeof ( real_T ) << 4U ) ; T2 [ 0 ] = 1.0 ; T2 [ 5 ] =
1.0 ; T2 [ 10 ] = 1.0 ; T2 [ 15 ] = 1.0 ; for ( b_i = 0 ; b_i < 4 ; b_i ++ )
{ iacol = ( b_i << 2 ) - 1 ; ibcol = ( b_i << 2 ) - 1 ; out [ ibcol + 1 ] =
T2 [ iacol + 1 ] ; out [ ibcol + 2 ] = T2 [ iacol + 2 ] ; out [ ibcol + 3 ] =
T2 [ iacol + 3 ] ; out [ ibcol + 4 ] = T2 [ iacol + 4 ] ; } ntmkpsyod5y (
tempR , b_newCoefs , kucwwqtnmc , & out [ 12 ] ) ; obj = & rtDW . h50oa4paoh
. IKInternal ; if ( rtDW . h50oa4paoh . IKInternal . isInitialized != 1 ) {
rtDW . h50oa4paoh . IKInternal . isSetupComplete = false ; rtDW . h50oa4paoh
. IKInternal . isInitialized = 1 ; jkqy2d3rp1 ( rtDW . h50oa4paoh .
IKInternal . RigidBodyTreeInternal , rtDW . h50oa4paoh . IKInternal . Limits
) ; rtDW . h50oa4paoh . IKInternal . Solver -> ExtraArgs = & obj -> _pobj0 ;
for ( b_i_p = 0 ; b_i_p < 36 ; b_i_p ++ ) { rtDW . h50oa4paoh . IKInternal .
Solver -> ExtraArgs -> WeightMatrix [ b_i_p ] = 0.0 ; } cy4r1g1cm1 ( & tmp_m
, 1 ) ; rtDW . h50oa4paoh . IKInternal . Solver -> ExtraArgs -> Robot = rtDW
. h50oa4paoh . IKInternal . RigidBodyTreeInternal ; b_i = rtDW . h50oa4paoh .
IKInternal . Limits -> size [ 0 ] << 1 ; ntilecols = rtDW . h50oa4paoh .
IKInternal . Solver -> ExtraArgs -> Limits -> size [ 0 ] * rtDW . h50oa4paoh
. IKInternal . Solver -> ExtraArgs -> Limits -> size [ 1 ] ; rtDW .
h50oa4paoh . IKInternal . Solver -> ExtraArgs -> Limits -> size [ 0 ] = rtDW
. h50oa4paoh . IKInternal . Limits -> size [ 0 ] ; rtDW . h50oa4paoh .
IKInternal . Solver -> ExtraArgs -> Limits -> size [ 1 ] = 2 ; ier0p3wwtw (
rtDW . h50oa4paoh . IKInternal . Solver -> ExtraArgs -> Limits , ntilecols )
; ntilecols = tmp_m -> size [ 0 ] ; tmp_m -> size [ 0 ] = b_i ; ier0p3wwtw (
tmp_m , ntilecols ) ; for ( d = 0 ; d < b_i ; d ++ ) { tmp_m -> data [ d ] =
rtDW . h50oa4paoh . IKInternal . Limits -> data [ d ] ; } loop_ub = tmp_m ->
size [ 0 ] ; for ( d = 0 ; d < loop_ub ; d ++ ) { rtDW . h50oa4paoh .
IKInternal . Solver -> ExtraArgs -> Limits -> data [ d ] = tmp_m -> data [ d
] ; } njzmd0hlqd ( & tmp_m ) ; memset ( & T2 [ 0 ] , 0 , sizeof ( real_T ) <<
4U ) ; T2 [ 0 ] = 1.0 ; T2 [ 5 ] = 1.0 ; T2 [ 10 ] = 1.0 ; T2 [ 15 ] = 1.0 ;
for ( b_i_p = 0 ; b_i_p < 16 ; b_i_p ++ ) { rtDW . h50oa4paoh . IKInternal .
Solver -> ExtraArgs -> Tform [ b_i_p ] = T2 [ b_i_p ] ; } rtDW . h50oa4paoh .
IKInternal . Solver -> ExtraArgs -> BodyName -> size [ 0 ] = 1 ; rtDW .
h50oa4paoh . IKInternal . Solver -> ExtraArgs -> BodyName -> size [ 1 ] = 0 ;
ntilecols = rtDW . h50oa4paoh . IKInternal . Solver -> ExtraArgs -> ErrTemp
-> size [ 0 ] ; rtDW . h50oa4paoh . IKInternal . Solver -> ExtraArgs ->
ErrTemp -> size [ 0 ] = 6 ; ier0p3wwtw ( rtDW . h50oa4paoh . IKInternal .
Solver -> ExtraArgs -> ErrTemp , ntilecols ) ; for ( b_i_p = 0 ; b_i_p < 6 ;
b_i_p ++ ) { rtDW . h50oa4paoh . IKInternal . Solver -> ExtraArgs -> ErrTemp
-> data [ b_i_p ] = 0.0 ; } lscqsvg2j5 ( & b_gradTmp , 1 ) ; rtDW .
h50oa4paoh . IKInternal . Solver -> ExtraArgs -> CostTemp = 0.0 ; ntilecols =
b_gradTmp -> size [ 0 ] ; b_gradTmp -> size [ 0 ] = ( int32_T ) rtDW .
h50oa4paoh . IKInternal . RigidBodyTreeInternal -> PositionNumber ;
nmpbytu0qq ( b_gradTmp , ntilecols ) ; loop_ub = ( int32_T ) rtDW .
h50oa4paoh . IKInternal . RigidBodyTreeInternal -> PositionNumber ; if (
loop_ub - 1 >= 0 ) { memset ( & b_gradTmp -> data [ 0 ] , 0 , loop_ub *
sizeof ( int8_T ) ) ; } ntilecols = rtDW . h50oa4paoh . IKInternal . Solver
-> ExtraArgs -> GradTemp -> size [ 0 ] ; rtDW . h50oa4paoh . IKInternal .
Solver -> ExtraArgs -> GradTemp -> size [ 0 ] = b_gradTmp -> size [ 0 ] ;
ier0p3wwtw ( rtDW . h50oa4paoh . IKInternal . Solver -> ExtraArgs -> GradTemp
, ntilecols ) ; loop_ub = b_gradTmp -> size [ 0 ] ; adwdjvxler ( & b_gradTmp
) ; for ( b_i_p = 0 ; b_i_p < loop_ub ; b_i_p ++ ) { rtDW . h50oa4paoh .
IKInternal . Solver -> ExtraArgs -> GradTemp -> data [ b_i_p ] = 0.0 ; } rtDW
. h50oa4paoh . IKInternal . isSetupComplete = true ; } cy4r1g1cm1 ( & b , 2 )
; ku0om0mcw0 ( & Ttree , 2 ) ; e3cpkwfxpp ( & rtDW . h50oa4paoh . IKInternal
, out , rtP . Constant1_Value , rtP . Constant2_Value , rtB . kocxhnfx4g ) ;
obj_p = & rtDW . au4tbeh3wp . TreeInternal ; evz05l0h04 ( & rtDW . au4tbeh3wp
. TreeInternal , rtB . kocxhnfx4g , Ttree ) ; ntilecols = b -> size [ 0 ] * b
-> size [ 1 ] ; b -> size [ 0 ] = 6 ; b -> size [ 1 ] = ( int32_T ) rtDW .
au4tbeh3wp . TreeInternal . VelocityNumber ; ier0p3wwtw ( b , ntilecols ) ;
loop_ub = 6 * ( int32_T ) rtDW . au4tbeh3wp . TreeInternal . VelocityNumber -
1 ; if ( loop_ub >= 0 ) { memset ( & b -> data [ 0 ] , 0 , ( loop_ub + 1 ) *
sizeof ( real_T ) ) ; } for ( b_i_p = 0 ; b_i_p < 5 ; b_i_p ++ ) { chainmask
[ b_i_p ] = 0.0 ; } gunzkbl0qg ( & bname , 2 ) ; ntilecols = bname -> size [
0 ] * bname -> size [ 1 ] ; bname -> size [ 0 ] = 1 ; bname -> size [ 1 ] =
obj_p -> Base . NameInternal -> size [ 1 ] ; ac0ugu5nlz ( bname , ntilecols )
; loop_ub = obj_p -> Base . NameInternal -> size [ 1 ] - 1 ; for ( b_i_p = 0
; b_i_p <= loop_ub ; b_i_p ++ ) { bname -> data [ b_i_p ] = obj_p -> Base .
NameInternal -> data [ b_i_p ] ; } for ( b_i_p = 0 ; b_i_p < 5 ; b_i_p ++ ) {
a [ b_i_p ] = tmp_f [ b_i_p ] ; } p = false ; if ( bname -> size [ 1 ] == 5 )
{ ntilecols = 1 ; do { exitg2 = 0 ; if ( ntilecols - 1 < 5 ) { if ( a [
ntilecols - 1 ] != bname -> data [ ntilecols - 1 ] ) { exitg2 = 1 ; } else {
ntilecols ++ ; } } else { p = true ; exitg2 = 1 ; } } while ( exitg2 == 0 ) ;
} if ( p ) { memset ( & out [ 0 ] , 0 , sizeof ( real_T ) << 4U ) ; out [ 0 ]
= 1.0 ; out [ 5 ] = 1.0 ; out [ 10 ] = 1.0 ; out [ 15 ] = 1.0 ; memset ( & T2
[ 0 ] , 0 , sizeof ( real_T ) << 4U ) ; T2 [ 0 ] = 1.0 ; T2 [ 5 ] = 1.0 ; T2
[ 10 ] = 1.0 ; T2 [ 15 ] = 1.0 ; } else { kucwwqtnmc = - 1.0 ; ntilecols =
bname -> size [ 0 ] * bname -> size [ 1 ] ; bname -> size [ 0 ] = 1 ; bname
-> size [ 1 ] = obj_p -> Base . NameInternal -> size [ 1 ] ; ac0ugu5nlz (
bname , ntilecols ) ; loop_ub = obj_p -> Base . NameInternal -> size [ 1 ] -
1 ; for ( b_i_p = 0 ; b_i_p <= loop_ub ; b_i_p ++ ) { bname -> data [ b_i_p ]
= obj_p -> Base . NameInternal -> data [ b_i_p ] ; } if ( bname -> size [ 1 ]
!= 5 ) { } else { ntilecols = 1 ; do { exitg2 = 0 ; if ( ntilecols - 1 < 5 )
{ if ( bname -> data [ ntilecols - 1 ] != a [ ntilecols - 1 ] ) { exitg2 = 1
; } else { ntilecols ++ ; } } else { p = true ; exitg2 = 1 ; } } while (
exitg2 == 0 ) ; } if ( p ) { kucwwqtnmc = 0.0 ; } else { b_coeffVec_idx_0 =
rtDW . au4tbeh3wp . TreeInternal . NumBodies ; b_i = 0 ; exitg1 = false ;
while ( ( ! exitg1 ) && ( b_i <= ( int32_T ) b_coeffVec_idx_0 - 1 ) ) { body
= obj_p -> Bodies [ b_i ] ; ntilecols = bname -> size [ 0 ] * bname -> size [
1 ] ; bname -> size [ 0 ] = 1 ; bname -> size [ 1 ] = body -> NameInternal ->
size [ 1 ] ; ac0ugu5nlz ( bname , ntilecols ) ; loop_ub = body ->
NameInternal -> size [ 1 ] - 1 ; for ( b_i_p = 0 ; b_i_p <= loop_ub ; b_i_p
++ ) { bname -> data [ b_i_p ] = body -> NameInternal -> data [ b_i_p ] ; }
for ( b_i_p = 0 ; b_i_p < 5 ; b_i_p ++ ) { a [ b_i_p ] = tmp_f [ b_i_p ] ; }
if ( bname -> size [ 1 ] != 5 ) { } else { ntilecols = 1 ; do { exitg2 = 0 ;
if ( ntilecols - 1 < 5 ) { if ( bname -> data [ ntilecols - 1 ] != a [
ntilecols - 1 ] ) { exitg2 = 1 ; } else { ntilecols ++ ; } } else { p = true
; exitg2 = 1 ; } } while ( exitg2 == 0 ) ; } if ( p ) { kucwwqtnmc = ( real_T
) b_i + 1.0 ; exitg1 = true ; } else { b_i ++ ; } } } body = rtDW .
au4tbeh3wp . TreeInternal . Bodies [ ( int32_T ) kucwwqtnmc - 1 ] ; for (
b_i_p = 0 ; b_i_p < 16 ; b_i_p ++ ) { T2 [ b_i_p ] = Ttree -> data [ (
int32_T ) kucwwqtnmc - 1 ] . f1 [ b_i_p ] ; } for ( b_i_p = 0 ; b_i_p < 3 ;
b_i_p ++ ) { newBreaks [ 3 * b_i_p ] = Ttree -> data [ ( int32_T ) kucwwqtnmc
- 1 ] . f1 [ b_i_p ] ; newBreaks [ 3 * b_i_p + 1 ] = Ttree -> data [ (
int32_T ) kucwwqtnmc - 1 ] . f1 [ b_i_p + 4 ] ; newBreaks [ 3 * b_i_p + 2 ] =
Ttree -> data [ ( int32_T ) kucwwqtnmc - 1 ] . f1 [ b_i_p + 8 ] ; } for (
b_i_p = 0 ; b_i_p < 9 ; b_i_p ++ ) { tempR [ b_i_p ] = - newBreaks [ b_i_p ]
; } for ( b_i_p = 0 ; b_i_p < 3 ; b_i_p ++ ) { out [ b_i_p << 2 ] = newBreaks
[ 3 * b_i_p ] ; out [ ( b_i_p << 2 ) + 1 ] = newBreaks [ 3 * b_i_p + 1 ] ;
out [ ( b_i_p << 2 ) + 2 ] = newBreaks [ 3 * b_i_p + 2 ] ; out [ b_i_p + 12 ]
= ( tempR [ b_i_p + 3 ] * Ttree -> data [ ( int32_T ) kucwwqtnmc - 1 ] . f1 [
13 ] + Ttree -> data [ ( int32_T ) kucwwqtnmc - 1 ] . f1 [ 12 ] * tempR [
b_i_p ] ) + tempR [ b_i_p + 6 ] * Ttree -> data [ ( int32_T ) kucwwqtnmc - 1
] . f1 [ 14 ] ; } out [ 3 ] = 0.0 ; out [ 7 ] = 0.0 ; out [ 11 ] = 0.0 ; out
[ 15 ] = 1.0 ; chainmask [ ( int32_T ) kucwwqtnmc - 1 ] = 1.0 ; while ( body
-> ParentIndex > 0.0 ) { body = obj_p -> Bodies [ ( int32_T ) body ->
ParentIndex - 1 ] ; chainmask [ ( int32_T ) body -> Index - 1 ] = 1.0 ; } }
b_coeffVec_idx_0 = rtDW . au4tbeh3wp . TreeInternal . NumBodies ; iacol = (
int32_T ) b_coeffVec_idx_0 - 1 ; if ( ( int32_T ) b_coeffVec_idx_0 - 1 >= 0 )
{ for ( b_i_p = 0 ; b_i_p < 5 ; b_i_p ++ ) { a [ b_i_p ] = tmp_c [ b_i_p ] ;
} } cy4r1g1cm1 ( & b_p , 2 ) ; cy4r1g1cm1 ( & tmp_g , 2 ) ; for ( b_i = 0 ;
b_i <= iacol ; b_i ++ ) { body = obj_p -> Bodies [ b_i ] ; ntilecols = bname
-> size [ 0 ] * bname -> size [ 1 ] ; bname -> size [ 0 ] = 1 ; bname -> size
[ 1 ] = body -> JointInternal . Type -> size [ 1 ] ; ac0ugu5nlz ( bname ,
ntilecols ) ; loop_ub = body -> JointInternal . Type -> size [ 1 ] - 1 ; for
( b_i_p = 0 ; b_i_p <= loop_ub ; b_i_p ++ ) { bname -> data [ b_i_p ] = body
-> JointInternal . Type -> data [ b_i_p ] ; } p = false ; if ( bname -> size
[ 1 ] != 5 ) { } else { ntilecols = 1 ; do { exitg2 = 0 ; if ( ntilecols - 1
< 5 ) { if ( bname -> data [ ntilecols - 1 ] != a [ ntilecols - 1 ] ) {
exitg2 = 1 ; } else { ntilecols ++ ; } } else { p = true ; exitg2 = 1 ; } }
while ( exitg2 == 0 ) ; } if ( ( ! p ) && ( chainmask [ b_i ] != 0.0 ) ) {
for ( b_i_p = 0 ; b_i_p < 16 ; b_i_p ++ ) { T1 [ b_i_p ] = Ttree -> data [ (
int32_T ) body -> Index - 1 ] . f1 [ b_i_p ] ; } for ( b_i_p = 0 ; b_i_p < 16
; b_i_p ++ ) { Tdh [ b_i_p ] = body -> JointInternal . ChildToJointTransform
[ b_i_p ] ; } for ( b_i_p = 0 ; b_i_p < 3 ; b_i_p ++ ) { newBreaks [ 3 *
b_i_p ] = Tdh [ b_i_p ] ; newBreaks [ 3 * b_i_p + 1 ] = Tdh [ b_i_p + 4 ] ;
newBreaks [ 3 * b_i_p + 2 ] = Tdh [ b_i_p + 8 ] ; } for ( b_i_p = 0 ; b_i_p <
9 ; b_i_p ++ ) { tempR [ b_i_p ] = - newBreaks [ b_i_p ] ; } for ( b_i_p = 0
; b_i_p < 3 ; b_i_p ++ ) { v [ b_i_p ] = ( tempR [ b_i_p + 3 ] * Tdh [ 13 ] +
tempR [ b_i_p ] * Tdh [ 12 ] ) + tempR [ b_i_p + 6 ] * Tdh [ 14 ] ; } for (
b_i_p = 0 ; b_i_p < 4 ; b_i_p ++ ) { for ( d = 0 ; d < 4 ; d ++ ) { Tdh [
b_i_p + ( d << 2 ) ] = 0.0 ; Tdh [ b_i_p + ( d << 2 ) ] += T1 [ d << 2 ] *
out [ b_i_p ] ; Tdh [ b_i_p + ( d << 2 ) ] += T1 [ ( d << 2 ) + 1 ] * out [
b_i_p + 4 ] ; Tdh [ b_i_p + ( d << 2 ) ] += T1 [ ( d << 2 ) + 2 ] * out [
b_i_p + 8 ] ; Tdh [ b_i_p + ( d << 2 ) ] += T1 [ ( d << 2 ) + 3 ] * out [
b_i_p + 12 ] ; } } for ( b_i_p = 0 ; b_i_p < 3 ; b_i_p ++ ) { newBreaks_p [
b_i_p << 2 ] = newBreaks [ 3 * b_i_p ] ; newBreaks_p [ ( b_i_p << 2 ) + 1 ] =
newBreaks [ 3 * b_i_p + 1 ] ; newBreaks_p [ ( b_i_p << 2 ) + 2 ] = newBreaks
[ 3 * b_i_p + 2 ] ; newBreaks_p [ b_i_p + 12 ] = v [ b_i_p ] ; } newBreaks_p
[ 3 ] = 0.0 ; newBreaks_p [ 7 ] = 0.0 ; newBreaks_p [ 11 ] = 0.0 ;
newBreaks_p [ 15 ] = 1.0 ; for ( b_i_p = 0 ; b_i_p < 4 ; b_i_p ++ ) { for ( d
= 0 ; d < 4 ; d ++ ) { T1 [ b_i_p + ( d << 2 ) ] = 0.0 ; T1 [ b_i_p + ( d <<
2 ) ] += newBreaks_p [ d << 2 ] * Tdh [ b_i_p ] ; T1 [ b_i_p + ( d << 2 ) ]
+= newBreaks_p [ ( d << 2 ) + 1 ] * Tdh [ b_i_p + 4 ] ; T1 [ b_i_p + ( d << 2
) ] += newBreaks_p [ ( d << 2 ) + 2 ] * Tdh [ b_i_p + 8 ] ; T1 [ b_i_p + ( d
<< 2 ) ] += newBreaks_p [ ( d << 2 ) + 3 ] * Tdh [ b_i_p + 12 ] ; } }
kucwwqtnmc = obj_p -> PositionDoFMap [ b_i ] ; finalTime = obj_p ->
PositionDoFMap [ b_i + 5 ] ; ntilecols = b_p -> size [ 0 ] * b_p -> size [ 1
] ; b_p -> size [ 0 ] = 6 ; b_p -> size [ 1 ] = body -> JointInternal .
MotionSubspace -> size [ 1 ] ; ier0p3wwtw ( b_p , ntilecols ) ; loop_ub = 6 *
body -> JointInternal . MotionSubspace -> size [ 1 ] ; for ( b_i_p = 0 ;
b_i_p < loop_ub ; b_i_p ++ ) { b_p -> data [ b_i_p ] = body -> JointInternal
. MotionSubspace -> data [ b_i_p ] ; } if ( kucwwqtnmc > finalTime ) {
ntilecols = 0 ; } else { ntilecols = ( int32_T ) kucwwqtnmc - 1 ; } newBreaks
[ 0 ] = 0.0 ; newBreaks [ 3 ] = - T1 [ 14 ] ; newBreaks [ 6 ] = T1 [ 13 ] ;
newBreaks [ 1 ] = T1 [ 14 ] ; newBreaks [ 4 ] = 0.0 ; newBreaks [ 7 ] = - T1
[ 12 ] ; newBreaks [ 2 ] = - T1 [ 13 ] ; newBreaks [ 5 ] = T1 [ 12 ] ;
newBreaks [ 8 ] = 0.0 ; for ( b_i_p = 0 ; b_i_p < 3 ; b_i_p ++ ) { for ( d =
0 ; d < 3 ; d ++ ) { tempR [ b_i_p + 3 * d ] = 0.0 ; tempR [ b_i_p + 3 * d ]
+= T1 [ d << 2 ] * newBreaks [ b_i_p ] ; tempR [ b_i_p + 3 * d ] += T1 [ ( d
<< 2 ) + 1 ] * newBreaks [ b_i_p + 3 ] ; tempR [ b_i_p + 3 * d ] += T1 [ ( d
<< 2 ) + 2 ] * newBreaks [ b_i_p + 6 ] ; T [ d + 6 * b_i_p ] = T1 [ ( b_i_p
<< 2 ) + d ] ; T [ d + 6 * ( b_i_p + 3 ) ] = 0.0 ; } } for ( b_i_p = 0 ;
b_i_p < 3 ; b_i_p ++ ) { T [ 6 * b_i_p + 3 ] = tempR [ 3 * b_i_p ] ; T [ 6 *
( b_i_p + 3 ) + 3 ] = T1 [ b_i_p << 2 ] ; T [ 6 * b_i_p + 4 ] = tempR [ 3 *
b_i_p + 1 ] ; T [ 6 * ( b_i_p + 3 ) + 4 ] = T1 [ ( b_i_p << 2 ) + 1 ] ; T [ 6
* b_i_p + 5 ] = tempR [ 3 * b_i_p + 2 ] ; T [ 6 * ( b_i_p + 3 ) + 5 ] = T1 [
( b_i_p << 2 ) + 2 ] ; } knqlderc2u ( T , b_p , tmp_g ) ; loop_ub = tmp_g ->
size [ 1 ] ; for ( b_i_p = 0 ; b_i_p < loop_ub ; b_i_p ++ ) { for ( d = 0 ; d
< 6 ; d ++ ) { b -> data [ d + 6 * ( ntilecols + b_i_p ) ] = tmp_g -> data [
6 * b_i_p + d ] ; } } } } njzmd0hlqd ( & tmp_g ) ; njzmd0hlqd ( & b_p ) ; for
( b_i_p = 0 ; b_i_p < 3 ; b_i_p ++ ) { kucwwqtnmc = T2 [ b_i_p << 2 ] ; T [ 6
* b_i_p ] = kucwwqtnmc ; T [ 6 * ( b_i_p + 3 ) ] = 0.0 ; T [ 6 * b_i_p + 3 ]
= 0.0 ; T [ 6 * ( b_i_p + 3 ) + 3 ] = kucwwqtnmc ; kucwwqtnmc = T2 [ ( b_i_p
<< 2 ) + 1 ] ; T [ 6 * b_i_p + 1 ] = kucwwqtnmc ; T [ 6 * ( b_i_p + 3 ) + 1 ]
= 0.0 ; T [ 6 * b_i_p + 4 ] = 0.0 ; T [ 6 * ( b_i_p + 3 ) + 4 ] = kucwwqtnmc
; kucwwqtnmc = T2 [ ( b_i_p << 2 ) + 2 ] ; T [ 6 * b_i_p + 2 ] = kucwwqtnmc ;
T [ 6 * ( b_i_p + 3 ) + 2 ] = 0.0 ; T [ 6 * b_i_p + 5 ] = 0.0 ; T [ 6 * (
b_i_p + 3 ) + 5 ] = kucwwqtnmc ; } cy4r1g1cm1 ( & b_g , 2 ) ; ntilecols = b_g
-> size [ 0 ] * b_g -> size [ 1 ] ; b_g -> size [ 0 ] = 6 ; b_g -> size [ 1 ]
= b -> size [ 1 ] ; ier0p3wwtw ( b_g , ntilecols ) ; loop_ub = b -> size [ 0
] * b -> size [ 1 ] - 1 ; if ( loop_ub >= 0 ) { memcpy ( & b_g -> data [ 0 ]
, & b -> data [ 0 ] , ( loop_ub + 1 ) * sizeof ( real_T ) ) ; } knqlderc2u (
T , b_g , b ) ; njzmd0hlqd ( & b_g ) ; memcpy ( & rtB . olngjflg0n [ 0 ] , &
b -> data [ 0 ] , 30U * sizeof ( real_T ) ) ; njzmd0hlqd ( & b ) ; if ( rtDW
. htunnpm4aw == 0.0 ) { rtDW . htunnpm4aw = 1.0 ; rtX . ostptot32c [ 0 ] =
rtB . kocxhnfx4g [ 1 ] ; rtX . ostptot32c [ 1 ] = 0.0 ; } rtB . g35gtlfojh [
0 ] = rtX . ostptot32c [ 0 ] ; rtB . g35gtlfojh [ 1 ] = rtX . ostptot32c [ 1
] ; rtB . g35gtlfojh [ 2 ] = ( ( rtB . kocxhnfx4g [ 1 ] - rtX . ostptot32c [
0 ] ) * 1000.0 - 2.0 * rtX . ostptot32c [ 1 ] ) * 1000.0 ; rtB . g35gtlfojh [
3 ] = 0.0 ; if ( rtDW . jjb3503ojt == 0.0 ) { rtDW . jjb3503ojt = 1.0 ; rtX .
dl0o42unpr [ 0 ] = rtB . kocxhnfx4g [ 0 ] ; rtX . dl0o42unpr [ 1 ] = 0.0 ; }
rtB . jrnj3m5jkq [ 0 ] = rtX . dl0o42unpr [ 0 ] ; rtB . jrnj3m5jkq [ 1 ] =
rtX . dl0o42unpr [ 1 ] ; rtB . jrnj3m5jkq [ 2 ] = ( ( rtB . kocxhnfx4g [ 0 ]
- rtX . dl0o42unpr [ 0 ] ) * 1000.0 - 2.0 * rtX . dl0o42unpr [ 1 ] ) * 1000.0
; rtB . jrnj3m5jkq [ 3 ] = 0.0 ; if ( rtDW . frbgw4ey21 == 0.0 ) { rtDW .
frbgw4ey21 = 1.0 ; rtX . pycppw2m5m [ 0 ] = rtB . kocxhnfx4g [ 2 ] ; rtX .
pycppw2m5m [ 1 ] = 0.0 ; } rtB . mxjei2s3ub [ 0 ] = rtX . pycppw2m5m [ 0 ] ;
rtB . mxjei2s3ub [ 1 ] = rtX . pycppw2m5m [ 1 ] ; rtB . mxjei2s3ub [ 2 ] = (
( rtB . kocxhnfx4g [ 2 ] - rtX . pycppw2m5m [ 0 ] ) * 1000.0 - 2.0 * rtX .
pycppw2m5m [ 1 ] ) * 1000.0 ; rtB . mxjei2s3ub [ 3 ] = 0.0 ; if ( rtDW .
o4fw42gm5j == 0.0 ) { rtDW . o4fw42gm5j = 1.0 ; rtX . i4uxujxgss [ 0 ] = rtB
. kocxhnfx4g [ 3 ] ; rtX . i4uxujxgss [ 1 ] = 0.0 ; } rtB . d4sufxfyw0 [ 0 ]
= rtX . i4uxujxgss [ 0 ] ; rtB . d4sufxfyw0 [ 1 ] = rtX . i4uxujxgss [ 1 ] ;
rtB . d4sufxfyw0 [ 2 ] = ( ( rtB . kocxhnfx4g [ 3 ] - rtX . i4uxujxgss [ 0 ]
) * 1000.0 - 2.0 * rtX . i4uxujxgss [ 1 ] ) * 1000.0 ; rtB . d4sufxfyw0 [ 3 ]
= 0.0 ; rtB . kvi533iz0u [ 0 ] = rtP . Constant_Value ; rtB . kvi533iz0u [ 1
] = 0.0 ; rtB . kvi533iz0u [ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( rtS ) ) {
rtDW . pz4m5n3fa5 [ 0 ] = ! ( rtB . kvi533iz0u [ 0 ] == rtDW . pz4m5n3fa5 [ 1
] ) ; rtDW . pz4m5n3fa5 [ 1 ] = rtB . kvi533iz0u [ 0 ] ; } rtB . kvi533iz0u [
0 ] = rtDW . pz4m5n3fa5 [ 1 ] ; rtB . kvi533iz0u [ 3 ] = rtDW . pz4m5n3fa5 [
0 ] ; simulationData = ( NeslSimulationData * ) rtDW . igg4nbzrjn ; time =
ssGetT ( rtS ) ; simulationData -> mData -> mTime . mN = 1 ; simulationData
-> mData -> mTime . mX = & time ; simulationData -> mData -> mContStates . mN
= 0 ; simulationData -> mData -> mContStates . mX = NULL ; simulationData ->
mData -> mDiscStates . mN = 0 ; simulationData -> mData -> mDiscStates . mX =
& rtDW . a0oc1r2fmm ; simulationData -> mData -> mModeVector . mN = 0 ;
simulationData -> mData -> mModeVector . mX = & rtDW . kjdxfgqbzw ; p = (
ssIsMajorTimeStep ( rtS ) && ssGetRTWSolverInfo ( rtS ) -> foundContZcEvents
) ; simulationData -> mData -> mFoundZcEvents = p ; simulationData -> mData
-> mIsMajorTimeStep = ssIsMajorTimeStep ( rtS ) ; p = ( ssGetMdlInfoPtr ( rtS
) -> mdlFlags . solverAssertCheck == 1U ) ; simulationData -> mData ->
mIsSolverAssertCheck = p ; p = ssIsSolverCheckingCIC ( rtS ) ; simulationData
-> mData -> mIsSolverCheckingCIC = p ; simulationData -> mData ->
mIsComputingJacobian = false ; simulationData -> mData -> mIsEvaluatingF0 =
false ; p = ssIsSolverRequestingReset ( rtS ) ; simulationData -> mData ->
mIsSolverRequestingReset = p ; simulationData -> mData ->
mIsModeUpdateTimeStep = ssIsModeUpdateTimeStep ( rtS ) ; tmp_p [ 0 ] = 0 ;
tmp [ 0 ] = rtB . g35gtlfojh [ 0 ] ; tmp [ 1 ] = rtB . g35gtlfojh [ 1 ] ; tmp
[ 2 ] = rtB . g35gtlfojh [ 2 ] ; tmp [ 3 ] = rtB . g35gtlfojh [ 3 ] ; tmp_p [
1 ] = 4 ; tmp [ 4 ] = rtB . jrnj3m5jkq [ 0 ] ; tmp [ 5 ] = rtB . jrnj3m5jkq [
1 ] ; tmp [ 6 ] = rtB . jrnj3m5jkq [ 2 ] ; tmp [ 7 ] = rtB . jrnj3m5jkq [ 3 ]
; tmp_p [ 2 ] = 8 ; tmp [ 8 ] = rtB . mxjei2s3ub [ 0 ] ; tmp [ 9 ] = rtB .
mxjei2s3ub [ 1 ] ; tmp [ 10 ] = rtB . mxjei2s3ub [ 2 ] ; tmp [ 11 ] = rtB .
mxjei2s3ub [ 3 ] ; tmp_p [ 3 ] = 12 ; tmp [ 12 ] = rtB . d4sufxfyw0 [ 0 ] ;
tmp [ 13 ] = rtB . d4sufxfyw0 [ 1 ] ; tmp [ 14 ] = rtB . d4sufxfyw0 [ 2 ] ;
tmp [ 15 ] = rtB . d4sufxfyw0 [ 3 ] ; tmp_p [ 4 ] = 16 ; tmp [ 16 ] = rtB .
kvi533iz0u [ 0 ] ; tmp [ 17 ] = rtB . kvi533iz0u [ 1 ] ; tmp [ 18 ] = rtB .
kvi533iz0u [ 2 ] ; tmp [ 19 ] = rtB . kvi533iz0u [ 3 ] ; tmp_p [ 5 ] = 20 ;
simulationData -> mData -> mInputValues . mN = 20 ; simulationData -> mData
-> mInputValues . mX = & tmp [ 0 ] ; simulationData -> mData -> mInputOffsets
. mN = 6 ; simulationData -> mData -> mInputOffsets . mX = & tmp_p [ 0 ] ;
simulationData -> mData -> mOutputs . mN = 12 ; simulationData -> mData ->
mOutputs . mX = & ckevwcwhlm [ 0 ] ; simulationData -> mData -> mTolerances .
mN = 0 ; simulationData -> mData -> mTolerances . mX = NULL ; simulationData
-> mData -> mCstateHasChanged = false ; time_p = ssGetTaskTime ( rtS , 0 ) ;
simulationData -> mData -> mTime . mN = 1 ; simulationData -> mData -> mTime
. mX = & time_p ; simulationData -> mData -> mSampleHits . mN = 0 ;
simulationData -> mData -> mSampleHits . mX = NULL ; simulationData -> mData
-> mIsFundamentalSampleHit = false ; diagnosticManager = (
NeuDiagnosticManager * ) rtDW . m1h5n4uw0s ; diagnosticTree =
neu_diagnostic_manager_get_initial_tree ( diagnosticManager ) ; b_i =
ne_simulator_method ( ( NeslSimulator * ) rtDW . m2zu25uvwa ,
NESL_SIM_OUTPUTS , simulationData , diagnosticManager ) ; if ( b_i != 0 ) { p
= error_buffer_is_empty ( ssGetErrorStatus ( rtS ) ) ; if ( p ) { msg =
rtw_diagnostics_msg ( diagnosticTree ) ; ssSetErrorStatus ( rtS , msg ) ; } }
if ( ssIsMajorTimeStep ( rtS ) && simulationData -> mData ->
mCstateHasChanged ) { ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; }
chainmask [ 0 ] = ckevwcwhlm [ 4 ] ; chainmask [ 1 ] = ckevwcwhlm [ 1 ] ;
chainmask [ 2 ] = ckevwcwhlm [ 7 ] ; chainmask [ 3 ] = ckevwcwhlm [ 10 ] ;
chainmask [ 4 ] = rtP . Constant3_Value ; for ( b_i_p = 0 ; b_i_p < 6 ; b_i_p
++ ) { rtB . aqvrlbktfx [ b_i_p ] = 0.0 ; for ( d = 0 ; d < 5 ; d ++ ) { rtB
. aqvrlbktfx [ b_i_p ] += rtB . olngjflg0n [ 6 * d + b_i_p ] * chainmask [ d
] ; } } chainmask [ 0 ] = ckevwcwhlm [ 3 ] ; chainmask [ 1 ] = ckevwcwhlm [ 0
] ; chainmask [ 2 ] = ckevwcwhlm [ 6 ] ; chainmask [ 3 ] = ckevwcwhlm [ 9 ] ;
chainmask [ 4 ] = rtP . Constant4_Value ; obj_e = & rtDW . nbtjvvk0iu .
TreeInternal ; finalTime = rtDW . nbtjvvk0iu . TreeInternal . NumBodies ; for
( b_i_p = 0 ; b_i_p < 16 ; b_i_p ++ ) { expl_temp . f1 [ b_i_p ] = tmp_k [
b_i_p ] ; } ntilecols = Ttree -> size [ 0 ] * Ttree -> size [ 1 ] ; Ttree ->
size [ 0 ] = 1 ; Ttree -> size [ 1 ] = ( int32_T ) finalTime ; k5uooz0d10 (
Ttree , ntilecols ) ; if ( ( int32_T ) finalTime != 0 ) { ntilecols = (
int32_T ) finalTime - 1 ; for ( b_i = 0 ; b_i <= ntilecols ; b_i ++ ) { Ttree
-> data [ b_i ] = expl_temp ; } } kucwwqtnmc = 1.0 ; ibcol = ( int32_T )
finalTime - 1 ; if ( ( int32_T ) finalTime - 1 >= 0 ) { for ( b_i_p = 0 ;
b_i_p < 5 ; b_i_p ++ ) { a [ b_i_p ] = tmp_c [ b_i_p ] ; } } for ( b_i = 0 ;
b_i <= ibcol ; b_i ++ ) { body_p = obj_e -> Bodies [ b_i ] ; finalTime =
body_p -> JointInternal . PositionNumber ; b_coeffVec_idx_0 = ( kucwwqtnmc +
finalTime ) - 1.0 ; if ( kucwwqtnmc > b_coeffVec_idx_0 ) { iacol = 0 ; d = 0
; } else { iacol = ( int32_T ) kucwwqtnmc - 1 ; d = ( int32_T )
b_coeffVec_idx_0 ; } for ( b_i_p = 0 ; b_i_p < 16 ; b_i_p ++ ) { T2 [ b_i_p ]
= body_p -> JointInternal . JointToParentTransform [ b_i_p ] ; } ntilecols =
bname -> size [ 0 ] * bname -> size [ 1 ] ; bname -> size [ 0 ] = 1 ; bname
-> size [ 1 ] = body_p -> JointInternal . Type -> size [ 1 ] ; ac0ugu5nlz (
bname , ntilecols ) ; loop_ub = body_p -> JointInternal . Type -> size [ 1 ]
- 1 ; for ( b_i_p = 0 ; b_i_p <= loop_ub ; b_i_p ++ ) { bname -> data [ b_i_p
] = body_p -> JointInternal . Type -> data [ b_i_p ] ; } p = false ; if (
bname -> size [ 1 ] != 5 ) { } else { ntilecols = 1 ; do { exitg2 = 0 ; if (
ntilecols - 1 < 5 ) { if ( bname -> data [ ntilecols - 1 ] != a [ ntilecols -
1 ] ) { exitg2 = 1 ; } else { ntilecols ++ ; } } else { p = true ; exitg2 = 1
; } } while ( exitg2 == 0 ) ; } if ( p ) { b_coeffVec_idx_0 = 0.0 ; } else {
for ( b_i_p = 0 ; b_i_p < 8 ; b_i_p ++ ) { b_m [ b_i_p ] = tmp_b [ b_i_p ] ;
} if ( bname -> size [ 1 ] != 8 ) { } else { ntilecols = 1 ; do { exitg2 = 0
; if ( ntilecols - 1 < 8 ) { if ( bname -> data [ ntilecols - 1 ] != b_m [
ntilecols - 1 ] ) { exitg2 = 1 ; } else { ntilecols ++ ; } } else { p = true
; exitg2 = 1 ; } } while ( exitg2 == 0 ) ; } if ( p ) { b_coeffVec_idx_0 =
1.0 ; } else { b_coeffVec_idx_0 = - 1.0 ; } } switch ( ( int32_T )
b_coeffVec_idx_0 ) { case 0 : memset ( & out [ 0 ] , 0 , sizeof ( real_T ) <<
4U ) ; out [ 0 ] = 1.0 ; out [ 5 ] = 1.0 ; out [ 10 ] = 1.0 ; out [ 15 ] =
1.0 ; break ; case 1 : ocuijkr1g1j ( & body_p -> JointInternal , v ) ;
result_data [ 0 ] = v [ 0 ] ; result_data [ 1 ] = v [ 1 ] ; result_data [ 2 ]
= v [ 2 ] ; if ( ( d - iacol != 0 ) - 1 >= 0 ) { result_data [ 3 ] =
chainmask [ iacol ] ; } b_coeffVec_idx_0 = result_data [ 0 ] ; v [ 0 ] =
b_coeffVec_idx_0 * b_coeffVec_idx_0 ; b_coeffVec_idx_0 = result_data [ 1 ] ;
v [ 1 ] = b_coeffVec_idx_0 * b_coeffVec_idx_0 ; b_coeffVec_idx_0 =
result_data [ 2 ] ; b_coeffVec_idx_0 = 1.0 / muDoubleScalarSqrt ( ( v [ 0 ] +
v [ 1 ] ) + b_coeffVec_idx_0 * b_coeffVec_idx_0 ) ; v [ 0 ] = result_data [ 0
] * b_coeffVec_idx_0 ; v [ 1 ] = result_data [ 1 ] * b_coeffVec_idx_0 ; v [ 2
] = result_data [ 2 ] * b_coeffVec_idx_0 ; b_coeffVec_idx_1 = result_data [ 3
] ; b_coeffVec_idx_0 = muDoubleScalarCos ( b_coeffVec_idx_1 ) ;
b_coeffVec_idx_1 = muDoubleScalarSin ( b_coeffVec_idx_1 ) ; tempR [ 0 ] = v [
0 ] * v [ 0 ] * ( 1.0 - b_coeffVec_idx_0 ) + b_coeffVec_idx_0 ; tempR [ 1 ] =
v [ 0 ] * v [ 1 ] * ( 1.0 - b_coeffVec_idx_0 ) - v [ 2 ] * b_coeffVec_idx_1 ;
tempR [ 2 ] = v [ 0 ] * v [ 2 ] * ( 1.0 - b_coeffVec_idx_0 ) + v [ 1 ] *
b_coeffVec_idx_1 ; tempR [ 3 ] = v [ 0 ] * v [ 1 ] * ( 1.0 - b_coeffVec_idx_0
) + v [ 2 ] * b_coeffVec_idx_1 ; tempR [ 4 ] = v [ 1 ] * v [ 1 ] * ( 1.0 -
b_coeffVec_idx_0 ) + b_coeffVec_idx_0 ; tempR [ 5 ] = v [ 1 ] * v [ 2 ] * (
1.0 - b_coeffVec_idx_0 ) - v [ 0 ] * b_coeffVec_idx_1 ; tempR [ 6 ] = v [ 0 ]
* v [ 2 ] * ( 1.0 - b_coeffVec_idx_0 ) - v [ 1 ] * b_coeffVec_idx_1 ; tempR [
7 ] = v [ 1 ] * v [ 2 ] * ( 1.0 - b_coeffVec_idx_0 ) + v [ 0 ] *
b_coeffVec_idx_1 ; tempR [ 8 ] = v [ 2 ] * v [ 2 ] * ( 1.0 - b_coeffVec_idx_0
) + b_coeffVec_idx_0 ; for ( ntilecols = 0 ; ntilecols < 3 ; ntilecols ++ ) {
newBreaks [ ntilecols ] = tempR [ ntilecols * 3 ] ; newBreaks [ ntilecols + 3
] = tempR [ ntilecols * 3 + 1 ] ; newBreaks [ ntilecols + 6 ] = tempR [
ntilecols * 3 + 2 ] ; } memset ( & out [ 0 ] , 0 , sizeof ( real_T ) << 4U )
; for ( b_i_p = 0 ; b_i_p < 3 ; b_i_p ++ ) { out [ b_i_p << 2 ] = newBreaks [
3 * b_i_p ] ; out [ ( b_i_p << 2 ) + 1 ] = newBreaks [ 3 * b_i_p + 1 ] ; out
[ ( b_i_p << 2 ) + 2 ] = newBreaks [ 3 * b_i_p + 2 ] ; } out [ 15 ] = 1.0 ;
break ; default : ocuijkr1g1j ( & body_p -> JointInternal , v ) ; memset ( &
tempR [ 0 ] , 0 , 9U * sizeof ( real_T ) ) ; tempR [ 0 ] = 1.0 ; tempR [ 4 ]
= 1.0 ; tempR [ 8 ] = 1.0 ; b_coeffVec_idx_0 = chainmask [ iacol ] ; for (
b_i_p = 0 ; b_i_p < 3 ; b_i_p ++ ) { out [ b_i_p << 2 ] = tempR [ 3 * b_i_p ]
; out [ ( b_i_p << 2 ) + 1 ] = tempR [ 3 * b_i_p + 1 ] ; out [ ( b_i_p << 2 )
+ 2 ] = tempR [ 3 * b_i_p + 2 ] ; out [ b_i_p + 12 ] = v [ b_i_p ] *
b_coeffVec_idx_0 ; } out [ 3 ] = 0.0 ; out [ 7 ] = 0.0 ; out [ 11 ] = 0.0 ;
out [ 15 ] = 1.0 ; break ; } for ( b_i_p = 0 ; b_i_p < 16 ; b_i_p ++ ) { T1 [
b_i_p ] = body_p -> JointInternal . ChildToJointTransform [ b_i_p ] ; } for (
b_i_p = 0 ; b_i_p < 4 ; b_i_p ++ ) { for ( d = 0 ; d < 4 ; d ++ ) { Tdh [
b_i_p + ( d << 2 ) ] = 0.0 ; Tdh [ b_i_p + ( d << 2 ) ] += out [ d << 2 ] *
T2 [ b_i_p ] ; Tdh [ b_i_p + ( d << 2 ) ] += out [ ( d << 2 ) + 1 ] * T2 [
b_i_p + 4 ] ; Tdh [ b_i_p + ( d << 2 ) ] += out [ ( d << 2 ) + 2 ] * T2 [
b_i_p + 8 ] ; Tdh [ b_i_p + ( d << 2 ) ] += out [ ( d << 2 ) + 3 ] * T2 [
b_i_p + 12 ] ; } for ( d = 0 ; d < 4 ; d ++ ) { Ttree -> data [ b_i ] . f1 [
b_i_p + ( d << 2 ) ] = 0.0 ; Ttree -> data [ b_i ] . f1 [ b_i_p + ( d << 2 )
] = Ttree -> data [ b_i ] . f1 [ ( d << 2 ) + b_i_p ] + T1 [ d << 2 ] * Tdh [
b_i_p ] ; Ttree -> data [ b_i ] . f1 [ b_i_p + ( d << 2 ) ] = T1 [ ( d << 2 )
+ 1 ] * Tdh [ b_i_p + 4 ] + Ttree -> data [ b_i ] . f1 [ ( d << 2 ) + b_i_p ]
; Ttree -> data [ b_i ] . f1 [ b_i_p + ( d << 2 ) ] = T1 [ ( d << 2 ) + 2 ] *
Tdh [ b_i_p + 8 ] + Ttree -> data [ b_i ] . f1 [ ( d << 2 ) + b_i_p ] ; Ttree
-> data [ b_i ] . f1 [ b_i_p + ( d << 2 ) ] = T1 [ ( d << 2 ) + 3 ] * Tdh [
b_i_p + 12 ] + Ttree -> data [ b_i ] . f1 [ ( d << 2 ) + b_i_p ] ; } }
kucwwqtnmc += finalTime ; if ( body_p -> ParentIndex > 0.0 ) { for ( b_i_p =
0 ; b_i_p < 16 ; b_i_p ++ ) { T2 [ b_i_p ] = Ttree -> data [ ( int32_T )
body_p -> ParentIndex - 1 ] . f1 [ b_i_p ] ; } for ( b_i_p = 0 ; b_i_p < 4 ;
b_i_p ++ ) { for ( d = 0 ; d < 4 ; d ++ ) { Tdh [ b_i_p + ( d << 2 ) ] = 0.0
; Tdh [ b_i_p + ( d << 2 ) ] += Ttree -> data [ b_i ] . f1 [ d << 2 ] * T2 [
b_i_p ] ; Tdh [ b_i_p + ( d << 2 ) ] += Ttree -> data [ b_i ] . f1 [ ( d << 2
) + 1 ] * T2 [ b_i_p + 4 ] ; Tdh [ b_i_p + ( d << 2 ) ] += Ttree -> data [
b_i ] . f1 [ ( d << 2 ) + 2 ] * T2 [ b_i_p + 8 ] ; Tdh [ b_i_p + ( d << 2 ) ]
+= Ttree -> data [ b_i ] . f1 [ ( d << 2 ) + 3 ] * T2 [ b_i_p + 12 ] ; } }
memcpy ( & Ttree -> data [ b_i ] . f1 [ 0 ] , & Tdh [ 0 ] , sizeof ( real_T )
<< 4U ) ; } } kucwwqtnmc = - 1.0 ; ntilecols = bname -> size [ 0 ] * bname ->
size [ 1 ] ; bname -> size [ 0 ] = 1 ; bname -> size [ 1 ] = obj_e -> Base .
NameInternal -> size [ 1 ] ; ac0ugu5nlz ( bname , ntilecols ) ; loop_ub =
obj_e -> Base . NameInternal -> size [ 1 ] - 1 ; for ( b_i_p = 0 ; b_i_p <=
loop_ub ; b_i_p ++ ) { bname -> data [ b_i_p ] = obj_e -> Base . NameInternal
-> data [ b_i_p ] ; } for ( b_i_p = 0 ; b_i_p < 5 ; b_i_p ++ ) { a [ b_i_p ]
= tmp_f [ b_i_p ] ; } p = false ; if ( bname -> size [ 1 ] != 5 ) { } else {
ntilecols = 1 ; do { exitg2 = 0 ; if ( ntilecols - 1 < 5 ) { if ( bname ->
data [ ntilecols - 1 ] != a [ ntilecols - 1 ] ) { exitg2 = 1 ; } else {
ntilecols ++ ; } } else { p = true ; exitg2 = 1 ; } } while ( exitg2 == 0 ) ;
} if ( p ) { kucwwqtnmc = 0.0 ; } else { b_coeffVec_idx_0 = rtDW . nbtjvvk0iu
. TreeInternal . NumBodies ; b_i = 0 ; exitg1 = false ; while ( ( ! exitg1 )
&& ( b_i <= ( int32_T ) b_coeffVec_idx_0 - 1 ) ) { body_p = obj_e -> Bodies [
b_i ] ; ntilecols = bname -> size [ 0 ] * bname -> size [ 1 ] ; bname -> size
[ 0 ] = 1 ; bname -> size [ 1 ] = body_p -> NameInternal -> size [ 1 ] ;
ac0ugu5nlz ( bname , ntilecols ) ; loop_ub = body_p -> NameInternal -> size [
1 ] - 1 ; for ( b_i_p = 0 ; b_i_p <= loop_ub ; b_i_p ++ ) { bname -> data [
b_i_p ] = body_p -> NameInternal -> data [ b_i_p ] ; } for ( b_i_p = 0 ;
b_i_p < 5 ; b_i_p ++ ) { a [ b_i_p ] = tmp_f [ b_i_p ] ; } if ( bname -> size
[ 1 ] != 5 ) { } else { ntilecols = 1 ; do { exitg2 = 0 ; if ( ntilecols - 1
< 5 ) { if ( bname -> data [ ntilecols - 1 ] != a [ ntilecols - 1 ] ) {
exitg2 = 1 ; } else { ntilecols ++ ; } } else { p = true ; exitg2 = 1 ; } }
while ( exitg2 == 0 ) ; } if ( p ) { kucwwqtnmc = ( real_T ) b_i + 1.0 ;
exitg1 = true ; } else { b_i ++ ; } } } if ( kucwwqtnmc == 0.0 ) { memset ( &
T1 [ 0 ] , 0 , sizeof ( real_T ) << 4U ) ; T1 [ 0 ] = 1.0 ; T1 [ 5 ] = 1.0 ;
T1 [ 10 ] = 1.0 ; T1 [ 15 ] = 1.0 ; } else { for ( b_i_p = 0 ; b_i_p < 16 ;
b_i_p ++ ) { T1 [ b_i_p ] = Ttree -> data [ ( int32_T ) kucwwqtnmc - 1 ] . f1
[ b_i_p ] ; } } kucwwqtnmc = - 1.0 ; ntilecols = bname -> size [ 0 ] * bname
-> size [ 1 ] ; bname -> size [ 0 ] = 1 ; bname -> size [ 1 ] = obj_e -> Base
. NameInternal -> size [ 1 ] ; ac0ugu5nlz ( bname , ntilecols ) ; loop_ub =
obj_e -> Base . NameInternal -> size [ 1 ] - 1 ; for ( b_i_p = 0 ; b_i_p <=
loop_ub ; b_i_p ++ ) { bname -> data [ b_i_p ] = obj_e -> Base . NameInternal
-> data [ b_i_p ] ; } b_e [ 0 ] = 'B' ; b_e [ 1 ] = 'a' ; b_e [ 2 ] = 's' ;
b_e [ 3 ] = 'e' ; p = false ; if ( bname -> size [ 1 ] != 4 ) { } else {
ntilecols = 1 ; do { exitg2 = 0 ; if ( ntilecols - 1 < 4 ) { if ( bname ->
data [ ntilecols - 1 ] != b_e [ ntilecols - 1 ] ) { exitg2 = 1 ; } else {
ntilecols ++ ; } } else { p = true ; exitg2 = 1 ; } } while ( exitg2 == 0 ) ;
} if ( p ) { kucwwqtnmc = 0.0 ; } else { b_coeffVec_idx_0 = rtDW . nbtjvvk0iu
. TreeInternal . NumBodies ; b_i = 0 ; exitg1 = false ; while ( ( ! exitg1 )
&& ( b_i <= ( int32_T ) b_coeffVec_idx_0 - 1 ) ) { body_p = obj_e -> Bodies [
b_i ] ; ntilecols = bname -> size [ 0 ] * bname -> size [ 1 ] ; bname -> size
[ 0 ] = 1 ; bname -> size [ 1 ] = body_p -> NameInternal -> size [ 1 ] ;
ac0ugu5nlz ( bname , ntilecols ) ; loop_ub = body_p -> NameInternal -> size [
1 ] - 1 ; for ( b_i_p = 0 ; b_i_p <= loop_ub ; b_i_p ++ ) { bname -> data [
b_i_p ] = body_p -> NameInternal -> data [ b_i_p ] ; } b_e [ 0 ] = 'B' ; b_e
[ 1 ] = 'a' ; b_e [ 2 ] = 's' ; b_e [ 3 ] = 'e' ; if ( bname -> size [ 1 ] !=
4 ) { } else { ntilecols = 1 ; do { exitg2 = 0 ; if ( ntilecols - 1 < 4 ) {
if ( bname -> data [ ntilecols - 1 ] != b_e [ ntilecols - 1 ] ) { exitg2 = 1
; } else { ntilecols ++ ; } } else { p = true ; exitg2 = 1 ; } } while (
exitg2 == 0 ) ; } if ( p ) { kucwwqtnmc = ( real_T ) b_i + 1.0 ; exitg1 =
true ; } else { b_i ++ ; } } } b0l0vcvht3 ( & bname ) ; if ( kucwwqtnmc ==
0.0 ) { memset ( & T2 [ 0 ] , 0 , sizeof ( real_T ) << 4U ) ; T2 [ 0 ] = 1.0
; T2 [ 5 ] = 1.0 ; T2 [ 10 ] = 1.0 ; T2 [ 15 ] = 1.0 ; } else { for ( b_i_p =
0 ; b_i_p < 16 ; b_i_p ++ ) { T2 [ b_i_p ] = Ttree -> data [ ( int32_T )
kucwwqtnmc - 1 ] . f1 [ b_i_p ] ; } } nzox4rsktc ( & Ttree ) ; for ( b_i_p =
0 ; b_i_p < 3 ; b_i_p ++ ) { newBreaks [ 3 * b_i_p ] = T2 [ b_i_p ] ;
newBreaks [ 3 * b_i_p + 1 ] = T2 [ b_i_p + 4 ] ; newBreaks [ 3 * b_i_p + 2 ]
= T2 [ b_i_p + 8 ] ; } for ( b_i_p = 0 ; b_i_p < 9 ; b_i_p ++ ) { tempR [
b_i_p ] = - newBreaks [ b_i_p ] ; } for ( b_i_p = 0 ; b_i_p < 3 ; b_i_p ++ )
{ newBreaks_p [ b_i_p << 2 ] = newBreaks [ 3 * b_i_p ] ; newBreaks_p [ (
b_i_p << 2 ) + 1 ] = newBreaks [ 3 * b_i_p + 1 ] ; newBreaks_p [ ( b_i_p << 2
) + 2 ] = newBreaks [ 3 * b_i_p + 2 ] ; newBreaks_p [ b_i_p + 12 ] = ( tempR
[ b_i_p + 3 ] * T2 [ 13 ] + tempR [ b_i_p ] * T2 [ 12 ] ) + tempR [ b_i_p + 6
] * T2 [ 14 ] ; } newBreaks_p [ 3 ] = 0.0 ; newBreaks_p [ 7 ] = 0.0 ;
newBreaks_p [ 11 ] = 0.0 ; newBreaks_p [ 15 ] = 1.0 ; for ( b_i_p = 0 ; b_i_p
< 4 ; b_i_p ++ ) { for ( d = 0 ; d < 4 ; d ++ ) { rtB . mubufhmikb [ d + (
b_i_p << 2 ) ] = 0.0 ; rtB . mubufhmikb [ d + ( b_i_p << 2 ) ] += T1 [ b_i_p
<< 2 ] * newBreaks_p [ d ] ; rtB . mubufhmikb [ d + ( b_i_p << 2 ) ] += T1 [
( b_i_p << 2 ) + 1 ] * newBreaks_p [ d + 4 ] ; rtB . mubufhmikb [ d + ( b_i_p
<< 2 ) ] += T1 [ ( b_i_p << 2 ) + 2 ] * newBreaks_p [ d + 8 ] ; rtB .
mubufhmikb [ d + ( b_i_p << 2 ) ] += T1 [ ( b_i_p << 2 ) + 3 ] * newBreaks_p
[ d + 12 ] ; } } for ( ntilecols = 0 ; ntilecols < 5 ; ntilecols ++ ) { rtB .
g0n3japp2o [ ntilecols ] = rtP . Gain_Gain * rtB . kocxhnfx4g [ ntilecols ] ;
} rtB . evts0truna = ckevwcwhlm [ 5 ] ; rtB . oxlbdgveau = ckevwcwhlm [ 2 ] ;
rtB . gtrv14nqvd = ckevwcwhlm [ 8 ] ; rtB . cnntouejof = ckevwcwhlm [ 11 ] ;
simulationData = ( NeslSimulationData * ) rtDW . oebpmsajkl ; time_e = ssGetT
( rtS ) ; simulationData -> mData -> mTime . mN = 1 ; simulationData -> mData
-> mTime . mX = & time_e ; simulationData -> mData -> mContStates . mN = 0 ;
simulationData -> mData -> mContStates . mX = NULL ; simulationData -> mData
-> mDiscStates . mN = 0 ; simulationData -> mData -> mDiscStates . mX = &
rtDW . ldjhzt1tvv ; simulationData -> mData -> mModeVector . mN = 0 ;
simulationData -> mData -> mModeVector . mX = & rtDW . lc4aznzqkp ; p = (
ssIsMajorTimeStep ( rtS ) && ssGetRTWSolverInfo ( rtS ) -> foundContZcEvents
) ; simulationData -> mData -> mFoundZcEvents = p ; simulationData -> mData
-> mIsMajorTimeStep = ssIsMajorTimeStep ( rtS ) ; p = ( ssGetMdlInfoPtr ( rtS
) -> mdlFlags . solverAssertCheck == 1U ) ; simulationData -> mData ->
mIsSolverAssertCheck = p ; p = ssIsSolverCheckingCIC ( rtS ) ; simulationData
-> mData -> mIsSolverCheckingCIC = p ; simulationData -> mData ->
mIsComputingJacobian = false ; simulationData -> mData -> mIsEvaluatingF0 =
false ; p = ssIsSolverRequestingReset ( rtS ) ; simulationData -> mData ->
mIsSolverRequestingReset = p ; simulationData -> mData ->
mIsModeUpdateTimeStep = ssIsModeUpdateTimeStep ( rtS ) ; tmp_i [ 0 ] = 0 ;
tmp_e [ 0 ] = rtB . g35gtlfojh [ 0 ] ; tmp_e [ 1 ] = rtB . g35gtlfojh [ 1 ] ;
tmp_e [ 2 ] = rtB . g35gtlfojh [ 2 ] ; tmp_e [ 3 ] = rtB . g35gtlfojh [ 3 ] ;
tmp_i [ 1 ] = 4 ; tmp_e [ 4 ] = rtB . jrnj3m5jkq [ 0 ] ; tmp_e [ 5 ] = rtB .
jrnj3m5jkq [ 1 ] ; tmp_e [ 6 ] = rtB . jrnj3m5jkq [ 2 ] ; tmp_e [ 7 ] = rtB .
jrnj3m5jkq [ 3 ] ; tmp_i [ 2 ] = 8 ; tmp_e [ 8 ] = rtB . mxjei2s3ub [ 0 ] ;
tmp_e [ 9 ] = rtB . mxjei2s3ub [ 1 ] ; tmp_e [ 10 ] = rtB . mxjei2s3ub [ 2 ]
; tmp_e [ 11 ] = rtB . mxjei2s3ub [ 3 ] ; tmp_i [ 3 ] = 12 ; tmp_e [ 12 ] =
rtB . d4sufxfyw0 [ 0 ] ; tmp_e [ 13 ] = rtB . d4sufxfyw0 [ 1 ] ; tmp_e [ 14 ]
= rtB . d4sufxfyw0 [ 2 ] ; tmp_e [ 15 ] = rtB . d4sufxfyw0 [ 3 ] ; tmp_i [ 4
] = 16 ; tmp_e [ 16 ] = rtB . kvi533iz0u [ 0 ] ; tmp_e [ 17 ] = rtB .
kvi533iz0u [ 1 ] ; tmp_e [ 18 ] = rtB . kvi533iz0u [ 2 ] ; tmp_e [ 19 ] = rtB
. kvi533iz0u [ 3 ] ; tmp_i [ 5 ] = 20 ; simulationData -> mData ->
mInputValues . mN = 20 ; simulationData -> mData -> mInputValues . mX = &
tmp_e [ 0 ] ; simulationData -> mData -> mInputOffsets . mN = 6 ;
simulationData -> mData -> mInputOffsets . mX = & tmp_i [ 0 ] ;
simulationData -> mData -> mOutputs . mN = 0 ; simulationData -> mData ->
mOutputs . mX = NULL ; simulationData -> mData -> mTolerances . mN = 0 ;
simulationData -> mData -> mTolerances . mX = NULL ; simulationData -> mData
-> mCstateHasChanged = false ; time_i = ssGetTaskTime ( rtS , 0 ) ;
simulationData -> mData -> mTime . mN = 1 ; simulationData -> mData -> mTime
. mX = & time_i ; simulationData -> mData -> mSampleHits . mN = 0 ;
simulationData -> mData -> mSampleHits . mX = NULL ; simulationData -> mData
-> mIsFundamentalSampleHit = false ; diagnosticManager = (
NeuDiagnosticManager * ) rtDW . jjwd1cr3xx ; diagnosticTree_p =
neu_diagnostic_manager_get_initial_tree ( diagnosticManager ) ; b_i =
ne_simulator_method ( ( NeslSimulator * ) rtDW . hxun4zugta ,
NESL_SIM_OUTPUTS , simulationData , diagnosticManager ) ; if ( b_i != 0 ) { p
= error_buffer_is_empty ( ssGetErrorStatus ( rtS ) ) ; if ( p ) { msg_p =
rtw_diagnostics_msg ( diagnosticTree_p ) ; ssSetErrorStatus ( rtS , msg_p ) ;
} } if ( ssIsMajorTimeStep ( rtS ) && simulationData -> mData ->
mCstateHasChanged ) { ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; }
UNUSED_PARAMETER ( tid ) ; } void MdlOutputsTID1 ( int_T tid ) {
UNUSED_PARAMETER ( tid ) ; } void MdlUpdate ( int_T tid ) {
NeslSimulationData * simulationData ; NeuDiagnosticManager *
diagnosticManager ; NeuDiagnosticTree * diagnosticTree ; char * msg ; real_T
tmp_p [ 20 ] ; real_T time ; int32_T tmp_i ; int_T tmp_e [ 6 ] ; boolean_T
tmp ; simulationData = ( NeslSimulationData * ) rtDW . oebpmsajkl ; time =
ssGetT ( rtS ) ; simulationData -> mData -> mTime . mN = 1 ; simulationData
-> mData -> mTime . mX = & time ; simulationData -> mData -> mContStates . mN
= 0 ; simulationData -> mData -> mContStates . mX = NULL ; simulationData ->
mData -> mDiscStates . mN = 0 ; simulationData -> mData -> mDiscStates . mX =
& rtDW . ldjhzt1tvv ; simulationData -> mData -> mModeVector . mN = 0 ;
simulationData -> mData -> mModeVector . mX = & rtDW . lc4aznzqkp ; tmp = (
ssIsMajorTimeStep ( rtS ) && ssGetRTWSolverInfo ( rtS ) -> foundContZcEvents
) ; simulationData -> mData -> mFoundZcEvents = tmp ; simulationData -> mData
-> mIsMajorTimeStep = ssIsMajorTimeStep ( rtS ) ; tmp = ( ssGetMdlInfoPtr (
rtS ) -> mdlFlags . solverAssertCheck == 1U ) ; simulationData -> mData ->
mIsSolverAssertCheck = tmp ; tmp = ssIsSolverCheckingCIC ( rtS ) ;
simulationData -> mData -> mIsSolverCheckingCIC = tmp ; simulationData ->
mData -> mIsComputingJacobian = false ; simulationData -> mData ->
mIsEvaluatingF0 = false ; tmp = ssIsSolverRequestingReset ( rtS ) ;
simulationData -> mData -> mIsSolverRequestingReset = tmp ; simulationData ->
mData -> mIsModeUpdateTimeStep = ssIsModeUpdateTimeStep ( rtS ) ; tmp_e [ 0 ]
= 0 ; tmp_p [ 0 ] = rtB . g35gtlfojh [ 0 ] ; tmp_p [ 1 ] = rtB . g35gtlfojh [
1 ] ; tmp_p [ 2 ] = rtB . g35gtlfojh [ 2 ] ; tmp_p [ 3 ] = rtB . g35gtlfojh [
3 ] ; tmp_e [ 1 ] = 4 ; tmp_p [ 4 ] = rtB . jrnj3m5jkq [ 0 ] ; tmp_p [ 5 ] =
rtB . jrnj3m5jkq [ 1 ] ; tmp_p [ 6 ] = rtB . jrnj3m5jkq [ 2 ] ; tmp_p [ 7 ] =
rtB . jrnj3m5jkq [ 3 ] ; tmp_e [ 2 ] = 8 ; tmp_p [ 8 ] = rtB . mxjei2s3ub [ 0
] ; tmp_p [ 9 ] = rtB . mxjei2s3ub [ 1 ] ; tmp_p [ 10 ] = rtB . mxjei2s3ub [
2 ] ; tmp_p [ 11 ] = rtB . mxjei2s3ub [ 3 ] ; tmp_e [ 3 ] = 12 ; tmp_p [ 12 ]
= rtB . d4sufxfyw0 [ 0 ] ; tmp_p [ 13 ] = rtB . d4sufxfyw0 [ 1 ] ; tmp_p [ 14
] = rtB . d4sufxfyw0 [ 2 ] ; tmp_p [ 15 ] = rtB . d4sufxfyw0 [ 3 ] ; tmp_e [
4 ] = 16 ; tmp_p [ 16 ] = rtB . kvi533iz0u [ 0 ] ; tmp_p [ 17 ] = rtB .
kvi533iz0u [ 1 ] ; tmp_p [ 18 ] = rtB . kvi533iz0u [ 2 ] ; tmp_p [ 19 ] = rtB
. kvi533iz0u [ 3 ] ; tmp_e [ 5 ] = 20 ; simulationData -> mData ->
mInputValues . mN = 20 ; simulationData -> mData -> mInputValues . mX = &
tmp_p [ 0 ] ; simulationData -> mData -> mInputOffsets . mN = 6 ;
simulationData -> mData -> mInputOffsets . mX = & tmp_e [ 0 ] ;
diagnosticManager = ( NeuDiagnosticManager * ) rtDW . jjwd1cr3xx ;
diagnosticTree = neu_diagnostic_manager_get_initial_tree ( diagnosticManager
) ; tmp_i = ne_simulator_method ( ( NeslSimulator * ) rtDW . hxun4zugta ,
NESL_SIM_UPDATE , simulationData , diagnosticManager ) ; if ( tmp_i != 0 ) {
tmp = error_buffer_is_empty ( ssGetErrorStatus ( rtS ) ) ; if ( tmp ) { msg =
rtw_diagnostics_msg ( diagnosticTree ) ; ssSetErrorStatus ( rtS , msg ) ; } }
UNUSED_PARAMETER ( tid ) ; } void MdlUpdateTID1 ( int_T tid ) {
UNUSED_PARAMETER ( tid ) ; } void MdlDerivatives ( void ) { XDot * _rtXdot ;
_rtXdot = ( ( XDot * ) ssGetdX ( rtS ) ) ; _rtXdot -> ostptot32c [ 0 ] = rtX
. ostptot32c [ 1 ] ; _rtXdot -> ostptot32c [ 1 ] = ( ( rtB . kocxhnfx4g [ 1 ]
- rtX . ostptot32c [ 0 ] ) * 1000.0 - 2.0 * rtX . ostptot32c [ 1 ] ) * 1000.0
; _rtXdot -> dl0o42unpr [ 0 ] = rtX . dl0o42unpr [ 1 ] ; _rtXdot ->
dl0o42unpr [ 1 ] = ( ( rtB . kocxhnfx4g [ 0 ] - rtX . dl0o42unpr [ 0 ] ) *
1000.0 - 2.0 * rtX . dl0o42unpr [ 1 ] ) * 1000.0 ; _rtXdot -> pycppw2m5m [ 0
] = rtX . pycppw2m5m [ 1 ] ; _rtXdot -> pycppw2m5m [ 1 ] = ( ( rtB .
kocxhnfx4g [ 2 ] - rtX . pycppw2m5m [ 0 ] ) * 1000.0 - 2.0 * rtX . pycppw2m5m
[ 1 ] ) * 1000.0 ; _rtXdot -> i4uxujxgss [ 0 ] = rtX . i4uxujxgss [ 1 ] ;
_rtXdot -> i4uxujxgss [ 1 ] = ( ( rtB . kocxhnfx4g [ 3 ] - rtX . i4uxujxgss [
0 ] ) * 1000.0 - 2.0 * rtX . i4uxujxgss [ 1 ] ) * 1000.0 ; } void
MdlProjection ( void ) { } void MdlTerminate ( void ) { void *
geometryInternal ; iabjthfi1p * obj ; mqyxc3drwd * obj_p ; int32_T b ; if ( !
rtDW . h50oa4paoh . matlabCodegenIsDeleted ) { rtDW . h50oa4paoh .
matlabCodegenIsDeleted = true ; } obj = & rtDW . h50oa4paoh . IKInternal ; if
( ! obj -> matlabCodegenIsDeleted ) { obj -> matlabCodegenIsDeleted = true ;
if ( obj -> isInitialized == 1 ) { obj -> isInitialized = 2 ; } } for ( b = 0
; b < 11 ; b ++ ) { obj_p = & rtDW . h50oa4paoh . TreeInternal . _pobj0 [ b ]
. _pobj0 ; if ( ! obj_p -> matlabCodegenIsDeleted ) { obj_p ->
matlabCodegenIsDeleted = true ; geometryInternal = obj_p ->
CollisionPrimitive ; collisioncodegen_destructGeometry ( & geometryInternal )
; } } for ( b = 0 ; b < 11 ; b ++ ) { obj_p = & rtDW . h50oa4paoh .
IKInternal . _pobj3 [ b ] . _pobj0 ; if ( ! obj_p -> matlabCodegenIsDeleted )
{ obj_p -> matlabCodegenIsDeleted = true ; geometryInternal = obj_p ->
CollisionPrimitive ; collisioncodegen_destructGeometry ( & geometryInternal )
; } } for ( b = 0 ; b < 6 ; b ++ ) { obj_p = & rtDW . h50oa4paoh . IKInternal
. _pobj4 . _pobj1 [ b ] . _pobj0 ; if ( ! obj_p -> matlabCodegenIsDeleted ) {
obj_p -> matlabCodegenIsDeleted = true ; geometryInternal = obj_p ->
CollisionPrimitive ; collisioncodegen_destructGeometry ( & geometryInternal )
; } } oh1nyigqv2 ( & rtDW . h50oa4paoh ) ; obj_p = & rtDW . au4tbeh3wp .
TreeInternal . Base . CollisionsInternal . _pobj0 ; if ( ! obj_p ->
matlabCodegenIsDeleted ) { obj_p -> matlabCodegenIsDeleted = true ;
geometryInternal = obj_p -> CollisionPrimitive ;
collisioncodegen_destructGeometry ( & geometryInternal ) ; } for ( b = 0 ; b
< 10 ; b ++ ) { obj_p = & rtDW . au4tbeh3wp . TreeInternal . _pobj0 [ b ] .
CollisionsInternal . _pobj0 ; if ( ! obj_p -> matlabCodegenIsDeleted ) {
obj_p -> matlabCodegenIsDeleted = true ; geometryInternal = obj_p ->
CollisionPrimitive ; collisioncodegen_destructGeometry ( & geometryInternal )
; } } oh1nyigqv24 ( & rtDW . au4tbeh3wp ) ; neu_destroy_diagnostic_manager (
( NeuDiagnosticManager * ) rtDW . m1h5n4uw0s ) ; nesl_destroy_simulation_data
( ( NeslSimulationData * ) rtDW . igg4nbzrjn ) ; nesl_erase_simulator (
"Jacobian/Subsystem/Solver Configuration_1" ) ; nesl_destroy_registry ( ) ;
obj_p = & rtDW . nbtjvvk0iu . TreeInternal . Base . CollisionsInternal .
_pobj0 ; if ( ! obj_p -> matlabCodegenIsDeleted ) { obj_p ->
matlabCodegenIsDeleted = true ; geometryInternal = obj_p ->
CollisionPrimitive ; collisioncodegen_destructGeometry ( & geometryInternal )
; } for ( b = 0 ; b < 10 ; b ++ ) { obj_p = & rtDW . nbtjvvk0iu .
TreeInternal . _pobj0 [ b ] . CollisionsInternal . _pobj0 ; if ( ! obj_p ->
matlabCodegenIsDeleted ) { obj_p -> matlabCodegenIsDeleted = true ;
geometryInternal = obj_p -> CollisionPrimitive ;
collisioncodegen_destructGeometry ( & geometryInternal ) ; } } oh1nyigqv241 (
& rtDW . nbtjvvk0iu ) ; neu_destroy_diagnostic_manager ( (
NeuDiagnosticManager * ) rtDW . jjwd1cr3xx ) ; nesl_destroy_simulation_data (
( NeslSimulationData * ) rtDW . oebpmsajkl ) ; nesl_erase_simulator (
"Jacobian/Subsystem/Solver Configuration_1" ) ; nesl_destroy_registry ( ) ; }
static void mr_Jacobian_cacheDataAsMxArray ( mxArray * destArray , mwIndex i
, int j , const void * srcData , size_t numBytes ) ; static void
mr_Jacobian_cacheDataAsMxArray ( mxArray * destArray , mwIndex i , int j ,
const void * srcData , size_t numBytes ) { mxArray * newArray =
mxCreateUninitNumericMatrix ( ( size_t ) 1 , numBytes , mxUINT8_CLASS ,
mxREAL ) ; memcpy ( ( uint8_T * ) mxGetData ( newArray ) , ( const uint8_T *
) srcData , numBytes ) ; mxSetFieldByNumber ( destArray , i , j , newArray )
; } static void mr_Jacobian_restoreDataFromMxArray ( void * destData , const
mxArray * srcArray , mwIndex i , int j , size_t numBytes ) ; static void
mr_Jacobian_restoreDataFromMxArray ( void * destData , const mxArray *
srcArray , mwIndex i , int j , size_t numBytes ) { memcpy ( ( uint8_T * )
destData , ( const uint8_T * ) mxGetData ( mxGetFieldByNumber ( srcArray , i
, j ) ) , numBytes ) ; } static void mr_Jacobian_cacheBitFieldToMxArray (
mxArray * destArray , mwIndex i , int j , uint_T bitVal ) ; static void
mr_Jacobian_cacheBitFieldToMxArray ( mxArray * destArray , mwIndex i , int j
, uint_T bitVal ) { mxSetFieldByNumber ( destArray , i , j ,
mxCreateDoubleScalar ( ( double ) bitVal ) ) ; } static uint_T
mr_Jacobian_extractBitFieldFromMxArray ( const mxArray * srcArray , mwIndex i
, int j , uint_T numBits ) ; static uint_T
mr_Jacobian_extractBitFieldFromMxArray ( const mxArray * srcArray , mwIndex i
, int j , uint_T numBits ) { const uint_T varVal = ( uint_T ) mxGetScalar (
mxGetFieldByNumber ( srcArray , i , j ) ) ; return varVal & ( ( 1u << numBits
) - 1u ) ; } static void mr_Jacobian_cacheDataToMxArrayWithOffset ( mxArray *
destArray , mwIndex i , int j , mwIndex offset , const void * srcData ,
size_t numBytes ) ; static void mr_Jacobian_cacheDataToMxArrayWithOffset (
mxArray * destArray , mwIndex i , int j , mwIndex offset , const void *
srcData , size_t numBytes ) { uint8_T * varData = ( uint8_T * ) mxGetData (
mxGetFieldByNumber ( destArray , i , j ) ) ; memcpy ( ( uint8_T * ) & varData
[ offset * numBytes ] , ( const uint8_T * ) srcData , numBytes ) ; } static
void mr_Jacobian_restoreDataFromMxArrayWithOffset ( void * destData , const
mxArray * srcArray , mwIndex i , int j , mwIndex offset , size_t numBytes ) ;
static void mr_Jacobian_restoreDataFromMxArrayWithOffset ( void * destData ,
const mxArray * srcArray , mwIndex i , int j , mwIndex offset , size_t
numBytes ) { const uint8_T * varData = ( const uint8_T * ) mxGetData (
mxGetFieldByNumber ( srcArray , i , j ) ) ; memcpy ( ( uint8_T * ) destData ,
( const uint8_T * ) & varData [ offset * numBytes ] , numBytes ) ; } static
void mr_Jacobian_cacheBitFieldToCellArrayWithOffset ( mxArray * destArray ,
mwIndex i , int j , mwIndex offset , uint_T fieldVal ) ; static void
mr_Jacobian_cacheBitFieldToCellArrayWithOffset ( mxArray * destArray ,
mwIndex i , int j , mwIndex offset , uint_T fieldVal ) { mxSetCell (
mxGetFieldByNumber ( destArray , i , j ) , offset , mxCreateDoubleScalar ( (
double ) fieldVal ) ) ; } static uint_T
mr_Jacobian_extractBitFieldFromCellArrayWithOffset ( const mxArray * srcArray
, mwIndex i , int j , mwIndex offset , uint_T numBits ) ; static uint_T
mr_Jacobian_extractBitFieldFromCellArrayWithOffset ( const mxArray * srcArray
, mwIndex i , int j , mwIndex offset , uint_T numBits ) { const uint_T
fieldVal = ( uint_T ) mxGetScalar ( mxGetCell ( mxGetFieldByNumber ( srcArray
, i , j ) , offset ) ) ; return fieldVal & ( ( 1u << numBits ) - 1u ) ; }
mxArray * mr_Jacobian_GetDWork ( ) { static const char * ssDWFieldNames [ 3 ]
= { "rtB" , "rtDW" , "NULL_PrevZCX" , } ; mxArray * ssDW =
mxCreateStructMatrix ( 1 , 1 , 3 , ssDWFieldNames ) ;
mr_Jacobian_cacheDataAsMxArray ( ssDW , 0 , 0 , ( const void * ) & ( rtB ) ,
sizeof ( rtB ) ) ; { static const char * rtdwDataFieldNames [ 39 ] = {
"rtDW.h50oa4paoh" , "rtDW.au4tbeh3wp" , "rtDW.nbtjvvk0iu" , "rtDW.fymvqkxpsu"
, "rtDW.j3as2zn3ny" , "rtDW.htunnpm4aw" , "rtDW.btrdhary1n" ,
"rtDW.jjb3503ojt" , "rtDW.jmhtlb4kaj" , "rtDW.frbgw4ey21" , "rtDW.oqhsxqjtcq"
, "rtDW.o4fw42gm5j" , "rtDW.pz4m5n3fa5" , "rtDW.a0oc1r2fmm" ,
"rtDW.ldjhzt1tvv" , "rtDW.ndveltha3i" , "rtDW.apqphginxx" , "rtDW.a424fqcnvz"
, "rtDW.iovoxirwro" , "rtDW.coliwj5sya" , "rtDW.fz2ttztfrx" ,
"rtDW.frbywcoc2g" , "rtDW.df2e0pg2dx" , "rtDW.kjdxfgqbzw" , "rtDW.lc4aznzqkp"
, "rtDW.aq3afxfwxg" , "rtDW.oe04kxktvd" , "rtDW.paf4jizn5q" ,
"rtDW.chxdltntn1" , "rtDW.lvfg2ialf5" , "rtDW.fs53o4lsci" , "rtDW.idgjtzemzw"
, "rtDW.mkp2eepxcj" , "rtDW.gmdfw45vlb" , "rtDW.cueoevswm1" ,
"rtDW.n1jgscci0o" , "rtDW.i2pqjw3yac" , "rtDW.kkhkendrtu" , "rtDW.a5bv3potn3"
, } ; mxArray * rtdwData = mxCreateStructMatrix ( 1 , 1 , 39 ,
rtdwDataFieldNames ) ; mr_Jacobian_cacheDataAsMxArray ( rtdwData , 0 , 0 , (
const void * ) & ( rtDW . h50oa4paoh ) , sizeof ( rtDW . h50oa4paoh ) ) ;
mr_Jacobian_cacheDataAsMxArray ( rtdwData , 0 , 1 , ( const void * ) & ( rtDW
. au4tbeh3wp ) , sizeof ( rtDW . au4tbeh3wp ) ) ;
mr_Jacobian_cacheDataAsMxArray ( rtdwData , 0 , 2 , ( const void * ) & ( rtDW
. nbtjvvk0iu ) , sizeof ( rtDW . nbtjvvk0iu ) ) ;
mr_Jacobian_cacheDataAsMxArray ( rtdwData , 0 , 3 , ( const void * ) & ( rtDW
. fymvqkxpsu ) , sizeof ( rtDW . fymvqkxpsu ) ) ;
mr_Jacobian_cacheDataAsMxArray ( rtdwData , 0 , 4 , ( const void * ) & ( rtDW
. j3as2zn3ny ) , sizeof ( rtDW . j3as2zn3ny ) ) ;
mr_Jacobian_cacheDataAsMxArray ( rtdwData , 0 , 5 , ( const void * ) & ( rtDW
. htunnpm4aw ) , sizeof ( rtDW . htunnpm4aw ) ) ;
mr_Jacobian_cacheDataAsMxArray ( rtdwData , 0 , 6 , ( const void * ) & ( rtDW
. btrdhary1n ) , sizeof ( rtDW . btrdhary1n ) ) ;
mr_Jacobian_cacheDataAsMxArray ( rtdwData , 0 , 7 , ( const void * ) & ( rtDW
. jjb3503ojt ) , sizeof ( rtDW . jjb3503ojt ) ) ;
mr_Jacobian_cacheDataAsMxArray ( rtdwData , 0 , 8 , ( const void * ) & ( rtDW
. jmhtlb4kaj ) , sizeof ( rtDW . jmhtlb4kaj ) ) ;
mr_Jacobian_cacheDataAsMxArray ( rtdwData , 0 , 9 , ( const void * ) & ( rtDW
. frbgw4ey21 ) , sizeof ( rtDW . frbgw4ey21 ) ) ;
mr_Jacobian_cacheDataAsMxArray ( rtdwData , 0 , 10 , ( const void * ) & (
rtDW . oqhsxqjtcq ) , sizeof ( rtDW . oqhsxqjtcq ) ) ;
mr_Jacobian_cacheDataAsMxArray ( rtdwData , 0 , 11 , ( const void * ) & (
rtDW . o4fw42gm5j ) , sizeof ( rtDW . o4fw42gm5j ) ) ;
mr_Jacobian_cacheDataAsMxArray ( rtdwData , 0 , 12 , ( const void * ) & (
rtDW . pz4m5n3fa5 ) , sizeof ( rtDW . pz4m5n3fa5 ) ) ;
mr_Jacobian_cacheDataAsMxArray ( rtdwData , 0 , 13 , ( const void * ) & (
rtDW . a0oc1r2fmm ) , sizeof ( rtDW . a0oc1r2fmm ) ) ;
mr_Jacobian_cacheDataAsMxArray ( rtdwData , 0 , 14 , ( const void * ) & (
rtDW . ldjhzt1tvv ) , sizeof ( rtDW . ldjhzt1tvv ) ) ;
mr_Jacobian_cacheDataAsMxArray ( rtdwData , 0 , 15 , ( const void * ) & (
rtDW . ndveltha3i ) , sizeof ( rtDW . ndveltha3i ) ) ;
mr_Jacobian_cacheDataAsMxArray ( rtdwData , 0 , 16 , ( const void * ) & (
rtDW . apqphginxx ) , sizeof ( rtDW . apqphginxx ) ) ;
mr_Jacobian_cacheDataAsMxArray ( rtdwData , 0 , 17 , ( const void * ) & (
rtDW . a424fqcnvz ) , sizeof ( rtDW . a424fqcnvz ) ) ;
mr_Jacobian_cacheDataAsMxArray ( rtdwData , 0 , 18 , ( const void * ) & (
rtDW . iovoxirwro ) , sizeof ( rtDW . iovoxirwro ) ) ;
mr_Jacobian_cacheDataAsMxArray ( rtdwData , 0 , 19 , ( const void * ) & (
rtDW . coliwj5sya ) , sizeof ( rtDW . coliwj5sya ) ) ;
mr_Jacobian_cacheDataAsMxArray ( rtdwData , 0 , 20 , ( const void * ) & (
rtDW . fz2ttztfrx ) , sizeof ( rtDW . fz2ttztfrx ) ) ;
mr_Jacobian_cacheDataAsMxArray ( rtdwData , 0 , 21 , ( const void * ) & (
rtDW . frbywcoc2g ) , sizeof ( rtDW . frbywcoc2g ) ) ;
mr_Jacobian_cacheDataAsMxArray ( rtdwData , 0 , 22 , ( const void * ) & (
rtDW . df2e0pg2dx ) , sizeof ( rtDW . df2e0pg2dx ) ) ;
mr_Jacobian_cacheDataAsMxArray ( rtdwData , 0 , 23 , ( const void * ) & (
rtDW . kjdxfgqbzw ) , sizeof ( rtDW . kjdxfgqbzw ) ) ;
mr_Jacobian_cacheDataAsMxArray ( rtdwData , 0 , 24 , ( const void * ) & (
rtDW . lc4aznzqkp ) , sizeof ( rtDW . lc4aznzqkp ) ) ;
mr_Jacobian_cacheDataAsMxArray ( rtdwData , 0 , 25 , ( const void * ) & (
rtDW . aq3afxfwxg ) , sizeof ( rtDW . aq3afxfwxg ) ) ;
mr_Jacobian_cacheDataAsMxArray ( rtdwData , 0 , 26 , ( const void * ) & (
rtDW . oe04kxktvd ) , sizeof ( rtDW . oe04kxktvd ) ) ;
mr_Jacobian_cacheDataAsMxArray ( rtdwData , 0 , 27 , ( const void * ) & (
rtDW . paf4jizn5q ) , sizeof ( rtDW . paf4jizn5q ) ) ;
mr_Jacobian_cacheDataAsMxArray ( rtdwData , 0 , 28 , ( const void * ) & (
rtDW . chxdltntn1 ) , sizeof ( rtDW . chxdltntn1 ) ) ;
mr_Jacobian_cacheDataAsMxArray ( rtdwData , 0 , 29 , ( const void * ) & (
rtDW . lvfg2ialf5 ) , sizeof ( rtDW . lvfg2ialf5 ) ) ;
mr_Jacobian_cacheDataAsMxArray ( rtdwData , 0 , 30 , ( const void * ) & (
rtDW . fs53o4lsci ) , sizeof ( rtDW . fs53o4lsci ) ) ;
mr_Jacobian_cacheDataAsMxArray ( rtdwData , 0 , 31 , ( const void * ) & (
rtDW . idgjtzemzw ) , sizeof ( rtDW . idgjtzemzw ) ) ;
mr_Jacobian_cacheDataAsMxArray ( rtdwData , 0 , 32 , ( const void * ) & (
rtDW . mkp2eepxcj ) , sizeof ( rtDW . mkp2eepxcj ) ) ;
mr_Jacobian_cacheDataAsMxArray ( rtdwData , 0 , 33 , ( const void * ) & (
rtDW . gmdfw45vlb ) , sizeof ( rtDW . gmdfw45vlb ) ) ;
mr_Jacobian_cacheDataAsMxArray ( rtdwData , 0 , 34 , ( const void * ) & (
rtDW . cueoevswm1 ) , sizeof ( rtDW . cueoevswm1 ) ) ;
mr_Jacobian_cacheDataAsMxArray ( rtdwData , 0 , 35 , ( const void * ) & (
rtDW . n1jgscci0o ) , sizeof ( rtDW . n1jgscci0o ) ) ;
mr_Jacobian_cacheDataAsMxArray ( rtdwData , 0 , 36 , ( const void * ) & (
rtDW . i2pqjw3yac ) , sizeof ( rtDW . i2pqjw3yac ) ) ;
mr_Jacobian_cacheDataAsMxArray ( rtdwData , 0 , 37 , ( const void * ) & (
rtDW . kkhkendrtu ) , sizeof ( rtDW . kkhkendrtu ) ) ;
mr_Jacobian_cacheDataAsMxArray ( rtdwData , 0 , 38 , ( const void * ) & (
rtDW . a5bv3potn3 ) , sizeof ( rtDW . a5bv3potn3 ) ) ; mxSetFieldByNumber (
ssDW , 0 , 1 , rtdwData ) ; } return ssDW ; } void mr_Jacobian_SetDWork (
const mxArray * ssDW ) { ( void ) ssDW ; mr_Jacobian_restoreDataFromMxArray (
( void * ) & ( rtB ) , ssDW , 0 , 0 , sizeof ( rtB ) ) ; { const mxArray *
rtdwData = mxGetFieldByNumber ( ssDW , 0 , 1 ) ;
mr_Jacobian_restoreDataFromMxArray ( ( void * ) & ( rtDW . h50oa4paoh ) ,
rtdwData , 0 , 0 , sizeof ( rtDW . h50oa4paoh ) ) ;
mr_Jacobian_restoreDataFromMxArray ( ( void * ) & ( rtDW . au4tbeh3wp ) ,
rtdwData , 0 , 1 , sizeof ( rtDW . au4tbeh3wp ) ) ;
mr_Jacobian_restoreDataFromMxArray ( ( void * ) & ( rtDW . nbtjvvk0iu ) ,
rtdwData , 0 , 2 , sizeof ( rtDW . nbtjvvk0iu ) ) ;
mr_Jacobian_restoreDataFromMxArray ( ( void * ) & ( rtDW . fymvqkxpsu ) ,
rtdwData , 0 , 3 , sizeof ( rtDW . fymvqkxpsu ) ) ;
mr_Jacobian_restoreDataFromMxArray ( ( void * ) & ( rtDW . j3as2zn3ny ) ,
rtdwData , 0 , 4 , sizeof ( rtDW . j3as2zn3ny ) ) ;
mr_Jacobian_restoreDataFromMxArray ( ( void * ) & ( rtDW . htunnpm4aw ) ,
rtdwData , 0 , 5 , sizeof ( rtDW . htunnpm4aw ) ) ;
mr_Jacobian_restoreDataFromMxArray ( ( void * ) & ( rtDW . btrdhary1n ) ,
rtdwData , 0 , 6 , sizeof ( rtDW . btrdhary1n ) ) ;
mr_Jacobian_restoreDataFromMxArray ( ( void * ) & ( rtDW . jjb3503ojt ) ,
rtdwData , 0 , 7 , sizeof ( rtDW . jjb3503ojt ) ) ;
mr_Jacobian_restoreDataFromMxArray ( ( void * ) & ( rtDW . jmhtlb4kaj ) ,
rtdwData , 0 , 8 , sizeof ( rtDW . jmhtlb4kaj ) ) ;
mr_Jacobian_restoreDataFromMxArray ( ( void * ) & ( rtDW . frbgw4ey21 ) ,
rtdwData , 0 , 9 , sizeof ( rtDW . frbgw4ey21 ) ) ;
mr_Jacobian_restoreDataFromMxArray ( ( void * ) & ( rtDW . oqhsxqjtcq ) ,
rtdwData , 0 , 10 , sizeof ( rtDW . oqhsxqjtcq ) ) ;
mr_Jacobian_restoreDataFromMxArray ( ( void * ) & ( rtDW . o4fw42gm5j ) ,
rtdwData , 0 , 11 , sizeof ( rtDW . o4fw42gm5j ) ) ;
mr_Jacobian_restoreDataFromMxArray ( ( void * ) & ( rtDW . pz4m5n3fa5 ) ,
rtdwData , 0 , 12 , sizeof ( rtDW . pz4m5n3fa5 ) ) ;
mr_Jacobian_restoreDataFromMxArray ( ( void * ) & ( rtDW . a0oc1r2fmm ) ,
rtdwData , 0 , 13 , sizeof ( rtDW . a0oc1r2fmm ) ) ;
mr_Jacobian_restoreDataFromMxArray ( ( void * ) & ( rtDW . ldjhzt1tvv ) ,
rtdwData , 0 , 14 , sizeof ( rtDW . ldjhzt1tvv ) ) ;
mr_Jacobian_restoreDataFromMxArray ( ( void * ) & ( rtDW . ndveltha3i ) ,
rtdwData , 0 , 15 , sizeof ( rtDW . ndveltha3i ) ) ;
mr_Jacobian_restoreDataFromMxArray ( ( void * ) & ( rtDW . apqphginxx ) ,
rtdwData , 0 , 16 , sizeof ( rtDW . apqphginxx ) ) ;
mr_Jacobian_restoreDataFromMxArray ( ( void * ) & ( rtDW . a424fqcnvz ) ,
rtdwData , 0 , 17 , sizeof ( rtDW . a424fqcnvz ) ) ;
mr_Jacobian_restoreDataFromMxArray ( ( void * ) & ( rtDW . iovoxirwro ) ,
rtdwData , 0 , 18 , sizeof ( rtDW . iovoxirwro ) ) ;
mr_Jacobian_restoreDataFromMxArray ( ( void * ) & ( rtDW . coliwj5sya ) ,
rtdwData , 0 , 19 , sizeof ( rtDW . coliwj5sya ) ) ;
mr_Jacobian_restoreDataFromMxArray ( ( void * ) & ( rtDW . fz2ttztfrx ) ,
rtdwData , 0 , 20 , sizeof ( rtDW . fz2ttztfrx ) ) ;
mr_Jacobian_restoreDataFromMxArray ( ( void * ) & ( rtDW . frbywcoc2g ) ,
rtdwData , 0 , 21 , sizeof ( rtDW . frbywcoc2g ) ) ;
mr_Jacobian_restoreDataFromMxArray ( ( void * ) & ( rtDW . df2e0pg2dx ) ,
rtdwData , 0 , 22 , sizeof ( rtDW . df2e0pg2dx ) ) ;
mr_Jacobian_restoreDataFromMxArray ( ( void * ) & ( rtDW . kjdxfgqbzw ) ,
rtdwData , 0 , 23 , sizeof ( rtDW . kjdxfgqbzw ) ) ;
mr_Jacobian_restoreDataFromMxArray ( ( void * ) & ( rtDW . lc4aznzqkp ) ,
rtdwData , 0 , 24 , sizeof ( rtDW . lc4aznzqkp ) ) ;
mr_Jacobian_restoreDataFromMxArray ( ( void * ) & ( rtDW . aq3afxfwxg ) ,
rtdwData , 0 , 25 , sizeof ( rtDW . aq3afxfwxg ) ) ;
mr_Jacobian_restoreDataFromMxArray ( ( void * ) & ( rtDW . oe04kxktvd ) ,
rtdwData , 0 , 26 , sizeof ( rtDW . oe04kxktvd ) ) ;
mr_Jacobian_restoreDataFromMxArray ( ( void * ) & ( rtDW . paf4jizn5q ) ,
rtdwData , 0 , 27 , sizeof ( rtDW . paf4jizn5q ) ) ;
mr_Jacobian_restoreDataFromMxArray ( ( void * ) & ( rtDW . chxdltntn1 ) ,
rtdwData , 0 , 28 , sizeof ( rtDW . chxdltntn1 ) ) ;
mr_Jacobian_restoreDataFromMxArray ( ( void * ) & ( rtDW . lvfg2ialf5 ) ,
rtdwData , 0 , 29 , sizeof ( rtDW . lvfg2ialf5 ) ) ;
mr_Jacobian_restoreDataFromMxArray ( ( void * ) & ( rtDW . fs53o4lsci ) ,
rtdwData , 0 , 30 , sizeof ( rtDW . fs53o4lsci ) ) ;
mr_Jacobian_restoreDataFromMxArray ( ( void * ) & ( rtDW . idgjtzemzw ) ,
rtdwData , 0 , 31 , sizeof ( rtDW . idgjtzemzw ) ) ;
mr_Jacobian_restoreDataFromMxArray ( ( void * ) & ( rtDW . mkp2eepxcj ) ,
rtdwData , 0 , 32 , sizeof ( rtDW . mkp2eepxcj ) ) ;
mr_Jacobian_restoreDataFromMxArray ( ( void * ) & ( rtDW . gmdfw45vlb ) ,
rtdwData , 0 , 33 , sizeof ( rtDW . gmdfw45vlb ) ) ;
mr_Jacobian_restoreDataFromMxArray ( ( void * ) & ( rtDW . cueoevswm1 ) ,
rtdwData , 0 , 34 , sizeof ( rtDW . cueoevswm1 ) ) ;
mr_Jacobian_restoreDataFromMxArray ( ( void * ) & ( rtDW . n1jgscci0o ) ,
rtdwData , 0 , 35 , sizeof ( rtDW . n1jgscci0o ) ) ;
mr_Jacobian_restoreDataFromMxArray ( ( void * ) & ( rtDW . i2pqjw3yac ) ,
rtdwData , 0 , 36 , sizeof ( rtDW . i2pqjw3yac ) ) ;
mr_Jacobian_restoreDataFromMxArray ( ( void * ) & ( rtDW . kkhkendrtu ) ,
rtdwData , 0 , 37 , sizeof ( rtDW . kkhkendrtu ) ) ;
mr_Jacobian_restoreDataFromMxArray ( ( void * ) & ( rtDW . a5bv3potn3 ) ,
rtdwData , 0 , 38 , sizeof ( rtDW . a5bv3potn3 ) ) ; } } mxArray *
mr_Jacobian_GetSimStateDisallowedBlocks ( ) { mxArray * data =
mxCreateCellMatrix ( 10 , 3 ) ; mwIndex subs [ 2 ] , offset ; { static const
char * blockType [ 10 ] = { "SimscapeExecutionBlock" , "Scope" ,
"SimscapeSinkBlock" , "SimscapeExecutionBlock" , "MATLABSystem" ,
"MATLABSystem" , "MATLABSystem" , "MATLABSystem" , "MATLABSystem" ,
"SimscapeExecutionBlock" , } ; static const char * blockPath [ 10 ] = {
"Jacobian/Subsystem/Solver Configuration/EVAL_KEY/OUTPUT_1_0" ,
"Jacobian/Scope" , "Jacobian/Subsystem/Solver Configuration/EVAL_KEY/SINK_1"
, "Jacobian/Subsystem/Solver Configuration/EVAL_KEY/STATE_1" ,
"Jacobian/Coordinate Transformation Conversion" ,
"Jacobian/Get Jacobian/MATLAB System" ,
"Jacobian/Get Transform/MATLAB System" ,
"Jacobian/Inverse Kinematics/MATLAB System" ,
"Jacobian/Polynomial Trajectory" ,
"Jacobian/Subsystem/Solver Configuration/EVAL_KEY/OUTPUT_1_0" , } ; static
const int reason [ 10 ] = { 0 , 0 , 0 , 0 , 6 , 6 , 6 , 6 , 6 , 6 , } ; for (
subs [ 0 ] = 0 ; subs [ 0 ] < 10 ; ++ ( subs [ 0 ] ) ) { subs [ 1 ] = 0 ;
offset = mxCalcSingleSubscript ( data , 2 , subs ) ; mxSetCell ( data ,
offset , mxCreateString ( blockType [ subs [ 0 ] ] ) ) ; subs [ 1 ] = 1 ;
offset = mxCalcSingleSubscript ( data , 2 , subs ) ; mxSetCell ( data ,
offset , mxCreateString ( blockPath [ subs [ 0 ] ] ) ) ; subs [ 1 ] = 2 ;
offset = mxCalcSingleSubscript ( data , 2 , subs ) ; mxSetCell ( data ,
offset , mxCreateDoubleScalar ( ( double ) reason [ subs [ 0 ] ] ) ) ; } }
return data ; } void MdlInitializeSizes ( void ) { ssSetNumContStates ( rtS ,
8 ) ; ssSetNumPeriodicContStates ( rtS , 0 ) ; ssSetNumY ( rtS , 0 ) ;
ssSetNumU ( rtS , 0 ) ; ssSetDirectFeedThrough ( rtS , 0 ) ;
ssSetNumSampleTimes ( rtS , 1 ) ; ssSetNumBlocks ( rtS , 99 ) ;
ssSetNumBlockIO ( rtS , 16 ) ; ssSetNumBlockParams ( rtS , 64 ) ; } void
MdlInitializeSampleTimes ( void ) { ssSetSampleTime ( rtS , 0 , 0.0 ) ;
ssSetOffsetTime ( rtS , 0 , 0.0 ) ; } void raccel_set_checksum ( ) {
ssSetChecksumVal ( rtS , 0 , 2398350275U ) ; ssSetChecksumVal ( rtS , 1 ,
3287781363U ) ; ssSetChecksumVal ( rtS , 2 , 1908459515U ) ; ssSetChecksumVal
( rtS , 3 , 1989708611U ) ; }
#if defined(_MSC_VER)
#pragma optimize( "", off )
#endif
SimStruct * raccel_register_model ( ssExecutionInfo * executionInfo ) {
static struct _ssMdlInfo mdlInfo ; static struct _ssBlkInfo2 blkInfo2 ;
static struct _ssBlkInfoSLSize blkInfoSLSize ; ( void ) memset ( ( char * )
rtS , 0 , sizeof ( SimStruct ) ) ; ( void ) memset ( ( char * ) & mdlInfo , 0
, sizeof ( struct _ssMdlInfo ) ) ; ( void ) memset ( ( char * ) & blkInfo2 ,
0 , sizeof ( struct _ssBlkInfo2 ) ) ; ( void ) memset ( ( char * ) &
blkInfoSLSize , 0 , sizeof ( struct _ssBlkInfoSLSize ) ) ; ssSetBlkInfo2Ptr (
rtS , & blkInfo2 ) ; ssSetBlkInfoSLSizePtr ( rtS , & blkInfoSLSize ) ;
ssSetMdlInfoPtr ( rtS , & mdlInfo ) ; ssSetExecutionInfo ( rtS ,
executionInfo ) ; slsaAllocOPModelData ( rtS ) ; { static time_T mdlPeriod [
NSAMPLE_TIMES ] ; static time_T mdlOffset [ NSAMPLE_TIMES ] ; static time_T
mdlTaskTimes [ NSAMPLE_TIMES ] ; static int_T mdlTsMap [ NSAMPLE_TIMES ] ;
static int_T mdlSampleHits [ NSAMPLE_TIMES ] ; static boolean_T
mdlTNextWasAdjustedPtr [ NSAMPLE_TIMES ] ; static int_T mdlPerTaskSampleHits
[ NSAMPLE_TIMES * NSAMPLE_TIMES ] ; static time_T mdlTimeOfNextSampleHit [
NSAMPLE_TIMES ] ; { int_T i ; for ( i = 0 ; i < NSAMPLE_TIMES ; i ++ ) {
mdlPeriod [ i ] = 0.0 ; mdlOffset [ i ] = 0.0 ; mdlTaskTimes [ i ] = 0.0 ;
mdlTsMap [ i ] = i ; mdlSampleHits [ i ] = 1 ; } } ssSetSampleTimePtr ( rtS ,
& mdlPeriod [ 0 ] ) ; ssSetOffsetTimePtr ( rtS , & mdlOffset [ 0 ] ) ;
ssSetSampleTimeTaskIDPtr ( rtS , & mdlTsMap [ 0 ] ) ; ssSetTPtr ( rtS , &
mdlTaskTimes [ 0 ] ) ; ssSetSampleHitPtr ( rtS , & mdlSampleHits [ 0 ] ) ;
ssSetTNextWasAdjustedPtr ( rtS , & mdlTNextWasAdjustedPtr [ 0 ] ) ;
ssSetPerTaskSampleHitsPtr ( rtS , & mdlPerTaskSampleHits [ 0 ] ) ;
ssSetTimeOfNextSampleHitPtr ( rtS , & mdlTimeOfNextSampleHit [ 0 ] ) ; }
ssSetSolverMode ( rtS , SOLVER_MODE_SINGLETASKING ) ; { ssSetBlockIO ( rtS ,
( ( void * ) & rtB ) ) ; ( void ) memset ( ( ( void * ) & rtB ) , 0 , sizeof
( B ) ) ; } { real_T * x = ( real_T * ) & rtX ; ssSetContStates ( rtS , x ) ;
( void ) memset ( ( void * ) x , 0 , sizeof ( X ) ) ; } { void * dwork = (
void * ) & rtDW ; ssSetRootDWork ( rtS , dwork ) ; ( void ) memset ( dwork ,
0 , sizeof ( DW ) ) ; } { static DataTypeTransInfo dtInfo ; ( void ) memset (
( char_T * ) & dtInfo , 0 , sizeof ( dtInfo ) ) ; ssSetModelMappingInfo ( rtS
, & dtInfo ) ; dtInfo . numDataTypes = 29 ; dtInfo . dataTypeSizes = &
rtDataTypeSizes [ 0 ] ; dtInfo . dataTypeNames = & rtDataTypeNames [ 0 ] ;
dtInfo . BTransTable = & rtBTransTable ; dtInfo . PTransTable = &
rtPTransTable ; dtInfo . dataTypeInfoTable = rtDataTypeInfoTable ; }
Jacobian_InitializeDataMapInfo ( ) ; ssSetIsRapidAcceleratorActive ( rtS ,
true ) ; ssSetRootSS ( rtS , rtS ) ; ssSetVersion ( rtS ,
SIMSTRUCT_VERSION_LEVEL2 ) ; ssSetModelName ( rtS , "Jacobian" ) ; ssSetPath
( rtS , "Jacobian" ) ; ssSetTStart ( rtS , 0.0 ) ; ssSetTFinal ( rtS , 7.0 )
; { static RTWLogInfo rt_DataLoggingInfo ; rt_DataLoggingInfo .
loggingInterval = ( NULL ) ; ssSetRTWLogInfo ( rtS , & rt_DataLoggingInfo ) ;
} { { static int_T rt_LoggedStateWidths [ ] = { 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1
, 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 2 } ; static int_T
rt_LoggedStateNumDimensions [ ] = { 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1
, 1 , 1 , 1 , 1 , 1 , 1 } ; static int_T rt_LoggedStateDimensions [ ] = { 1 ,
1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 2 } ; static
boolean_T rt_LoggedStateIsVarDims [ ] = { 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 ,
0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 } ; static BuiltInDTypeId
rt_LoggedStateDataTypeIds [ ] = { SS_DOUBLE , SS_DOUBLE , SS_DOUBLE ,
SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE ,
SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE ,
SS_DOUBLE , SS_DOUBLE } ; static int_T rt_LoggedStateComplexSignals [ ] = { 0
, 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 } ; static
RTWPreprocessingFcnPtr rt_LoggingStatePreprocessingFcnPtrs [ ] = { ( NULL ) ,
( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) ,
( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) ,
( NULL ) , ( NULL ) } ; static const char_T * rt_LoggedStateLabels [ ] = {
"CSTATE" , "CSTATE" , "CSTATE" , "CSTATE" , "CSTATE" , "CSTATE" , "CSTATE" ,
"CSTATE" , "Discrete" , "FirstOutput" , "Discrete" , "FirstOutput" ,
"Discrete" , "FirstOutput" , "Discrete" , "FirstOutput" , "Discrete" } ;
static const char_T * rt_LoggedStateBlockNames [ ] = {
"Jacobian/Subsystem/Simulink-PS\nConverter1" ,
"Jacobian/Subsystem/Simulink-PS\nConverter1" ,
"Jacobian/Subsystem/Simulink-PS\nConverter" ,
"Jacobian/Subsystem/Simulink-PS\nConverter" ,
"Jacobian/Subsystem/Simulink-PS\nConverter2" ,
"Jacobian/Subsystem/Simulink-PS\nConverter2" ,
"Jacobian/Subsystem/Simulink-PS\nConverter3" ,
"Jacobian/Subsystem/Simulink-PS\nConverter3" ,
"Jacobian/Subsystem/Solver\nConfiguration/EVAL_KEY/INPUT_2_1_1" ,
"Jacobian/Subsystem/Solver\nConfiguration/EVAL_KEY/INPUT_2_1_1" ,
"Jacobian/Subsystem/Solver\nConfiguration/EVAL_KEY/INPUT_1_1_1" ,
"Jacobian/Subsystem/Solver\nConfiguration/EVAL_KEY/INPUT_1_1_1" ,
"Jacobian/Subsystem/Solver\nConfiguration/EVAL_KEY/INPUT_3_1_1" ,
"Jacobian/Subsystem/Solver\nConfiguration/EVAL_KEY/INPUT_3_1_1" ,
"Jacobian/Subsystem/Solver\nConfiguration/EVAL_KEY/INPUT_4_1_1" ,
"Jacobian/Subsystem/Solver\nConfiguration/EVAL_KEY/INPUT_4_1_1" ,
"Jacobian/Subsystem/Solver\nConfiguration/EVAL_KEY/INPUT_5_1_1" } ; static
const char_T * rt_LoggedStateNames [ ] = {
"Jacobian.Subsystem.Simulink_PS_Converter1.outputFiltered_1568672898_0" ,
"Jacobian.Subsystem.Simulink_PS_Converter1.outputFiltered_1568672898_1" ,
"Jacobian.Subsystem.Simulink_PS_Converter.outputFiltered_438335058_0" ,
"Jacobian.Subsystem.Simulink_PS_Converter.outputFiltered_438335058_1" ,
"Jacobian.Subsystem.Simulink_PS_Converter2.outputFiltered_1625302322_0" ,
"Jacobian.Subsystem.Simulink_PS_Converter2.outputFiltered_1625302322_1" ,
"Jacobian.Subsystem.Simulink_PS_Converter3.outputFiltered_3535862050_0" ,
"Jacobian.Subsystem.Simulink_PS_Converter3.outputFiltered_3535862050_1" ,
"Discrete" , "FirstOutput" , "Discrete" , "FirstOutput" , "Discrete" ,
"FirstOutput" , "Discrete" , "FirstOutput" , "Discrete" } ; static boolean_T
rt_LoggedStateCrossMdlRef [ ] = { 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 ,
0 , 0 , 0 , 0 , 0 , 0 } ; static RTWLogDataTypeConvert
rt_RTWLogDataTypeConvert [ ] = { { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 ,
1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } ,
{ 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE ,
SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0
, 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 ,
0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 ,
SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE ,
SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0
, 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 ,
0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 ,
SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE ,
SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0
, 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 ,
0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } } ; static
int_T rt_LoggedStateIdxList [ ] = { 0 , 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 ,
10 , 11 , 12 } ; static RTWLogSignalInfo rt_LoggedStateSignalInfo = { 17 ,
rt_LoggedStateWidths , rt_LoggedStateNumDimensions , rt_LoggedStateDimensions
, rt_LoggedStateIsVarDims , ( NULL ) , ( NULL ) , rt_LoggedStateDataTypeIds ,
rt_LoggedStateComplexSignals , ( NULL ) , rt_LoggingStatePreprocessingFcnPtrs
, { rt_LoggedStateLabels } , ( NULL ) , ( NULL ) , ( NULL ) , {
rt_LoggedStateBlockNames } , { rt_LoggedStateNames } ,
rt_LoggedStateCrossMdlRef , rt_RTWLogDataTypeConvert , rt_LoggedStateIdxList
} ; static void * rt_LoggedStateSignalPtrs [ 17 ] ; rtliSetLogXSignalPtrs (
ssGetRTWLogInfo ( rtS ) , ( LogSignalPtrsType ) rt_LoggedStateSignalPtrs ) ;
rtliSetLogXSignalInfo ( ssGetRTWLogInfo ( rtS ) , & rt_LoggedStateSignalInfo
) ; rt_LoggedStateSignalPtrs [ 0 ] = ( void * ) & rtX . ostptot32c [ 0 ] ;
rt_LoggedStateSignalPtrs [ 1 ] = ( void * ) & rtX . ostptot32c [ 1 ] ;
rt_LoggedStateSignalPtrs [ 2 ] = ( void * ) & rtX . dl0o42unpr [ 0 ] ;
rt_LoggedStateSignalPtrs [ 3 ] = ( void * ) & rtX . dl0o42unpr [ 1 ] ;
rt_LoggedStateSignalPtrs [ 4 ] = ( void * ) & rtX . pycppw2m5m [ 0 ] ;
rt_LoggedStateSignalPtrs [ 5 ] = ( void * ) & rtX . pycppw2m5m [ 1 ] ;
rt_LoggedStateSignalPtrs [ 6 ] = ( void * ) & rtX . i4uxujxgss [ 0 ] ;
rt_LoggedStateSignalPtrs [ 7 ] = ( void * ) & rtX . i4uxujxgss [ 1 ] ;
rt_LoggedStateSignalPtrs [ 8 ] = ( void * ) & rtDW . j3as2zn3ny ;
rt_LoggedStateSignalPtrs [ 9 ] = ( void * ) & rtDW . htunnpm4aw ;
rt_LoggedStateSignalPtrs [ 10 ] = ( void * ) & rtDW . btrdhary1n ;
rt_LoggedStateSignalPtrs [ 11 ] = ( void * ) & rtDW . jjb3503ojt ;
rt_LoggedStateSignalPtrs [ 12 ] = ( void * ) & rtDW . jmhtlb4kaj ;
rt_LoggedStateSignalPtrs [ 13 ] = ( void * ) & rtDW . frbgw4ey21 ;
rt_LoggedStateSignalPtrs [ 14 ] = ( void * ) & rtDW . oqhsxqjtcq ;
rt_LoggedStateSignalPtrs [ 15 ] = ( void * ) & rtDW . o4fw42gm5j ;
rt_LoggedStateSignalPtrs [ 16 ] = ( void * ) rtDW . pz4m5n3fa5 ; }
rtliSetLogT ( ssGetRTWLogInfo ( rtS ) , "tout" ) ; rtliSetLogX (
ssGetRTWLogInfo ( rtS ) , "" ) ; rtliSetLogXFinal ( ssGetRTWLogInfo ( rtS ) ,
"xFinal" ) ; rtliSetLogVarNameModifier ( ssGetRTWLogInfo ( rtS ) , "none" ) ;
rtliSetLogFormat ( ssGetRTWLogInfo ( rtS ) , 4 ) ; rtliSetLogMaxRows (
ssGetRTWLogInfo ( rtS ) , 0 ) ; rtliSetLogDecimation ( ssGetRTWLogInfo ( rtS
) , 1 ) ; rtliSetLogY ( ssGetRTWLogInfo ( rtS ) , "" ) ;
rtliSetLogYSignalInfo ( ssGetRTWLogInfo ( rtS ) , ( NULL ) ) ;
rtliSetLogYSignalPtrs ( ssGetRTWLogInfo ( rtS ) , ( NULL ) ) ; } { static
struct _ssStatesInfo2 statesInfo2 ; ssSetStatesInfo2 ( rtS , & statesInfo2 )
; } { static ssPeriodicStatesInfo periodicStatesInfo ;
ssSetPeriodicStatesInfo ( rtS , & periodicStatesInfo ) ; } { static
ssJacobianPerturbationBounds jacobianPerturbationBounds ;
ssSetJacobianPerturbationBounds ( rtS , & jacobianPerturbationBounds ) ; } {
static ssSolverInfo slvrInfo ; static boolean_T contStatesDisabled [ 8 ] ;
static real_T absTol [ 8 ] = { 1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 ,
1.0E-6 , 1.0E-6 , 1.0E-6 } ; static uint8_T absTolControl [ 8 ] = { 0U , 0U ,
0U , 0U , 0U , 0U , 0U , 0U } ; static real_T contStateJacPerturbBoundMinVec
[ 8 ] ; static real_T contStateJacPerturbBoundMaxVec [ 8 ] ; { int i ; for (
i = 0 ; i < 8 ; ++ i ) { contStateJacPerturbBoundMinVec [ i ] = 0 ;
contStateJacPerturbBoundMaxVec [ i ] = rtGetInf ( ) ; } } ssSetSolverRelTol (
rtS , 0.001 ) ; ssSetStepSize ( rtS , 0.0 ) ; ssSetMinStepSize ( rtS , 0.0 )
; ssSetMaxNumMinSteps ( rtS , - 1 ) ; ssSetMinStepViolatedError ( rtS , 0 ) ;
ssSetMaxStepSize ( rtS , 0.14 ) ; ssSetSolverMaxOrder ( rtS , - 1 ) ;
ssSetSolverRefineFactor ( rtS , 1 ) ; ssSetOutputTimes ( rtS , ( NULL ) ) ;
ssSetNumOutputTimes ( rtS , 0 ) ; ssSetOutputTimesOnly ( rtS , 0 ) ;
ssSetOutputTimesIndex ( rtS , 0 ) ; ssSetZCCacheNeedsReset ( rtS , 0 ) ;
ssSetDerivCacheNeedsReset ( rtS , 0 ) ; ssSetNumNonContDerivSigInfos ( rtS ,
0 ) ; ssSetNonContDerivSigInfos ( rtS , ( NULL ) ) ; ssSetSolverInfo ( rtS ,
& slvrInfo ) ; ssSetSolverName ( rtS , "VariableStepAuto" ) ;
ssSetVariableStepSolver ( rtS , 1 ) ; ssSetSolverConsistencyChecking ( rtS ,
0 ) ; ssSetSolverAdaptiveZcDetection ( rtS , 0 ) ;
ssSetSolverRobustResetMethod ( rtS , 0 ) ; ssSetAbsTolVector ( rtS , absTol )
; ssSetAbsTolControlVector ( rtS , absTolControl ) ;
ssSetSolverAbsTol_Obsolete ( rtS , absTol ) ;
ssSetSolverAbsTolControl_Obsolete ( rtS , absTolControl ) ;
ssSetJacobianPerturbationBoundsMinVec ( rtS , contStateJacPerturbBoundMinVec
) ; ssSetJacobianPerturbationBoundsMaxVec ( rtS ,
contStateJacPerturbBoundMaxVec ) ; ssSetSolverStateProjection ( rtS , 0 ) ;
ssSetSolverMassMatrixType ( rtS , ( ssMatrixType ) 0 ) ;
ssSetSolverMassMatrixNzMax ( rtS , 0 ) ; ssSetModelOutputs ( rtS , MdlOutputs
) ; ssSetModelLogData ( rtS , rt_UpdateTXYLogVars ) ;
ssSetModelLogDataIfInInterval ( rtS , rt_UpdateTXXFYLogVars ) ;
ssSetModelUpdate ( rtS , MdlUpdate ) ; ssSetModelDerivatives ( rtS ,
MdlDerivatives ) ; ssSetSolverMaxConsecutiveMinStep ( rtS , 1 ) ;
ssSetSolverShapePreserveControl ( rtS , 2 ) ; ssSetTNextTid ( rtS , INT_MIN )
; ssSetTNext ( rtS , rtMinusInf ) ; ssSetSolverNeedsReset ( rtS ) ;
ssSetNumNonsampledZCs ( rtS , 0 ) ; ssSetContStateDisabled ( rtS ,
contStatesDisabled ) ; ssSetSolverMaxConsecutiveMinStep ( rtS , 1 ) ; }
ssSetChecksumVal ( rtS , 0 , 2398350275U ) ; ssSetChecksumVal ( rtS , 1 ,
3287781363U ) ; ssSetChecksumVal ( rtS , 2 , 1908459515U ) ; ssSetChecksumVal
( rtS , 3 , 1989708611U ) ; { static const sysRanDType rtAlwaysEnabled =
SUBSYS_RAN_BC_ENABLE ; static RTWExtModeInfo rt_ExtModeInfo ; static const
sysRanDType * systemRan [ 6 ] ; gblRTWExtModeInfo = & rt_ExtModeInfo ;
ssSetRTWExtModeInfo ( rtS , & rt_ExtModeInfo ) ;
rteiSetSubSystemActiveVectorAddresses ( & rt_ExtModeInfo , systemRan ) ;
systemRan [ 0 ] = & rtAlwaysEnabled ; systemRan [ 1 ] = & rtAlwaysEnabled ;
systemRan [ 2 ] = & rtAlwaysEnabled ; systemRan [ 3 ] = & rtAlwaysEnabled ;
systemRan [ 4 ] = & rtAlwaysEnabled ; systemRan [ 5 ] = & rtAlwaysEnabled ;
rteiSetModelMappingInfoPtr ( ssGetRTWExtModeInfo ( rtS ) , &
ssGetModelMappingInfo ( rtS ) ) ; rteiSetChecksumsPtr ( ssGetRTWExtModeInfo (
rtS ) , ssGetChecksums ( rtS ) ) ; rteiSetTPtr ( ssGetRTWExtModeInfo ( rtS )
, ssGetTPtr ( rtS ) ) ; } slsaDisallowedBlocksForSimTargetOP ( rtS ,
mr_Jacobian_GetSimStateDisallowedBlocks ) ; slsaGetWorkFcnForSimTargetOP (
rtS , mr_Jacobian_GetDWork ) ; slsaSetWorkFcnForSimTargetOP ( rtS ,
mr_Jacobian_SetDWork ) ; rt_RapidReadMatFileAndUpdateParams ( rtS ) ; if (
ssGetErrorStatus ( rtS ) ) { return rtS ; } return rtS ; }
#if defined(_MSC_VER)
#pragma optimize( "", on )
#endif
const int_T gblParameterTuningTid = 1 ; void MdlOutputsParameterSampleTime (
int_T tid ) { MdlOutputsTID1 ( tid ) ; }
