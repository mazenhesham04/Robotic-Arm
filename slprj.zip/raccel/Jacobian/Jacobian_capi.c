#include "rtw_capi.h"
#ifdef HOST_CAPI_BUILD
#include "Jacobian_capi_host.h"
#define sizeof(s) ((size_t)(0xFFFF))
#undef rt_offsetof
#define rt_offsetof(s,el) ((uint16_T)(0xFFFF))
#define TARGET_CONST
#define TARGET_STRING(s) (s)
#ifndef SS_UINT64
#define SS_UINT64 24
#endif
#ifndef SS_INT64
#define SS_INT64 25
#endif
#else
#include "builtin_typeid_types.h"
#include "Jacobian.h"
#include "Jacobian_capi.h"
#include "Jacobian_private.h"
#ifdef LIGHT_WEIGHT_CAPI
#define TARGET_CONST
#define TARGET_STRING(s)               ((NULL))
#else
#define TARGET_CONST                   const
#define TARGET_STRING(s)               (s)
#endif
#endif
static const rtwCAPI_Signals rtBlockSignals [ ] = { { 0 , 0 , TARGET_STRING (
"Jacobian/MatrixMultiply" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , {
1 , 5 , TARGET_STRING ( "Jacobian/Polynomial Trajectory" ) , TARGET_STRING (
"" ) , 1 , 0 , 1 , 0 , 0 } , { 2 , 5 , TARGET_STRING (
"Jacobian/Polynomial Trajectory" ) , TARGET_STRING ( "" ) , 2 , 0 , 1 , 0 , 0
} , { 3 , 2 , TARGET_STRING ( "Jacobian/Get Jacobian/MATLAB System" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 2 , 0 , 0 } , { 4 , 3 , TARGET_STRING (
"Jacobian/Get Transform/MATLAB System" ) , TARGET_STRING ( "" ) , 0 , 0 , 3 ,
0 , 0 } , { 5 , 4 , TARGET_STRING (
"Jacobian/Inverse Kinematics/MATLAB System" ) , TARGET_STRING ( "" ) , 0 , 0
, 4 , 0 , 0 } , { 6 , 0 , TARGET_STRING ( "Jacobian/Radians to Degrees/Gain"
) , TARGET_STRING ( "" ) , 0 , 0 , 4 , 0 , 0 } , { 7 , 0 , TARGET_STRING (
"Jacobian/Subsystem/PS-Simulink Converter12/EVAL_KEY/RESHAPE" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 5 , 0 , 0 } , { 8 , 0 , TARGET_STRING (
"Jacobian/Subsystem/PS-Simulink Converter13/EVAL_KEY/RESHAPE" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 5 , 0 , 0 } , { 9 , 0 , TARGET_STRING (
"Jacobian/Subsystem/PS-Simulink Converter14/EVAL_KEY/RESHAPE" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 5 , 0 , 0 } , { 10 , 0 , TARGET_STRING (
"Jacobian/Subsystem/PS-Simulink Converter15/EVAL_KEY/RESHAPE" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 5 , 0 , 0 } , { 11 , 0 , TARGET_STRING (
"Jacobian/Subsystem/Solver Configuration/EVAL_KEY/INPUT_1_1_1" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 6 , 0 , 0 } , { 12 , 0 , TARGET_STRING (
"Jacobian/Subsystem/Solver Configuration/EVAL_KEY/INPUT_2_1_1" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 6 , 0 , 0 } , { 13 , 0 , TARGET_STRING (
"Jacobian/Subsystem/Solver Configuration/EVAL_KEY/INPUT_3_1_1" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 6 , 0 , 0 } , { 14 , 0 , TARGET_STRING (
"Jacobian/Subsystem/Solver Configuration/EVAL_KEY/INPUT_4_1_1" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 6 , 0 , 0 } , { 15 , 0 , TARGET_STRING (
"Jacobian/Subsystem/Solver Configuration/EVAL_KEY/INPUT_5_1_1" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 6 , 0 , 0 } , { 0 , 0 , ( NULL ) , ( NULL ) ,
0 , 0 , 0 , 0 , 0 } } ; static const rtwCAPI_BlockParameters
rtBlockParameters [ ] = { { 16 , TARGET_STRING ( "Jacobian/Constant1" ) ,
TARGET_STRING ( "Value" ) , 0 , 7 , 0 } , { 17 , TARGET_STRING (
"Jacobian/Constant2" ) , TARGET_STRING ( "Value" ) , 0 , 8 , 0 } , { 18 ,
TARGET_STRING ( "Jacobian/Constant3" ) , TARGET_STRING ( "Value" ) , 0 , 5 ,
0 } , { 19 , TARGET_STRING ( "Jacobian/Constant4" ) , TARGET_STRING ( "Value"
) , 0 , 5 , 0 } , { 20 , TARGET_STRING ( "Jacobian/Polynomial Trajectory" ) ,
TARGET_STRING ( "Waypoints" ) , 0 , 9 , 0 } , { 21 , TARGET_STRING (
"Jacobian/Polynomial Trajectory" ) , TARGET_STRING ( "TimePoints" ) , 0 , 10
, 0 } , { 22 , TARGET_STRING ( "Jacobian/Polynomial Trajectory" ) ,
TARGET_STRING ( "VelocityBoundaryCondition" ) , 0 , 9 , 0 } , { 23 ,
TARGET_STRING ( "Jacobian/Radians to Degrees/Gain" ) , TARGET_STRING ( "Gain"
) , 0 , 5 , 0 } , { 24 , TARGET_STRING ( "Jacobian/Subsystem/Constant" ) ,
TARGET_STRING ( "Value" ) , 0 , 5 , 0 } , { 0 , ( NULL ) , ( NULL ) , 0 , 0 ,
0 } } ; static int_T rt_LoggedStateIdxList [ ] = { - 1 } ; static const
rtwCAPI_Signals rtRootInputs [ ] = { { 0 , 0 , ( NULL ) , ( NULL ) , 0 , 0 ,
0 , 0 , 0 } } ; static const rtwCAPI_Signals rtRootOutputs [ ] = { { 0 , 0 ,
( NULL ) , ( NULL ) , 0 , 0 , 0 , 0 , 0 } } ; static const
rtwCAPI_ModelParameters rtModelParameters [ ] = { { 0 , ( NULL ) , 0 , 0 , 0
} } ;
#ifndef HOST_CAPI_BUILD
static void * rtDataAddrMap [ ] = { & rtB . aqvrlbktfx [ 0 ] , & rtB .
jduggdofo3 [ 0 ] , & rtB . pwxyrrsugo [ 0 ] , & rtB . olngjflg0n [ 0 ] , &
rtB . mubufhmikb [ 0 ] , & rtB . kocxhnfx4g [ 0 ] , & rtB . g0n3japp2o [ 0 ]
, & rtB . evts0truna , & rtB . oxlbdgveau , & rtB . gtrv14nqvd , & rtB .
cnntouejof , & rtB . jrnj3m5jkq [ 0 ] , & rtB . g35gtlfojh [ 0 ] , & rtB .
mxjei2s3ub [ 0 ] , & rtB . d4sufxfyw0 [ 0 ] , & rtB . kvi533iz0u [ 0 ] , &
rtP . Constant1_Value [ 0 ] , & rtP . Constant2_Value [ 0 ] , & rtP .
Constant3_Value , & rtP . Constant4_Value , & rtP .
PolynomialTrajectory_Waypoints [ 0 ] , & rtP .
PolynomialTrajectory_TimePoints [ 0 ] , & rtP .
PolynomialTrajectory_VelocityBoundaryCondition [ 0 ] , & rtP . Gain_Gain , &
rtP . Constant_Value , } ; static int32_T * rtVarDimsAddrMap [ ] = { ( NULL )
} ;
#endif
static TARGET_CONST rtwCAPI_DataTypeMap rtDataTypeMap [ ] = { { "double" ,
"real_T" , 0 , 0 , sizeof ( real_T ) , ( uint8_T ) SS_DOUBLE , 0 , 0 , 0 } }
;
#ifdef HOST_CAPI_BUILD
#undef sizeof
#endif
static TARGET_CONST rtwCAPI_ElementMap rtElementMap [ ] = { { ( NULL ) , 0 ,
0 , 0 , 0 } , } ; static const rtwCAPI_DimensionMap rtDimensionMap [ ] = { {
rtwCAPI_VECTOR , 0 , 2 , 0 } , { rtwCAPI_MATRIX_COL_MAJOR , 2 , 2 , 0 } , {
rtwCAPI_MATRIX_COL_MAJOR , 4 , 2 , 0 } , { rtwCAPI_MATRIX_COL_MAJOR , 6 , 2 ,
0 } , { rtwCAPI_MATRIX_COL_MAJOR , 8 , 2 , 0 } , { rtwCAPI_SCALAR , 10 , 2 ,
0 } , { rtwCAPI_VECTOR , 12 , 2 , 0 } , { rtwCAPI_VECTOR , 14 , 2 , 0 } , {
rtwCAPI_VECTOR , 16 , 2 , 0 } , { rtwCAPI_MATRIX_COL_MAJOR , 18 , 2 , 0 } , {
rtwCAPI_VECTOR , 20 , 2 , 0 } } ; static const uint_T rtDimensionArray [ ] =
{ 6 , 1 , 3 , 1 , 6 , 5 , 4 , 4 , 5 , 1 , 1 , 1 , 4 , 1 , 1 , 6 , 1 , 5 , 3 ,
7 , 1 , 7 } ; static const real_T rtcapiStoredFloats [ ] = { 0.0 } ; static
const rtwCAPI_FixPtMap rtFixPtMap [ ] = { { ( NULL ) , ( NULL ) ,
rtwCAPI_FIX_RESERVED , 0 , 0 , ( boolean_T ) 0 } , } ; static const
rtwCAPI_SampleTimeMap rtSampleTimeMap [ ] = { { ( const void * ) &
rtcapiStoredFloats [ 0 ] , ( const void * ) & rtcapiStoredFloats [ 0 ] , (
int8_T ) 0 , ( uint8_T ) 0 } } ; static rtwCAPI_ModelMappingStaticInfo
mmiStatic = { { rtBlockSignals , 16 , rtRootInputs , 0 , rtRootOutputs , 0 }
, { rtBlockParameters , 9 , rtModelParameters , 0 } , { ( NULL ) , 0 } , {
rtDataTypeMap , rtDimensionMap , rtFixPtMap , rtElementMap , rtSampleTimeMap
, rtDimensionArray } , "float" , { 2398350275U , 3287781363U , 1908459515U ,
1989708611U } , ( NULL ) , 0 , ( boolean_T ) 0 , rt_LoggedStateIdxList } ;
const rtwCAPI_ModelMappingStaticInfo * Jacobian_GetCAPIStaticMap ( void ) {
return & mmiStatic ; }
#ifndef HOST_CAPI_BUILD
void Jacobian_InitializeDataMapInfo ( void ) { rtwCAPI_SetVersion ( ( *
rt_dataMapInfoPtr ) . mmi , 1 ) ; rtwCAPI_SetStaticMap ( ( *
rt_dataMapInfoPtr ) . mmi , & mmiStatic ) ; rtwCAPI_SetLoggingStaticMap ( ( *
rt_dataMapInfoPtr ) . mmi , ( NULL ) ) ; rtwCAPI_SetDataAddressMap ( ( *
rt_dataMapInfoPtr ) . mmi , rtDataAddrMap ) ; rtwCAPI_SetVarDimsAddressMap (
( * rt_dataMapInfoPtr ) . mmi , rtVarDimsAddrMap ) ;
rtwCAPI_SetInstanceLoggingInfo ( ( * rt_dataMapInfoPtr ) . mmi , ( NULL ) ) ;
rtwCAPI_SetChildMMIArray ( ( * rt_dataMapInfoPtr ) . mmi , ( NULL ) ) ;
rtwCAPI_SetChildMMIArrayLen ( ( * rt_dataMapInfoPtr ) . mmi , 0 ) ; }
#else
#ifdef __cplusplus
extern "C" {
#endif
void Jacobian_host_InitializeDataMapInfo ( Jacobian_host_DataMapInfo_T *
dataMap , const char * path ) { rtwCAPI_SetVersion ( dataMap -> mmi , 1 ) ;
rtwCAPI_SetStaticMap ( dataMap -> mmi , & mmiStatic ) ;
rtwCAPI_SetDataAddressMap ( dataMap -> mmi , ( NULL ) ) ;
rtwCAPI_SetVarDimsAddressMap ( dataMap -> mmi , ( NULL ) ) ; rtwCAPI_SetPath
( dataMap -> mmi , path ) ; rtwCAPI_SetFullPath ( dataMap -> mmi , ( NULL ) )
; rtwCAPI_SetChildMMIArray ( dataMap -> mmi , ( NULL ) ) ;
rtwCAPI_SetChildMMIArrayLen ( dataMap -> mmi , 0 ) ; }
#ifdef __cplusplus
}
#endif
#endif
