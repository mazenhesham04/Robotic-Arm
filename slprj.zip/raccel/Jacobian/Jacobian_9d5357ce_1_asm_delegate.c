#include <math.h>
#include <string.h>
#include "pm_std.h"
#include "sm_std.h"
#include "ne_std.h"
#include "ne_dae.h"
#include "sm_ssci_run_time_errors.h"
#include "sm_RuntimeDerivedValuesBundle.h"
#include "sm_CTarget.h"
void Jacobian_9d5357ce_1_setTargets ( const RuntimeDerivedValuesBundle * rtdv
, CTarget * targets ) { ( void ) rtdv ; ( void ) targets ; } void
Jacobian_9d5357ce_1_resetAsmStateVector ( const void * mech , double * state
) { double xx [ 1 ] ; ( void ) mech ; xx [ 0 ] = 0.0 ; state [ 0 ] = xx [ 0 ]
; state [ 1 ] = xx [ 0 ] ; state [ 2 ] = xx [ 0 ] ; state [ 3 ] = xx [ 0 ] ;
state [ 4 ] = xx [ 0 ] ; state [ 5 ] = xx [ 0 ] ; state [ 6 ] = xx [ 0 ] ;
state [ 7 ] = xx [ 0 ] ; state [ 8 ] = xx [ 0 ] ; state [ 9 ] = xx [ 0 ] ; }
void Jacobian_9d5357ce_1_initializeTrackedAngleState ( const void * mech ,
const RuntimeDerivedValuesBundle * rtdv , const int * modeVector , const
double * motionData , double * state ) { const double * rtdvd = rtdv ->
mDoubles . mValues ; const int * rtdvi = rtdv -> mInts . mValues ; ( void )
mech ; ( void ) rtdvd ; ( void ) rtdvi ; ( void ) state ; ( void ) modeVector
; ( void ) motionData ; } void Jacobian_9d5357ce_1_computeDiscreteState (
const void * mech , const RuntimeDerivedValuesBundle * rtdv , double * state
) { const double * rtdvd = rtdv -> mDoubles . mValues ; const int * rtdvi =
rtdv -> mInts . mValues ; ( void ) mech ; ( void ) rtdvd ; ( void ) rtdvi ; (
void ) state ; } void Jacobian_9d5357ce_1_adjustPosition ( const void * mech
, const double * dofDeltas , double * state ) { ( void ) mech ; state [ 0 ] =
state [ 0 ] + dofDeltas [ 0 ] ; state [ 2 ] = state [ 2 ] + dofDeltas [ 1 ] ;
state [ 4 ] = state [ 4 ] + dofDeltas [ 2 ] ; state [ 6 ] = state [ 6 ] +
dofDeltas [ 3 ] ; state [ 8 ] = state [ 8 ] + dofDeltas [ 4 ] ; } static void
perturbAsmJointPrimitiveState_0_0 ( double mag , double * state ) { state [ 0
] = state [ 0 ] + mag ; } static void perturbAsmJointPrimitiveState_0_0v (
double mag , double * state ) { state [ 0 ] = state [ 0 ] + mag ; state [ 1 ]
= state [ 1 ] - 0.875 * mag ; } static void perturbAsmJointPrimitiveState_1_0
( double mag , double * state ) { state [ 2 ] = state [ 2 ] + mag ; } static
void perturbAsmJointPrimitiveState_1_0v ( double mag , double * state ) {
state [ 2 ] = state [ 2 ] + mag ; state [ 3 ] = state [ 3 ] - 0.875 * mag ; }
static void perturbAsmJointPrimitiveState_2_0 ( double mag , double * state )
{ state [ 4 ] = state [ 4 ] + mag ; } static void
perturbAsmJointPrimitiveState_2_0v ( double mag , double * state ) { state [
4 ] = state [ 4 ] + mag ; state [ 5 ] = state [ 5 ] - 0.875 * mag ; } static
void perturbAsmJointPrimitiveState_3_0 ( double mag , double * state ) {
state [ 6 ] = state [ 6 ] + mag ; } static void
perturbAsmJointPrimitiveState_3_0v ( double mag , double * state ) { state [
6 ] = state [ 6 ] + mag ; state [ 7 ] = state [ 7 ] - 0.875 * mag ; } static
void perturbAsmJointPrimitiveState_4_0 ( double mag , double * state ) {
state [ 8 ] = state [ 8 ] + mag ; } static void
perturbAsmJointPrimitiveState_4_0v ( double mag , double * state ) { state [
8 ] = state [ 8 ] + mag ; state [ 9 ] = state [ 9 ] - 0.875 * mag ; } void
Jacobian_9d5357ce_1_perturbAsmJointPrimitiveState ( const void * mech ,
size_t stageIdx , size_t primIdx , double mag , boolean_T doPerturbVelocity ,
double * state ) { ( void ) mech ; ( void ) stageIdx ; ( void ) primIdx ; (
void ) mag ; ( void ) doPerturbVelocity ; ( void ) state ; switch ( (
stageIdx * 6 + primIdx ) * 2 + ( doPerturbVelocity ? 1 : 0 ) ) { case 0 :
perturbAsmJointPrimitiveState_0_0 ( mag , state ) ; break ; case 1 :
perturbAsmJointPrimitiveState_0_0v ( mag , state ) ; break ; case 12 :
perturbAsmJointPrimitiveState_1_0 ( mag , state ) ; break ; case 13 :
perturbAsmJointPrimitiveState_1_0v ( mag , state ) ; break ; case 24 :
perturbAsmJointPrimitiveState_2_0 ( mag , state ) ; break ; case 25 :
perturbAsmJointPrimitiveState_2_0v ( mag , state ) ; break ; case 36 :
perturbAsmJointPrimitiveState_3_0 ( mag , state ) ; break ; case 37 :
perturbAsmJointPrimitiveState_3_0v ( mag , state ) ; break ; case 48 :
perturbAsmJointPrimitiveState_4_0 ( mag , state ) ; break ; case 49 :
perturbAsmJointPrimitiveState_4_0v ( mag , state ) ; break ; } } void
Jacobian_9d5357ce_1_computePosDofBlendMatrix ( const void * mech , size_t
stageIdx , size_t primIdx , const double * state , int partialType , double *
matrix ) { ( void ) mech ; ( void ) stageIdx ; ( void ) primIdx ; ( void )
state ; ( void ) partialType ; ( void ) matrix ; switch ( ( stageIdx * 6 +
primIdx ) ) { } } void Jacobian_9d5357ce_1_computeVelDofBlendMatrix ( const
void * mech , size_t stageIdx , size_t primIdx , const double * state , int
partialType , double * matrix ) { ( void ) mech ; ( void ) stageIdx ; ( void
) primIdx ; ( void ) state ; ( void ) partialType ; ( void ) matrix ; switch
( ( stageIdx * 6 + primIdx ) ) { } } void
Jacobian_9d5357ce_1_projectPartiallyTargetedPos ( const void * mech , size_t
stageIdx , size_t primIdx , const double * origState , int partialType ,
double * state ) { ( void ) mech ; ( void ) stageIdx ; ( void ) primIdx ; (
void ) origState ; ( void ) partialType ; ( void ) state ; switch ( (
stageIdx * 6 + primIdx ) ) { } } void Jacobian_9d5357ce_1_propagateMotion (
const void * mech , const RuntimeDerivedValuesBundle * rtdv , const double *
state , double * motionData ) { const double * rtdvd = rtdv -> mDoubles .
mValues ; const int * rtdvi = rtdv -> mInts . mValues ; double xx [ 75 ] ; (
void ) mech ; ( void ) rtdvd ; ( void ) rtdvi ; xx [ 0 ] = -
0.9968075318968037 ; xx [ 1 ] = 2.255609827694904e-6 ; xx [ 2 ] = -
3.299863329253583e-7 ; xx [ 3 ] = 0.07984199614617948 ; xx [ 4 ] = 0.5 ; xx [
5 ] = xx [ 4 ] * state [ 0 ] ; xx [ 6 ] = 0.1591742062418632 ; xx [ 7 ] = sin
( xx [ 5 ] ) ; xx [ 8 ] = 0.987250511292612 ; xx [ 9 ] = 4.444124194868948e-6
; xx [ 10 ] = cos ( xx [ 5 ] ) ; xx [ 11 ] = - ( xx [ 6 ] * xx [ 7 ] ) ; xx [
12 ] = xx [ 8 ] * xx [ 7 ] ; xx [ 13 ] = xx [ 9 ] * xx [ 7 ] ;
pm_math_Quaternion_compose_ra ( xx + 0 , xx + 10 , xx + 14 ) ; xx [ 0 ] =
6.756469269377422e-3 ; xx [ 1 ] = - 0.103054783632969 ; xx [ 2 ] = -
5.206905692380579e-7 ; pm_math_Quaternion_xform_ra ( xx + 14 , xx + 0 , xx +
10 ) ; xx [ 0 ] = - 0.07746793516837766 ; xx [ 1 ] = 0.07960137041752086 ; xx
[ 2 ] = - 0.9937926467205985 ; xx [ 3 ] = - 6.206139900867214e-3 ; xx [ 5 ] =
xx [ 4 ] * state [ 2 ] ; xx [ 7 ] = 0.9879205634564509 ; xx [ 13 ] = sin ( xx
[ 5 ] ) ; xx [ 18 ] = 1.884654521777662e-6 ; xx [ 19 ] = 0.1549611573793158 ;
xx [ 20 ] = cos ( xx [ 5 ] ) ; xx [ 21 ] = - ( xx [ 7 ] * xx [ 13 ] ) ; xx [
22 ] = - ( xx [ 18 ] * xx [ 13 ] ) ; xx [ 23 ] = xx [ 19 ] * xx [ 13 ] ;
pm_math_Quaternion_compose_ra ( xx + 0 , xx + 20 , xx + 24 ) ; xx [ 0 ] =
0.1877774726328889 ; xx [ 1 ] = 3.328131052158979e-7 ; xx [ 2 ] = -
0.05231542826632854 ; pm_math_Quaternion_xform_ra ( xx + 24 , xx + 0 , xx +
20 ) ; xx [ 0 ] = - ( 0.05342718524467881 + xx [ 20 ] ) ; xx [ 1 ] =
0.0189206554113088 - xx [ 21 ] ; xx [ 2 ] = 1.632253786240014e-8 - xx [ 22 ]
; xx [ 20 ] = 0.5646178024837725 ; xx [ 21 ] = - 0.5080371901076823 ; xx [ 22
] = - 0.4256843833930758 ; xx [ 23 ] = - 0.4918310241547837 ; xx [ 3 ] = xx [
4 ] * state [ 4 ] ; xx [ 5 ] = 0.9924229712447767 ; xx [ 13 ] = sin ( xx [ 3
] ) ; xx [ 28 ] = 2.98995580305661e-6 ; xx [ 29 ] = 0.1228684098405683 ; xx [
30 ] = cos ( xx [ 3 ] ) ; xx [ 31 ] = - ( xx [ 5 ] * xx [ 13 ] ) ; xx [ 32 ]
= xx [ 28 ] * xx [ 13 ] ; xx [ 33 ] = - ( xx [ 29 ] * xx [ 13 ] ) ;
pm_math_Quaternion_compose_ra ( xx + 20 , xx + 30 , xx + 34 ) ; xx [ 20 ] = -
0.04082308587771714 ; xx [ 21 ] = 1.72520477372018e-7 ; xx [ 22 ] = -
0.02400881023584372 ; pm_math_Quaternion_xform_ra ( xx + 34 , xx + 20 , xx +
30 ) ; xx [ 3 ] = 9.268507096993006e-3 - xx [ 30 ] ; xx [ 13 ] =
2.546368536373208e-7 - xx [ 31 ] ; xx [ 20 ] = 0.1069153331754183 - xx [ 32 ]
; xx [ 30 ] = 5.028122702054597e-7 ; xx [ 31 ] = - 0.9925311081280426 ; xx [
32 ] = 1.347375321216013e-6 ; xx [ 33 ] = - 0.1219918005279538 ; xx [ 21 ] =
xx [ 4 ] * state [ 6 ] ; xx [ 22 ] = 0.1211150960430416 ; xx [ 23 ] = sin (
xx [ 21 ] ) ; xx [ 38 ] = 3.288910678538823e-8 ; xx [ 39 ] =
0.9926384706984133 ; xx [ 40 ] = cos ( xx [ 21 ] ) ; xx [ 41 ] = xx [ 22 ] *
xx [ 23 ] ; xx [ 42 ] = - ( xx [ 38 ] * xx [ 23 ] ) ; xx [ 43 ] = - ( xx [ 39
] * xx [ 23 ] ) ; pm_math_Quaternion_compose_ra ( xx + 30 , xx + 40 , xx + 44
) ; xx [ 30 ] = - 0.02044256463300171 ; xx [ 31 ] = 4.06010237751526e-9 ; xx
[ 32 ] = 0.2255834686598589 ; pm_math_Quaternion_xform_ra ( xx + 44 , xx + 30
, xx + 40 ) ; xx [ 21 ] = 0.01351804099819887 - xx [ 40 ] ; xx [ 23 ] =
6.029877828280862e-8 - xx [ 41 ] ; xx [ 30 ] = - ( 0.05598922408200427 + xx [
42 ] ) ; xx [ 40 ] = 0.5267905997666387 ; xx [ 41 ] = 0.4667055010928088 ; xx
[ 42 ] = 0.4707469087149515 ; xx [ 43 ] = 0.5320479181263028 ; xx [ 31 ] = xx
[ 4 ] * state [ 8 ] ; xx [ 4 ] = 9.20747648943954e-3 ; xx [ 32 ] = sin ( xx [
31 ] ) ; xx [ 33 ] = 4.073584924244647e-5 ; xx [ 48 ] = 0.999957609460165 ;
xx [ 49 ] = cos ( xx [ 31 ] ) ; xx [ 50 ] = xx [ 4 ] * xx [ 32 ] ; xx [ 51 ]
= xx [ 33 ] * xx [ 32 ] ; xx [ 52 ] = - ( xx [ 48 ] * xx [ 32 ] ) ;
pm_math_Quaternion_compose_ra ( xx + 40 , xx + 49 , xx + 53 ) ; xx [ 40 ] = -
2.13144617995885e-4 ; xx [ 41 ] = - 5.622537199868788e-7 ; xx [ 42 ] =
0.02684256075846762 ; pm_math_Quaternion_xform_ra ( xx + 53 , xx + 40 , xx +
49 ) ; xx [ 31 ] = - ( 0.0448782424051596 + xx [ 49 ] ) ; xx [ 32 ] = - (
2.124807382095257e-8 + xx [ 50 ] ) ; xx [ 40 ] = - ( 0.04188909189960371 + xx
[ 51 ] ) ; xx [ 41 ] = - ( xx [ 6 ] * state [ 1 ] ) ; xx [ 6 ] = xx [ 8 ] *
state [ 1 ] ; xx [ 8 ] = xx [ 9 ] * state [ 1 ] ; xx [ 9 ] =
5.606377336525179e-8 * state [ 1 ] ; xx [ 42 ] = 5.285391950416306e-8 * state
[ 1 ] ; xx [ 43 ] = 9.733335643479122e-3 * state [ 1 ] ; xx [ 49 ] = xx [ 41
] ; xx [ 50 ] = xx [ 6 ] ; xx [ 51 ] = xx [ 8 ] ;
pm_math_Quaternion_inverseXform_ra ( xx + 24 , xx + 49 , xx + 57 ) ; xx [ 52
] = xx [ 57 ] - xx [ 7 ] * state [ 3 ] ; xx [ 7 ] = xx [ 58 ] - xx [ 18 ] *
state [ 3 ] ; xx [ 18 ] = xx [ 59 ] + xx [ 19 ] * state [ 3 ] ;
pm_math_Vector3_cross_ra ( xx + 49 , xx + 0 , xx + 57 ) ; xx [ 49 ] = xx [ 57
] + xx [ 9 ] ; xx [ 50 ] = xx [ 58 ] + xx [ 42 ] ; xx [ 51 ] = xx [ 59 ] - xx
[ 43 ] ; pm_math_Quaternion_inverseXform_ra ( xx + 24 , xx + 49 , xx + 57 ) ;
xx [ 19 ] = xx [ 57 ] - 4.702340446561146e-8 * state [ 3 ] ; xx [ 49 ] = xx [
58 ] + 0.02258527288138155 * state [ 3 ] ; xx [ 50 ] = xx [ 59 ] -
2.510275245497444e-8 * state [ 3 ] ; xx [ 57 ] = xx [ 52 ] ; xx [ 58 ] = xx [
7 ] ; xx [ 59 ] = xx [ 18 ] ; pm_math_Quaternion_inverseXform_ra ( xx + 34 ,
xx + 57 , xx + 60 ) ; xx [ 51 ] = xx [ 60 ] - xx [ 5 ] * state [ 5 ] ; xx [ 5
] = xx [ 61 ] + xx [ 28 ] * state [ 5 ] ; xx [ 28 ] = xx [ 62 ] - xx [ 29 ] *
state [ 5 ] ; xx [ 60 ] = xx [ 3 ] ; xx [ 61 ] = xx [ 13 ] ; xx [ 62 ] = xx [
20 ] ; pm_math_Vector3_cross_ra ( xx + 57 , xx + 60 , xx + 63 ) ; xx [ 57 ] =
xx [ 63 ] + xx [ 19 ] ; xx [ 58 ] = xx [ 64 ] + xx [ 49 ] ; xx [ 59 ] = xx [
65 ] + xx [ 50 ] ; pm_math_Quaternion_inverseXform_ra ( xx + 34 , xx + 57 ,
xx + 60 ) ; xx [ 29 ] = xx [ 60 ] + 5.058796476951027e-8 * state [ 5 ] ; xx [
57 ] = xx [ 61 ] + 0.01881102714372797 * state [ 5 ] ; xx [ 58 ] = xx [ 62 ]
+ 4.915406223534665e-8 * state [ 5 ] ; xx [ 59 ] = xx [ 51 ] ; xx [ 60 ] = xx
[ 5 ] ; xx [ 61 ] = xx [ 28 ] ; pm_math_Quaternion_inverseXform_ra ( xx + 44
, xx + 59 , xx + 62 ) ; xx [ 65 ] = xx [ 62 ] + xx [ 22 ] * state [ 7 ] ; xx
[ 22 ] = xx [ 63 ] - xx [ 38 ] * state [ 7 ] ; xx [ 38 ] = xx [ 64 ] - xx [
39 ] * state [ 7 ] ; xx [ 62 ] = xx [ 21 ] ; xx [ 63 ] = xx [ 23 ] ; xx [ 64
] = xx [ 30 ] ; pm_math_Vector3_cross_ra ( xx + 59 , xx + 62 , xx + 66 ) ; xx
[ 59 ] = xx [ 66 ] + xx [ 29 ] ; xx [ 60 ] = xx [ 67 ] + xx [ 57 ] ; xx [ 61
] = xx [ 68 ] + xx [ 58 ] ; pm_math_Quaternion_inverseXform_ra ( xx + 44 , xx
+ 59 , xx + 62 ) ; xx [ 39 ] = xx [ 62 ] + 3.389024974876639e-9 * state [ 7 ]
; xx [ 59 ] = xx [ 63 ] + 7.029487378004986e-3 * state [ 7 ] ; xx [ 60 ] = xx
[ 64 ] + 1.805980017846517e-10 * state [ 7 ] ; xx [ 61 ] = xx [ 65 ] ; xx [
62 ] = xx [ 22 ] ; xx [ 63 ] = xx [ 38 ] ; pm_math_Quaternion_inverseXform_ra
( xx + 53 , xx + 61 , xx + 66 ) ; xx [ 69 ] = xx [ 31 ] ; xx [ 70 ] = xx [ 32
] ; xx [ 71 ] = xx [ 40 ] ; pm_math_Vector3_cross_ra ( xx + 61 , xx + 69 , xx
+ 72 ) ; xx [ 61 ] = xx [ 72 ] + xx [ 39 ] ; xx [ 62 ] = xx [ 73 ] + xx [ 59
] ; xx [ 63 ] = xx [ 74 ] + xx [ 60 ] ; pm_math_Quaternion_inverseXform_ra (
xx + 53 , xx + 61 , xx + 69 ) ; motionData [ 0 ] = xx [ 14 ] ; motionData [ 1
] = xx [ 15 ] ; motionData [ 2 ] = xx [ 16 ] ; motionData [ 3 ] = xx [ 17 ] ;
motionData [ 4 ] = 6.570453024191184e-3 - xx [ 10 ] ; motionData [ 5 ] =
0.04712085191226531 - xx [ 11 ] ; motionData [ 6 ] = 0.01942706586484597 - xx
[ 12 ] ; motionData [ 7 ] = xx [ 24 ] ; motionData [ 8 ] = xx [ 25 ] ;
motionData [ 9 ] = xx [ 26 ] ; motionData [ 10 ] = xx [ 27 ] ; motionData [
11 ] = xx [ 0 ] ; motionData [ 12 ] = xx [ 1 ] ; motionData [ 13 ] = xx [ 2 ]
; motionData [ 14 ] = xx [ 34 ] ; motionData [ 15 ] = xx [ 35 ] ; motionData
[ 16 ] = xx [ 36 ] ; motionData [ 17 ] = xx [ 37 ] ; motionData [ 18 ] = xx [
3 ] ; motionData [ 19 ] = xx [ 13 ] ; motionData [ 20 ] = xx [ 20 ] ;
motionData [ 21 ] = xx [ 44 ] ; motionData [ 22 ] = xx [ 45 ] ; motionData [
23 ] = xx [ 46 ] ; motionData [ 24 ] = xx [ 47 ] ; motionData [ 25 ] = xx [
21 ] ; motionData [ 26 ] = xx [ 23 ] ; motionData [ 27 ] = xx [ 30 ] ;
motionData [ 28 ] = xx [ 53 ] ; motionData [ 29 ] = xx [ 54 ] ; motionData [
30 ] = xx [ 55 ] ; motionData [ 31 ] = xx [ 56 ] ; motionData [ 32 ] = xx [
31 ] ; motionData [ 33 ] = xx [ 32 ] ; motionData [ 34 ] = xx [ 40 ] ;
motionData [ 35 ] = xx [ 41 ] ; motionData [ 36 ] = xx [ 6 ] ; motionData [
37 ] = xx [ 8 ] ; motionData [ 38 ] = xx [ 9 ] ; motionData [ 39 ] = xx [ 42
] ; motionData [ 40 ] = - xx [ 43 ] ; motionData [ 41 ] = xx [ 52 ] ;
motionData [ 42 ] = xx [ 7 ] ; motionData [ 43 ] = xx [ 18 ] ; motionData [
44 ] = xx [ 19 ] ; motionData [ 45 ] = xx [ 49 ] ; motionData [ 46 ] = xx [
50 ] ; motionData [ 47 ] = xx [ 51 ] ; motionData [ 48 ] = xx [ 5 ] ;
motionData [ 49 ] = xx [ 28 ] ; motionData [ 50 ] = xx [ 29 ] ; motionData [
51 ] = xx [ 57 ] ; motionData [ 52 ] = xx [ 58 ] ; motionData [ 53 ] = xx [
65 ] ; motionData [ 54 ] = xx [ 22 ] ; motionData [ 55 ] = xx [ 38 ] ;
motionData [ 56 ] = xx [ 39 ] ; motionData [ 57 ] = xx [ 59 ] ; motionData [
58 ] = xx [ 60 ] ; motionData [ 59 ] = xx [ 66 ] + xx [ 4 ] * state [ 9 ] ;
motionData [ 60 ] = xx [ 67 ] + xx [ 33 ] * state [ 9 ] ; motionData [ 61 ] =
xx [ 68 ] - xx [ 48 ] * state [ 9 ] ; motionData [ 62 ] = xx [ 69 ] -
5.312246225899824e-7 * state [ 9 ] ; motionData [ 63 ] = xx [ 70 ] +
3.401666441947787e-5 * state [ 9 ] ; motionData [ 64 ] = xx [ 71 ] -
3.505689117640104e-9 * state [ 9 ] ; } size_t
Jacobian_9d5357ce_1_computeAssemblyError ( const void * mech , const
RuntimeDerivedValuesBundle * rtdv , size_t constraintIdx , const int *
modeVector , const double * motionData , double * error ) { ( void ) mech ; (
void ) rtdv ; ( void ) modeVector ; ( void ) motionData ; ( void ) error ;
switch ( constraintIdx ) { } return 0 ; } size_t
Jacobian_9d5357ce_1_computeAssemblyJacobian ( const void * mech , const
RuntimeDerivedValuesBundle * rtdv , size_t constraintIdx , boolean_T
forVelocitySatisfaction , const double * state , const int * modeVector ,
const double * motionData , double * J ) { ( void ) mech ; ( void ) rtdv ; (
void ) state ; ( void ) modeVector ; ( void ) forVelocitySatisfaction ; (
void ) motionData ; ( void ) J ; switch ( constraintIdx ) { } return 0 ; }
size_t Jacobian_9d5357ce_1_computeFullAssemblyJacobian ( const void * mech ,
const RuntimeDerivedValuesBundle * rtdv , const double * state , const int *
modeVector , const double * motionData , double * J ) { const double * rtdvd
= rtdv -> mDoubles . mValues ; const int * rtdvi = rtdv -> mInts . mValues ;
( void ) mech ; ( void ) rtdvd ; ( void ) rtdvi ; ( void ) state ; ( void )
modeVector ; ( void ) motionData ; ( void ) J ; return 0 ; } boolean_T
Jacobian_9d5357ce_1_isInKinematicSingularity ( const void * mech , const
RuntimeDerivedValuesBundle * rtdv , size_t constraintIdx , const int *
modeVector , const double * motionData ) { ( void ) mech ; ( void ) rtdv ; (
void ) modeVector ; ( void ) motionData ; switch ( constraintIdx ) { } return
0 ; } void Jacobian_9d5357ce_1_convertStateVector ( const void * asmMech ,
const RuntimeDerivedValuesBundle * rtdv , const void * simMech , const double
* asmState , const int * asmModeVector , const int * simModeVector , double *
simState ) { const double * rtdvd = rtdv -> mDoubles . mValues ; const int *
rtdvi = rtdv -> mInts . mValues ; ( void ) asmMech ; ( void ) rtdvd ; ( void
) rtdvi ; ( void ) simMech ; ( void ) asmModeVector ; ( void ) simModeVector
; simState [ 0 ] = asmState [ 0 ] ; simState [ 1 ] = asmState [ 1 ] ;
simState [ 2 ] = asmState [ 2 ] ; simState [ 3 ] = asmState [ 3 ] ; simState
[ 4 ] = asmState [ 4 ] ; simState [ 5 ] = asmState [ 5 ] ; simState [ 6 ] =
asmState [ 6 ] ; simState [ 7 ] = asmState [ 7 ] ; simState [ 8 ] = asmState
[ 8 ] ; simState [ 9 ] = asmState [ 9 ] ; }
