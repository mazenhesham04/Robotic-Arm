    function targMap = targDataMap(),

    ;%***********************
    ;% Create Parameter Map *
    ;%***********************
    
        nTotData      = 0; %add to this count as we go
        nTotSects     = 1;
        sectIdxOffset = 0;

        ;%
        ;% Define dummy sections & preallocate arrays
        ;%
        dumSection.nData = -1;
        dumSection.data  = [];

        dumData.logicalSrcIdx = -1;
        dumData.dtTransOffset = -1;

        ;%
        ;% Init/prealloc paramMap
        ;%
        paramMap.nSections           = nTotSects;
        paramMap.sectIdxOffset       = sectIdxOffset;
            paramMap.sections(nTotSects) = dumSection; %prealloc
        paramMap.nTotData            = -1;

        ;%
        ;% Auto data (rtP)
        ;%
            section.nData     = 9;
            section.data(9)  = dumData; %prealloc

                    ;% rtP.PolynomialTrajectory_Waypoints
                    section.data(1).logicalSrcIdx = 0;
                    section.data(1).dtTransOffset = 0;

                    ;% rtP.PolynomialTrajectory_TimePoints
                    section.data(2).logicalSrcIdx = 1;
                    section.data(2).dtTransOffset = 21;

                    ;% rtP.PolynomialTrajectory_VelocityBoundaryCondition
                    section.data(3).logicalSrcIdx = 2;
                    section.data(3).dtTransOffset = 28;

                    ;% rtP.Gain_Gain
                    section.data(4).logicalSrcIdx = 3;
                    section.data(4).dtTransOffset = 49;

                    ;% rtP.Constant1_Value
                    section.data(5).logicalSrcIdx = 4;
                    section.data(5).dtTransOffset = 50;

                    ;% rtP.Constant2_Value
                    section.data(6).logicalSrcIdx = 5;
                    section.data(6).dtTransOffset = 56;

                    ;% rtP.Constant3_Value
                    section.data(7).logicalSrcIdx = 6;
                    section.data(7).dtTransOffset = 61;

                    ;% rtP.Constant4_Value
                    section.data(8).logicalSrcIdx = 7;
                    section.data(8).dtTransOffset = 62;

                    ;% rtP.Constant_Value
                    section.data(9).logicalSrcIdx = 8;
                    section.data(9).dtTransOffset = 63;

            nTotData = nTotData + section.nData;
            paramMap.sections(1) = section;
            clear section


            ;%
            ;% Non-auto Data (parameter)
            ;%


        ;%
        ;% Add final counts to struct.
        ;%
        paramMap.nTotData = nTotData;



    ;%**************************
    ;% Create Block Output Map *
    ;%**************************
    
        nTotData      = 0; %add to this count as we go
        nTotSects     = 1;
        sectIdxOffset = 0;

        ;%
        ;% Define dummy sections & preallocate arrays
        ;%
        dumSection.nData = -1;
        dumSection.data  = [];

        dumData.logicalSrcIdx = -1;
        dumData.dtTransOffset = -1;

        ;%
        ;% Init/prealloc sigMap
        ;%
        sigMap.nSections           = nTotSects;
        sigMap.sectIdxOffset       = sectIdxOffset;
            sigMap.sections(nTotSects) = dumSection; %prealloc
        sigMap.nTotData            = -1;

        ;%
        ;% Auto data (rtB)
        ;%
            section.nData     = 16;
            section.data(16)  = dumData; %prealloc

                    ;% rtB.g35gtlfojh
                    section.data(1).logicalSrcIdx = 0;
                    section.data(1).dtTransOffset = 0;

                    ;% rtB.jrnj3m5jkq
                    section.data(2).logicalSrcIdx = 1;
                    section.data(2).dtTransOffset = 4;

                    ;% rtB.mxjei2s3ub
                    section.data(3).logicalSrcIdx = 2;
                    section.data(3).dtTransOffset = 8;

                    ;% rtB.d4sufxfyw0
                    section.data(4).logicalSrcIdx = 3;
                    section.data(4).dtTransOffset = 12;

                    ;% rtB.kvi533iz0u
                    section.data(5).logicalSrcIdx = 4;
                    section.data(5).dtTransOffset = 16;

                    ;% rtB.aqvrlbktfx
                    section.data(6).logicalSrcIdx = 5;
                    section.data(6).dtTransOffset = 20;

                    ;% rtB.g0n3japp2o
                    section.data(7).logicalSrcIdx = 6;
                    section.data(7).dtTransOffset = 26;

                    ;% rtB.evts0truna
                    section.data(8).logicalSrcIdx = 7;
                    section.data(8).dtTransOffset = 31;

                    ;% rtB.oxlbdgveau
                    section.data(9).logicalSrcIdx = 8;
                    section.data(9).dtTransOffset = 32;

                    ;% rtB.gtrv14nqvd
                    section.data(10).logicalSrcIdx = 9;
                    section.data(10).dtTransOffset = 33;

                    ;% rtB.cnntouejof
                    section.data(11).logicalSrcIdx = 10;
                    section.data(11).dtTransOffset = 34;

                    ;% rtB.jduggdofo3
                    section.data(12).logicalSrcIdx = 11;
                    section.data(12).dtTransOffset = 35;

                    ;% rtB.pwxyrrsugo
                    section.data(13).logicalSrcIdx = 12;
                    section.data(13).dtTransOffset = 38;

                    ;% rtB.kocxhnfx4g
                    section.data(14).logicalSrcIdx = 13;
                    section.data(14).dtTransOffset = 41;

                    ;% rtB.mubufhmikb
                    section.data(15).logicalSrcIdx = 14;
                    section.data(15).dtTransOffset = 46;

                    ;% rtB.olngjflg0n
                    section.data(16).logicalSrcIdx = 15;
                    section.data(16).dtTransOffset = 62;

            nTotData = nTotData + section.nData;
            sigMap.sections(1) = section;
            clear section


            ;%
            ;% Non-auto Data (signal)
            ;%


        ;%
        ;% Add final counts to struct.
        ;%
        sigMap.nTotData = nTotData;



    ;%*******************
    ;% Create DWork Map *
    ;%*******************
    
        nTotData      = 0; %add to this count as we go
        nTotSects     = 10;
        sectIdxOffset = 1;

        ;%
        ;% Define dummy sections & preallocate arrays
        ;%
        dumSection.nData = -1;
        dumSection.data  = [];

        dumData.logicalSrcIdx = -1;
        dumData.dtTransOffset = -1;

        ;%
        ;% Init/prealloc dworkMap
        ;%
        dworkMap.nSections           = nTotSects;
        dworkMap.sectIdxOffset       = sectIdxOffset;
            dworkMap.sections(nTotSects) = dumSection; %prealloc
        dworkMap.nTotData            = -1;

        ;%
        ;% Auto data (rtDW)
        ;%
            section.nData     = 1;
            section.data(1)  = dumData; %prealloc

                    ;% rtDW.h50oa4paoh
                    section.data(1).logicalSrcIdx = 0;
                    section.data(1).dtTransOffset = 0;

            nTotData = nTotData + section.nData;
            dworkMap.sections(1) = section;
            clear section

            section.nData     = 1;
            section.data(1)  = dumData; %prealloc

                    ;% rtDW.au4tbeh3wp
                    section.data(1).logicalSrcIdx = 1;
                    section.data(1).dtTransOffset = 0;

            nTotData = nTotData + section.nData;
            dworkMap.sections(2) = section;
            clear section

            section.nData     = 1;
            section.data(1)  = dumData; %prealloc

                    ;% rtDW.nbtjvvk0iu
                    section.data(1).logicalSrcIdx = 2;
                    section.data(1).dtTransOffset = 0;

            nTotData = nTotData + section.nData;
            dworkMap.sections(3) = section;
            clear section

            section.nData     = 1;
            section.data(1)  = dumData; %prealloc

                    ;% rtDW.fymvqkxpsu
                    section.data(1).logicalSrcIdx = 3;
                    section.data(1).dtTransOffset = 0;

            nTotData = nTotData + section.nData;
            dworkMap.sections(4) = section;
            clear section

            section.nData     = 12;
            section.data(12)  = dumData; %prealloc

                    ;% rtDW.j3as2zn3ny
                    section.data(1).logicalSrcIdx = 4;
                    section.data(1).dtTransOffset = 0;

                    ;% rtDW.htunnpm4aw
                    section.data(2).logicalSrcIdx = 5;
                    section.data(2).dtTransOffset = 1;

                    ;% rtDW.btrdhary1n
                    section.data(3).logicalSrcIdx = 6;
                    section.data(3).dtTransOffset = 2;

                    ;% rtDW.jjb3503ojt
                    section.data(4).logicalSrcIdx = 7;
                    section.data(4).dtTransOffset = 3;

                    ;% rtDW.jmhtlb4kaj
                    section.data(5).logicalSrcIdx = 8;
                    section.data(5).dtTransOffset = 4;

                    ;% rtDW.frbgw4ey21
                    section.data(6).logicalSrcIdx = 9;
                    section.data(6).dtTransOffset = 5;

                    ;% rtDW.oqhsxqjtcq
                    section.data(7).logicalSrcIdx = 10;
                    section.data(7).dtTransOffset = 6;

                    ;% rtDW.o4fw42gm5j
                    section.data(8).logicalSrcIdx = 11;
                    section.data(8).dtTransOffset = 7;

                    ;% rtDW.pz4m5n3fa5
                    section.data(9).logicalSrcIdx = 12;
                    section.data(9).dtTransOffset = 8;

                    ;% rtDW.a0oc1r2fmm
                    section.data(10).logicalSrcIdx = 13;
                    section.data(10).dtTransOffset = 10;

                    ;% rtDW.ldjhzt1tvv
                    section.data(11).logicalSrcIdx = 14;
                    section.data(11).dtTransOffset = 11;

                    ;% rtDW.ndveltha3i
                    section.data(12).logicalSrcIdx = 15;
                    section.data(12).dtTransOffset = 12;

            nTotData = nTotData + section.nData;
            dworkMap.sections(5) = section;
            clear section

            section.nData     = 14;
            section.data(14)  = dumData; %prealloc

                    ;% rtDW.m2zu25uvwa
                    section.data(1).logicalSrcIdx = 16;
                    section.data(1).dtTransOffset = 0;

                    ;% rtDW.igg4nbzrjn
                    section.data(2).logicalSrcIdx = 17;
                    section.data(2).dtTransOffset = 1;

                    ;% rtDW.m1h5n4uw0s
                    section.data(3).logicalSrcIdx = 18;
                    section.data(3).dtTransOffset = 2;

                    ;% rtDW.diah0phtmh
                    section.data(4).logicalSrcIdx = 19;
                    section.data(4).dtTransOffset = 3;

                    ;% rtDW.bmykrst20m
                    section.data(5).logicalSrcIdx = 20;
                    section.data(5).dtTransOffset = 4;

                    ;% rtDW.fzprrnveh3.LoggedData
                    section.data(6).logicalSrcIdx = 21;
                    section.data(6).dtTransOffset = 5;

                    ;% rtDW.cijqlagja3
                    section.data(7).logicalSrcIdx = 22;
                    section.data(7).dtTransOffset = 7;

                    ;% rtDW.nrqaiodvpd
                    section.data(8).logicalSrcIdx = 23;
                    section.data(8).dtTransOffset = 8;

                    ;% rtDW.nrgj4ojjz1
                    section.data(9).logicalSrcIdx = 24;
                    section.data(9).dtTransOffset = 9;

                    ;% rtDW.hxun4zugta
                    section.data(10).logicalSrcIdx = 25;
                    section.data(10).dtTransOffset = 10;

                    ;% rtDW.oebpmsajkl
                    section.data(11).logicalSrcIdx = 26;
                    section.data(11).dtTransOffset = 11;

                    ;% rtDW.jjwd1cr3xx
                    section.data(12).logicalSrcIdx = 27;
                    section.data(12).dtTransOffset = 12;

                    ;% rtDW.foz0avbtnh
                    section.data(13).logicalSrcIdx = 28;
                    section.data(13).dtTransOffset = 13;

                    ;% rtDW.gzmlcrpjpo
                    section.data(14).logicalSrcIdx = 29;
                    section.data(14).dtTransOffset = 14;

            nTotData = nTotData + section.nData;
            dworkMap.sections(6) = section;
            clear section

            section.nData     = 6;
            section.data(6)  = dumData; %prealloc

                    ;% rtDW.apqphginxx
                    section.data(1).logicalSrcIdx = 30;
                    section.data(1).dtTransOffset = 0;

                    ;% rtDW.a424fqcnvz
                    section.data(2).logicalSrcIdx = 31;
                    section.data(2).dtTransOffset = 1;

                    ;% rtDW.iovoxirwro
                    section.data(3).logicalSrcIdx = 32;
                    section.data(3).dtTransOffset = 3;

                    ;% rtDW.coliwj5sya
                    section.data(4).logicalSrcIdx = 33;
                    section.data(4).dtTransOffset = 628;

                    ;% rtDW.fz2ttztfrx
                    section.data(5).logicalSrcIdx = 34;
                    section.data(5).dtTransOffset = 629;

                    ;% rtDW.frbywcoc2g
                    section.data(6).logicalSrcIdx = 35;
                    section.data(6).dtTransOffset = 630;

            nTotData = nTotData + section.nData;
            dworkMap.sections(7) = section;
            clear section

            section.nData     = 1;
            section.data(1)  = dumData; %prealloc

                    ;% rtDW.df2e0pg2dx
                    section.data(1).logicalSrcIdx = 36;
                    section.data(1).dtTransOffset = 0;

            nTotData = nTotData + section.nData;
            dworkMap.sections(8) = section;
            clear section

            section.nData     = 2;
            section.data(2)  = dumData; %prealloc

                    ;% rtDW.kjdxfgqbzw
                    section.data(1).logicalSrcIdx = 37;
                    section.data(1).dtTransOffset = 0;

                    ;% rtDW.lc4aznzqkp
                    section.data(2).logicalSrcIdx = 38;
                    section.data(2).dtTransOffset = 1;

            nTotData = nTotData + section.nData;
            dworkMap.sections(9) = section;
            clear section

            section.nData     = 14;
            section.data(14)  = dumData; %prealloc

                    ;% rtDW.aq3afxfwxg
                    section.data(1).logicalSrcIdx = 39;
                    section.data(1).dtTransOffset = 0;

                    ;% rtDW.oe04kxktvd
                    section.data(2).logicalSrcIdx = 40;
                    section.data(2).dtTransOffset = 1;

                    ;% rtDW.paf4jizn5q
                    section.data(3).logicalSrcIdx = 41;
                    section.data(3).dtTransOffset = 2;

                    ;% rtDW.chxdltntn1
                    section.data(4).logicalSrcIdx = 42;
                    section.data(4).dtTransOffset = 3;

                    ;% rtDW.lvfg2ialf5
                    section.data(5).logicalSrcIdx = 43;
                    section.data(5).dtTransOffset = 4;

                    ;% rtDW.fs53o4lsci
                    section.data(6).logicalSrcIdx = 44;
                    section.data(6).dtTransOffset = 5;

                    ;% rtDW.idgjtzemzw
                    section.data(7).logicalSrcIdx = 45;
                    section.data(7).dtTransOffset = 6;

                    ;% rtDW.mkp2eepxcj
                    section.data(8).logicalSrcIdx = 46;
                    section.data(8).dtTransOffset = 7;

                    ;% rtDW.gmdfw45vlb
                    section.data(9).logicalSrcIdx = 47;
                    section.data(9).dtTransOffset = 8;

                    ;% rtDW.cueoevswm1
                    section.data(10).logicalSrcIdx = 48;
                    section.data(10).dtTransOffset = 9;

                    ;% rtDW.n1jgscci0o
                    section.data(11).logicalSrcIdx = 49;
                    section.data(11).dtTransOffset = 10;

                    ;% rtDW.i2pqjw3yac
                    section.data(12).logicalSrcIdx = 50;
                    section.data(12).dtTransOffset = 11;

                    ;% rtDW.kkhkendrtu
                    section.data(13).logicalSrcIdx = 51;
                    section.data(13).dtTransOffset = 12;

                    ;% rtDW.a5bv3potn3
                    section.data(14).logicalSrcIdx = 52;
                    section.data(14).dtTransOffset = 13;

            nTotData = nTotData + section.nData;
            dworkMap.sections(10) = section;
            clear section


            ;%
            ;% Non-auto Data (dwork)
            ;%


        ;%
        ;% Add final counts to struct.
        ;%
        dworkMap.nTotData = nTotData;



    ;%
    ;% Add individual maps to base struct.
    ;%

    targMap.paramMap  = paramMap;
    targMap.signalMap = sigMap;
    targMap.dworkMap  = dworkMap;

    ;%
    ;% Add checksums to base struct.
    ;%


    targMap.checksum0 = 2398350275;
    targMap.checksum1 = 3287781363;
    targMap.checksum2 = 1908459515;
    targMap.checksum3 = 1989708611;

