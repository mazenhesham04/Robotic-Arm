#if defined(_MSC_VER)
#include "pm_printf.h"
#else
typedef int pm_printf_dummy ;
#endif
