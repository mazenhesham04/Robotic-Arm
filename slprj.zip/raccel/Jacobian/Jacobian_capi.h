#ifndef RTW_HEADER_Jacobian_capi_h_
#define RTW_HEADER_Jacobian_capi_h_
#include "Jacobian.h"
extern void Jacobian_InitializeDataMapInfo ( void ) ;
#endif
