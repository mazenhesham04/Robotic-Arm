#ifndef RTW_HEADER_Jacobian_types_h_
#define RTW_HEADER_Jacobian_types_h_
#include "rtwtypes.h"
#ifndef DEFINED_TYPEDEF_FOR_ikblock_info_bus_
#define DEFINED_TYPEDEF_FOR_ikblock_info_bus_
typedef struct { real_T Iterations ; real_T PoseErrorNorm ; uint16_T ExitFlag
; uint8_T Status ; uint8_T sl_padding0 [ 5 ] ; } ikblock_info_bus ;
#endif
#ifndef DEFINED_TYPEDEF_FOR_struct_j29BDD3GtugYMsepf4x9iH_
#define DEFINED_TYPEDEF_FOR_struct_j29BDD3GtugYMsepf4x9iH_
typedef struct { boolean_T EnforceJointLimits ; boolean_T AllowRandomRestart
; uint8_T sl_padding0 [ 6 ] ; real_T MaxIterations ; real_T MaxTime ; real_T
GradientTolerance ; real_T SolutionTolerance ; real_T StepTolerance ; real_T
ErrorChangeTolerance ; boolean_T UseErrorDamping ; uint8_T sl_padding1 [ 7 ]
; real_T DampingBias ; } struct_j29BDD3GtugYMsepf4x9iH ;
#endif
#ifndef struct_tag_2PsGMppoK4e2vdwpogf6iH
#define struct_tag_2PsGMppoK4e2vdwpogf6iH
struct tag_2PsGMppoK4e2vdwpogf6iH { int32_T isInitialized ; } ;
#endif
#ifndef typedef_lcs2lgkanf
#define typedef_lcs2lgkanf
typedef struct tag_2PsGMppoK4e2vdwpogf6iH lcs2lgkanf ;
#endif
#ifndef struct_tag_OXsSBS5uVDavZp4vbYKETG
#define struct_tag_OXsSBS5uVDavZp4vbYKETG
struct tag_OXsSBS5uVDavZp4vbYKETG { boolean_T matlabCodegenIsDeleted ; void *
CollisionPrimitive ; } ;
#endif
#ifndef typedef_mqyxc3drwd
#define typedef_mqyxc3drwd
typedef struct tag_OXsSBS5uVDavZp4vbYKETG mqyxc3drwd ;
#endif
#ifndef struct_tag_sdAmwXbnJnEmimT0NaJRtAD
#define struct_tag_sdAmwXbnJnEmimT0NaJRtAD
struct tag_sdAmwXbnJnEmimT0NaJRtAD { real_T tv_sec ; real_T tv_nsec ; } ;
#endif
#ifndef typedef_nm2s20qzlx
#define typedef_nm2s20qzlx
typedef struct tag_sdAmwXbnJnEmimT0NaJRtAD nm2s20qzlx ;
#endif
#include "coder_posix_time.h"
#ifndef struct_tag_1FpmCQNe36RDLjratTWCgF
#define struct_tag_1FpmCQNe36RDLjratTWCgF
struct tag_1FpmCQNe36RDLjratTWCgF { int32_T __dummy ; } ;
#endif
#ifndef typedef_fzruicbsug
#define typedef_fzruicbsug
typedef struct tag_1FpmCQNe36RDLjratTWCgF fzruicbsug ;
#endif
#ifndef struct_tag_9VaLdcnhzQxC5h4iXVOCU
#define struct_tag_9VaLdcnhzQxC5h4iXVOCU
struct tag_9VaLdcnhzQxC5h4iXVOCU { nm2s20qzlx StartTime ; } ;
#endif
#ifndef typedef_nq0d4lot34
#define typedef_nq0d4lot34
typedef struct tag_9VaLdcnhzQxC5h4iXVOCU nq0d4lot34 ;
#endif
#ifndef struct_tag_I7lxy6BEal0s7MBxygd9JE
#define struct_tag_I7lxy6BEal0s7MBxygd9JE
struct tag_I7lxy6BEal0s7MBxygd9JE { real_T f1 [ 16 ] ; } ;
#endif
#ifndef typedef_csbe03lymu
#define typedef_csbe03lymu
typedef struct tag_I7lxy6BEal0s7MBxygd9JE csbe03lymu ;
#endif
#ifndef struct_tag_BlgwLpgj2bjudmbmVKWwDE
#define struct_tag_BlgwLpgj2bjudmbmVKWwDE
struct tag_BlgwLpgj2bjudmbmVKWwDE { uint32_T f1 [ 8 ] ; } ;
#endif
#ifndef typedef_e0wtrs4zcc
#define typedef_e0wtrs4zcc
typedef struct tag_BlgwLpgj2bjudmbmVKWwDE e0wtrs4zcc ;
#endif
#ifndef struct_emxArray_char_T
#define struct_emxArray_char_T
struct emxArray_char_T { char_T * data ; int32_T * size ; int32_T
allocatedSize ; int32_T numDimensions ; boolean_T canFreeData ; } ;
#endif
#ifndef typedef_e2b0f4s35s
#define typedef_e2b0f4s35s
typedef struct emxArray_char_T e2b0f4s35s ;
#endif
#ifndef struct_emxArray_real_T
#define struct_emxArray_real_T
struct emxArray_real_T { real_T * data ; int32_T * size ; int32_T
allocatedSize ; int32_T numDimensions ; boolean_T canFreeData ; } ;
#endif
#ifndef typedef_moo4o4s0qn
#define typedef_moo4o4s0qn
typedef struct emxArray_real_T moo4o4s0qn ;
#endif
#ifndef typedef_naq1wbp3ki
#define typedef_naq1wbp3ki
typedef struct { mqyxc3drwd * * data ; int32_T * size ; int32_T allocatedSize
; int32_T numDimensions ; boolean_T canFreeData ; } naq1wbp3ki ;
#endif
#ifndef struct_tag_OKYIVqOvg741z7TkldGUv
#define struct_tag_OKYIVqOvg741z7TkldGUv
struct tag_OKYIVqOvg741z7TkldGUv { e2b0f4s35s * Type ; real_T PositionNumber
; moo4o4s0qn * MotionSubspace ; real_T JointToParentTransform [ 16 ] ; real_T
ChildToJointTransform [ 16 ] ; real_T JointAxisInternal [ 3 ] ; } ;
#endif
#ifndef typedef_iyg0swfnbf
#define typedef_iyg0swfnbf
typedef struct tag_OKYIVqOvg741z7TkldGUv iyg0swfnbf ;
#endif
#ifndef struct_tag_00yCXi7nR9pQk8H9si1uXF
#define struct_tag_00yCXi7nR9pQk8H9si1uXF
struct tag_00yCXi7nR9pQk8H9si1uXF { naq1wbp3ki * CollisionGeometries ; real_T
MaxElements ; mqyxc3drwd _pobj0 ; } ;
#endif
#ifndef typedef_gtd4jhsf2r
#define typedef_gtd4jhsf2r
typedef struct tag_00yCXi7nR9pQk8H9si1uXF gtd4jhsf2r ;
#endif
#ifndef struct_tag_zmoHTLL789ZyfPRCAvEruB
#define struct_tag_zmoHTLL789ZyfPRCAvEruB
struct tag_zmoHTLL789ZyfPRCAvEruB { real_T Index ; e2b0f4s35s * NameInternal
; iyg0swfnbf JointInternal ; real_T ParentIndex ; gtd4jhsf2r
CollisionsInternal ; } ;
#endif
#ifndef typedef_gxcsgl11sl
#define typedef_gxcsgl11sl
typedef struct tag_zmoHTLL789ZyfPRCAvEruB gxcsgl11sl ;
#endif
#ifndef struct_tag_TekDHquJNRoNuIYrsmJm7
#define struct_tag_TekDHquJNRoNuIYrsmJm7
struct tag_TekDHquJNRoNuIYrsmJm7 { real_T NumBodies ; gxcsgl11sl Base ;
gxcsgl11sl * Bodies [ 5 ] ; real_T PositionNumber ; real_T VelocityNumber ;
real_T PositionDoFMap [ 10 ] ; gxcsgl11sl _pobj0 [ 10 ] ; } ;
#endif
#ifndef typedef_kp1en3mw3x
#define typedef_kp1en3mw3x
typedef struct tag_TekDHquJNRoNuIYrsmJm7 kp1en3mw3x ;
#endif
#ifndef struct_tag_ljL6GZOOOH4wXu7iznvHnC
#define struct_tag_ljL6GZOOOH4wXu7iznvHnC
struct tag_ljL6GZOOOH4wXu7iznvHnC { int32_T isInitialized ; kp1en3mw3x
TreeInternal ; } ;
#endif
#ifndef typedef_exm4lytzjq
#define typedef_exm4lytzjq
typedef struct tag_ljL6GZOOOH4wXu7iznvHnC exm4lytzjq ;
#endif
#ifndef struct_tag_fg3hltRT1BVNp1FuRifnyD
#define struct_tag_fg3hltRT1BVNp1FuRifnyD
struct tag_fg3hltRT1BVNp1FuRifnyD { e2b0f4s35s * Type ; real_T PositionNumber
; real_T JointToParentTransform [ 16 ] ; real_T ChildToJointTransform [ 16 ]
; real_T JointAxisInternal [ 3 ] ; } ;
#endif
#ifndef typedef_iyg0swfnbfo
#define typedef_iyg0swfnbfo
typedef struct tag_fg3hltRT1BVNp1FuRifnyD iyg0swfnbfo ;
#endif
#ifndef struct_tag_6Ennm3tvYwAZBE9gAK62iF
#define struct_tag_6Ennm3tvYwAZBE9gAK62iF
struct tag_6Ennm3tvYwAZBE9gAK62iF { e2b0f4s35s * NameInternal ; iyg0swfnbfo
JointInternal ; real_T ParentIndex ; gtd4jhsf2r CollisionsInternal ; } ;
#endif
#ifndef typedef_gxcsgl11sl3
#define typedef_gxcsgl11sl3
typedef struct tag_6Ennm3tvYwAZBE9gAK62iF gxcsgl11sl3 ;
#endif
#ifndef struct_tag_rsyxsBAt5Mj2oMVX3wcCbD
#define struct_tag_rsyxsBAt5Mj2oMVX3wcCbD
struct tag_rsyxsBAt5Mj2oMVX3wcCbD { real_T NumBodies ; gxcsgl11sl3 Base ;
gxcsgl11sl3 * Bodies [ 5 ] ; real_T PositionNumber ; gxcsgl11sl3 _pobj0 [ 10
] ; } ;
#endif
#ifndef typedef_kp1en3mw3xl
#define typedef_kp1en3mw3xl
typedef struct tag_rsyxsBAt5Mj2oMVX3wcCbD kp1en3mw3xl ;
#endif
#ifndef struct_tag_L0r1CVAtRnKkzPSU7z8WPC
#define struct_tag_L0r1CVAtRnKkzPSU7z8WPC
struct tag_L0r1CVAtRnKkzPSU7z8WPC { int32_T isInitialized ; kp1en3mw3xl
TreeInternal ; } ;
#endif
#ifndef typedef_gsvdge1jib
#define typedef_gsvdge1jib
typedef struct tag_L0r1CVAtRnKkzPSU7z8WPC gsvdge1jib ;
#endif
#ifndef struct_tag_EhjQFBatIylmRskzCQ6c4C
#define struct_tag_EhjQFBatIylmRskzCQ6c4C
struct tag_EhjQFBatIylmRskzCQ6c4C { e2b0f4s35s * Type ; real_T VelocityNumber
; real_T PositionNumber ; moo4o4s0qn * MotionSubspace ; boolean_T InTree ;
real_T JointToParentTransform [ 16 ] ; real_T ChildToJointTransform [ 16 ] ;
e2b0f4s35s * NameInternal ; moo4o4s0qn * PositionLimitsInternal ; moo4o4s0qn
* HomePositionInternal ; real_T JointAxisInternal [ 3 ] ; } ;
#endif
#ifndef typedef_iyg0swfnbfoc
#define typedef_iyg0swfnbfoc
typedef struct tag_EhjQFBatIylmRskzCQ6c4C iyg0swfnbfoc ;
#endif
#ifndef struct_emxArray_int8_T
#define struct_emxArray_int8_T
struct emxArray_int8_T { int8_T * data ; int32_T * size ; int32_T
allocatedSize ; int32_T numDimensions ; boolean_T canFreeData ; } ;
#endif
#ifndef typedef_ksusmq01tx
#define typedef_ksusmq01tx
typedef struct emxArray_int8_T ksusmq01tx ;
#endif
#ifndef struct_emxArray_tag_I7lxy6BEal0s7MBxyg
#define struct_emxArray_tag_I7lxy6BEal0s7MBxyg
struct emxArray_tag_I7lxy6BEal0s7MBxyg { csbe03lymu * data ; int32_T * size ;
int32_T allocatedSize ; int32_T numDimensions ; boolean_T canFreeData ; } ;
#endif
#ifndef typedef_fgmfslti0b
#define typedef_fgmfslti0b
typedef struct emxArray_tag_I7lxy6BEal0s7MBxyg fgmfslti0b ;
#endif
#ifndef struct_emxArray_boolean_T
#define struct_emxArray_boolean_T
struct emxArray_boolean_T { boolean_T * data ; int32_T * size ; int32_T
allocatedSize ; int32_T numDimensions ; boolean_T canFreeData ; } ;
#endif
#ifndef typedef_itipyws4dn
#define typedef_itipyws4dn
typedef struct emxArray_boolean_T itipyws4dn ;
#endif
#ifndef struct_emxArray_int32_T
#define struct_emxArray_int32_T
struct emxArray_int32_T { int32_T * data ; int32_T * size ; int32_T
allocatedSize ; int32_T numDimensions ; boolean_T canFreeData ; } ;
#endif
#ifndef typedef_iidpvf4tee
#define typedef_iidpvf4tee
typedef struct emxArray_int32_T iidpvf4tee ;
#endif
#ifndef struct_emxArray_uint32_T
#define struct_emxArray_uint32_T
struct emxArray_uint32_T { uint32_T * data ; int32_T * size ; int32_T
allocatedSize ; int32_T numDimensions ; boolean_T canFreeData ; } ;
#endif
#ifndef typedef_izqiyoa4ub
#define typedef_izqiyoa4ub
typedef struct emxArray_uint32_T izqiyoa4ub ;
#endif
#ifndef struct_tag_v6rRZ5Zp2Oqr77pqOQdFKF
#define struct_tag_v6rRZ5Zp2Oqr77pqOQdFKF
struct tag_v6rRZ5Zp2Oqr77pqOQdFKF { naq1wbp3ki * CollisionGeometries ; real_T
MaxElements ; real_T Size ; mqyxc3drwd _pobj0 ; } ;
#endif
#ifndef typedef_gtd4jhsf2rw
#define typedef_gtd4jhsf2rw
typedef struct tag_v6rRZ5Zp2Oqr77pqOQdFKF gtd4jhsf2rw ;
#endif
#ifndef struct_tag_2x4mAAAurrfRmmdikUuSMH
#define struct_tag_2x4mAAAurrfRmmdikUuSMH
struct tag_2x4mAAAurrfRmmdikUuSMH { real_T Index ; e2b0f4s35s * NameInternal
; iyg0swfnbfoc * JointInternal ; real_T ParentIndex ; real_T MassInternal ;
real_T CenterOfMassInternal [ 3 ] ; real_T InertiaInternal [ 9 ] ; real_T
SpatialInertia [ 36 ] ; gtd4jhsf2rw * CollisionsInternal ; } ;
#endif
#ifndef typedef_gxcsgl11sl35
#define typedef_gxcsgl11sl35
typedef struct tag_2x4mAAAurrfRmmdikUuSMH gxcsgl11sl35 ;
#endif
#ifndef struct_tag_QDofkmeG0czRqgdm8DKdbC
#define struct_tag_QDofkmeG0czRqgdm8DKdbC
struct tag_QDofkmeG0czRqgdm8DKdbC { real_T NumBodies ; gxcsgl11sl35 Base ;
fzruicbsug FastVisualizationHelper ; gxcsgl11sl35 * Bodies [ 5 ] ; real_T
NumNonFixedBodies ; real_T PositionNumber ; real_T VelocityNumber ; real_T
PositionDoFMap [ 10 ] ; real_T VelocityDoFMap [ 10 ] ; gxcsgl11sl35 _pobj0 [
5 ] ; gtd4jhsf2rw _pobj1 [ 6 ] ; iyg0swfnbfoc _pobj2 [ 6 ] ; } ;
#endif
#ifndef typedef_itgfp4rmev
#define typedef_itgfp4rmev
typedef struct tag_QDofkmeG0czRqgdm8DKdbC itgfp4rmev ;
#endif
#ifndef struct_tag_vx1HRkzv0rRTJAwDh80upD
#define struct_tag_vx1HRkzv0rRTJAwDh80upD
struct tag_vx1HRkzv0rRTJAwDh80upD { real_T NumBodies ; gxcsgl11sl35 Base ;
real_T Gravity [ 3 ] ; gxcsgl11sl35 * Bodies [ 5 ] ; gtd4jhsf2rw _pobj0 [ 11
] ; iyg0swfnbfoc _pobj1 [ 11 ] ; gxcsgl11sl35 _pobj2 [ 10 ] ; } ;
#endif
#ifndef typedef_kp1en3mw3xln
#define typedef_kp1en3mw3xln
typedef struct tag_vx1HRkzv0rRTJAwDh80upD kp1en3mw3xln ;
#endif
#ifndef struct_tag_yYLezKjRG3hmNyMkYalRQF
#define struct_tag_yYLezKjRG3hmNyMkYalRQF
struct tag_yYLezKjRG3hmNyMkYalRQF { itgfp4rmev * Robot ; real_T WeightMatrix
[ 36 ] ; moo4o4s0qn * Limits ; e2b0f4s35s * BodyName ; real_T Tform [ 16 ] ;
moo4o4s0qn * ErrTemp ; real_T CostTemp ; moo4o4s0qn * GradTemp ; } ;
#endif
#ifndef typedef_l2t3f2z1w3
#define typedef_l2t3f2z1w3
typedef struct tag_yYLezKjRG3hmNyMkYalRQF l2t3f2z1w3 ;
#endif
#ifndef struct_tag_p2FQHJQlvu7nZNvFKQvqlC
#define struct_tag_p2FQHJQlvu7nZNvFKQvqlC
struct tag_p2FQHJQlvu7nZNvFKQvqlC { char_T Name [ 18 ] ; boolean_T
ConstraintsOn ; real_T SolutionTolerance ; boolean_T RandomRestart ;
l2t3f2z1w3 * ExtraArgs ; real_T MaxNumIteration ; real_T MaxTime ; real_T
SeedInternal [ 5 ] ; real_T MaxTimeInternal ; real_T MaxNumIterationInternal
; real_T StepTolerance ; nq0d4lot34 TimeObj ; real_T GradientTolerance ;
real_T ErrorChangeTolerance ; real_T DampingBias ; boolean_T UseErrorDamping
; nq0d4lot34 TimeObjInternal ; } ;
#endif
#ifndef typedef_pmprofizlh
#define typedef_pmprofizlh
typedef struct tag_p2FQHJQlvu7nZNvFKQvqlC pmprofizlh ;
#endif
#ifndef struct_tag_M2cP338epkceOXrD5kTvN
#define struct_tag_M2cP338epkceOXrD5kTvN
struct tag_M2cP338epkceOXrD5kTvN { boolean_T matlabCodegenIsDeleted ; int32_T
isInitialized ; boolean_T isSetupComplete ; pmprofizlh * Solver ; moo4o4s0qn
* Limits ; itgfp4rmev * RigidBodyTreeInternal ; l2t3f2z1w3 _pobj0 ;
iyg0swfnbfoc _pobj1 [ 10 ] ; gxcsgl11sl35 _pobj2 [ 5 ] ; gtd4jhsf2rw _pobj3 [
11 ] ; itgfp4rmev _pobj4 ; pmprofizlh _pobj5 ; } ;
#endif
#ifndef typedef_iabjthfi1p
#define typedef_iabjthfi1p
typedef struct tag_M2cP338epkceOXrD5kTvN iabjthfi1p ;
#endif
#ifndef struct_tag_WfXCkVh3kObkhsVLF6AmPD
#define struct_tag_WfXCkVh3kObkhsVLF6AmPD
struct tag_WfXCkVh3kObkhsVLF6AmPD { boolean_T matlabCodegenIsDeleted ;
int32_T isInitialized ; kp1en3mw3xln TreeInternal ; iabjthfi1p IKInternal ; }
;
#endif
#ifndef typedef_gh04rvpx0o
#define typedef_gh04rvpx0o
typedef struct tag_WfXCkVh3kObkhsVLF6AmPD gh04rvpx0o ;
#endif
#ifndef typedef_iu3zpbmgcw
#define typedef_iu3zpbmgcw
typedef int32_T iu3zpbmgcw ;
#endif
#ifndef robotics_core_internal_NLPSolverExitFlags_constants
#define robotics_core_internal_NLPSolverExitFlags_constants
#define robotics_core_internal_NLPSolverExitFlags_LocalMinimumFound (1)
#define robotics_core_internal_NLPSolverExitFlags_IterationLimitExceeded (2)
#define robotics_core_internal_NLPSolverExitFlags_TimeLimitExceeded (3)
#define robotics_core_internal_NLPSolverExitFlags_StepSizeBelowMinimum (4)
#define robotics_core_internal_NLPSolverExitFlags_ChangeInErrorBelowMinimum (5)
#define robotics_core_internal_NLPSolverExitFlags_SearchDirectionInvalid (6)
#define robotics_core_internal_NLPSolverExitFlags_HessianNotPositiveSemidefinite (7)
#define robotics_core_internal_NLPSolverExitFlags_TrustRegionRadiusBelowMinimum (8)
#endif
#ifndef struct_tag_DeYFC8S45QuZ5xPAPK17bB
#define struct_tag_DeYFC8S45QuZ5xPAPK17bB
struct tag_DeYFC8S45QuZ5xPAPK17bB { int32_T isInitialized ; boolean_T
TunablePropsChanged ; e0wtrs4zcc inputVarSize ; real_T Waypoints [ 21 ] ;
real_T TimePoints [ 7 ] ; real_T VelocityBoundaryCondition [ 21 ] ; real_T
AccelerationBoundaryCondition [ 10 ] ; } ;
#endif
#ifndef typedef_f3sl3rrx3a
#define typedef_f3sl3rrx3a
typedef struct tag_DeYFC8S45QuZ5xPAPK17bB f3sl3rrx3a ;
#endif
#ifndef SS_UINT64
#define SS_UINT64 24
#endif
#ifndef SS_INT64
#define SS_INT64 25
#endif
typedef struct P_ P ;
#endif
