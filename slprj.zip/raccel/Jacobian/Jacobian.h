#ifndef RTW_HEADER_Jacobian_h_
#define RTW_HEADER_Jacobian_h_
#ifndef Jacobian_COMMON_INCLUDES_
#define Jacobian_COMMON_INCLUDES_
#include <stdlib.h>
#include <string.h>
#include "rtwtypes.h"
#include "sigstream_rtw.h"
#include "simtarget/slSimTgtSigstreamRTW.h"
#include "simtarget/slSimTgtSlioCoreRTW.h"
#include "simtarget/slSimTgtSlioClientsRTW.h"
#include "simtarget/slSimTgtSlioSdiRTW.h"
#include "simstruc.h"
#include "fixedpoint.h"
#include "raccel.h"
#include "slsv_diagnostic_codegen_c_api.h"
#include "rt_logging_simtarget.h"
#include "dt_info.h"
#include "ext_work.h"
#include "collisioncodegen_api.hpp"
#include "coder_posix_time.h"
#include "nesl_rtw.h"
#include "Jacobian_9d5357ce_1_gateway.h"
#endif
#include "Jacobian_types.h"
#include "rtGetNaN.h"
#include "rt_nonfinite.h"
#include <stddef.h>
#include "rtw_modelmap_simtarget.h"
#include "rt_defines.h"
#include "rtGetInf.h"
#define MODEL_NAME Jacobian
#define NSAMPLE_TIMES (2) 
#define NINPUTS (0)       
#define NOUTPUTS (0)     
#define NBLOCKIO (16) 
#define NUM_ZC_EVENTS (0) 
#ifndef NCSTATES
#define NCSTATES (8)   
#elif NCSTATES != 8
#error Invalid specification of NCSTATES defined in compiler command
#endif
#ifndef rtmGetDataMapInfo
#define rtmGetDataMapInfo(rtm) (*rt_dataMapInfoPtr)
#endif
#ifndef rtmSetDataMapInfo
#define rtmSetDataMapInfo(rtm, val) (rt_dataMapInfoPtr = &val)
#endif
#ifndef IN_RACCEL_MAIN
#endif
typedef struct { real_T g35gtlfojh [ 4 ] ; real_T jrnj3m5jkq [ 4 ] ; real_T
mxjei2s3ub [ 4 ] ; real_T d4sufxfyw0 [ 4 ] ; real_T kvi533iz0u [ 4 ] ; real_T
aqvrlbktfx [ 6 ] ; real_T g0n3japp2o [ 5 ] ; real_T evts0truna ; real_T
oxlbdgveau ; real_T gtrv14nqvd ; real_T cnntouejof ; real_T jduggdofo3 [ 3 ]
; real_T pwxyrrsugo [ 3 ] ; real_T kocxhnfx4g [ 5 ] ; real_T mubufhmikb [ 16
] ; real_T olngjflg0n [ 30 ] ; } B ; typedef struct { gh04rvpx0o h50oa4paoh ;
exm4lytzjq au4tbeh3wp ; gsvdge1jib nbtjvvk0iu ; f3sl3rrx3a fymvqkxpsu ;
real_T j3as2zn3ny ; real_T htunnpm4aw ; real_T btrdhary1n ; real_T jjb3503ojt
; real_T jmhtlb4kaj ; real_T frbgw4ey21 ; real_T oqhsxqjtcq ; real_T
o4fw42gm5j ; real_T pz4m5n3fa5 [ 2 ] ; real_T a0oc1r2fmm ; real_T ldjhzt1tvv
; real_T ndveltha3i ; void * m2zu25uvwa ; void * igg4nbzrjn ; void *
m1h5n4uw0s ; void * diah0phtmh ; void * bmykrst20m ; struct { void *
LoggedData [ 2 ] ; } fzprrnveh3 ; void * cijqlagja3 ; void * nrqaiodvpd ;
void * nrgj4ojjz1 ; void * hxun4zugta ; void * oebpmsajkl ; void * jjwd1cr3xx
; void * foz0avbtnh ; void * gzmlcrpjpo ; uint32_T apqphginxx ; uint32_T
a424fqcnvz [ 2 ] ; uint32_T iovoxirwro [ 625 ] ; uint32_T coliwj5sya ;
uint32_T fz2ttztfrx ; uint32_T frbywcoc2g [ 2 ] ; lcs2lgkanf df2e0pg2dx ;
int_T kjdxfgqbzw ; int_T lc4aznzqkp ; boolean_T aq3afxfwxg ; boolean_T
oe04kxktvd ; boolean_T paf4jizn5q ; boolean_T chxdltntn1 ; boolean_T
lvfg2ialf5 ; boolean_T fs53o4lsci ; boolean_T idgjtzemzw ; boolean_T
mkp2eepxcj ; boolean_T gmdfw45vlb ; boolean_T cueoevswm1 ; boolean_T
n1jgscci0o ; boolean_T i2pqjw3yac ; boolean_T kkhkendrtu ; boolean_T
a5bv3potn3 ; } DW ; typedef struct { real_T ostptot32c [ 2 ] ; real_T
dl0o42unpr [ 2 ] ; real_T pycppw2m5m [ 2 ] ; real_T i4uxujxgss [ 2 ] ; } X ;
typedef struct { real_T ostptot32c [ 2 ] ; real_T dl0o42unpr [ 2 ] ; real_T
pycppw2m5m [ 2 ] ; real_T i4uxujxgss [ 2 ] ; } XDot ; typedef struct {
boolean_T ostptot32c [ 2 ] ; boolean_T dl0o42unpr [ 2 ] ; boolean_T
pycppw2m5m [ 2 ] ; boolean_T i4uxujxgss [ 2 ] ; } XDis ; typedef struct {
real_T ostptot32c [ 2 ] ; real_T dl0o42unpr [ 2 ] ; real_T pycppw2m5m [ 2 ] ;
real_T i4uxujxgss [ 2 ] ; } CStateAbsTol ; typedef struct { real_T ostptot32c
[ 2 ] ; real_T dl0o42unpr [ 2 ] ; real_T pycppw2m5m [ 2 ] ; real_T i4uxujxgss
[ 2 ] ; } CXPtMin ; typedef struct { real_T ostptot32c [ 2 ] ; real_T
dl0o42unpr [ 2 ] ; real_T pycppw2m5m [ 2 ] ; real_T i4uxujxgss [ 2 ] ; }
CXPtMax ; typedef struct { rtwCAPI_ModelMappingInfo mmi ; } DataMapInfo ;
struct P_ { real_T PolynomialTrajectory_Waypoints [ 21 ] ; real_T
PolynomialTrajectory_TimePoints [ 7 ] ; real_T
PolynomialTrajectory_VelocityBoundaryCondition [ 21 ] ; real_T Gain_Gain ;
real_T Constant1_Value [ 6 ] ; real_T Constant2_Value [ 5 ] ; real_T
Constant3_Value ; real_T Constant4_Value ; real_T Constant_Value ; } ; extern
const char * RT_MEMORY_ALLOCATION_ERROR ; extern B rtB ; extern X rtX ;
extern DW rtDW ; extern P rtP ; extern mxArray * mr_Jacobian_GetDWork ( ) ;
extern void mr_Jacobian_SetDWork ( const mxArray * ssDW ) ; extern mxArray *
mr_Jacobian_GetSimStateDisallowedBlocks ( ) ; extern const
rtwCAPI_ModelMappingStaticInfo * Jacobian_GetCAPIStaticMap ( void ) ; extern
SimStruct * const rtS ; extern const int_T gblNumToFiles ; extern const int_T
gblNumFrFiles ; extern const int_T gblNumFrWksBlocks ; extern rtInportTUtable
* gblInportTUtables ; extern const char * gblInportFileName ; extern const
int_T gblNumRootInportBlks ; extern const int_T gblNumModelInputs ; extern
const int_T gblInportDataTypeIdx [ ] ; extern const int_T gblInportDims [ ] ;
extern const int_T gblInportComplex [ ] ; extern const int_T
gblInportInterpoFlag [ ] ; extern const int_T gblInportContinuous [ ] ;
extern const int_T gblParameterTuningTid ; extern DataMapInfo *
rt_dataMapInfoPtr ; extern rtwCAPI_ModelMappingInfo * rt_modelMapInfoPtr ;
void MdlOutputs ( int_T tid ) ; void MdlOutputsParameterSampleTime ( int_T
tid ) ; void MdlUpdate ( int_T tid ) ; void MdlTerminate ( void ) ; void
MdlInitializeSizes ( void ) ; void MdlInitializeSampleTimes ( void ) ;
SimStruct * raccel_register_model ( ssExecutionInfo * executionInfo ) ;
#endif
