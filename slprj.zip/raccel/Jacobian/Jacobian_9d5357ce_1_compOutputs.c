#include <math.h>
#include <string.h>
#include "pm_std.h"
#include "sm_std.h"
#include "ne_std.h"
#include "ne_dae.h"
#include "sm_ssci_run_time_errors.h"
#include "sm_RuntimeDerivedValuesBundle.h"
#include "Jacobian_9d5357ce_1_geometries.h"
PmfMessageId Jacobian_9d5357ce_1_compOutputs ( const
RuntimeDerivedValuesBundle * rtdv , const int * eqnEnableFlags , const double
* state , const int * modeVector , const double * input , const double *
inputDot , const double * inputDdot , const double * discreteState , double *
deriv , double * output , int * derivErr , double * errorResult ,
NeuDiagnosticManager * neDiagMgr ) { const double * rtdvd = rtdv -> mDoubles
. mValues ; const int * rtdvi = rtdv -> mInts . mValues ; double xx [ 262 ] ;
( void ) rtdvd ; ( void ) rtdvi ; ( void ) eqnEnableFlags ; ( void ) state ;
( void ) modeVector ; ( void ) discreteState ; ( void ) neDiagMgr ; ( void )
deriv ; ( void ) derivErr ; errorResult [ 0 ] = 0.0 ; xx [ 0 ] =
6.906648334961606e-4 ; xx [ 1 ] = 0.5646178024837725 ; xx [ 2 ] = -
0.5080371901076823 ; xx [ 3 ] = - 0.4256843833930758 ; xx [ 4 ] = -
0.4918310241547837 ; xx [ 5 ] = 0.5 ; xx [ 6 ] = xx [ 5 ] * input [ 2 ] ; xx
[ 7 ] = 0.9924229712447767 ; xx [ 8 ] = sin ( xx [ 6 ] ) ; xx [ 9 ] =
2.98995580305661e-6 ; xx [ 10 ] = 0.1228684098405683 ; xx [ 11 ] = cos ( xx [
6 ] ) ; xx [ 12 ] = - ( xx [ 7 ] * xx [ 8 ] ) ; xx [ 13 ] = xx [ 9 ] * xx [ 8
] ; xx [ 14 ] = - ( xx [ 10 ] * xx [ 8 ] ) ; pm_math_Quaternion_compose_ra (
xx + 1 , xx + 11 , xx + 15 ) ; xx [ 1 ] = xx [ 15 ] * xx [ 15 ] ; xx [ 2 ] =
2.0 ; xx [ 3 ] = 1.0 ; xx [ 4 ] = xx [ 16 ] * xx [ 17 ] ; xx [ 6 ] = xx [ 15
] * xx [ 18 ] ; xx [ 8 ] = xx [ 16 ] * xx [ 18 ] ; xx [ 11 ] = xx [ 15 ] * xx
[ 17 ] ; xx [ 12 ] = xx [ 17 ] * xx [ 18 ] ; xx [ 13 ] = xx [ 15 ] * xx [ 16
] ; xx [ 19 ] = ( xx [ 1 ] + xx [ 16 ] * xx [ 16 ] ) * xx [ 2 ] - xx [ 3 ] ;
xx [ 20 ] = xx [ 2 ] * ( xx [ 4 ] - xx [ 6 ] ) ; xx [ 21 ] = ( xx [ 8 ] + xx
[ 11 ] ) * xx [ 2 ] ; xx [ 22 ] = ( xx [ 4 ] + xx [ 6 ] ) * xx [ 2 ] ; xx [
23 ] = ( xx [ 1 ] + xx [ 17 ] * xx [ 17 ] ) * xx [ 2 ] - xx [ 3 ] ; xx [ 24 ]
= xx [ 2 ] * ( xx [ 12 ] - xx [ 13 ] ) ; xx [ 25 ] = xx [ 2 ] * ( xx [ 8 ] -
xx [ 11 ] ) ; xx [ 26 ] = ( xx [ 12 ] + xx [ 13 ] ) * xx [ 2 ] ; xx [ 27 ] =
( xx [ 1 ] + xx [ 18 ] * xx [ 18 ] ) * xx [ 2 ] - xx [ 3 ] ; xx [ 1 ] =
1.975704780042954e-4 ; xx [ 11 ] = 5.028122702054597e-7 ; xx [ 12 ] = -
0.9925311081280426 ; xx [ 13 ] = 1.347375321216013e-6 ; xx [ 14 ] = -
0.1219918005279538 ; xx [ 4 ] = xx [ 5 ] * input [ 3 ] ; xx [ 6 ] =
0.1211150960430416 ; xx [ 8 ] = sin ( xx [ 4 ] ) ; xx [ 28 ] =
3.288910678538823e-8 ; xx [ 29 ] = 0.9926384706984133 ; xx [ 30 ] = cos ( xx
[ 4 ] ) ; xx [ 31 ] = xx [ 6 ] * xx [ 8 ] ; xx [ 32 ] = - ( xx [ 28 ] * xx [
8 ] ) ; xx [ 33 ] = - ( xx [ 29 ] * xx [ 8 ] ) ;
pm_math_Quaternion_compose_ra ( xx + 11 , xx + 30 , xx + 34 ) ; xx [ 4 ] = xx
[ 34 ] * xx [ 34 ] ; xx [ 8 ] = xx [ 35 ] * xx [ 36 ] ; xx [ 11 ] = xx [ 34 ]
* xx [ 37 ] ; xx [ 12 ] = xx [ 35 ] * xx [ 37 ] ; xx [ 13 ] = xx [ 34 ] * xx
[ 36 ] ; xx [ 14 ] = xx [ 36 ] * xx [ 37 ] ; xx [ 30 ] = xx [ 34 ] * xx [ 35
] ; xx [ 38 ] = ( xx [ 4 ] + xx [ 35 ] * xx [ 35 ] ) * xx [ 2 ] - xx [ 3 ] ;
xx [ 39 ] = xx [ 2 ] * ( xx [ 8 ] - xx [ 11 ] ) ; xx [ 40 ] = ( xx [ 12 ] +
xx [ 13 ] ) * xx [ 2 ] ; xx [ 41 ] = ( xx [ 8 ] + xx [ 11 ] ) * xx [ 2 ] ; xx
[ 42 ] = ( xx [ 4 ] + xx [ 36 ] * xx [ 36 ] ) * xx [ 2 ] - xx [ 3 ] ; xx [ 43
] = xx [ 2 ] * ( xx [ 14 ] - xx [ 30 ] ) ; xx [ 44 ] = xx [ 2 ] * ( xx [ 12 ]
- xx [ 13 ] ) ; xx [ 45 ] = ( xx [ 14 ] + xx [ 30 ] ) * xx [ 2 ] ; xx [ 46 ]
= ( xx [ 4 ] + xx [ 37 ] * xx [ 37 ] ) * xx [ 2 ] - xx [ 3 ] ; xx [ 4 ] =
2.950011316381179e-4 ; xx [ 11 ] = 0.5267905997666387 ; xx [ 12 ] =
0.4667055010928088 ; xx [ 13 ] = 0.4707469087149515 ; xx [ 14 ] =
0.5320479181263028 ; xx [ 8 ] = xx [ 5 ] * input [ 4 ] ; xx [ 30 ] =
9.20747648943954e-3 ; xx [ 31 ] = sin ( xx [ 8 ] ) ; xx [ 32 ] =
4.073584924244647e-5 ; xx [ 33 ] = 0.999957609460165 ; xx [ 47 ] = cos ( xx [
8 ] ) ; xx [ 48 ] = xx [ 30 ] * xx [ 31 ] ; xx [ 49 ] = xx [ 32 ] * xx [ 31 ]
; xx [ 50 ] = - ( xx [ 33 ] * xx [ 31 ] ) ; pm_math_Quaternion_compose_ra (
xx + 11 , xx + 47 , xx + 51 ) ; xx [ 8 ] = xx [ 51 ] * xx [ 51 ] ; xx [ 11 ]
= ( xx [ 8 ] + xx [ 52 ] * xx [ 52 ] ) * xx [ 2 ] - xx [ 3 ] ; xx [ 12 ] = xx
[ 52 ] * xx [ 53 ] ; xx [ 13 ] = xx [ 51 ] * xx [ 54 ] ; xx [ 14 ] = xx [ 2 ]
* ( xx [ 12 ] - xx [ 13 ] ) ; xx [ 31 ] = xx [ 52 ] * xx [ 54 ] ; xx [ 47 ] =
xx [ 51 ] * xx [ 53 ] ; xx [ 48 ] = ( xx [ 31 ] + xx [ 47 ] ) * xx [ 2 ] ; xx
[ 49 ] = ( xx [ 12 ] + xx [ 13 ] ) * xx [ 2 ] ; xx [ 12 ] = ( xx [ 8 ] + xx [
53 ] * xx [ 53 ] ) * xx [ 2 ] - xx [ 3 ] ; xx [ 13 ] = xx [ 53 ] * xx [ 54 ]
; xx [ 50 ] = xx [ 51 ] * xx [ 52 ] ; xx [ 55 ] = xx [ 2 ] * ( xx [ 13 ] - xx
[ 50 ] ) ; xx [ 56 ] = xx [ 2 ] * ( xx [ 31 ] - xx [ 47 ] ) ; xx [ 31 ] = (
xx [ 13 ] + xx [ 50 ] ) * xx [ 2 ] ; xx [ 13 ] = ( xx [ 8 ] + xx [ 54 ] * xx
[ 54 ] ) * xx [ 2 ] - xx [ 3 ] ; xx [ 57 ] = xx [ 11 ] ; xx [ 58 ] = xx [ 14
] ; xx [ 59 ] = xx [ 48 ] ; xx [ 60 ] = xx [ 49 ] ; xx [ 61 ] = xx [ 12 ] ;
xx [ 62 ] = xx [ 55 ] ; xx [ 63 ] = xx [ 56 ] ; xx [ 64 ] = xx [ 31 ] ; xx [
65 ] = xx [ 13 ] ; xx [ 8 ] = 9.604973143064952e-6 ; xx [ 47 ] =
9.916372004245326e-6 ; xx [ 50 ] = 8.038870802725645e-6 ; xx [ 66 ] = xx [ 8
] * xx [ 11 ] ; xx [ 67 ] = xx [ 8 ] * xx [ 49 ] ; xx [ 68 ] = xx [ 8 ] * xx
[ 56 ] ; xx [ 69 ] = xx [ 47 ] * xx [ 14 ] ; xx [ 70 ] = xx [ 47 ] * xx [ 12
] ; xx [ 71 ] = xx [ 47 ] * xx [ 31 ] ; xx [ 72 ] = xx [ 50 ] * xx [ 48 ] ;
xx [ 73 ] = xx [ 50 ] * xx [ 55 ] ; xx [ 74 ] = xx [ 50 ] * xx [ 13 ] ;
pm_math_Matrix3x3_compose_ra ( xx + 57 , xx + 66 , xx + 75 ) ; xx [ 66 ] =
0.02773943708071183 ; xx [ 84 ] = xx [ 66 ] * xx [ 11 ] ; xx [ 85 ] = xx [ 66
] * xx [ 49 ] ; xx [ 86 ] = xx [ 66 ] * xx [ 56 ] ; xx [ 87 ] = xx [ 66 ] *
xx [ 14 ] ; xx [ 88 ] = xx [ 66 ] * xx [ 12 ] ; xx [ 89 ] = xx [ 66 ] * xx [
31 ] ; xx [ 90 ] = xx [ 66 ] * xx [ 48 ] ; xx [ 91 ] = xx [ 66 ] * xx [ 55 ]
; xx [ 92 ] = xx [ 66 ] * xx [ 13 ] ; pm_math_Matrix3x3_compose_ra ( xx + 57
, xx + 84 , xx + 93 ) ; xx [ 11 ] = - 2.13144617995885e-4 ; xx [ 12 ] = -
5.622537199868788e-7 ; xx [ 13 ] = 0.02684256075846762 ;
pm_math_Quaternion_xform_ra ( xx + 51 , xx + 11 , xx + 55 ) ; xx [ 11 ] = - (
0.0448782424051596 + xx [ 55 ] ) ; xx [ 12 ] = - ( 2.124807382095257e-8 + xx
[ 56 ] ) ; xx [ 13 ] = - ( 0.04188909189960371 + xx [ 57 ] ) ;
pm_math_Matrix3x3_postCross_ra ( xx + 93 , xx + 11 , xx + 55 ) ;
pm_math_Matrix3x3_preCross_ra ( xx + 55 , xx + 11 , xx + 84 ) ; xx [ 14 ] =
3.155351126133716e-4 ; xx [ 31 ] = 5.356052328764158e-5 ; xx [ 102 ] = xx [ 4
] + xx [ 75 ] - xx [ 84 ] ; xx [ 103 ] = xx [ 76 ] - xx [ 85 ] ; xx [ 104 ] =
xx [ 77 ] - xx [ 86 ] ; xx [ 105 ] = xx [ 78 ] - xx [ 87 ] ; xx [ 106 ] = xx
[ 14 ] + xx [ 79 ] - xx [ 88 ] ; xx [ 107 ] = xx [ 80 ] - xx [ 89 ] ; xx [
108 ] = xx [ 81 ] - xx [ 90 ] ; xx [ 109 ] = xx [ 82 ] - xx [ 91 ] ; xx [ 110
] = xx [ 31 ] + xx [ 83 ] - xx [ 92 ] ; pm_math_Matrix3x3_composeTranspose_ra
( xx + 102 , xx + 38 , xx + 67 ) ; pm_math_Matrix3x3_compose_ra ( xx + 38 ,
xx + 67 , xx + 76 ) ; xx [ 67 ] = - xx [ 55 ] ; xx [ 68 ] = - xx [ 58 ] ; xx
[ 69 ] = - xx [ 61 ] ; xx [ 70 ] = - xx [ 56 ] ; xx [ 71 ] = - xx [ 59 ] ; xx
[ 72 ] = - xx [ 62 ] ; xx [ 73 ] = - xx [ 57 ] ; xx [ 74 ] = - xx [ 60 ] ; xx
[ 75 ] = - xx [ 63 ] ; pm_math_Matrix3x3_composeTranspose_ra ( xx + 67 , xx +
38 , xx + 55 ) ; pm_math_Matrix3x3_compose_ra ( xx + 38 , xx + 55 , xx + 111
) ; xx [ 55 ] = - 0.02044256463300171 ; xx [ 56 ] = 4.06010237751526e-9 ; xx
[ 57 ] = 0.2255834686598589 ; pm_math_Quaternion_xform_ra ( xx + 34 , xx + 55
, xx + 58 ) ; xx [ 55 ] = 0.01351804099819887 - xx [ 58 ] ; xx [ 56 ] =
6.029877828280862e-8 - xx [ 59 ] ; xx [ 57 ] = - ( 0.05598922408200427 + xx [
60 ] ) ; pm_math_Matrix3x3_postCross_ra ( xx + 111 , xx + 55 , xx + 120 ) ;
xx [ 48 ] = 0.1142415350411276 ; xx [ 129 ] = xx [ 48 ] + xx [ 93 ] ; xx [
130 ] = xx [ 94 ] ; xx [ 131 ] = xx [ 95 ] ; xx [ 132 ] = xx [ 96 ] ; xx [
133 ] = xx [ 48 ] + xx [ 97 ] ; xx [ 134 ] = xx [ 98 ] ; xx [ 135 ] = xx [ 99
] ; xx [ 136 ] = xx [ 100 ] ; xx [ 137 ] = xx [ 48 ] + xx [ 101 ] ;
pm_math_Matrix3x3_composeTranspose_ra ( xx + 129 , xx + 38 , xx + 85 ) ;
pm_math_Matrix3x3_compose_ra ( xx + 38 , xx + 85 , xx + 138 ) ;
pm_math_Matrix3x3_postCross_ra ( xx + 138 , xx + 55 , xx + 38 ) ;
pm_math_Matrix3x3_preCross_ra ( xx + 38 , xx + 55 , xx + 85 ) ; xx [ 48 ] =
2.12453417776446e-4 ; xx [ 49 ] = 7.642506210728961e-5 ; xx [ 147 ] = xx [ 1
] + xx [ 76 ] - xx [ 120 ] - xx [ 120 ] - xx [ 85 ] ; xx [ 148 ] = xx [ 77 ]
- xx [ 121 ] - xx [ 123 ] - xx [ 86 ] ; xx [ 149 ] = xx [ 78 ] - xx [ 122 ] -
xx [ 126 ] - xx [ 87 ] ; xx [ 150 ] = xx [ 79 ] - xx [ 123 ] - xx [ 121 ] -
xx [ 88 ] ; xx [ 151 ] = xx [ 48 ] + xx [ 80 ] - xx [ 124 ] - xx [ 124 ] - xx
[ 89 ] ; xx [ 152 ] = xx [ 81 ] - xx [ 125 ] - xx [ 127 ] - xx [ 90 ] ; xx [
153 ] = xx [ 82 ] - xx [ 126 ] - xx [ 122 ] - xx [ 91 ] ; xx [ 154 ] = xx [
83 ] - xx [ 127 ] - xx [ 125 ] - xx [ 92 ] ; xx [ 155 ] = xx [ 49 ] + xx [ 84
] - xx [ 128 ] - xx [ 128 ] - xx [ 93 ] ;
pm_math_Matrix3x3_composeTranspose_ra ( xx + 147 , xx + 19 , xx + 76 ) ;
pm_math_Matrix3x3_compose_ra ( xx + 19 , xx + 76 , xx + 85 ) ; xx [ 76 ] = xx
[ 111 ] - xx [ 38 ] ; xx [ 77 ] = xx [ 112 ] - xx [ 41 ] ; xx [ 78 ] = xx [
113 ] - xx [ 44 ] ; xx [ 79 ] = xx [ 114 ] - xx [ 39 ] ; xx [ 80 ] = xx [ 115
] - xx [ 42 ] ; xx [ 81 ] = xx [ 116 ] - xx [ 45 ] ; xx [ 82 ] = xx [ 117 ] -
xx [ 40 ] ; xx [ 83 ] = xx [ 118 ] - xx [ 43 ] ; xx [ 84 ] = xx [ 119 ] - xx
[ 46 ] ; pm_math_Matrix3x3_composeTranspose_ra ( xx + 76 , xx + 19 , xx + 38
) ; pm_math_Matrix3x3_compose_ra ( xx + 19 , xx + 38 , xx + 111 ) ; xx [ 38 ]
= - 0.04082308587771714 ; xx [ 39 ] = 1.72520477372018e-7 ; xx [ 40 ] = -
0.02400881023584372 ; pm_math_Quaternion_xform_ra ( xx + 15 , xx + 38 , xx +
41 ) ; xx [ 38 ] = 9.268507096993006e-3 - xx [ 41 ] ; xx [ 39 ] =
2.546368536373208e-7 - xx [ 42 ] ; xx [ 40 ] = 0.1069153331754183 - xx [ 43 ]
; pm_math_Matrix3x3_postCross_ra ( xx + 111 , xx + 38 , xx + 120 ) ; xx [ 41
] = 0.1201463090066361 ; xx [ 156 ] = xx [ 41 ] + xx [ 138 ] ; xx [ 157 ] =
xx [ 139 ] ; xx [ 158 ] = xx [ 140 ] ; xx [ 159 ] = xx [ 141 ] ; xx [ 160 ] =
xx [ 41 ] + xx [ 142 ] ; xx [ 161 ] = xx [ 143 ] ; xx [ 162 ] = xx [ 144 ] ;
xx [ 163 ] = xx [ 145 ] ; xx [ 164 ] = xx [ 41 ] + xx [ 146 ] ;
pm_math_Matrix3x3_composeTranspose_ra ( xx + 156 , xx + 19 , xx + 138 ) ;
pm_math_Matrix3x3_compose_ra ( xx + 19 , xx + 138 , xx + 165 ) ;
pm_math_Matrix3x3_postCross_ra ( xx + 165 , xx + 38 , xx + 19 ) ;
pm_math_Matrix3x3_preCross_ra ( xx + 19 , xx + 38 , xx + 138 ) ; xx [ 41 ] =
7.908443756518444e-4 ; xx [ 42 ] = 3.014114311819444e-4 ; xx [ 174 ] = xx [ 0
] + xx [ 85 ] - xx [ 120 ] - xx [ 120 ] - xx [ 138 ] ; xx [ 175 ] = xx [ 86 ]
- xx [ 121 ] - xx [ 123 ] - xx [ 139 ] ; xx [ 176 ] = xx [ 87 ] - xx [ 122 ]
- xx [ 126 ] - xx [ 140 ] ; xx [ 177 ] = xx [ 88 ] - xx [ 123 ] - xx [ 121 ]
- xx [ 141 ] ; xx [ 178 ] = xx [ 41 ] + xx [ 89 ] - xx [ 124 ] - xx [ 124 ] -
xx [ 142 ] ; xx [ 179 ] = xx [ 90 ] - xx [ 125 ] - xx [ 127 ] - xx [ 143 ] ;
xx [ 180 ] = xx [ 91 ] - xx [ 126 ] - xx [ 122 ] - xx [ 144 ] ; xx [ 181 ] =
xx [ 92 ] - xx [ 127 ] - xx [ 125 ] - xx [ 145 ] ; xx [ 182 ] = xx [ 42 ] +
xx [ 93 ] - xx [ 128 ] - xx [ 128 ] - xx [ 146 ] ; xx [ 43 ] =
0.9879205634564509 ; xx [ 44 ] = 1.884654521777662e-6 ; xx [ 45 ] =
0.1549611573793158 ; xx [ 58 ] = - xx [ 43 ] ; xx [ 59 ] = - xx [ 44 ] ; xx [
60 ] = xx [ 45 ] ; pm_math_Matrix3x3_xform_ra ( xx + 174 , xx + 58 , xx + 61
) ; xx [ 85 ] = xx [ 111 ] - xx [ 19 ] ; xx [ 86 ] = xx [ 112 ] - xx [ 22 ] ;
xx [ 87 ] = xx [ 113 ] - xx [ 25 ] ; xx [ 88 ] = xx [ 114 ] - xx [ 20 ] ; xx
[ 89 ] = xx [ 115 ] - xx [ 23 ] ; xx [ 90 ] = xx [ 116 ] - xx [ 26 ] ; xx [
91 ] = xx [ 117 ] - xx [ 21 ] ; xx [ 92 ] = xx [ 118 ] - xx [ 24 ] ; xx [ 93
] = xx [ 119 ] - xx [ 27 ] ; xx [ 19 ] = 4.702340446561146e-8 ; xx [ 20 ] =
0.02258527288138155 ; xx [ 21 ] = 2.510275245497444e-8 ; xx [ 22 ] = - xx [
19 ] ; xx [ 23 ] = xx [ 20 ] ; xx [ 24 ] = - xx [ 21 ] ;
pm_math_Matrix3x3_xform_ra ( xx + 85 , xx + 22 , xx + 25 ) ; xx [ 94 ] = xx [
61 ] + xx [ 25 ] ; xx [ 95 ] = xx [ 62 ] + xx [ 26 ] ; xx [ 96 ] = xx [ 63 ]
+ xx [ 27 ] ; xx [ 61 ] = - 0.07746793516837766 ; xx [ 62 ] =
0.07960137041752086 ; xx [ 63 ] = - 0.9937926467205985 ; xx [ 64 ] = -
6.206139900867214e-3 ; xx [ 25 ] = xx [ 5 ] * input [ 0 ] ; xx [ 26 ] = sin (
xx [ 25 ] ) ; xx [ 97 ] = cos ( xx [ 25 ] ) ; xx [ 98 ] = - ( xx [ 43 ] * xx
[ 26 ] ) ; xx [ 99 ] = - ( xx [ 44 ] * xx [ 26 ] ) ; xx [ 100 ] = xx [ 45 ] *
xx [ 26 ] ; pm_math_Quaternion_compose_ra ( xx + 61 , xx + 97 , xx + 111 ) ;
xx [ 25 ] = 0.1591742062418632 ; xx [ 26 ] = 0.987250511292612 ; xx [ 27 ] =
4.444124194868948e-6 ; xx [ 61 ] = - ( xx [ 25 ] * inputDdot [ 1 ] ) ; xx [
62 ] = xx [ 26 ] * inputDdot [ 1 ] ; xx [ 63 ] = xx [ 27 ] * inputDdot [ 1 ]
; pm_math_Quaternion_inverseXform_ra ( xx + 111 , xx + 61 , xx + 97 ) ; xx [
115 ] = - ( xx [ 25 ] * inputDot [ 1 ] ) ; xx [ 116 ] = xx [ 26 ] * inputDot
[ 1 ] ; xx [ 117 ] = xx [ 27 ] * inputDot [ 1 ] ;
pm_math_Quaternion_inverseXform_ra ( xx + 111 , xx + 115 , xx + 118 ) ; xx [
46 ] = xx [ 43 ] * inputDot [ 0 ] ; xx [ 64 ] = xx [ 44 ] * inputDot [ 0 ] ;
xx [ 65 ] = xx [ 45 ] * inputDot [ 0 ] ; xx [ 121 ] = - xx [ 46 ] ; xx [ 122
] = - xx [ 64 ] ; xx [ 123 ] = xx [ 65 ] ; pm_math_Vector3_cross_ra ( xx +
118 , xx + 121 , xx + 124 ) ; xx [ 100 ] = xx [ 124 ] - xx [ 43 ] * inputDdot
[ 0 ] ; xx [ 43 ] = xx [ 125 ] - xx [ 44 ] * inputDdot [ 0 ] ; xx [ 44 ] = xx
[ 126 ] + xx [ 45 ] * inputDdot [ 0 ] ; xx [ 121 ] = xx [ 97 ] + xx [ 100 ] ;
xx [ 122 ] = xx [ 98 ] + xx [ 43 ] ; xx [ 123 ] = xx [ 99 ] + xx [ 44 ] ;
pm_math_Matrix3x3_transposeXform_ra ( xx + 85 , xx + 58 , xx + 97 ) ; xx [ 45
] = 0.3575354053670361 ; xx [ 138 ] = xx [ 45 ] + xx [ 165 ] ; xx [ 139 ] =
xx [ 166 ] ; xx [ 140 ] = xx [ 167 ] ; xx [ 141 ] = xx [ 168 ] ; xx [ 142 ] =
xx [ 45 ] + xx [ 169 ] ; xx [ 143 ] = xx [ 170 ] ; xx [ 144 ] = xx [ 171 ] ;
xx [ 145 ] = xx [ 172 ] ; xx [ 146 ] = xx [ 45 ] + xx [ 173 ] ;
pm_math_Matrix3x3_xform_ra ( xx + 138 , xx + 22 , xx + 124 ) ; xx [ 165 ] =
xx [ 97 ] + xx [ 124 ] ; xx [ 166 ] = xx [ 98 ] + xx [ 125 ] ; xx [ 167 ] =
xx [ 99 ] + xx [ 126 ] ; xx [ 124 ] = - 0.9968075318968037 ; xx [ 125 ] =
2.255609827694904e-6 ; xx [ 126 ] = - 3.299863329253583e-7 ; xx [ 127 ] =
0.07984199614617948 ; xx [ 45 ] = xx [ 5 ] * input [ 1 ] ; xx [ 5 ] = sin (
xx [ 45 ] ) ; xx [ 168 ] = cos ( xx [ 45 ] ) ; xx [ 169 ] = - ( xx [ 25 ] *
xx [ 5 ] ) ; xx [ 170 ] = xx [ 26 ] * xx [ 5 ] ; xx [ 171 ] = xx [ 27 ] * xx
[ 5 ] ; pm_math_Quaternion_compose_ra ( xx + 124 , xx + 168 , xx + 183 ) ; xx
[ 5 ] = 9.806649999999999 ; xx [ 45 ] = xx [ 5 ] * xx [ 186 ] ; xx [ 97 ] =
xx [ 5 ] * xx [ 184 ] ; xx [ 98 ] = 5.606377336525179e-8 ; xx [ 99 ] =
5.285391950416306e-8 ; xx [ 101 ] = 9.733335643479122e-3 ; xx [ 124 ] = xx [
98 ] * inputDot [ 1 ] ; xx [ 125 ] = xx [ 99 ] * inputDot [ 1 ] ; xx [ 126 ]
= - ( xx [ 101 ] * inputDot [ 1 ] ) ; pm_math_Vector3_cross_ra ( xx + 115 ,
xx + 124 , xx + 168 ) ; xx [ 124 ] = ( xx [ 183 ] * xx [ 45 ] + xx [ 185 ] *
xx [ 97 ] ) * xx [ 2 ] + xx [ 168 ] + xx [ 98 ] * inputDdot [ 1 ] ; xx [ 125
] = 0.1877774726328889 ; xx [ 126 ] = 3.328131052158979e-7 ; xx [ 127 ] = -
0.05231542826632854 ; pm_math_Quaternion_xform_ra ( xx + 111 , xx + 125 , xx
+ 171 ) ; xx [ 125 ] = - ( 0.05342718524467881 + xx [ 171 ] ) ; xx [ 126 ] =
0.0189206554113088 - xx [ 172 ] ; xx [ 127 ] = 1.632253786240014e-8 - xx [
173 ] ; pm_math_Vector3_cross_ra ( xx + 61 , xx + 125 , xx + 171 ) ; xx [ 128
] = xx [ 5 ] - ( xx [ 186 ] * xx [ 45 ] + xx [ 184 ] * xx [ 97 ] ) * xx [ 2 ]
+ xx [ 169 ] + xx [ 99 ] * inputDdot [ 1 ] ; xx [ 5 ] = xx [ 2 ] * ( xx [ 185
] * xx [ 45 ] - xx [ 183 ] * xx [ 97 ] ) + xx [ 170 ] - xx [ 101 ] *
inputDdot [ 1 ] ; xx [ 168 ] = xx [ 124 ] + xx [ 171 ] ; xx [ 169 ] = xx [
128 ] + xx [ 172 ] ; xx [ 170 ] = xx [ 5 ] + xx [ 173 ] ;
pm_math_Quaternion_inverseXform_ra ( xx + 111 , xx + 168 , xx + 171 ) ; xx [
45 ] = xx [ 118 ] - xx [ 46 ] ; xx [ 46 ] = xx [ 119 ] - xx [ 64 ] ; xx [ 64
] = xx [ 120 ] + xx [ 65 ] ; xx [ 168 ] = xx [ 118 ] + xx [ 45 ] ; xx [ 169 ]
= xx [ 119 ] + xx [ 46 ] ; xx [ 170 ] = xx [ 120 ] + xx [ 64 ] ; xx [ 118 ] =
- ( xx [ 19 ] * inputDot [ 0 ] ) ; xx [ 119 ] = xx [ 20 ] * inputDot [ 0 ] ;
xx [ 120 ] = - ( xx [ 21 ] * inputDot [ 0 ] ) ; pm_math_Vector3_cross_ra ( xx
+ 168 , xx + 118 , xx + 183 ) ; pm_math_Vector3_cross_ra ( xx + 115 , xx +
125 , xx + 118 ) ; pm_math_Vector3_cross_ra ( xx + 115 , xx + 118 , xx + 168
) ; pm_math_Quaternion_inverseXform_ra ( xx + 111 , xx + 168 , xx + 118 ) ;
xx [ 65 ] = xx [ 183 ] + xx [ 118 ] - xx [ 19 ] * inputDdot [ 0 ] ; xx [ 19 ]
= xx [ 171 ] + xx [ 65 ] ; xx [ 97 ] = xx [ 184 ] + xx [ 119 ] + xx [ 20 ] *
inputDdot [ 0 ] ; xx [ 20 ] = xx [ 172 ] + xx [ 97 ] ; xx [ 118 ] = xx [ 185
] + xx [ 120 ] - xx [ 21 ] * inputDdot [ 0 ] ; xx [ 21 ] = xx [ 173 ] + xx [
118 ] ; xx [ 168 ] = xx [ 45 ] ; xx [ 169 ] = xx [ 46 ] ; xx [ 170 ] = xx [
64 ] ; xx [ 171 ] = xx [ 45 ] * xx [ 0 ] ; xx [ 172 ] = xx [ 46 ] * xx [ 41 ]
; xx [ 173 ] = xx [ 64 ] * xx [ 42 ] ; pm_math_Vector3_cross_ra ( xx + 168 ,
xx + 171 , xx + 183 ) ; pm_math_Quaternion_inverseXform_ra ( xx + 15 , xx +
168 , xx + 171 ) ; xx [ 0 ] = xx [ 7 ] * inputDot [ 2 ] ; xx [ 41 ] = xx [
171 ] - xx [ 0 ] ; xx [ 42 ] = xx [ 9 ] * inputDot [ 2 ] ; xx [ 45 ] = xx [
172 ] + xx [ 42 ] ; xx [ 46 ] = xx [ 10 ] * inputDot [ 2 ] ; xx [ 64 ] = xx [
173 ] - xx [ 46 ] ; xx [ 186 ] = xx [ 41 ] ; xx [ 187 ] = xx [ 45 ] ; xx [
188 ] = xx [ 64 ] ; xx [ 189 ] = xx [ 41 ] * xx [ 1 ] ; xx [ 190 ] = xx [ 45
] * xx [ 48 ] ; xx [ 191 ] = xx [ 64 ] * xx [ 49 ] ; pm_math_Vector3_cross_ra
( xx + 186 , xx + 189 , xx + 192 ) ; pm_math_Quaternion_inverseXform_ra ( xx
+ 34 , xx + 186 , xx + 189 ) ; xx [ 1 ] = xx [ 6 ] * inputDot [ 3 ] ; xx [ 48
] = xx [ 189 ] + xx [ 1 ] ; xx [ 49 ] = xx [ 28 ] * inputDot [ 3 ] ; xx [ 119
] = xx [ 190 ] - xx [ 49 ] ; xx [ 120 ] = xx [ 29 ] * inputDot [ 3 ] ; xx [
195 ] = xx [ 191 ] - xx [ 120 ] ; xx [ 196 ] = xx [ 48 ] ; xx [ 197 ] = xx [
119 ] ; xx [ 198 ] = xx [ 195 ] ; xx [ 199 ] = xx [ 48 ] * xx [ 4 ] ; xx [
200 ] = xx [ 119 ] * xx [ 14 ] ; xx [ 201 ] = xx [ 195 ] * xx [ 31 ] ;
pm_math_Vector3_cross_ra ( xx + 196 , xx + 199 , xx + 202 ) ;
pm_math_Quaternion_inverseXform_ra ( xx + 51 , xx + 196 , xx + 199 ) ; xx [ 4
] = xx [ 30 ] * inputDot [ 4 ] ; xx [ 14 ] = xx [ 199 ] + xx [ 4 ] ; xx [ 31
] = xx [ 32 ] * inputDot [ 4 ] ; xx [ 205 ] = xx [ 200 ] + xx [ 31 ] ; xx [
206 ] = xx [ 33 ] * inputDot [ 4 ] ; xx [ 207 ] = xx [ 201 ] - xx [ 206 ] ;
xx [ 208 ] = xx [ 14 ] ; xx [ 209 ] = xx [ 205 ] ; xx [ 210 ] = xx [ 207 ] ;
xx [ 211 ] = xx [ 14 ] * xx [ 8 ] ; xx [ 212 ] = xx [ 205 ] * xx [ 47 ] ; xx
[ 213 ] = xx [ 207 ] * xx [ 50 ] ; pm_math_Vector3_cross_ra ( xx + 208 , xx +
211 , xx + 214 ) ; xx [ 208 ] = xx [ 4 ] ; xx [ 209 ] = xx [ 31 ] ; xx [ 210
] = - xx [ 206 ] ; pm_math_Vector3_cross_ra ( xx + 199 , xx + 208 , xx + 211
) ; xx [ 208 ] = xx [ 214 ] + ( xx [ 211 ] + xx [ 30 ] * inputDdot [ 4 ] ) *
xx [ 8 ] ; xx [ 209 ] = xx [ 215 ] + ( xx [ 212 ] + xx [ 32 ] * inputDdot [ 4
] ) * xx [ 47 ] ; xx [ 210 ] = xx [ 216 ] + ( xx [ 213 ] - xx [ 33 ] *
inputDdot [ 4 ] ) * xx [ 50 ] ; pm_math_Quaternion_xform_ra ( xx + 51 , xx +
208 , xx + 30 ) ; xx [ 208 ] = xx [ 199 ] + xx [ 14 ] ; xx [ 209 ] = xx [ 200
] + xx [ 205 ] ; xx [ 210 ] = xx [ 201 ] + xx [ 207 ] ; xx [ 4 ] =
5.312246225899824e-7 ; xx [ 8 ] = 3.401666441947787e-5 ; xx [ 14 ] =
3.505689117640104e-9 ; xx [ 199 ] = - ( xx [ 4 ] * inputDot [ 4 ] ) ; xx [
200 ] = xx [ 8 ] * inputDot [ 4 ] ; xx [ 201 ] = - ( xx [ 14 ] * inputDot [ 4
] ) ; pm_math_Vector3_cross_ra ( xx + 208 , xx + 199 , xx + 205 ) ;
pm_math_Vector3_cross_ra ( xx + 196 , xx + 11 , xx + 199 ) ;
pm_math_Vector3_cross_ra ( xx + 196 , xx + 199 , xx + 208 ) ;
pm_math_Quaternion_inverseXform_ra ( xx + 51 , xx + 208 , xx + 196 ) ; xx [
199 ] = ( xx [ 205 ] + xx [ 196 ] - xx [ 4 ] * inputDdot [ 4 ] ) * xx [ 66 ]
; xx [ 200 ] = ( xx [ 206 ] + xx [ 197 ] + xx [ 8 ] * inputDdot [ 4 ] ) * xx
[ 66 ] ; xx [ 201 ] = ( xx [ 207 ] + xx [ 198 ] - xx [ 14 ] * inputDdot [ 4 ]
) * xx [ 66 ] ; pm_math_Quaternion_xform_ra ( xx + 51 , xx + 199 , xx + 196 )
; pm_math_Vector3_cross_ra ( xx + 11 , xx + 196 , xx + 50 ) ; xx [ 4 ] = xx [
202 ] + xx [ 30 ] + xx [ 50 ] ; xx [ 11 ] = xx [ 1 ] ; xx [ 12 ] = - xx [ 49
] ; xx [ 13 ] = - xx [ 120 ] ; pm_math_Vector3_cross_ra ( xx + 189 , xx + 11
, xx + 199 ) ; xx [ 1 ] = xx [ 199 ] + xx [ 6 ] * inputDdot [ 3 ] ; xx [ 8 ]
= xx [ 200 ] - xx [ 28 ] * inputDdot [ 3 ] ; xx [ 11 ] = xx [ 201 ] - xx [ 29
] * inputDdot [ 3 ] ; xx [ 12 ] = xx [ 1 ] ; xx [ 13 ] = xx [ 8 ] ; xx [ 14 ]
= xx [ 11 ] ; pm_math_Matrix3x3_xform_ra ( xx + 102 , xx + 12 , xx + 199 ) ;
xx [ 205 ] = xx [ 189 ] + xx [ 48 ] ; xx [ 206 ] = xx [ 190 ] + xx [ 119 ] ;
xx [ 207 ] = xx [ 191 ] + xx [ 195 ] ; xx [ 33 ] = 3.389024974876639e-9 ; xx
[ 47 ] = 7.029487378004986e-3 ; xx [ 48 ] = 1.805980017846517e-10 ; xx [ 189
] = xx [ 33 ] * inputDot [ 3 ] ; xx [ 190 ] = xx [ 47 ] * inputDot [ 3 ] ; xx
[ 191 ] = xx [ 48 ] * inputDot [ 3 ] ; pm_math_Vector3_cross_ra ( xx + 205 ,
xx + 189 , xx + 208 ) ; pm_math_Vector3_cross_ra ( xx + 186 , xx + 55 , xx +
189 ) ; pm_math_Vector3_cross_ra ( xx + 186 , xx + 189 , xx + 205 ) ;
pm_math_Quaternion_inverseXform_ra ( xx + 34 , xx + 205 , xx + 186 ) ; xx [
49 ] = xx [ 208 ] + xx [ 186 ] + xx [ 33 ] * inputDdot [ 3 ] ; xx [ 53 ] = xx
[ 209 ] + xx [ 187 ] + xx [ 47 ] * inputDdot [ 3 ] ; xx [ 54 ] = xx [ 210 ] +
xx [ 188 ] + xx [ 48 ] * inputDdot [ 3 ] ; xx [ 186 ] = xx [ 49 ] ; xx [ 187
] = xx [ 53 ] ; xx [ 188 ] = xx [ 54 ] ; pm_math_Matrix3x3_xform_ra ( xx + 67
, xx + 186 , xx + 189 ) ; xx [ 66 ] = xx [ 203 ] + xx [ 31 ] + xx [ 51 ] ; xx
[ 30 ] = xx [ 204 ] + xx [ 32 ] + xx [ 52 ] ; xx [ 50 ] = xx [ 4 ] + xx [ 199
] + xx [ 189 ] ; xx [ 51 ] = xx [ 66 ] + xx [ 200 ] + xx [ 190 ] ; xx [ 52 ]
= xx [ 30 ] + xx [ 201 ] + xx [ 191 ] ; pm_math_Quaternion_xform_ra ( xx + 34
, xx + 50 , xx + 189 ) ; pm_math_Matrix3x3_transposeXform_ra ( xx + 67 , xx +
12 , xx + 50 ) ; pm_math_Matrix3x3_xform_ra ( xx + 129 , xx + 186 , xx + 12 )
; xx [ 186 ] = xx [ 196 ] + xx [ 50 ] + xx [ 12 ] ; xx [ 187 ] = xx [ 197 ] +
xx [ 51 ] + xx [ 13 ] ; xx [ 188 ] = xx [ 198 ] + xx [ 52 ] + xx [ 14 ] ;
pm_math_Quaternion_xform_ra ( xx + 34 , xx + 186 , xx + 12 ) ;
pm_math_Vector3_cross_ra ( xx + 55 , xx + 12 , xx + 50 ) ; xx [ 31 ] = xx [
192 ] + xx [ 189 ] + xx [ 50 ] ; xx [ 186 ] = - xx [ 0 ] ; xx [ 187 ] = xx [
42 ] ; xx [ 188 ] = - xx [ 46 ] ; pm_math_Vector3_cross_ra ( xx + 171 , xx +
186 , xx + 199 ) ; xx [ 0 ] = xx [ 199 ] - xx [ 7 ] * inputDdot [ 2 ] ; xx [
32 ] = xx [ 200 ] + xx [ 9 ] * inputDdot [ 2 ] ; xx [ 42 ] = xx [ 201 ] - xx
[ 10 ] * inputDdot [ 2 ] ; xx [ 186 ] = xx [ 0 ] ; xx [ 187 ] = xx [ 32 ] ;
xx [ 188 ] = xx [ 42 ] ; pm_math_Matrix3x3_xform_ra ( xx + 147 , xx + 186 ,
xx + 199 ) ; xx [ 202 ] = xx [ 171 ] + xx [ 41 ] ; xx [ 203 ] = xx [ 172 ] +
xx [ 45 ] ; xx [ 204 ] = xx [ 173 ] + xx [ 64 ] ; xx [ 41 ] =
5.058796476951027e-8 ; xx [ 45 ] = 0.01881102714372797 ; xx [ 46 ] =
4.915406223534665e-8 ; xx [ 171 ] = xx [ 41 ] * inputDot [ 2 ] ; xx [ 172 ] =
xx [ 45 ] * inputDot [ 2 ] ; xx [ 173 ] = xx [ 46 ] * inputDot [ 2 ] ;
pm_math_Vector3_cross_ra ( xx + 202 , xx + 171 , xx + 205 ) ;
pm_math_Vector3_cross_ra ( xx + 168 , xx + 38 , xx + 171 ) ;
pm_math_Vector3_cross_ra ( xx + 168 , xx + 171 , xx + 202 ) ;
pm_math_Quaternion_inverseXform_ra ( xx + 15 , xx + 202 , xx + 168 ) ; xx [
64 ] = xx [ 205 ] + xx [ 168 ] + xx [ 41 ] * inputDdot [ 2 ] ; xx [ 119 ] =
xx [ 206 ] + xx [ 169 ] + xx [ 45 ] * inputDdot [ 2 ] ; xx [ 120 ] = xx [ 207
] + xx [ 170 ] + xx [ 46 ] * inputDdot [ 2 ] ; xx [ 168 ] = xx [ 64 ] ; xx [
169 ] = xx [ 119 ] ; xx [ 170 ] = xx [ 120 ] ; pm_math_Matrix3x3_xform_ra (
xx + 76 , xx + 168 , xx + 171 ) ; xx [ 195 ] = xx [ 193 ] + xx [ 190 ] + xx [
51 ] ; xx [ 50 ] = xx [ 194 ] + xx [ 191 ] + xx [ 52 ] ; xx [ 189 ] = xx [ 31
] + xx [ 199 ] + xx [ 171 ] ; xx [ 190 ] = xx [ 195 ] + xx [ 200 ] + xx [ 172
] ; xx [ 191 ] = xx [ 50 ] + xx [ 201 ] + xx [ 173 ] ;
pm_math_Quaternion_xform_ra ( xx + 15 , xx + 189 , xx + 171 ) ;
pm_math_Matrix3x3_transposeXform_ra ( xx + 76 , xx + 186 , xx + 189 ) ;
pm_math_Matrix3x3_xform_ra ( xx + 156 , xx + 168 , xx + 186 ) ; xx [ 168 ] =
xx [ 12 ] + xx [ 189 ] + xx [ 186 ] ; xx [ 169 ] = xx [ 13 ] + xx [ 190 ] +
xx [ 187 ] ; xx [ 170 ] = xx [ 14 ] + xx [ 191 ] + xx [ 188 ] ;
pm_math_Quaternion_xform_ra ( xx + 15 , xx + 168 , xx + 186 ) ;
pm_math_Vector3_cross_ra ( xx + 38 , xx + 186 , xx + 168 ) ; xx [ 51 ] = xx [
183 ] + xx [ 171 ] + xx [ 168 ] ; xx [ 52 ] = xx [ 184 ] + xx [ 172 ] + xx [
169 ] ; xx [ 168 ] = xx [ 185 ] + xx [ 173 ] + xx [ 170 ] ; xx [ 169 ] = xx [
51 ] ; xx [ 170 ] = xx [ 52 ] ; xx [ 171 ] = xx [ 168 ] ; xx [ 172 ] = xx [
111 ] * xx [ 111 ] ; xx [ 173 ] = xx [ 112 ] * xx [ 113 ] ; xx [ 183 ] = xx [
111 ] * xx [ 114 ] ; xx [ 184 ] = xx [ 112 ] * xx [ 114 ] ; xx [ 185 ] = xx [
111 ] * xx [ 113 ] ; xx [ 189 ] = xx [ 113 ] * xx [ 114 ] ; xx [ 190 ] = xx [
111 ] * xx [ 112 ] ; xx [ 199 ] = ( xx [ 172 ] + xx [ 112 ] * xx [ 112 ] ) *
xx [ 2 ] - xx [ 3 ] ; xx [ 200 ] = xx [ 2 ] * ( xx [ 173 ] - xx [ 183 ] ) ;
xx [ 201 ] = ( xx [ 184 ] + xx [ 185 ] ) * xx [ 2 ] ; xx [ 202 ] = ( xx [ 173
] + xx [ 183 ] ) * xx [ 2 ] ; xx [ 203 ] = ( xx [ 172 ] + xx [ 113 ] * xx [
113 ] ) * xx [ 2 ] - xx [ 3 ] ; xx [ 204 ] = xx [ 2 ] * ( xx [ 189 ] - xx [
190 ] ) ; xx [ 205 ] = xx [ 2 ] * ( xx [ 184 ] - xx [ 185 ] ) ; xx [ 206 ] =
( xx [ 189 ] + xx [ 190 ] ) * xx [ 2 ] ; xx [ 207 ] = ( xx [ 172 ] + xx [ 114
] * xx [ 114 ] ) * xx [ 2 ] - xx [ 3 ] ;
pm_math_Matrix3x3_composeTranspose_ra ( xx + 174 , xx + 199 , xx + 208 ) ;
pm_math_Matrix3x3_compose_ra ( xx + 199 , xx + 208 , xx + 217 ) ;
pm_math_Matrix3x3_composeTranspose_ra ( xx + 85 , xx + 199 , xx + 208 ) ;
pm_math_Matrix3x3_compose_ra ( xx + 199 , xx + 208 , xx + 226 ) ;
pm_math_Matrix3x3_postCross_ra ( xx + 226 , xx + 125 , xx + 208 ) ;
pm_math_Matrix3x3_composeTranspose_ra ( xx + 138 , xx + 199 , xx + 235 ) ;
pm_math_Matrix3x3_compose_ra ( xx + 199 , xx + 235 , xx + 244 ) ;
pm_math_Matrix3x3_postCross_ra ( xx + 244 , xx + 125 , xx + 199 ) ;
pm_math_Matrix3x3_preCross_ra ( xx + 199 , xx + 125 , xx + 235 ) ; xx [ 253 ]
= 9.372749152884289e-4 + xx [ 217 ] - xx [ 208 ] - xx [ 208 ] - xx [ 235 ] ;
xx [ 254 ] = xx [ 218 ] - xx [ 209 ] - xx [ 211 ] - xx [ 236 ] ; xx [ 255 ] =
xx [ 219 ] - xx [ 210 ] - xx [ 214 ] - xx [ 237 ] ; xx [ 256 ] = xx [ 220 ] -
xx [ 211 ] - xx [ 209 ] - xx [ 238 ] ; xx [ 257 ] = 4.570793547407612e-4 + xx
[ 221 ] - xx [ 212 ] - xx [ 212 ] - xx [ 239 ] ; xx [ 258 ] = xx [ 222 ] - xx
[ 213 ] - xx [ 215 ] - xx [ 240 ] ; xx [ 259 ] = xx [ 223 ] - xx [ 214 ] - xx
[ 210 ] - xx [ 241 ] ; xx [ 260 ] = xx [ 224 ] - xx [ 215 ] - xx [ 213 ] - xx
[ 242 ] ; xx [ 261 ] = 1.03350459079831e-3 + xx [ 225 ] - xx [ 216 ] - xx [
216 ] - xx [ 243 ] ; xx [ 183 ] = - xx [ 25 ] ; xx [ 184 ] = xx [ 26 ] ; xx [
185 ] = xx [ 27 ] ; pm_math_Matrix3x3_xform_ra ( xx + 253 , xx + 183 , xx +
25 ) ; xx [ 208 ] = xx [ 226 ] - xx [ 199 ] ; xx [ 209 ] = xx [ 227 ] - xx [
202 ] ; xx [ 210 ] = xx [ 228 ] - xx [ 205 ] ; xx [ 211 ] = xx [ 229 ] - xx [
200 ] ; xx [ 212 ] = xx [ 230 ] - xx [ 203 ] ; xx [ 213 ] = xx [ 231 ] - xx [
206 ] ; xx [ 214 ] = xx [ 232 ] - xx [ 201 ] ; xx [ 215 ] = xx [ 233 ] - xx [
204 ] ; xx [ 216 ] = xx [ 234 ] - xx [ 207 ] ; xx [ 189 ] = xx [ 98 ] ; xx [
190 ] = xx [ 99 ] ; xx [ 191 ] = - xx [ 101 ] ; pm_math_Matrix3x3_xform_ra (
xx + 208 , xx + 189 , xx + 192 ) ; xx [ 199 ] = xx [ 25 ] + xx [ 192 ] ; xx [
200 ] = xx [ 26 ] + xx [ 193 ] ; xx [ 201 ] = xx [ 27 ] + xx [ 194 ] ;
pm_math_Matrix3x3_transposeXform_ra ( xx + 208 , xx + 183 , xx + 25 ) ; xx [
2 ] = 0.2865190874487085 ; xx [ 202 ] = xx [ 2 ] + xx [ 244 ] ; xx [ 203 ] =
xx [ 245 ] ; xx [ 204 ] = xx [ 246 ] ; xx [ 205 ] = xx [ 247 ] ; xx [ 206 ] =
xx [ 2 ] + xx [ 248 ] ; xx [ 207 ] = xx [ 249 ] ; xx [ 208 ] = xx [ 250 ] ;
xx [ 209 ] = xx [ 251 ] ; xx [ 210 ] = xx [ 2 ] + xx [ 252 ] ;
pm_math_Matrix3x3_xform_ra ( xx + 202 , xx + 189 , xx + 192 ) ; xx [ 202 ] =
xx [ 25 ] + xx [ 192 ] ; xx [ 203 ] = xx [ 26 ] + xx [ 193 ] ; xx [ 204 ] =
xx [ 27 ] + xx [ 194 ] ; xx [ 25 ] = xx [ 124 ] ; xx [ 26 ] = xx [ 128 ] ; xx
[ 27 ] = xx [ 5 ] ; xx [ 192 ] = - ( 1.491899906714453e-4 * inputDot [ 1 ] )
; xx [ 193 ] = 4.512518266691137e-4 * inputDot [ 1 ] ; xx [ 194 ] =
4.593022757474903e-9 * inputDot [ 1 ] ; pm_math_Vector3_cross_ra ( xx + 115 ,
xx + 192 , xx + 205 ) ; xx [ 115 ] = xx [ 100 ] ; xx [ 116 ] = xx [ 43 ] ; xx
[ 117 ] = xx [ 44 ] ; pm_math_Matrix3x3_xform_ra ( xx + 174 , xx + 115 , xx +
98 ) ; xx [ 172 ] = xx [ 65 ] ; xx [ 173 ] = xx [ 97 ] ; xx [ 174 ] = xx [
118 ] ; pm_math_Matrix3x3_xform_ra ( xx + 85 , xx + 172 , xx + 175 ) ; xx [
178 ] = xx [ 51 ] + xx [ 98 ] + xx [ 175 ] ; xx [ 179 ] = xx [ 52 ] + xx [ 99
] + xx [ 176 ] ; xx [ 180 ] = xx [ 168 ] + xx [ 100 ] + xx [ 177 ] ;
pm_math_Quaternion_xform_ra ( xx + 111 , xx + 178 , xx + 97 ) ;
pm_math_Matrix3x3_transposeXform_ra ( xx + 85 , xx + 115 , xx + 175 ) ;
pm_math_Matrix3x3_xform_ra ( xx + 138 , xx + 172 , xx + 85 ) ; xx [ 88 ] = xx
[ 186 ] + xx [ 175 ] + xx [ 85 ] ; xx [ 89 ] = xx [ 187 ] + xx [ 176 ] + xx [
86 ] ; xx [ 90 ] = xx [ 188 ] + xx [ 177 ] + xx [ 87 ] ;
pm_math_Quaternion_xform_ra ( xx + 111 , xx + 88 , xx + 85 ) ;
pm_math_Vector3_cross_ra ( xx + 125 , xx + 85 , xx + 88 ) ; xx [ 91 ] = xx [
205 ] + xx [ 97 ] + xx [ 88 ] ; xx [ 92 ] = xx [ 206 ] + xx [ 98 ] + xx [ 89
] ; xx [ 93 ] = xx [ 207 ] + xx [ 99 ] + xx [ 90 ] ; xx [ 88 ] = - xx [ 7 ] ;
xx [ 89 ] = xx [ 9 ] ; xx [ 90 ] = - xx [ 10 ] ; pm_math_Matrix3x3_xform_ra (
xx + 147 , xx + 88 , xx + 97 ) ; xx [ 111 ] = xx [ 41 ] ; xx [ 112 ] = xx [
45 ] ; xx [ 113 ] = xx [ 46 ] ; pm_math_Matrix3x3_xform_ra ( xx + 76 , xx +
111 , xx + 43 ) ; xx [ 114 ] = xx [ 97 ] + xx [ 43 ] ; xx [ 115 ] = xx [ 98 ]
+ xx [ 44 ] ; xx [ 116 ] = xx [ 99 ] + xx [ 45 ] ;
pm_math_Quaternion_inverseXform_ra ( xx + 15 , xx + 121 , xx + 43 ) ; xx [ 97
] = xx [ 43 ] + xx [ 0 ] ; xx [ 98 ] = xx [ 44 ] + xx [ 32 ] ; xx [ 99 ] = xx
[ 45 ] + xx [ 42 ] ; pm_math_Matrix3x3_transposeXform_ra ( xx + 76 , xx + 88
, xx + 41 ) ; pm_math_Matrix3x3_xform_ra ( xx + 156 , xx + 111 , xx + 44 ) ;
xx [ 76 ] = xx [ 41 ] + xx [ 44 ] ; xx [ 77 ] = xx [ 42 ] + xx [ 45 ] ; xx [
78 ] = xx [ 43 ] + xx [ 46 ] ; pm_math_Vector3_cross_ra ( xx + 121 , xx + 38
, xx + 41 ) ; xx [ 38 ] = xx [ 19 ] + xx [ 41 ] ; xx [ 39 ] = xx [ 20 ] + xx
[ 42 ] ; xx [ 40 ] = xx [ 21 ] + xx [ 43 ] ;
pm_math_Quaternion_inverseXform_ra ( xx + 15 , xx + 38 , xx + 41 ) ; xx [ 0 ]
= xx [ 41 ] + xx [ 64 ] ; xx [ 2 ] = xx [ 42 ] + xx [ 119 ] ; xx [ 3 ] = xx [
43 ] + xx [ 120 ] ; xx [ 15 ] = xx [ 0 ] ; xx [ 16 ] = xx [ 2 ] ; xx [ 17 ] =
xx [ 3 ] ; xx [ 38 ] = xx [ 31 ] ; xx [ 39 ] = xx [ 195 ] ; xx [ 40 ] = xx [
50 ] ; xx [ 41 ] = xx [ 6 ] ; xx [ 42 ] = - xx [ 28 ] ; xx [ 43 ] = - xx [ 29
] ; pm_math_Matrix3x3_xform_ra ( xx + 102 , xx + 41 , xx + 5 ) ; xx [ 44 ] =
xx [ 33 ] ; xx [ 45 ] = xx [ 47 ] ; xx [ 46 ] = xx [ 48 ] ;
pm_math_Matrix3x3_xform_ra ( xx + 67 , xx + 44 , xx + 31 ) ; xx [ 50 ] = xx [
5 ] + xx [ 31 ] ; xx [ 51 ] = xx [ 6 ] + xx [ 32 ] ; xx [ 52 ] = xx [ 7 ] +
xx [ 33 ] ; pm_math_Quaternion_inverseXform_ra ( xx + 34 , xx + 97 , xx + 5 )
; xx [ 31 ] = xx [ 5 ] + xx [ 1 ] ; xx [ 32 ] = xx [ 6 ] + xx [ 8 ] ; xx [ 33
] = xx [ 7 ] + xx [ 11 ] ; pm_math_Matrix3x3_transposeXform_ra ( xx + 67 , xx
+ 41 , xx + 5 ) ; pm_math_Matrix3x3_xform_ra ( xx + 129 , xx + 44 , xx + 8 )
; xx [ 67 ] = xx [ 5 ] + xx [ 8 ] ; xx [ 68 ] = xx [ 6 ] + xx [ 9 ] ; xx [ 69
] = xx [ 7 ] + xx [ 10 ] ; pm_math_Vector3_cross_ra ( xx + 97 , xx + 55 , xx
+ 5 ) ; xx [ 8 ] = xx [ 0 ] + xx [ 5 ] ; xx [ 9 ] = xx [ 2 ] + xx [ 6 ] ; xx
[ 10 ] = xx [ 3 ] + xx [ 7 ] ; pm_math_Quaternion_inverseXform_ra ( xx + 34 ,
xx + 8 , xx + 0 ) ; xx [ 5 ] = xx [ 0 ] + xx [ 49 ] ; xx [ 6 ] = xx [ 1 ] +
xx [ 53 ] ; xx [ 7 ] = xx [ 2 ] + xx [ 54 ] ; xx [ 0 ] = xx [ 4 ] ; xx [ 1 ]
= xx [ 66 ] ; xx [ 2 ] = xx [ 30 ] ; output [ 0 ] = input [ 0 ] ; output [ 1
] = inputDot [ 0 ] ; output [ 2 ] = pm_math_Vector3_dot_ra ( xx + 94 , xx +
121 ) + pm_math_Vector3_dot_ra ( xx + 165 , xx + 19 ) +
pm_math_Vector3_dot_ra ( xx + 58 , xx + 169 ) + pm_math_Vector3_dot_ra ( xx +
22 , xx + 186 ) ; output [ 3 ] = input [ 1 ] ; output [ 4 ] = inputDot [ 1 ]
; output [ 5 ] = pm_math_Vector3_dot_ra ( xx + 199 , xx + 61 ) +
pm_math_Vector3_dot_ra ( xx + 202 , xx + 25 ) + pm_math_Vector3_dot_ra ( xx +
183 , xx + 91 ) + pm_math_Vector3_dot_ra ( xx + 189 , xx + 85 ) ; output [ 6
] = input [ 2 ] ; output [ 7 ] = inputDot [ 2 ] ; output [ 8 ] =
pm_math_Vector3_dot_ra ( xx + 114 , xx + 97 ) + pm_math_Vector3_dot_ra ( xx +
76 , xx + 15 ) + pm_math_Vector3_dot_ra ( xx + 88 , xx + 38 ) +
pm_math_Vector3_dot_ra ( xx + 111 , xx + 12 ) ; output [ 9 ] = input [ 3 ] ;
output [ 10 ] = inputDot [ 3 ] ; output [ 11 ] = pm_math_Vector3_dot_ra ( xx
+ 50 , xx + 31 ) + pm_math_Vector3_dot_ra ( xx + 67 , xx + 5 ) +
pm_math_Vector3_dot_ra ( xx + 41 , xx + 0 ) + pm_math_Vector3_dot_ra ( xx +
44 , xx + 196 ) ; return NULL ; }
