#ifndef __Jacobian_9d5357ce_1_h__
#define __Jacobian_9d5357ce_1_h__
#ifdef __cplusplus
extern "C" {
#endif
extern void Jacobian_9d5357ce_1_dae ( NeDae * * dae , const NeModelParameters
* modelParams , const NeSolverParameters * solverParams ) ;
#ifdef __cplusplus
}
#endif
#endif
